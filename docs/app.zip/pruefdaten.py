# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Fester Prüfdatensatz mit erfundenen Tagen (2023 bis 2025) und den von Hand nach den Zählregeln gerechneten Ergebnissen.
Er läuft als Test (tests/test_rechenwerte.py) und als Selbsttest in jeder Fassung der App (Web, Desktop, Android):

    python pruefdaten.py        rechnet in Wegwerf-Datenbanken und nennt jede Abweichung (Rückgabe 1)

Zwei Datensätze: A (2023 bis 2025, ohne Startwerte) und B (nur 2025, mit „Erfassung gültig ab“ 16.06.2025, Teilzeit je Tag,
Sonderurlaub und Kind krank). B braucht eine eigene Datenbank, weil Startwerte alle Tage davor (also fast ganz A) nicht mehr zählen ließen.
Alle Tage liegen in der Vergangenheit, damit kein Wert vom heutigen Datum abhängt. Es gelten die Voreinstellungen
(Bayern, 24.12. und 31.12. frei, Faschingsdienstag 4 Stunden, 40 Stunden Montag bis Freitag, Grenze 80 %).
Die Herleitung jedes erwarteten Werts steht im Test neben der Zahl."""
import os
import sys
import tempfile
from datetime import date, datetime

GLEITZEIT_START_MIN = 600                                   # Startstand des Gleitzeit-Kontos: +10:00

# (Datum, HO-Minuten, Büro-Minuten, Art, Notiz, Konto, Attest)
TAGE = [
    # Januar 2023: Vollzeit, Tag mit HO und Büro, Urlaub, Arbeit am Feiertag
    ("2023-01-02", 495, 0, "", "", 0, ""),                  # Mo, 8:15 HO (15 Minuten über dem Soll)
    ("2023-01-03", 0, 480, "", "", 0, ""),                  # Di, Büro
    ("2023-01-04", 240, 240, "", "", 0, ""),                # Mi, HO und Büro: zählt als Büro-Tag
    ("2023-01-05", 0, 0, "urlaub", "", 0, ""),              # Do, Erholungsurlaub
    ("2023-01-06", 120, 0, "", "", 0, ""),                  # Fr, Heilige Drei Könige: Arbeit am Feiertag geht aufs Freizeitkonto
    # Februar 2023: Krank ohne und mit Attest, Krank im Dienst, Faschingsdienstag
    ("2023-02-13", 0, 0, "krank", "", 0, ""),
    ("2023-02-14", 0, 0, "krank_attest", "", 0, "2023-02-14"),
    ("2023-02-15", 0, 180, "krank_dienst", "", 0, ""),      # zählt nicht als Krank, die 3 Stunden zählen als Büro, 5 Stunden werden aufgefüllt
    ("2023-02-21", 240, 0, "", "", 0, ""),                  # Faschingsdienstag, Soll 4 Stunden
    # März 2023: Gleittag, angesparter Urlaub aus dem ältesten Konto
    ("2023-03-17", 0, 0, "gleittag", "", 0, ""),
    ("2023-03-20", 0, 0, "angespart", "", 2021, ""),
    ("2023-03-21", 0, 0, "angespart", "", 2021, ""),
    # Juli 2023: Teilzeit 21 Stunden an Mo, Di, Mi (Tagessoll 7:00)
    ("2023-07-03", 420, 0, "", "", 0, ""),
    ("2023-07-04", 0, 450, "", "", 0, ""),
    ("2023-07-06", 60, 0, "", "", 0, ""),                   # Do, kein Arbeitstag in der Teilzeit
    # Jahreswechsel 2023/2024
    ("2023-12-27", 420, 0, "", "", 0, ""),
    ("2023-12-31", 0, 120, "", "", 0, ""),                  # So und Silvester: Freizeitkonto
    ("2024-01-01", 60, 0, "", "", 0, ""),                   # Neujahr: Freizeitkonto
    ("2024-01-02", 0, 480, "", "", 0, ""),
    # Schaltjahr 2024, Freizeitausgleich
    ("2024-02-29", 510, 0, "", "", 0, ""),
    ("2024-03-01", 0, 0, "freizeit", "", 0, ""),
    # Urlaubswoche, Urlaub an einem Feiertag (zählt nicht)
    ("2024-08-05", 0, 0, "urlaub", "", 0, ""),
    ("2024-08-06", 0, 0, "urlaub", "", 0, ""),
    ("2024-08-07", 0, 0, "urlaub", "", 0, ""),
    ("2024-08-08", 0, 0, "urlaub", "", 0, ""),
    ("2024-08-09", 0, 0, "urlaub", "", 0, ""),
    ("2024-10-03", 0, 0, "urlaub", "", 0, ""),              # Tag der Dt. Einheit
    # Oktober 2024: angespart aus zwei Konten, 10 Stunden, Tag mit 0 Minuten (nur Notiz), Gleittag
    ("2024-10-07", 0, 0, "angespart", "", 2021, ""),
    ("2024-10-08", 0, 0, "angespart", "", 2023, ""),
    ("2024-10-09", 600, 0, "", "", 0, ""),
    ("2024-10-10", 0, 0, "", "nur eine Notiz", 0, ""),
    ("2024-10-11", 0, 0, "gleittag", "", 0, ""),
    # 2025: Übertrag von Hand, Monat über 80 %
    ("2025-01-13", 480, 0, "", "", 0, ""),
    ("2025-01-15", 360, 120, "", "", 0, ""),
    ("2025-05-02", 0, 0, "urlaub", "", 0, ""),
]
EIGENE_FREI_2023 = ["2023-05-19"]                           # Brückentag nach Christi Himmelfahrt
ABSCHNITTE = [("2023-06-01", "2023-06-30", 0.0, "elternzeit", "Mo,Di,Mi,Do,Fr"),
              ("2023-07-01", "2023-12-31", 21.0, "elternteilzeit", "Mo,Di,Mi")]
KONTEN = [(2021, 4), (2023, 2)]                             # angesparter Urlaub je Herkunftsjahr
UEBERTRAG_2025 = 10                                         # von Hand festgelegt (automatisch wären es 54)
STEMPEL_MITTERNACHT = (datetime(2025, 3, 10, 22, 0), datetime(2025, 3, 11, 1, 0))     # 3 Stunden über Mitternacht, gebucht auf den 10.03.


def befuellen(db) -> None:
    """Den Prüfdatensatz in eine leere Datenbank schreiben (über dieselben Wege wie die App)."""
    from daten import stempel
    from kern.regeln import Abschnitt
    for datum, ho, dst, art, notiz, konto, attest in TAGE:
        db.tag_setzen(date.fromisoformat(datum), ho, dst, art, notiz, konto, attest)
    db.jahr_setzen(2023, 30, [date.fromisoformat(d) for d in EIGENE_FREI_2023])
    for von, bis, stunden, art, tage in ABSCHNITTE:
        db.abschnitt_speichern(Abschnitt(date.fromisoformat(von), date.fromisoformat(bis), stunden, art, tage))
    for herkunft, tage in KONTEN:
        db.konto_setzen(herkunft, tage)
    db.uebertrag_setzen(2025, UEBERTRAG_2025)
    db.meta_setzen("gleitzeit_start_min", GLEITZEIT_START_MIN)
    beginn, ende = STEMPEL_MITTERNACHT
    stempel.start(db, "dst", beginn)
    stempel.stop(db, ende)


def _monat(db, j, m, *felder):
    """Monatswerte für die gewählten Felder (Text, Summe oder ein Kennzeichen des Monats: rot, vor_beginn) aus dem Monatsbericht."""
    from kern import bericht
    r = bericht.monat(db, j, m)
    return [r["text"][f] if f in r["text"] else (r[f] if f in MONAT_KENNZEICHEN else r["summe"][f]) for f in felder]


def _jahr(db, j, *felder):
    """Jahreswerte für die gewählten Felder aus dem Jahresbericht."""
    from kern import bericht
    r = bericht.jahr(db, j)
    return [r["text"][f] if f in r["text"] else (r["rot"] if f == "rot" else r["gesamt"][f]) for f in felder]


def _woche(db, j, kw):
    """Wochenwerte: Ist, Soll, Saldo und Freizeit der Woche."""
    from kern import bericht
    w = bericht.woche(db, j, kw)
    return [w["ist"], w["soll"], w["saldo_min"], w["freizeit_woche_min"]]


def _urlaub(db, j):
    """Urlaubswerte eines Jahres inklusive der angesparten Konten."""
    from kern import bericht
    u = bericht.urlaub_stand(db, j)
    return [u["anspruch"], u["uebertrag"], u["uebertrag_auto"], u["uebertrag_hand"], u["genommen"], u["rest"], u["gleittage"], u["gleittage_rest"],
            u["angespart_genommen_jahr"], [(k["herkunft"], k["tage"], k["genommen"], k["rest"], k["nutzbar"]) for k in u["konten"]], u["naechstes_konto"]]


def _krank(db, j):
    """Krankwerte eines Jahres: Zahlen und die Phasen."""
    from kern import bericht
    k = bericht.krank(db, j)
    return [k["kranktage"], k["attest"], k["ohne_attest"], k["im_dienst"], k["attest_fehlt"],
            [(p["von"], p["bis"], p["tage"], p["im_dienst"], p["attest"], p["status"]) for p in k["phasen"]]]


def _nachweis(db, j):
    """Werte der Homeoffice-Übersicht eines Jahres."""
    from kern import bericht
    s = bericht.steuer(db, j)
    return [s[f] for f in ("urlaub", "angespart", "gleittage", "krank", "krank_attest", "krank_dienst", "ho_tage", "dst_tage", "elternzeit_tage", "ho_stunden", "dst_stunden", "quote")]


def _konten(db, tag):
    """Gleitzeit-Konto, dessen Text und Freizeitkonto an einem Stichtag (ISO-Datum)."""
    from kern import woche
    d = date.fromisoformat(tag)
    return [woche.konto(db, d), woche.fmt_saldo(woche.konto(db, d)), woche.freizeit_konto(db, d)]


MONAT_KENNZEICHEN = ("rot", "vor_beginn")
MONAT_FELDER = ("ho", "dst", "ist", "quote", "rot", "ho_tage", "dst_tage", "soll_tage", "soll", "rest", "ueberschritten")
JAHR_FELDER = ("ho", "dst", "ist", "quote", "rot", "ho_tage", "dst_tage", "urlaub", "angespart", "gleittage", "krank", "krank_attest", "krank_dienst", "elternzeit_tage")

# (Name, Rechenweg, erwarteter Wert). Die Herleitung steht in tests/test_rechenwerte.py.
ERWARTET = [
    ("Monat 2023-01", lambda db: _monat(db, 2023, 1, *MONAT_FELDER), ["14:15", "12:00", "26:15", "54,29 %", False, 2, 2, 21, "160:00", "06:45", "00:00"]),
    ("Monat 2023-02", lambda db: _monat(db, 2023, 2, *MONAT_FELDER), ["04:00", "03:00", "12:00", "57,14 %", False, 1, 1, 20, "140:00", "01:36", "00:00"]),
    ("Monat 2023-02 aufgefüllt", lambda db: _monat(db, 2023, 2, "aufgefuellt", "ist_quote"), ["05:00", "07:00"]),
    ("Monat 2023-03", lambda db: _monat(db, 2023, 3, *MONAT_FELDER), ["00:00", "00:00", "00:00", "–", False, 0, 0, 23, "160:00", "00:00", "00:00"]),
    ("Monat 2023-05", lambda db: _monat(db, 2023, 5, "soll_tage", "soll"), [19, "152:00"]),
    ("Monat 2023-06", lambda db: _monat(db, 2023, 6, "soll_tage", "soll", "elternzeit_tage"), [0, "00:00", 21]),
    ("Monat 2023-07", lambda db: _monat(db, 2023, 7, *MONAT_FELDER), ["08:00", "07:30", "15:30", "51,61 %", False, 2, 1, 13, "91:00", "04:24", "00:00"]),
    ("Monat 2023-12", lambda db: _monat(db, 2023, 12, *MONAT_FELDER), ["07:00", "02:00", "09:00", "77,78 %", False, 1, 1, 10, "70:00", "00:12", "00:00"]),
    ("Monat 2024-01", lambda db: _monat(db, 2024, 1, *MONAT_FELDER), ["01:00", "08:00", "09:00", "11,11 %", False, 1, 1, 22, "176:00", "06:12", "00:00"]),
    ("Monat 2024-02", lambda db: _monat(db, 2024, 2, *MONAT_FELDER), ["08:30", "00:00", "08:30", "100,00 %", True, 1, 0, 21, "164:00", "00:00", "01:42"]),
    ("Monat 2024-03", lambda db: _monat(db, 2024, 3, "soll_tage", "soll"), [20, "152:00"]),
    ("Monat 2024-08", lambda db: _monat(db, 2024, 8, "urlaub"), [5]),
    ("Monat 2024-10", lambda db: _monat(db, 2024, 10, "ho", "quote", "ho_tage", "urlaub", "angespart", "gleittage", "soll_tage", "soll"), ["10:00", "100,00 %", 1, 0, 2, 1, 22, "152:00"]),
    ("Monat 2025-01", lambda db: _monat(db, 2025, 1, "ho", "dst", "quote", "rot", "ho_tage", "dst_tage", "ueberschritten"), ["14:00", "02:00", "87,50 %", True, 1, 1, "01:12"]),
    ("Monat 2025-03", lambda db: _monat(db, 2025, 3, "ho", "dst", "quote", "dst_tage"), ["00:00", "03:00", "0,00 %", 1]),
    ("Jahr 2023", lambda db: _jahr(db, 2023, *JAHR_FELDER), ["33:15", "24:30", "62:45", "57,58 %", False, 6, 5, 1, 2, 1, 2, 1, 1, 21]),
    ("Jahr 2024", lambda db: _jahr(db, 2024, *JAHR_FELDER), ["19:30", "08:00", "27:30", "70,91 %", False, 3, 1, 5, 2, 1, 0, 0, 0, 0]),
    ("Jahr 2025", lambda db: _jahr(db, 2025, *JAHR_FELDER, "rest"), ["14:00", "05:00", "19:00", "73,68 %", False, 1, 2, 1, 0, 0, 0, 0, 0, 0, "01:12"]),
    ("Urlaub 2023", lambda db: _urlaub(db, 2023), [30.0, 0.0, 0.0, False, 1, 29.0, 1, 19, 2, [(2021, 4.0, 3, 1.0, True), (2023, 2.0, 1, 1.0, True)], 2021]),
    ("Urlaub 2024", lambda db: _urlaub(db, 2024), [30.0, 29.0, 29.0, False, 5, 54.0, 1, 19, 2, [(2021, 4.0, 3, 1.0, True), (2023, 2.0, 1, 1.0, True)], 2021]),
    ("Urlaub 2025", lambda db: _urlaub(db, 2025), [30.0, 10.0, 54.0, True, 1, 39.0, 0, 20, 0, [(2021, 4.0, 3, 1.0, False), (2023, 2.0, 1, 1.0, True)], 2023]),
    ("Krank 2023", lambda db: _krank(db, 2023), [2, 1, 1, 1, 0, [("2023-02-13", "2023-02-15", 2, 1, "14.02.2023", "attest")]]),
    ("Nachweis 2023", lambda db: _nachweis(db, 2023), [1, 2, 1, 2, 1, 1, 6, 5, 21, "33:15", "24:30", "57,58 %"]),
    ("Woche 2023-01", lambda db: _woche(db, 2023, 1), ["24:15", "24:00", 15, 120]),
    ("Woche 2023-07", lambda db: _woche(db, 2023, 7), ["08:00", "24:00", -960, 0]),
    ("Woche 2023-08", lambda db: _woche(db, 2023, 8), ["04:00", "36:00", -1920, 0]),
    ("Woche 2023-11", lambda db: _woche(db, 2023, 11), ["00:00", "40:00", -2400, 0]),
    ("Woche 2023-12", lambda db: _woche(db, 2023, 12), ["00:00", "24:00", -1440, 0]),
    ("Woche 2023-27", lambda db: _woche(db, 2023, 27), ["15:30", "21:00", -330, 0]),
    ("Woche 2023-52", lambda db: _woche(db, 2023, 52), ["07:00", "07:00", 0, 120]),
    ("Woche 2024-01", lambda db: _woche(db, 2024, 1), ["08:00", "32:00", -1440, 60]),
    ("Woche 2024-09", lambda db: _woche(db, 2024, 9), ["08:30", "32:00", -1410, -480]),
    ("Woche 2024-41", lambda db: _woche(db, 2024, 41), ["10:00", "24:00", -840, 0]),
    ("Konten 2023-01-08", lambda db: _konten(db, "2023-01-08"), [615, "+10:15", 120]),
    ("Konten 2023-01-15", lambda db: _konten(db, "2023-01-15"), [-1785, "−29:45", 120]),
    ("Konten 2023-02-19", lambda db: _konten(db, "2023-02-19"), [-12345, "−205:45", 120]),
    ("Freizeitkonto 2023-12-31", lambda db: _konten(db, "2023-12-31")[2], 240),
    ("Freizeitkonto 2024-12-31", lambda db: _konten(db, "2024-12-31")[2], -180),
    ("Mitternacht 2025-03-10", lambda db: [(t.datum.isoformat(), t.ho, t.dst) for t in db.tage(2025) if t.datum.month == 3], [("2025-03-10", 0, 180)]),
]


# Datensatz B: „Erfassung gültig ab“ Mo 16.06.2025 mit dem Stand des Jahres bis zum Vortag (direkt geschrieben, ohne Einfrieren der Konten)
STARTWERTE_B = {"ab": "2025-06-16", "ho_min": 18000, "dst_min": 14400, "urlaub": 12, "gleittage": 3, "krank": 4, "kind_krank": 0,
                "gleitzeit_min": 750, "freizeit_min": 0}
# (von, bis, Wochenstunden, Art, Arbeitstage, Stunden je Tag): A1 Teilzeit je Tag (Weg 3), darin A2 nur mit Wochenstunden (Weg 1, Tage der Regeln)
ABSCHNITTE_B = [("2025-09-01", "2025-12-31", 18.0, "teilzeit", "Mo,Di,Mi", "Mo:480,Di:360,Mi:240"),
                ("2025-10-01", "2025-10-31", 30.0, "teilzeit", "", "")]
# (Datum, HO-Minuten, Büro-Minuten, Art)
TAGE_B = [
    ("2025-06-12", 240, 0, ""),                             # Do vor „ab“: gespeichert, zählt nicht
    ("2025-06-13", 0, 0, "urlaub"),                         # Fr vor „ab“: zählt nicht (der Urlaub davor steckt im Startwert 12)
    ("2025-06-16", 480, 0, ""),
    ("2025-06-17", 510, 0, ""),
    ("2025-06-18", 0, 480, ""),
    ("2025-06-20", 240, 240, ""),                           # Do 19.06. ist Fronleichnam
    ("2025-06-23", 0, 0, "kind_krank"),
    ("2025-06-24", 0, 0, "sonderurlaub_tag"),
    ("2025-06-25", 0, 120, "krank_dienst"),                 # 6 Stunden werden aufgefüllt
    ("2025-06-26", 480, 0, ""),
    ("2025-06-27", 0, 480, ""),
    ("2025-06-30", 480, 0, ""),
    ("2025-09-01", 500, 0, ""),                             # Mo, Soll 8 Stunden (A1)
    ("2025-09-02", 0, 360, ""),                             # Di, Soll 6 Stunden
    ("2025-09-03", 60, 0, "krank_dienst"),                  # Mi, Soll 4 Stunden: 3 Stunden aufgefüllt
    ("2025-09-04", 0, 0, "kind_krank"),                     # Do: kein Arbeitstag in A1, zählt nicht
    ("2025-09-11", 0, 0, "krank"),                          # Do: kein Arbeitstag, kein Kranktag
    ("2025-10-06", 360, 0, ""),                             # Oktober: A2, 30 Stunden Mo–Fr = 6 Stunden je Tag
    ("2025-11-03", 480, 0, ""),
    ("2025-11-04", 0, 120, ""),
]


def befuellen_b(db) -> None:
    """Datensatz B in eine leere Datenbank schreiben (Startwerte, zwei Abschnitte, Tage nur in 2025)."""
    from kern.regeln import Abschnitt
    db.startwerte_setzen(STARTWERTE_B, sichern=False)
    for von, bis, stunden, art, tage, je_tag in ABSCHNITTE_B:
        db.abschnitt_speichern(Abschnitt(date.fromisoformat(von), date.fromisoformat(bis), stunden, art, tage, tagesminuten=je_tag))
    for datum, ho, dst, art in TAGE_B:
        db.tag_setzen(date.fromisoformat(datum), ho, dst, art, "")


def _urlaub_b(db):
    """Urlaubswerte 2025 aus B wie _urlaub, dazu die Zähler Kind krank (mit Limit und Rest) und Sonderurlaub."""
    from kern import bericht
    u = bericht.urlaub_stand(db, 2025)
    return _urlaub(db, 2025) + [u[f] for f in ("kind_krank", "kind_krank_max", "kind_krank_rest", "sonderurlaub")]


def _krank_b(db):
    """Krankwerte 2025 aus B wie _krank, dazu der Startwert der Kranktage."""
    from kern import bericht
    return _krank(db, 2025) + [bericht.krank(db, 2025)["krank_start"]]


def _nachweis_b(db):
    """Werte der Homeoffice-Übersicht 2025 aus B wie _nachweis, dazu Sonderurlaub und Kind krank."""
    from kern import bericht
    s = bericht.steuer(db, 2025)
    return _nachweis(db, 2025) + [s["sonderurlaub"], s["kind_krank"]]


def _uebertrag_auto(db, j):
    """Automatisch berechneter Übertrag des Resturlaubs ins Jahr j."""
    from kern import bericht
    return bericht.urlaub_stand(db, j)["uebertrag_auto"]


ERWARTET_B = [
    ("B Monat 2025-05", lambda db: _monat(db, 2025, 5, *MONAT_FELDER, "vor_beginn"), ["00:00", "00:00", "00:00", "–", False, 0, 0, 0, "00:00", "00:00", "00:00", True]),
    ("B Monat 2025-06", lambda db: _monat(db, 2025, 6, *MONAT_FELDER, "aufgefuellt"), ["36:30", "22:00", "64:30", "62,39 %", False, 4, 4, 10, "64:00", "10:18", "00:00", "06:00"]),
    ("B Monat 2025-09", lambda db: _monat(db, 2025, 9, *MONAT_FELDER, "aufgefuellt"), ["09:20", "06:00", "18:20", "60,87 %", False, 2, 1, 14, "86:00", "02:56", "00:00", "03:00"]),
    ("B Monat 2025-10", lambda db: _monat(db, 2025, 10, "soll_tage", "soll", "ho"), [22, "132:00", "06:00"]),
    ("B Monat 2025-11", lambda db: _monat(db, 2025, 11, "ho", "dst", "quote", "rot", "rest", "soll_tage", "soll"), ["08:00", "02:00", "80,00 %", False, "00:00", 12, "72:00"]),
    ("B Jahr 2025", lambda db: _jahr(db, 2025, *JAHR_FELDER, "sonderurlaub", "kind_krank", "aufgefuellt", "rest"),
     ["359:50", "270:00", "638:50", "57,13 %", False, 8, 6, 12, 0, 3, 4, 0, 2, 0, 1, 1, "09:00", "144:02"]),
    ("B Urlaub 2025", _urlaub_b, [30.0, 0.0, 0.0, False, 12, 18.0, 3, 17, 0, [], None, 1, 15, 14, 1]),
    ("B Übertrag 2026 automatisch", lambda db: _uebertrag_auto(db, 2026), 18.0),
    ("B Krank 2025", _krank_b, [4, 0, 0, 2, 0, [("2025-09-11", "2025-09-11", 0, 0, "", "frei"), ("2025-09-03", "2025-09-03", 0, 1, "", "dienst"),
                                               ("2025-06-25", "2025-06-25", 0, 1, "", "dienst")], 4]),
    ("B Nachweis 2025", _nachweis_b, [12, 0, 3, 4, 0, 2, 8, 6, 0, "359:50", "270:00", "57,13 %", 1, 1]),
    ("B Woche 2025-25", lambda db: _woche(db, 2025, 25), ["32:30", "32:00", 30, 0]),
    ("B Woche 2025-26", lambda db: _woche(db, 2025, 26), ["24:00", "24:00", 0, 0]),
    ("B Woche 2025-36", lambda db: _woche(db, 2025, 36), ["18:20", "18:00", 20, 0]),
    ("B Konten 2025-06-15", lambda db: _konten(db, "2025-06-15"), [750, "+12:30", 0]),
    ("B Konten 2025-06-29", lambda db: _konten(db, "2025-06-29"), [780, "+13:00", 0]),
]


def anzahl() -> int:
    """Zahl aller Rechenwerte (Datensatz A und B), die der Selbsttest prüft."""
    return len(ERWARTET) + len(ERWARTET_B)


def abweichungen(db, erwartet=None) -> list:
    """Alle Stellen, an denen die App anders rechnet als erwartet: [(Name, erwartet, gerechnet)]. erwartet: Liste wie ERWARTET (Vorgabe: Datensatz A)."""
    return [(name, soll, ist) for name, rechnen, soll in (ERWARTET if erwartet is None else erwartet) for ist in [rechnen(db)] if ist != soll]


WEGWERF_PRAGMAS = ("PRAGMA synchronous=OFF", "PRAGMA journal_mode=MEMORY")   # kein fsync und keine Journal-Datei je Commit


def _wegwerf_db(pfad: str):
    """Datenbank für den Selbsttest, die ohne fsync und Journal-Datei schreibt: Sie wird danach gelöscht, ein Absturz kostet nichts.
    Das spart den größten Teil von „App prüfen“ (116 Commits), ohne dass sich befuellen ändert (db.gen steht im Golden Master)."""
    from daten.db import Db

    class WegwerfDb(Db):
        """Db, deren Verbindungen ohne Schutz vor Stromausfall schreiben."""
        def _c(self):
            """Neue Verbindung wie Db._c, mit WEGWERF_PRAGMAS."""
            ctx = super()._c()
            for pragma in WEGWERF_PRAGMAS:
                ctx.con.execute(pragma)
            return ctx
    return WegwerfDb(pfad)


def _rechnen(ordner: str, name: str, befuellen_mit, erwartet) -> list:
    """Einen Datensatz in einer eigenen Wegwerf-Datenbank im Ordner rechnen und seine Abweichungen liefern."""
    db = _wegwerf_db(os.path.join(ordner, name))
    befuellen_mit(db)
    return abweichungen(db, erwartet)


def selbsttest() -> list:
    """Datensatz A und B in je einer Wegwerf-Datenbank mit den Voreinstellungen rechnen, in einem eigenen Regelstand (konfig.eigener_stand):
    Die Regeln der laufenden App, auch die weitergereichten Werte eines neueren Geräts (konfig.UNBEKANNT), bleiben unberührt, und
    Anfragen in anderen Threads rechnen währenddessen weiter mit ihnen. Rückgabe: die Abweichungen beider Datensätze (leer = alles stimmt)."""
    from daten import konfig
    with konfig.eigener_stand(), tempfile.TemporaryDirectory() as ordner:
        return _rechnen(ordner, "pruef.db", befuellen, ERWARTET) + _rechnen(ordner, "pruef_b.db", befuellen_b, ERWARTET_B)

if __name__ == "__main__":
    funde = selbsttest()
    for name, soll, ist in funde:
        print(f"ABWEICHUNG {name}: erwartet {soll!r}, gerechnet {ist!r}")
    print(f"Prüfdatensatz: {anzahl()} Rechenwerte (A {len(ERWARTET)}, B {len(ERWARTET_B)}), {len(funde)} Abweichungen")
    sys.exit(1 if funde else 0)
