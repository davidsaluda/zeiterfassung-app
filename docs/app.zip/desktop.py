# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Starter der portablen Desktop-Fassung (Entwurf: DESKTOP.md). Doppelklick genügt: kein Admin-Recht, keine Anmeldung, keine Installation.

- Die App ist ein Ordner (Zeiterfassung.exe mit _internal, seit 22.11.2026; vorher eine Datei). Daten und Zugangsdaten liegen versteckt im Benutzerprofil
  (siehe datenordner), oder in HO_DATEN. Im Ordner der App entsteht nichts, ein Update ersetzt ihn ganz.
- Der Dienst lauscht nur auf 127.0.0.1, auf einem freien Port, und lässt nur diese Adresse zu (HO_HOSTS).
- Die Oberfläche öffnet sich als eigenes App-Fenster (pywebview mit der Web-Anzeige von Windows, WebView2;
  Wunsch vom 17.11.2026). Schließt die Person das Fenster, endet der Dienst. Gibt es diese Anzeige nicht, öffnet sich wie früher ein Fenster von Edge
  oder Chrome (mit eigenem Profil im Datenordner) oder ein gewöhnlicher Tab; beendet wird dann über „App beenden“ in der Fußzeile.
- Ein zweiter Start öffnet nur das Fenster der laufenden App (Sperrdatei statt Netzabfrage).
- Andere Programme auf dem Rechner kommen nicht an den Dienst: Je Start gilt ein Zugangsgeheimnis, das nur das eigene Fenster bekommt."""
import json
import os
import secrets
import shutil
import subprocess
import sys
import threading
import time
import webbrowser

if os.name == "nt":                                          # nur Windows; der Import darf anderswo (Server, Tests) nicht scheitern
    import msvcrt

LAEUFT = "laeuft.json"
SPERRE = "laeuft.sperre"
DATENBANK = "zeiterfassung.db"                              # nur ein Ordner „daten“ mit dieser Datei stammt von der App
ZEITSTEMPEL = "%Y-%m-%d_%H%M%S"
UMZUG_SPERRE = "Zeiterfassung.umzug.sperre"                 # neben dem Profil: Zwei gleichzeitige Starts ziehen nie zugleich um
PROTOKOLL = "protokoll.txt"
FENSTER_PROFIL = "fenster"
APP_PROFIL = "fenster-app"                                  # Speicher des eigenen App-Fensters (Cookies, Darstellung) im Datenordner
ZEIGEN = "zeigen"                                           # ein zweiter Start legt diese Datei an: Das laufende App-Fenster kommt nach vorn
# Was die App selbst in ihren Datenordner legt (hier, in server.py, daten/sicherung.py und daten/konfig.py). Nur ein Ordner allein mit solchen Namen zieht ins Profil um;
# hat er weitere, gehört er der Person (Windows unterscheidet „daten“ und „Daten“ nicht), und nichts darin wandert.
APP_NAMEN = frozenset(n + endung for n in (DATENBANK, "homeoffice.db", "demo.db") for endung in ("", "-wal", "-shm", "-journal")) | {
    "geraet.json", "geraet.json.teil", LAEUFT, SPERRE, PROTOKOLL, ZEIGEN, FENSTER_PROFIL, FENSTER_PROFIL + "-firefox", APP_PROFIL,
    "sicherung", "abgleich", "profile"}
TITEL = "Zeiterfassung"
MARKIERUNG = ":Zone.Identifier"                             # Stream, mit dem Windows Dateien aus dem Internet markiert (Mark of the Web)
NOTWEG = "Rechtsklick auf die Zip > Eigenschaften > Zulassen, danach neu entpacken"
# Erste Anzeige im App-Fenster, bis der Dienst antwortet (fester Text, keine Daten, kein Skript): WebView2 startet so parallel zum Dienst.
LADESEITE = ('<!doctype html><html lang="de"><head><meta charset="utf-8"><title>Zeiterfassung</title><style>:root{color-scheme:dark}'
             'body{margin:0;height:100vh;display:grid;place-items:center;font:1.1rem system-ui,sans-serif}</style></head>'
             '<body><p role="status">Zeiterfassung startet …</p></body></html>')
NUR_WINDOWS = "Die Desktop-Fassung gibt es nur für Windows. Auf anderen Systemen: die Web-App im Browser."
WEITERGEREICHT = 3.0                                        # endet der Browser-Prozess so schnell, hat ein schon laufender Browser das Fenster übernommen
# Browser für das Fenster der App: Name -> Stellen unter Windows (Umgebungsvariable, Rest des Pfads). Die Reihenfolge gilt, solange die Person nichts gewählt hat.
BROWSER = {
    "edge": (("ProgramFiles(x86)", "Microsoft/Edge/Application/msedge.exe"), ("ProgramFiles", "Microsoft/Edge/Application/msedge.exe")),
    "chrome": (("ProgramFiles", "Google/Chrome/Application/chrome.exe"), ("ProgramFiles(x86)", "Google/Chrome/Application/chrome.exe"),
               ("LOCALAPPDATA", "Google/Chrome/Application/chrome.exe")),
    "firefox": (("ProgramFiles", "Mozilla Firefox/firefox.exe"), ("ProgramFiles(x86)", "Mozilla Firefox/firefox.exe"),
                ("LOCALAPPDATA", "Mozilla Firefox/firefox.exe")),
}
# Firefox im eigenen Profil: keine Begrüßungsseiten, keine Frage nach dem Standardbrowser, keine Messdaten, Fenster ohne wiederhergestellte Sitzung
FIREFOX_EINSTELLUNG = "".join(f'user_pref("{k}", {v});\n' for k, v in (
    ("browser.shell.checkDefaultBrowser", "false"), ("browser.aboutwelcome.enabled", "false"), ("startup.homepage_welcome_url", '""'),
    ("startup.homepage_welcome_url.additional", '""'), ("browser.startup.homepage_override.mstone", '"ignore"'), ("browser.startup.page", "0"),
    ("datareporting.policy.dataSubmissionEnabled", "false"), ("datareporting.healthreport.uploadEnabled", "false"), ("toolkit.telemetry.enabled", "false"),
    ("toolkit.telemetry.reporting.policy.firstRun", "false"), ("browser.sessionstore.resume_from_crash", "false"), ("app.update.auto", "false"),
    ("browser.tabs.warnOnClose", "false"), ("browser.warnOnQuit", "false")))


def basis() -> str:
    """Der Ordner des Programms: bei der gebauten Fassung der Ordner der .exe, sonst der Projektordner über „app“."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def hat_datenbank(ordner: str) -> bool:
    """Liegt die Datenbank der App in diesem Ordner?"""
    return os.path.isfile(os.path.join(ordner, DATENBANK))


def mit_datenbank(*ordner: str) -> str:
    """Der erste der Ordner, in dem die Datenbank liegt, sonst der erste: So startet die App nie leer, solange es ihre Daten noch gibt."""
    return next((o for o in ordner if hat_datenbank(o)), ordner[0])


def alter_datenordner(ordner: str) -> bool:
    """Stammt der Ordner von den Fassungen 20261117.1201 bis .1422? Nur mit Datenbank und nur mit Namen aus APP_NAMEN (Schreibweise egal)."""
    try:
        namen = os.listdir(ordner)
    except OSError:
        return False
    return hat_datenbank(ordner) and all(n.lower() in APP_NAMEN for n in namen)


def umzug_offen(neben: str, profil: str) -> bool:
    """Gibt es etwas umzuziehen? Ein alter Datenordner neben der .exe, oder ein abgebrochener Umzug: Das Profil hat keine Datenbank, „.neu“ schon."""
    return alter_datenordner(neben) or (not hat_datenbank(profil) and hat_datenbank(profil + ".neu"))


def datenordner() -> str:
    """HO_DATEN, sonst bei der gebauten Fassung der versteckte Ordner im Benutzerprofil (%LOCALAPPDATA%\\Zeiterfassung).
    Daten und Zugangsdaten bleiben so am selben Ort, egal von wo die Datei startet (auch aus einem Download oder einem entpackten Zip), und niemand sieht sie neben der .exe.
    Den Ordner „daten“ neben der .exe (Fassungen 20261117.1201 bis .1422) zieht der erste Start ins Profil um (siehe umziehen), aber nur, wenn darin die
    Datenbank und sonst nur Dateien der App liegen. Ein Ordner „Daten“ der Person mit eigenen Dateien bleibt liegen; hat das Profil noch keine Datenbank,
    gilt er an Ort und Stelle wie in den alten Fassungen. Der Umzug läuft unter einer eigenen Sperre: Ein gleichzeitiger zweiter Start wartet und prüft neu.
    Bekommt er sie nicht, zieht er nicht um. Beim Arbeiten am Quelltext: „daten“ im Projektordner."""
    eigen = os.environ.get("HO_DATEN", "").strip()
    if eigen:
        return eigen
    neben = os.path.join(basis(), "daten")
    if not getattr(sys, "frozen", False):
        return neben
    wurzel = os.environ.get("LOCALAPPDATA", "").strip() or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    profil = os.path.join(wurzel, "Zeiterfassung")
    if not umzug_offen(neben, profil):
        return mit_datenbank(profil, neben)
    try:
        os.makedirs(wurzel, exist_ok=True)
        with open(os.path.join(wurzel, UMZUG_SPERRE), "a+b") as sperre:   # Schließen gibt die Sperre frei
            sperre.seek(0)
            msvcrt.locking(sperre.fileno(), msvcrt.LK_LOCK, 1)          # wartet bis etwa 10 s, bis ein gleichzeitiger Start fertig umgezogen ist
            return umziehen(neben, profil)
    except OSError:
        return mit_datenbank(profil, neben, profil + ".neu")


def umziehen(neben: str, profil: str) -> str:
    """Zieht unter der Umzugssperre den alten Datenordner ins Profil um und gibt den Datenordner für diesen Start zurück.
    Erst ganz nach „.neu“, dann umbenennen: Scheitert das Verschieben, ist im Profil nichts verändert. Ein älterer Stand im Profil bleibt als Reserve
    „-vor-umzug-<Zeit>“ liegen. Ein Rest „.neu“ eines abgebrochenen Umzugs wird fertig eingesetzt, wenn es keinen alten Ordner mehr gibt, sonst
    unter Zeitstempel beiseitegelegt (er kann die einzige Kopie sein). Scheitert ein Schritt (Datei gesperrt, etwa weil die App schon läuft), wird der
    Stand vor dem Versuch hergestellt, so weit das geht; zurück kommt dann der erste Ordner mit der Datenbank, und der nächste Start versucht es neu."""
    halb, zeit = profil + ".neu", time.strftime(ZEITSTEMPEL)
    if not umzug_offen(neben, profil):                       # erneut unter der Sperre: Ein gleichzeitiger Start kann inzwischen umgezogen sein
        return mit_datenbank(profil, neben)
    verschoben = alter_datenordner(neben)                    # sonst wird nur ein Rest „.neu“ fertig eingesetzt
    if verschoben:
        try:
            if os.path.exists(halb):
                os.rename(halb, f"{halb}-{zeit}")
            shutil.move(neben, halb)
        except OSError:
            return mit_datenbank(neben, halb, profil)
    reserve = f"{profil}-vor-umzug-{zeit}"
    try:
        if os.path.exists(profil):
            os.rename(profil, reserve)
        os.rename(halb, profil)
    except OSError:                                          # z. B. hält eine laufende App Dateien im Profil offen
        try:
            if os.path.isdir(reserve) and not os.path.exists(profil):
                os.rename(reserve, profil)
            if verschoben:                                   # nur zurück, was dieser Start verschoben hat: nie in einen Ordner „Daten“ der Person
                shutil.move(halb, neben)
        except OSError:                                      # auch der Rückweg scheitert (etwa ein Virenscanner hält Dateien offen)
            pass
        return mit_datenbank(neben, halb, profil, reserve)
    return profil


class Sperre:
    """Nur eine laufende App je Datenordner. Die Sperre hält das Betriebssystem; sie fällt weg, wenn der Prozess endet (auch nach einem Absturz)."""

    def __init__(self, daten: str):
        """Merkt den Pfad der Sperrdatei im Datenordner."""
        self.pfad, self.datei = os.path.join(daten, SPERRE), None

    def bekommen(self) -> bool:
        """Versucht, die Sperre zu bekommen. True, wenn die App sonst nicht läuft; False, wenn schon eine Instanz läuft."""
        datei = open(self.pfad, "a+b")
        try:
            datei.seek(0)
            msvcrt.locking(datei.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            datei.close()
            return False
        self.datei = datei
        return True

    def freigeben(self) -> None:
        """Gibt die Sperre frei (Datei schließen)."""
        if self.datei is not None:
            self.datei.close()                              # Schließen gibt die Sperre frei
            self.datei = None


def browser_vorhanden(umgebung=os.environ, vorhanden=os.path.isfile) -> dict:
    """Die installierten Browser: Name -> Pfad, in der Reihenfolge von BROWSER."""
    gefunden = {}
    for name, stellen in BROWSER.items():
        pfad = next((p for variable, rest in stellen if umgebung.get(variable) for p in [os.path.join(umgebung[variable], *rest.split("/"))] if vorhanden(p)), None)
        if pfad:
            gefunden[name] = pfad
    return gefunden


def browser_suchen(umgebung=os.environ, vorhanden=os.path.isfile, wahl: str = ""):
    """Pfad des gewählten Browsers, sonst des ersten vorhandenen (Edge, Chrome, Firefox), oder None."""
    gefunden = browser_vorhanden(umgebung, vorhanden)
    return gefunden.get(wahl) or next(iter(gefunden.values()), None)


def browser_wahl(daten: str) -> str:
    """Die Wahl der Person aus geraet.json („“ = noch keine, „standard“ = gewöhnlicher Tab im Standardbrowser)."""
    try:
        with open(os.path.join(daten, "geraet.json"), encoding="utf-8") as f:
            wahl = json.load(f).get("browser", "")
        return wahl if isinstance(wahl, str) else ""
    except (OSError, ValueError, AttributeError):
        return ""


def fenster_befehl(browser: str, adresse: str, daten: str) -> list:
    """Eigenes Fenster mit eigenem Profil: Der gestartete Prozess lebt genau so lange wie das Fenster, und die Darstellung wandert mit dem Ordner mit.
    Edge und Chrome zeigen ein Fenster ohne Adresszeile. Firefox kennt das nicht: Dort ist es ein gewöhnliches Fenster im eigenen Profil."""
    if os.path.basename(browser).lower().startswith("firefox"):
        profil = os.path.join(daten, FENSTER_PROFIL + "-firefox")
        os.makedirs(profil, exist_ok=True)
        with open(os.path.join(profil, "user.js"), "w", encoding="utf-8") as f:
            f.write(FIREFOX_EINSTELLUNG)
        # -wait-for-browser: Unter Windows startet sonst nur ein Starter, der sofort endet; so lebt der Prozess mit dem Fenster
        return [browser, "-no-remote", "-wait-for-browser", "-profile", profil, "-new-window", adresse, "-width", "1180", "-height", "860"]
    return [browser, f"--app={adresse}", f"--user-data-dir={os.path.join(daten, FENSTER_PROFIL)}", "--no-first-run", "--no-default-browser-check",
            "--disable-background-mode", "--disable-features=msEdgeStartupBoost,Translate", "--window-size=1180,860"]


def fenster_oeffnen(adresse: str, daten: str):
    """-> der Prozess des Fensters (endet mit dem Fenster) oder None, wenn nur ein gewöhnlicher Tab geöffnet werden konnte."""
    wahl = browser_wahl(daten)
    browser = None if wahl == "standard" else browser_suchen(wahl=wahl)
    if browser:
        try:
            return subprocess.Popen(fenster_befehl(browser, adresse, daten), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            pass
    webbrowser.open(adresse)
    return None


def markierung_entfernen(ordner: str) -> int:
    """Den Stream Zone.Identifier von allen Dateien unter ordner entfernen: .NET (pythonnet für das App-Fenster) lädt keine Assemblys,
    die als „aus dem Internet“ markiert sind. -> Zahl der entfernten Markierungen. Fehler (z. B. schreibgeschützter Ort) still, einmal gemeldet."""
    entfernt, gemeldet = 0, False
    for wurzel, _, dateien in os.walk(ordner):
        for name in dateien:
            try:
                os.remove(os.path.join(wurzel, name) + MARKIERUNG)
                entfernt += 1
            except FileNotFoundError:
                pass
            except OSError as e:
                if not gemeldet:
                    print(f"Markierung „aus dem Internet“ ließ sich nicht entfernen ({type(e).__name__}). Falls kein App-Fenster kommt: {NOTWEG}.",
                          flush=True)
                    gemeldet = True
    return entfernt


def eigene_markierung_entfernen() -> None:
    """Nur in der gebauten Fassung: die Markierung der eigenen Programmdateien (sys._MEIPASS, nie außerhalb) vor dem Laden der Anzeige entfernen."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        beginn = time.perf_counter()
        entfernt = markierung_entfernen(sys._MEIPASS)
        print(f"Markierung „aus dem Internet“: {entfernt} entfernt ({(time.perf_counter() - beginn) * 1000:.0f} ms)", flush=True)


def app_fenster_da() -> bool:
    """Gibt es das eigene App-Fenster (pywebview ist in der gebauten Datei, beim Arbeiten am Quelltext nur, wenn installiert)?"""
    try:
        import webview  # noqa: F401
        return True
    except Exception as e:                                   # auch ein Fehler beim Laden der Anzeige
        print(f"Kein eigenes App-Fenster ({type(e).__name__}: {e}), es öffnet sich der Browser", flush=True)
        return False


def app_fenster(adresse_holen, daten: str, halt: threading.Event) -> bool:
    """Das eigene App-Fenster zeigen und warten, bis es geschlossen ist. -> False, wenn es nicht geöffnet werden konnte (dann der Browser).
    Das Fenster öffnet sofort mit LADESEITE; adresse_holen() startet im Hintergrund den Dienst und liefert die Adresse, die das Fenster dann lädt.
    Scheitert adresse_holen, schließt sich das Fenster und der Fehler kommt hier heraus.
    „App beenden“ (halt) schließt das Fenster; ein zweiter Start (Datei ZEIGEN) holt es nach vorn."""
    try:
        import webview
        webview.settings["ALLOW_DOWNLOADS"] = True              # Exporte und Sicherungen speichern (fragt nach dem Ort)
        webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        fenster = webview.create_window(TITEL, html=LADESEITE, width=1180, height=860, min_size=(360, 520))
    except Exception as e:
        print(f"Kein eigenes App-Fenster ({type(e).__name__}: {e}), es öffnet sich der Browser", flush=True)
        return False
    gescheitert = []

    def wache():
        """Wächter im Hintergrund: startet den Dienst und lädt die App ins Fenster, holt es danach nach vorn, wenn ein zweiter Start
        die Datei „zeigen“ anlegt, und schließt es bei „App beenden“."""
        try:
            fenster.load_url(adresse_holen())
        except Exception as e:                                  # Dienst startet nicht: Fenster zu, der Fehler geht an lauf weiter
            gescheitert.append(e)
            halt.set()
        while not halt.wait(0.5):
            zeigen = os.path.join(daten, ZEIGEN)
            if os.path.exists(zeigen):
                try:
                    os.remove(zeigen)
                    fenster.restore()
                    fenster.show()
                except Exception:
                    pass
        try:
            fenster.destroy()                                   # „App beenden“; ist das Fenster schon zu, passiert nichts
        except Exception:
            pass

    try:
        webview.start(wache, private_mode=False, storage_path=os.path.join(daten, APP_PROFIL))
    except Exception as e:
        print(f"Das App-Fenster ließ sich nicht starten ({type(e).__name__}: {e}), es öffnet sich der Browser. "
              f"Stammt die Zip aus dem Internet: {NOTWEG}.", flush=True)
        return False
    if gescheitert:
        raise gescheitert[0]
    return True


def _protokoll(daten: str) -> None:
    """Die gebaute Fassung hat keine Konsole: Meldungen gehen in eine kleine Datei im Datenordner (bei jedem Start neu)."""
    if sys.stdout is None or sys.stderr is None:
        sys.stdout = sys.stderr = open(os.path.join(daten, PROTOKOLL), "w", encoding="utf-8", buffering=1)


def _laeuft_lesen(daten: str, feld: str = ""):
    """-> (Port, Zugangsgeheimnis) der laufenden App oder None. Mit feld: nur dieser Wert aus der Datei."""
    try:
        with open(os.path.join(daten, LAEUFT), encoding="utf-8") as f:
            d = json.load(f)
        if feld:
            return d.get(feld)
        port, zugang = d["port"], d["zugang"]
        return (port, zugang) if isinstance(port, int) and 0 < port < 65536 and isinstance(zugang, str) and zugang.isalnum() else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _laeuft_schreiben(daten: str, port: int, zugang: str, eigen: bool) -> None:
    """laeuft.json für den zweiten Start schreiben: Port, Prozess, Zugangsgeheimnis und ob das eigene App-Fenster offen ist (eigen).
    Wer diese Datei lesen darf, darf auch die Datenbank lesen."""
    # laeuft.json liegt im geschützten Datenordner (ordner_schuetzen); 0o600 schadet unter Windows nicht
    with os.fdopen(os.open(os.path.join(daten, LAEUFT), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as f:
        json.dump({"port": port, "pid": os.getpid(), "zugang": zugang, "app_fenster": eigen}, f)


def adresse(port: int, zugang: str) -> str:
    """Einstieg für das eigene Fenster: Der Dienst setzt daraufhin das Zugangs-Cookie und leitet auf / um."""
    return f"http://127.0.0.1:{port}/?z={zugang}"


def ordner_schuetzen(daten: str) -> None:
    """Datenordner anlegen und nur für die Person lesbar machen (unter Windows ab Python 3.13 über mode=0o700).
    makedirs verschärft einen vorhandenen oder umgezogenen Ordner nicht."""
    os.makedirs(daten, mode=0o700, exist_ok=True)


def lauf(daten: str, fenster=fenster_oeffnen, halt: threading.Event = None, bereit=None) -> int:
    """Die App starten und warten, bis das Fenster geschlossen oder „App beenden“ gewählt wird. bereit(port, zugang): Rückruf für Tests."""
    ordner_schuetzen(daten)
    _protokoll(daten)
    os.environ["HO_PLATTFORM"] = "desktop"
    sperre = Sperre(daten)
    if not sperre.bekommen():                               # läuft schon: nur das Fenster zeigen
        laeuft = _laeuft_lesen(daten)
        if laeuft and _laeuft_lesen(daten, "app_fenster"):
            open(os.path.join(daten, ZEIGEN), "w").close()   # das laufende App-Fenster holt sich selbst nach vorn
        elif laeuft:
            fenster(adresse(*laeuft), daten)
        return 0 if laeuft else 1
    halt = halt or threading.Event()
    eigene_markierung_entfernen()                           # vor dem ersten „import webview“ (lädt pythonnet)
    eigen = fenster is fenster_oeffnen and app_fenster_da()     # Tests geben ein eigenes „fenster“ mit und bekommen den Browser-Weg
    if eigen:
        os.environ["HO_FENSTER"] = "app"                    # der Dienst bietet dann keine Browser-Wahl an
    zugang = secrets.token_hex(32)                          # gilt nur für diesen Start
    dienst = {}                                             # httpd und port, sobald der Dienst läuft; ende, sobald lauf aufräumt
    start_sperre = threading.Lock()                         # das Aufräumen wartet auf einen laufenden Start (Fenster zu während des Starts)

    def starten() -> int:
        """Startet den Dienst genau einmal (im App-Fenster aus dessen Wächter, parallel zum Start der Anzeige) -> Port.
        Fehler: RuntimeError, wenn lauf schon aufräumt (sonst schriebe ein später Start laeuft.json mit einem toten Geheimnis)."""
        with start_sperre:
            return _starten()

    def _starten() -> int:
        """starten ohne Sperre."""
        if "ende" in dienst:
            raise RuntimeError("Die App wird beendet")
        if "port" not in dienst:
            import server                                   # erst hier: Der zweite Start bleibt schnell, und das Fenster wartet nicht auf die Importe
            dienst["httpd"], db = server.erstellen(daten, 0, "127.0.0.1", "127.0.0.1:{port},localhost:{port}", zugang)
            port = dienst["httpd"].server_address[1]
            dienst["httpd"].RequestHandlerClass.beenden = halt.set
            _laeuft_schreiben(daten, port, zugang, eigen)
            server.tagessicherung(db, daten)
            threading.Thread(target=dienst["httpd"].serve_forever, daemon=True).start()
            threading.Thread(target=server._lokale_automatik, args=(db, daten, halt), daemon=True).start()
            print(f"Zeiterfassung (Desktop) läuft auf Port {port}", flush=True)
            dienst["port"] = port
            if bereit:
                bereit(port, zugang)
        return dienst["port"]
    try:
        if eigen and app_fenster(lambda: adresse(starten(), zugang), daten, halt):
            halt.set()                                      # Fenster geschlossen oder „App beenden“: Wächter und Automatik enden, finally beendet den Dienst
            return 0
        os.environ.pop("HO_FENSTER", None)                  # kein App-Fenster möglich: wie bisher mit Browser-Wahl
        port = starten()
        if eigen:
            _laeuft_schreiben(daten, port, zugang, False)   # sonst hielte ein zweiter Start den Browser für das App-Fenster
        beginn = time.monotonic()
        prozess = fenster(adresse(port, zugang), daten)
        while not halt.is_set():
            if prozess is not None and prozess.poll() is not None:
                if time.monotonic() - beginn >= WEITERGEREICHT:
                    break                                   # die Person hat das Fenster geschlossen
                prozess = None                              # ein laufender Browser mit demselben Profil zeigt das Fenster: weiter, bis „App beenden“
            halt.wait(0.5)
        halt.set()
        if prozess is not None and prozess.poll() is None:
            prozess.terminate()                             # „App beenden“: auch das Fenster schließen, sonst bliebe ein totes Fenster stehen
        return 0
    finally:
        with start_sperre:
            dienst["ende"] = True
        if "port" in dienst:                                # nur ein laufender Dienst lässt sich beenden (shutdown wartet sonst ewig)
            dienst["httpd"].shutdown()
            dienst["httpd"].server_close()
        elif "httpd" in dienst:
            dienst["httpd"].server_close()
        try:
            os.remove(os.path.join(daten, LAEUFT))
        except OSError:
            pass
        sperre.freigeben()


if __name__ == "__main__":
    if os.name != "nt":                                     # sonst bräche die Sperre ohne msvcrt mit einem Traceback ab
        sys.exit(NUR_WINDOWS)
    sys.exit(lauf(datenordner()))
