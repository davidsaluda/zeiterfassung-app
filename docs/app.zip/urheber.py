# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Version, Urheberhinweis und Fußzeilentexte für App und Exportdateien (an einer Stelle pflegen)."""
VERSION = "20261126.1125"              # Version der Anwendung (JJJJMMTT.HHMM), echte Uhrzeit, setzt version_setzen.py
HINWEIS = "© 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic)."   # Kopfzeile jeder Skript-Datei (tests/test_urheber.py)
# Exporte nennen nur App und Version: © und KI-Hinweis stehen sichtbar nur in Hilfe und Datenschutz (Entscheidung des Entwicklers 24.11.2026)
FUSS = f"Zeiterfassung · Version {VERSION}"       # Seitenfuß von PDF, Word, Writer, Excel und Calc
VERMERK = f"Zeiterfassung Version {VERSION}"      # letzte Zeile von CSV und Tabellen
