# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Version, Urheberhinweis und Fußzeilentexte für App und Exportdateien (an einer Stelle pflegen)."""
VERSION = "20261123.0553"              # Version der Anwendung (JJJJMMTT.HHMM), echte Uhrzeit, setzt version_setzen.py
HINWEIS = "© 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic)."   # Kopfzeile jeder Skript-Datei (tests/test_urheber.py)
FUSS = f"Zeiterfassung · Version {VERSION} · © 2026 David Saluda · Erstellt mit Unterstützung von KI (Claude, Anthropic)"
VERMERK = f"Zeiterfassung Version {VERSION} · © 2026 David Saluda · Erstellt mit Unterstützung von KI (Claude, Anthropic)"
