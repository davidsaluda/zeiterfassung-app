# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Bündelt die Skripte und Stile der Oberfläche zu je einer Datei, damit eine Seite beim ersten Laden zwei Anfragen statt rund fünfzig stellt
(Tempo-Messung 22.11.2026). Die Liste und die Reihenfolge stehen nur in app/web/index.html (Festlegung B5); die Quellen bleiben einzeln.
Der Dienst (server.py: NAS, Desktop, Android) baut die Bündel beim Abruf, der Bau der Web-App ohne Server (web_bauen.py) legt sie als Dateien ab.
Die Dateien werden unverändert aneinandergehängt: Jedes Skript beginnt mit "use strict"; (Wächter), das Bündel also auch, und es gilt für alle."""
import re

# Die eine Dateiliste der Oberfläche ist index.html (Festlegung B5): web_bauen.py nutzt beide von hier, pruef_design.py und tests/webtext.py haben eine Kopie (test_eine_dateiliste_ein_ausdruck).
SKRIPT = re.compile(r'<script src="([A-Za-z0-9_./-]+\.js)"></script>')
STIL = re.compile(r'<link rel="stylesheet" href="([A-Za-z0-9_./-]+\.css)">')
BUENDEL_JS = "buendel.js"
BUENDEL_CSS = "buendel.css"
NAMEN = (BUENDEL_JS, BUENDEL_CSS)
URHEBER = "Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic)."
KOPF = {BUENDEL_JS: f'"use strict";\n// {URHEBER}\n', BUENDEL_CSS: f"/* {URHEBER} */\n"}
MARKE = {BUENDEL_JS: "// ---- {} ----\n", BUENDEL_CSS: "/* ---- {} ---- */\n"}      # Herkunft jeder Datei im Bündel, für die Fehlersuche
EINTRAG = {BUENDEL_JS: (SKRIPT, '<script src="{}"></script>'), BUENDEL_CSS: (STIL, '<link rel="stylesheet" href="{}">')}


def bestandteile(html: str) -> dict:
    """-> {Bündelname: Dateinamen aus index.html in Ladereihenfolge}."""
    return {name: muster.findall(html) for name, (muster, _) in EINTRAG.items()}


def sicherer_name(datei: str) -> str:
    """Der Name, wenn er im Ordner der Oberfläche bleibt (kein „..“, kein Pfad ab der Wurzel, keine leeren Teile); sonst ValueError."""
    if not datei or any(teil in ("", ".", "..") for teil in datei.split("/")):
        raise ValueError("Datei außerhalb der Oberfläche")
    return datei


def buendel(name: str, dateien: list, lesen) -> bytes:
    """-> das Bündel name (BUENDEL_JS oder BUENDEL_CSS): Urheberkopf, dann jede Datei unverändert mit ihrer Herkunft davor, in der Reihenfolge
    von dateien. lesen(Dateiname) -> Bytes. Fehler: ValueError bei einem Namen außerhalb der Oberfläche (vor jedem Lesen)."""
    teile = [KOPF[name].encode("utf-8")]
    for datei in map(sicherer_name, list(dateien)):
        inhalt = lesen(datei)
        teile += [MARKE[name].format(datei).encode("utf-8"), inhalt, b"" if inhalt.endswith(b"\n") else b"\n"]
    return b"".join(teile)


def _ein_eintrag(html: str, muster: re.Pattern, eintrag: str) -> str:
    """Ersetzt den ersten Listeneintrag durch eintrag und entfernt die übrigen samt Zeilenende."""
    zeile = re.compile(muster.pattern + r"\r?\n?")
    erster = zeile.search(html)
    if not erster:
        return html
    return html[:erster.start()] + eintrag + "\n" + zeile.sub("", html[erster.start():])


def mit_buendel(html: str) -> str:
    """index.html, die statt der Liste je ein Bündel lädt, an der Stelle des ersten Skripts bzw. der ersten Stil-Datei. Andere Verweise bleiben."""
    for name, (muster, eintrag) in EINTRAG.items():
        html = _ein_eintrag(html, muster, eintrag.format(name))
    return html
