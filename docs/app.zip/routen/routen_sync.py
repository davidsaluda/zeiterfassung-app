# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Synchronisierung (aus server.py geschnitten, Runde 1.4): /api/abgleich mit allen Unterrouten (Stand, Einrichten,
Koppeln, Passwort, Jetzt, Einlesen, Entscheiden, Abmelden, Entfernen). Klasse SyncRouten und Einstieg _routen_sync
behalten ihren Namen bis zur Umbenennung.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import base64
import binascii
import os
import re
import secrets
import time

from daten import konfig
from daten import sync
from routen import anschluesse
from ausgabe import qr
from daten import rueckgaengig
from daten import sicherung
from routen.anschluesse import _oberflaeche, freigabe_an, freigabe_schalten, oberflaeche_schalten, oberflaeche_stand
from routen.eingabe import Fehler, MIT_ADRESSE, NICHT_ZUSTAENDIG, NUR_AM_RECHNER, _text, plattform
from routen.kopplung import _KOPPEL_SCHLOSS, _kopplung, koppeln_annehmen, koppeln_starten
from routen.ziele import ADRESSE, ANMELDE_MAX, ablage_einrichten, eigene_ablage, github_verbinden, github_ziel, netz_ziel

KEINE_SYNCDATEI = "Noch keine Synchronisierungsdatei. Erst „Jetzt synchronisieren“ wählen."
SYNC_IM_NAMEN = re.compile(r"abgleich-[0-9a-f]{16}")     # Gerätekennung im Namen einer hereingeholten Sync-Datei (Browser-Fassung)


def _anschluss_schalten(port: int, schalten, *args, **kw) -> None:
    """Ruft „schalten“ (Freigabe oder Oberfläche) mit den übrigen Angaben auf; ist der Anschluss „port“ belegt (OSError), wird daraus ein Fehler für die Person."""
    try:
        schalten(*args, **kw)
    except OSError:
        raise Fehler(f"Der Anschluss {port} ist auf diesem Gerät belegt. Die Freigabe geht gerade nicht.")


class SyncRouten:
    """Routen für Synchronisierung (Synchronisierung) der Oberfläche; Teil der Klasse Handler (Mixin)."""

    def _routen_sync(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if p == "/api/abgleich" or p.startswith("/api/abgleich/"):
            return self._sync(m, p, demo_an)
        return NICHT_ZUSTAENDIG

    def _sync_ziele(self, pruefen: bool = False, warten: float = None) -> list:
        """Alle eingetragenen Ziele der Synchronisierung dieses Geräts in fester Reihenfolge: Ordner, eigene Ablage (Freigabe), eigener Server, GitHub.
        Server und GitHub nur, wenn sie gerade antworten (GitHub nur mit pruefen). warten: kürzere Zeitgrenze je Anfrage in Sekunden."""
        ordner = self.daten_ordner
        frei = eigene_ablage(ordner) if freigabe_an(ordner) else None
        ziele = (self._ziel(), frei, netz_ziel(ordner, warten=warten), github_ziel(ordner, pruefen=pruefen, warten=warten))
        return [z for z in ziele if z is not None]

    def _sync(self, m: str, p: str, demo_an: bool) -> dict:
        """Synchronisierung der lokalen Fassungen (Desktop, Handy) über den Cloud-Ordner. Auf einem Server gibt es diese Adressen nicht."""
        if not self.daten_ordner:
            raise Fehler("Nicht gefunden", 404)
        ordner = self.daten_ordner
        if m == "GET" and p == "/api/abgleich":
            return self._sync_stand()
        if sync.aus(ordner):                                 # Modul „Sync“ aus: nichts senden, lesen, koppeln oder einstellen
            raise Fehler(sync.ABGESCHALTET, 403)
        if m == "POST" and p == "/api/abgleich/abmelden" and plattform() == "browser" and not demo_an and not self.fern:   # Web-App: Der letzte Sync (über Dateien) ist durch
            sync.abmelden(ordner)
            return self._sync_stand()
        if m == "GET" and p == "/api/abgleich/datei" and plattform() == "browser":
            return self._syncdatei(demo_an)
        if demo_an:
            raise Fehler("Im Demo-Modus wird nichts synchronisiert")
        b = self._body()
        if self.fern and p not in ("/api/abgleich/jetzt", "/api/abgleich/entscheiden"):
            raise Fehler(NUR_AM_RECHNER, 403)
        try:
            if m == "PUT" and p == "/api/abgleich":
                self._sync_einstellen(ordner, b)
            elif m == "POST" and p in ("/api/abgleich/koppeln", "/api/abgleich/koppeln/annehmen"):
                self._sync_koppeln(ordner, p, b)
            elif m == "POST" and p == "/api/abgleich/server-abmelden" and plattform() in MIT_ADRESSE:
                sicherung.geraet_aendern(ordner, ablage_schluessel="", ablage_geraet="", ablage_fehler="")    # nur hier: Am Server entfernt das Gerät die Person selbst
            elif m == "POST" and p == "/api/abgleich/passwort":
                sicherung.passwort_setzen(ordner, b.get("passwort"))
            elif m == "POST" and p == "/api/abgleich/jetzt":
                self._sync_jetzt(ordner, b)
            elif m == "POST" and p == "/api/abgleich/einlesen" and plattform() == "browser":
                self._sync_einlesen(ordner, b)
            elif m == "POST" and p == "/api/abgleich/entfernen":     # ein anderes Gerät aus der Synchronisierung nehmen (nur seine Sync-Datei)
                sync.entfernen(ordner, self._sync_ziele(), b.get("name"), _text(b.get("passwort"), "Passwort") or None)
            elif m == "POST" and p == "/api/abgleich/nachweis" and plattform() == "browser":
                return self._sync_nachweis(ordner, b)
            elif m == "POST" and p == "/api/abgleich/entscheiden":
                if "alle" in b:
                    sync.alle_entscheiden(self.db, b["alle"])
                else:
                    sync.entscheiden(self.db, _text(b.get("art"), "Art"), _text(b.get("schluessel"), "Schlüssel"), b.get("wahl"))
            else:
                raise Fehler("Nicht gefunden", 404)
        except OSError:
            raise Fehler(sicherung.ZIEL_WEG, 503)
        except konfig.Meldung as e:                           # SicherungFehler, SyncFehler; andere ValueError: allgemeine Meldung (server)
            raise Fehler(str(e))
        self.antworten.clear()
        self.gepackt.clear()
        return {"ok": True, **self._sync_stand()}

    def _sync_einstellen(self, ordner: str, b: dict) -> None:
        """PUT /api/abgleich: Automatik, Ordner, Server, GitHub, Freigabe und Oberflächen-Freigabe dieses Geräts einstellen.
        Prüft jede Angabe (Fehler bei ungültiger Angabe oder belegtem Anschluss) und speichert alle zusammen in geraet.json."""
        neu = {}
        if "auto" in b:
            if not isinstance(b["auto"], bool):
                raise Fehler("Automatisch synchronisieren: an oder aus")
            neu["abgleich_auto"] = b["auto"]
        if "ordner" in b:
            if plattform() != "desktop":
                raise Fehler("Den Ordner legt auf diesem Gerät die App fest")
            pfad = _text(b["ordner"], "Ordner").strip()
            if pfad and (len(pfad) > 500 or "\x00" in pfad or not os.path.isabs(pfad) or not os.path.isdir(pfad)):
                raise Fehler("Diesen Ordner gibt es nicht. Bitte den ganzen Pfad eines vorhandenen Ordners angeben.")
            neu["ziel_ordner"] = pfad
        if "server" in b:
            if plattform() not in MIT_ADRESSE:
                raise Fehler("Die Adresse des Servers gibt es nur in der Desktop-Fassung und in den Handy-Apps")
            adresse = _text(b["server"], "Adresse").strip()
            if adresse and (len(adresse) > 200 or not ADRESSE.fullmatch(adresse)):
                raise Fehler("Adresse des eigenen Servers: so wie im Browser, zum Beispiel https://zeiterfassung.example oder mit IP und Port wie http://192.0.2.10:8099")
            benutzer, passwort = _text(b.get("benutzer"), "Benutzername").strip(), _text(b.get("passwort"), "Passwort")
            if len(benutzer) > ANMELDE_MAX or len(passwort) > sicherung.PASSWORT_MAX:
                raise Fehler(f"Benutzername und Passwort: höchstens {ANMELDE_MAX} Zeichen")
            neu.update(ablage_einrichten(ordner, adresse, benutzer, passwort))
        if "github" in b:                                # ein eigenes Repo bei GitHub als Speicherort (alle Fassungen); None trennt die Verbindung
            neu.update(github_verbinden(b["github"]))
        if "freigabe" in b:                              # dieses Gerät als Speicherort für die anderen (ohne eigenen Server, ohne Cloud)
            if plattform() not in MIT_ADRESSE:
                raise Fehler("Die Freigabe gibt es nur in der Desktop-Fassung und in den Handy-Apps")
            an = b["freigabe"] is True
            ip = anschluesse.netz_adresse() if an else ""
            if an and not sicherung.geraet_lesen(ordner)["schluessel"]:
                raise Fehler(anschluesse.FREIGABE_OHNE_PASSWORT)
            if an and not ip:                            # ohne Netz gäbe es kein Netz zu merken (siehe freigabe_schalten)
                raise Fehler(anschluesse.KEIN_NETZ)
            _anschluss_schalten(anschluesse.FREIGABE_PORT, freigabe_schalten, self.__class__, an, ausdruecklich=True, adresse=ip)
            anschluesse.freigabe_merken(ordner, ip)      # an in diesem Netz, sofort (siehe freigabe_merken)
        if "oberflaeche" in b:                           # die Oberfläche dieses Rechners für das eigene Handy im selben Netz (iPhone: Safari)
            if plattform() != "desktop":
                raise Fehler("Die Freigabe der Oberfläche gibt es nur in der Desktop-Fassung")
            an = b["oberflaeche"] is True
            ip = anschluesse.netz_adresse() if an else ""
            if an and not ip:                            # wie bei 8793: 8794 merkt sich das Netz und öffnet nur dort
                raise Fehler(anschluesse.KEIN_NETZ)
            if an and _oberflaeche["dienst"] is None:    # jedes Einschalten gibt ein neues Geheimnis: Ein alter Code gilt nicht mehr
                sicherung.geraet_aendern(ordner, oberflaeche_zugang=secrets.token_hex(16))
            _anschluss_schalten(anschluesse.OBERFLAECHE_PORT, oberflaeche_schalten, self.__class__, ordner, an, adresse=ip)
            neu["oberflaeche"] = ip or False
        sicherung.geraet_aendern(ordner, **neu)

    def _sync_koppeln(self, ordner: str, p: str, b: dict) -> None:
        """POST /api/abgleich/koppeln startet die Kopplung per Code; …/koppeln/annehmen nimmt den Code eines anderen Geräts an und synchronisiert gleich."""
        if plattform() not in MIT_ADRESSE:
            raise Fehler("Die Kopplung per Code gibt es nur in der Desktop-Fassung und in den Handy-Apps")
        if p.endswith("/koppeln"):
            koppeln_starten(self.__class__, ordner)
        else:
            koppeln_annehmen(ordner, b.get("code"), ersetzen=b.get("bestaetigt") is True)
            sync.synchronisieren(self.db, ordner, netz_ziel(ordner))

    def _sync_jetzt(self, ordner: str, b: dict) -> None:
        """POST /api/abgleich/jetzt: mit jeder eingerichteten Stelle synchronisieren (Ordner, Freigabe, Server, GitHub); danach ggf. abmelden.
        Bei der Rückkehr in die App (automatik) wartet die Synchronisierung, solange ein Rückgängig offen ist; „Jetzt synchronisieren“ schließt das Fenster."""
        # automatik: Zurückkehren in die App. Wie die Automatik im Hintergrund still, wenn GitHub gerade nicht erreichbar oder nichts eingerichtet ist
        automatik = b.get("automatik") is True
        if automatik and rueckgaengig.offen(self.db):    # Kein Stand geht hinaus, den Rückgängig gleich zurücknimmt
            return
        rueckgaengig.verwerfen(self.db)
        passwort = _text(b.get("passwort"), "Passwort") or None
        ziele = self._sync_ziele(pruefen=automatik)
        if not ziele and not automatik:                  # ohne Ordner, Server, Freigabe und GitHub meldet der Sync, dass nichts eingerichtet ist
            sync.synchronisieren(self.db, ordner, None, passwort)
        for ziel in ziele:
            sync.synchronisieren(self.db, ordner, ziel, passwort)
        if (sicherung.geraet_lesen(ordner)["abgleich"] or {}).get("ok"):
            sync.abmelden(ordner)                    # Modul aus: Das war der letzte Sync, die anderen Geräte wissen jetzt Bescheid

    def _sync_einlesen(self, ordner: str, b: dict) -> None:
        """POST /api/abgleich/einlesen (nur Browser): die hereingeholte Synchronisierungsdatei eines anderen Geräts prüfen, ablegen und synchronisieren."""
        # Die Web-App im Browser hat keinen Cloud-Ordner: Die Person holt die Datei des anderen Geräts selbst herein.
        # Der Name darf vom Gerät verändert sein (Kopie mit Zusatz wie „ 2“ vor .zsich, Schnittstelle S3); es zählt die Gerätekennung darin.
        treffer = SYNC_IM_NAMEN.search(_text(b.get("name"), "Name"))
        ziel = self._ziel()
        if not treffer or ziel is None:
            raise Fehler("Das ist keine Synchronisierungsdatei dieser App (erwartet: abgleich-….zsich)")
        name = treffer.group(0) + sicherung.ENDUNG
        if name == sicherung.sync_name(sicherung.geraet_lesen(ordner)["geraet"]):
            raise Fehler("Das ist die Synchronisierungsdatei dieses Geräts. Bitte die Datei des anderen Geräts wählen.")
        try:
            roh = base64.b64decode(_text(b.get("daten"), "daten"), validate=True)
        except (binascii.Error, ValueError):
            raise Fehler("daten: Datei als Base64 erwartet")
        sicherung.kopf_lesen(roh)                         # passt die Datei überhaupt? (SicherungFehler)
        ziel.ablegen(name, roh)
        sync.synchronisieren(self.db, ordner, ziel, _text(b.get("passwort"), "Passwort") or None)

    def _sync_nachweis(self, ordner: str, b: dict) -> dict:
        """POST /api/abgleich/nachweis (nur Browser, seit 21.11.2026): Schreib-Nachweis für die eigene Synchronisierungsdatei. Eingabe: „ablage“, die Ankündigung
        aus der Liste der Ablage, „vorher“, die Summe der Datei, die dort schon liegt (aus derselben Liste, leer ohne Datei), und „passwort“
        (leer: nur gemerkte Schlüssel). Rückgabe {"nachweis": Hex}, leer ohne passenden Schlüssel. Fehler 400, wenn „vorher“ keine Summe ist.
        Mit „loeschen“ (seit 22.11.2026, Gerät entfernen) gilt der Nachweis dem Löschen der Datei eines anderen Geräts wie bei NetzZiel.loeschen
        (leerer Inhalt LOESCH_INHALT, „vorher“ Pflicht); nie für die eigene Datei. Der Schlüssel bleibt in der App; die Oberfläche reicht nur den Nachweis weiter."""
        vorher = _text(b.get("vorher"), "vorher")
        if vorher and not sicherung.SUMME.fullmatch(vorher):
            raise Fehler("vorher: Prüfsumme aus der Liste der Ablage erwartet")
        name = eigene = sicherung.sync_name(sicherung.geraet_lesen(ordner)["geraet"])
        if "loeschen" in b:
            name = b["loeschen"]
            if not (isinstance(name, str) and sicherung.SYNC_NAME.fullmatch(name) and name != eigene and vorher):
                raise Fehler("loeschen: Sync-Datei eines anderen Geräts aus der Liste der Ablage erwartet")
        halter = sicherung.NetzZiel("")                      # trägt nur Ankündigung, Vorgänger und Schlüssel, öffnet nie eine Verbindung
        halter.ankuendigung, halter.summen = sicherung.ankuendigung_lesen(b.get("ablage")), {name: vorher}
        sync.schreib_schluessel_setzen(ordner, halter, _text(b.get("passwort"), "Passwort") or None)
        inhalt = sicherung.LOESCH_INHALT if name != eigene else self._eigene_syncdatei(name, False)
        return {"nachweis": halter.nachweis_holen(name, inhalt) or ""}

    def _eigene_syncdatei(self, name: str, demo_an: bool) -> bytes:
        """Die eigene Synchronisierungsdatei aus dem Ziel. Fehler 404, wenn es (noch) keine gibt oder kein Ziel; OSError, wenn das Ziel nicht erreichbar ist."""
        ziel = self._ziel()
        if demo_an or ziel is None or name not in ziel.sync_namen():
            raise Fehler(KEINE_SYNCDATEI, 404)
        return ziel.lesen(name)

    def _syncdatei(self, demo_an: bool) -> None:
        """Browser-Fassung: die eigene, verschlüsselte Synchronisierungsdatei herausgeben. Die Person legt sie selbst in den Ordner der anderen Geräte."""
        name = sicherung.sync_name(sicherung.geraet_lesen(self.daten_ordner)["geraet"])
        try:
            self._senden(200, self._eigene_syncdatei(name, demo_an), "application/octet-stream", {"Content-Disposition": f'attachment; filename="{name}"'})
        except OSError:
            raise Fehler(sicherung.ZIEL_WEG, 503)

    def _sync_stand(self) -> dict:
        """Der Stand der Synchronisierung für die Oberfläche. Am Handy der freigegebenen Oberfläche nur die Grundangaben; sonst mit GitHub-Repo (nie das Token), am Desktop auch Ordner, Server und Oberflächen-Freigabe."""
        d = {"plattform": plattform(), "fern": self.fern, "stand": self.db.gen, **sync.stand(self.db, self.daten_ordner, self._ziel())}   # stand: ändert sich mit jedem Schreiben, auch durch den Sync im Hintergrund
        if self.fern:                                         # das Handy an der freigegebenen Oberfläche: Eingerichtet wird am Rechner
            return d
        g = sicherung.geraet_lesen(self.daten_ordner)
        d["github"] = {"repo": g["github_repo"], "privat": g["github_privat"]} if g["github_repo"] else None     # nie das Token
        if plattform() == "desktop":                          # am Desktop wählt die Person den Ordner selbst und sieht ihn deshalb auch
            g = sicherung.geraet_lesen(self.daten_ordner)
            d["ordner"], d["server"] = g["ziel_ordner"], g["ablage_adresse"]
            d["oberflaeche"] = oberflaeche_stand(self.daten_ordner)
        elif plattform() in MIT_ADRESSE:
            d["server"] = sicherung.geraet_lesen(self.daten_ordner)["ablage_adresse"]
        if plattform() in MIT_ADRESSE:
            d["freigabe"] = freigabe_an(self.daten_ordner)
            if g.get("freigabe") and not d["freigabe"]:      # eingeschaltet, hier aber zu: anderes Netz, ohne Netz oder Wert einer älteren Fassung
                d["freigabe_pausiert"] = True                # nur dann: Die Form der Antwort ohne Freigabe hält der Golden Master (tests/altstand/routen.json) fest
            d["server_anmeldung"] = {"angemeldet": bool(g["ablage_schluessel"]), "geraet": g["ablage_geraet"] if g["ablage_schluessel"] else "", "fehler": g["ablage_fehler"]}   # nie den Schlüssel
            d["freigabe_adressen"] = anschluesse.freigabe_adressen() if d["freigabe"] else []
            with _KOPPEL_SCHLOSS:                             # die Ablage leert _kopplung aus einem anderen Faden
                k = dict(_kopplung)
            rest = int(k["bis"] - time.monotonic()) if k else 0
            d["kopplung"] = {"code": k["code"], "sekunden": rest, "qr": qr.svg(k["code"])} if rest > 0 and d["freigabe"] else None
        return d
