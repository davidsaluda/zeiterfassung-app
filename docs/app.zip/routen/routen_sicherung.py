# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Sicherung (aus server.py geschnitten, Runde 1.4): GET /api/sicherung, /api/sicherung/info, /api/sicherung/liste,
/api/sicherung/davor/<Name>, POST /api/sicherung/wiederherstellen und /api/werkseinstellungen (auf dem Fern-Anschluss
gesperrt), /api/handysicherung mit Unterrouten (nur Handy und Browser) und GET /api/pruefen (Daten prüfen, liest nur).
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import base64
import binascii
import os
import re
import tempfile
from datetime import date

from daten import sync
from routen import anschluesse
from daten import konfig
from kern import eintraege_pruefen
from routen import kopplung
from daten import sicherung
from daten.db import Db, sicherung_liste, sicherung_stand
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _text, plattform

VOR_WIEDERHERSTELLUNG = re.compile(r"vor-wiederherstellung-[0-9_\-]+\.db")
HANDY_PLATTFORMEN = ("android", "browser")                 # haben die verschlüsselte Sicherung (sicherung.py)
SICHERUNGSDATEI = "/api/handysicherung/datei/"             # dahinter der Name einer verschlüsselten Sicherung


class SicherungRouten:
    """Routen für Sicherung, Wiederherstellen, Werkseinstellungen, Handy-Sicherung; Teil der Klasse Handler (Mixin)."""

    def _routen_sicherung(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if p == "/api/handysicherung" or p.startswith("/api/handysicherung/"):
            return self._handysicherung(m, p, demo_an)
        if m == "GET" and p == "/api/sicherung/info":        # Stand der nächtlichen Sicherung und der zweiten Kopie (Cloud-Ordner); keine Pfade
            ordner = os.path.join(self.daten_ordner, "sicherung") if self.daten_ordner else ""
            davor = next((s for s in sicherung_liste(ordner) if VOR_WIEDERHERSTELLUNG.fullmatch(s["name"])), None) if ordner and not demo_an else None
            return {"lokal": sicherung_stand(ordner) if ordner else None, "plattform": plattform(), "davor": davor}
        if m == "GET" and p == "/api/sicherung/liste":       # Sicherungen im Datenordner (nur API, die Oberfläche spielt nur Dateien vom Gerät ein)
            return {"sicherungen": sicherung_liste(os.path.join(self.daten_ordner, "sicherung")) if self.daten_ordner else []}
        if self.fern and m == "POST" and p in ("/api/sicherung/wiederherstellen", "/api/werkseinstellungen"):   # das Handy an der freigegebenen Oberfläche ersetzt oder löscht nicht alles
            raise Fehler("Wiederherstellen und Zurücksetzen gehen nur am Rechner, in der App dort.", 403)
        if m == "POST" and p == "/api/sicherung/wiederherstellen":
            return self._wiederherstellen(self._body(), demo_an)
        if m == "POST" and p == "/api/werkseinstellungen":
            return self._werkseinstellungen(self._body(), demo_an)
        g = re.fullmatch(r"/api/sicherung/davor/([\w.\-]+)", p)
        if m == "GET" and g:                                 # den Stand vor einem Wiederherstellen herunterladen (nur Namen aus der Liste, nie ein Pfad)
            ordner = os.path.join(self.daten_ordner, "sicherung") if self.daten_ordner else ""
            if demo_an or not ordner or not VOR_WIEDERHERSTELLUNG.fullmatch(g[1]) or g[1] not in {s["name"] for s in sicherung_liste(ordner)}:
                raise Fehler("Nicht gefunden", 404)
            with open(os.path.join(ordner, g[1]), "rb") as f:
                self._senden(200, f.read(), "application/octet-stream", {"Content-Disposition": f'attachment; filename="{g[1]}"'})
            return None
        if m == "GET" and p == "/api/pruefen":                # Daten prüfen (funktionen.md 10): liest nur
            return eintraege_pruefen.pruefen(db)
        if m == "GET" and p == "/api/sicherung":
            self._senden(200, db.sicherung_bytes(), "application/octet-stream", {"Content-Disposition": f'attachment; filename="zeiterfassung-{date.today().isoformat()}.db"'})
            return None
        return NICHT_ZUSTAENDIG

    def _wiederherstellen(self, b: dict, demo_an: bool) -> dict:
        """Den Datenbestand aus einer Sicherung ersetzen: {"bestaetigt": true, "datei": "<Name aus /api/sicherung/liste>"} oder
        {"bestaetigt": true, "daten": "<Datei als Base64>"} (.db). Der Stand davor wird gesichert."""
        if demo_an:
            raise Fehler("Im Demo-Modus lässt sich nichts wiederherstellen")
        if not self.daten_ordner:
            raise Fehler("Kein Datenordner", 503)
        if b.get("bestaetigt") is not True:
            raise Fehler("Bitte bestätigen: Wiederherstellen ersetzt alle Einträge und Einstellungen")
        ordner = os.path.join(self.daten_ordner, "sicherung")
        with tempfile.TemporaryDirectory() as t:
            if b.get("datei"):
                name = str(b["datei"])
                if name not in {s["name"] for s in sicherung_liste(ordner)}:       # nur Namen aus der Liste, nie ein Pfad
                    raise Fehler("Diese Sicherung gibt es nicht")
                quelle = os.path.join(ordner, name)
            else:
                try:
                    roh = base64.b64decode(str(b.get("daten") or ""), validate=True)
                except (binascii.Error, ValueError):
                    raise Fehler("daten: Datei als Base64 erwartet")
                if not roh:
                    raise Fehler("Keine Datei gewählt")
                quelle = os.path.join(t, "hochgeladen.db")
                with open(quelle, "wb") as f:
                    f.write(roh)
            try:
                r = self.db.wiederherstellen(quelle, ordner)
            except konfig.Meldung as e:
                raise Fehler(str(e))
        sicherung.sync_neu_lesen(self.daten_ordner)          # sonst liefe dieses Gerät still auseinander, bis ein anderes etwas ändert
        konfig.laden(self.db)
        self.antworten.clear()
        self.gepackt.clear()
        return {"ok": True, **r}

    def _werkseinstellungen(self, b: dict, demo_an: bool) -> dict:
        """Alles auf Anfang: wie Wiederherstellen mit einer leeren Datenbank. Der Stand davor wird gesichert (Datei vor-wiederherstellung-…db).
        Das Gerät verlässt auch die Synchronisierung: vorher eine letzte Synchronisierung mit abgemeldet=True an die eingetragenen Ziele (nur ein Versuch,
        sync.abmelden_versuchen, ohne db.lock), laufende Kopplung verworfen, Anschlüsse 8793 und 8794 zu, geraet.json auf die Vorgabe (Passwort-Schlüssel, gemerkte Schlüssel,
        Token, Server, Merklisten, Module); nur die Gerätekennung bleibt (sicherung.geraet_zuruecksetzen)."""
        if demo_an:
            raise Fehler("Im Demo-Modus lässt sich nichts zurücksetzen")
        if not self.daten_ordner:
            raise Fehler("Kein Datenordner", 503)
        if b.get("bestaetigt") is not True:
            raise Fehler("Bitte bestätigen: Zurücksetzen löscht alle Einträge und Einstellungen")
        aus_vorher = sicherung.geraet_lesen(self.daten_ordner)["abgleich_aus"]
        sync.abmelden_versuchen(self.db, self.daten_ordner, lambda warten: self._sync_ziele(warten=warten))   # ohne db.lock: die Oberfläche bleibt bedienbar
        try:
            with self.db.lock:                                   # Reihenfolge wie überall: sync._SCHLOSS (hält _schreiben), dann db.lock
                with tempfile.TemporaryDirectory() as t:
                    leer = os.path.join(t, "leer.db")
                    Db(leer)                                     # legt die leere Datenbank an (keine offene Verbindung)
                    r = self.db.wiederherstellen(leer, os.path.join(self.daten_ordner, "sicherung"))
                kopplung.koppeln_beenden()                       # vor dem Schließen von 8793: ein dort wartendes Koppeln findet keinen Code mehr
                anschluesse.freigabe_schalten(self.__class__, False)
                anschluesse.oberflaeche_schalten(self.__class__, self.daten_ordner, False)
                sicherung.geraet_zuruecksetzen(self.daten_ordner)    # leert auch die Merklisten des Syncs und schaltet sein Modul wieder an
                konfig.laden(self.db)
        except BaseException:                                    # nicht zurückgesetzt: sonst bliebe der Sync still aus und die Automatik meldete sich bei jedem Lauf ab
            sicherung.geraet_aendern(self.daten_ordner, **{"abgleich_aus": aus_vorher})
            raise
        self.antworten.clear()
        self.gepackt.clear()
        return {"ok": True, **r}

    def _handysicherung(self, m: str, p: str, demo_an: bool) -> dict:
        """Verschlüsselte Sicherung der Handy-Fassung. Auf einem Server gibt es diese Adressen nicht (die Web-App hat keine Cloud-Funktion)."""
        if plattform() not in HANDY_PLATTFORMEN or not self.daten_ordner:
            raise Fehler("Nicht gefunden", 404)
        ordner, ziel = self.daten_ordner, self._ziel()
        if m == "GET" and p == "/api/handysicherung":
            return {"plattform": plattform(), **sicherung.stand(ordner, ziel)}
        if m == "GET" and p.startswith(SICHERUNGSDATEI):
            return self._sicherungsdatei(p[len(SICHERUNGSDATEI):], ziel, demo_an)
        if demo_an:
            raise Fehler("Im Demo-Modus wird nichts gesichert oder wiederhergestellt")
        b = self._body()
        try:
            if m == "PUT" and p == "/api/handysicherung":
                sicherung.einstellungen_setzen(ordner, b.get("auto"), b.get("rhythmus"), b.get("behalten"))
            elif m == "POST" and p == "/api/handysicherung/passwort":
                sicherung.passwort_setzen(ordner, b.get("passwort"))
            elif m == "POST" and p == "/api/handysicherung/jetzt":
                sicherung.sichern(self.db, ordner, ziel)
            elif m == "POST" and p == "/api/handysicherung/wiederherstellen":
                if b.get("bestaetigt") is not True:
                    raise Fehler("Bitte bestätigen: Wiederherstellen ersetzt alle Einträge und Einstellungen")
                passwort = _text(b.get("passwort"), "Passwort")
                if b.get("datei"):
                    if ziel is None:
                        raise Fehler(sicherung.KEIN_ZIEL)
                    roh = ziel.lesen(_text(b["datei"], "Datei"))
                else:
                    try:
                        roh = base64.b64decode(_text(b.get("daten"), "daten"), validate=True)
                    except (binascii.Error, ValueError):
                        raise Fehler("daten: Datei als Base64 erwartet")
                    if not roh:
                        raise Fehler("Keine Sicherung gewählt")
                r = sicherung.wiederherstellen(self.db, ordner, roh, passwort or None)
                konfig.laden(self.db)
                self.antworten.clear()
                self.gepackt.clear()
                return {"ok": True, **r}
            else:
                raise Fehler("Nicht gefunden", 404)
        except OSError:                                       # Ziel nicht lesbar: klare Meldung statt „Datenbank nicht schreibbar“
            raise Fehler(sicherung.ZIEL_WEG, 503)
        except konfig.Meldung as e:                           # SicherungFehler und Meldungen aus der Prüfung der Datenbank; andere ValueError: allgemeine Meldung (server)
            raise Fehler(str(e))
        return {"ok": True, "plattform": plattform(), **sicherung.stand(ordner, ziel)}

    def _sicherungsdatei(self, name: str, ziel, demo_an: bool) -> None:
        """Eine verschlüsselte Sicherung als Datei herausgeben (nur Namen aus der Liste, nie ein Pfad). Im Browser ist das der Weg aus dem
        Speicher der Seite in die Dateien des Geräts; die Datei ist ohne das Passwort nicht lesbar."""
        try:
            if demo_an or ziel is None or name not in ziel.namen():
                raise Fehler("Nicht gefunden", 404)
            self._senden(200, ziel.lesen(name), "application/octet-stream", {"Content-Disposition": f'attachment; filename="{name}"'})
        except OSError:
            raise Fehler(sicherung.ZIEL_WEG, 503)
