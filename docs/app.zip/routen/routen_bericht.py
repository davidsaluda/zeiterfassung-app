# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Berichte (aus server.py geschnitten, Runde 1.4): GET /api/monat/<jahr>/<monat> und /api/steuer/<jahr> (auch als
Datei), GET /api/jahr/<jahr> (auch als PDF), /api/horest/<jahr>/<monat>, /api/gleitzeit/verlauf/<jahr>, /api/gleitzeit/saldo, /api/krank/<jahr>, /api/heute, /api/zutun, dazu /api/buero (PUT ändert).
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import os
import re
from datetime import date, datetime

from kern import bericht
from ausgabe import dokument
from ausgabe import export as exportformat
from kern import regeln
from kern import woche
from daten import konfig
from daten import sicherung
from daten import stempel
from daten import update
from kern import zutun
from daten.db import sicherung_stand
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _datum

ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
SALDO_DATUM_FEHLER = "„{}“: Datum JJJJ-MM-TT"
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
ODT = "application/vnd.oasis.opendocument.text"
ODS = "application/vnd.oasis.opendocument.spreadsheet"
DOKUMENTE = {".docx": lambda b: (dokument.zu_docx(b), DOCX), ".odt": lambda b: (dokument.zu_odt(b), ODT), ".ods": lambda b: (dokument.zu_ods(b), ODS),
             ".md": lambda b: (dokument.zu_md(b), "text/markdown; charset=utf-8"), ".txt": lambda b: (dokument.zu_txt(b), "text/plain; charset=utf-8")}


class BerichtRouten:
    """Routen für Monat, Jahr, Spielraum, Krank, Steuer, Heute, Büro und Zu tun; Teil der Klasse Handler (Mixin)."""

    def _routen_bericht(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        g = re.fullmatch(r"/api/monat/(\d{4})/(\d{1,2})(\.pdf|\.json|\.xml|\.csv|\.docx|\.odt|\.ods|\.md|\.txt)?", p)
        if m == "GET" and g:
            j, mo = int(g[1]), int(g[2])
            if not 1 <= mo <= 12:
                raise Fehler("Monat 1 bis 12")
            if g[3] in DOKUMENTE:
                bl = dokument.monat_dokument(db, j, mo, konfig.CFG["zeitformat"])
                daten, typ = DOKUMENTE[g[3]](bl)
                self._senden(200, daten, typ, {"Content-Disposition": f'attachment; filename="Zeiterfassung-{j}-{mo:02d}{g[3]}"'})
                return None
            if g[3] in (".json", ".xml", ".csv"):
                md = stempel.mit_eintraegen(db, bericht.monat(db, j, mo, konfig.CFG["zeitformat"]), konfig.CFG["zeitformat"])
                name = f"Zeiterfassung-{j}-{mo:02d}"
                zeilen = exportformat.monat_zeilen(md)
                kopf = {"Content-Disposition": f'attachment; filename="{name}{g[3]}"'}
                if g[3] == ".json":
                    self._senden(200, exportformat.zu_json({"jahr": j, "monat": mo, "name": md["name"], "summe": md["text"], "tage": zeilen}), "application/json; charset=utf-8", kopf)
                elif g[3] == ".xml":
                    self._senden(200, exportformat.zu_xml({"jahr": j, "monat": mo, "name": md["name"], "summe": md["text"], "tage": zeilen}, "zeiterfassung_monat"), "application/xml; charset=utf-8", kopf)
                else:
                    self._senden(200, exportformat.tage_csv_monat(zeilen), "text/csv; charset=utf-8", kopf)
                return None
            if g[3]:
                self._senden(200, dokument.monat_pdf(db, j, mo, konfig.CFG["zeitformat"]), "application/pdf", {"Content-Disposition": f'attachment; filename="Zeiterfassung-{j}-{mo:02d}.pdf"'})
                return None
            return stempel.mit_eintraegen(db, bericht.monat(db, j, mo, konfig.CFG["zeitformat"]), konfig.CFG["zeitformat"])
        if p == "/api/buero":
            zeitraum = "jahr"
            if m == "PUT":
                body = self._body()
                zeitraum = body.get("zeitraum", "jahr")
                if not isinstance(zeitraum, str) or zeitraum not in bericht.RATE_SCHLUESSEL:
                    raise Fehler(bericht.ZEITRAUM_FEHLER)
                schluessel = bericht.RATE_SCHLUESSEL[zeitraum]
                w = body.get("rate")
                if w in (None, ""):
                    db.meta_setzen(schluessel, "")
                else:
                    try:
                        w = float(str(w).replace(",", "."))
                    except ValueError:
                        raise Fehler(f"Büro-Tage pro Woche: Zahl von 0 bis {regeln.BUERO_TAGE_MAX} oder leer für automatisch")
                    if not 0 <= w <= regeln.BUERO_TAGE_MAX:
                        raise Fehler(f"Büro-Tage pro Woche: 0 bis {regeln.BUERO_TAGE_MAX}")
                    db.meta_setzen(schluessel, str(w))
            heute = date.today()
            pr = bericht.prognose(db, heute.year, heute.month if zeitraum == "monat" else None)
            return {"zeitraum": zeitraum, "rate_hand": bericht.buero_rate(db, zeitraum), "rate_auto": pr["rate_auto"] if pr else None}
        if m == "GET" and p == "/api/heute":
            return bericht.heute(db, date.today())
        if m == "GET" and p == "/api/zutun":                 # Karte „Zu tun“ (18.11.2026); in der Demo nichts, sie soll die Übersicht zeigen, nicht mahnen
            return {"eintraege": [] if demo_an else zutun.eintraege(db, datetime.now(), self._zutun_stand())}
        g = re.fullmatch(r"/api/jahr/(\d{4})(\.pdf)?", p)
        if m == "GET" and g:
            if g[2]:
                self._senden(200, dokument.jahr_pdf(db, int(g[1]), konfig.CFG["zeitformat"]), "application/pdf",
                             {"Content-Disposition": f'attachment; filename="{dokument.JAHR_DATEI}-{g[1]}.pdf"'})
                return None
            return bericht.jahr(db, int(g[1]), konfig.CFG["zeitformat"])
        g = re.fullmatch(r"/api/horest/(\d{4})/(\d{1,2})", p)
        if m == "GET" and g:
            if not 1 <= int(g[2]) <= 12:
                raise Fehler("Monat 1 bis 12")
            return bericht.horest(db, int(g[1]), int(g[2]), konfig.CFG["zeitformat"])
        g = re.fullmatch(r"/api/gleitzeit/verlauf/(\d{4})", p)
        if m == "GET" and g:
            return self._gleitzeit_verlauf(db, int(g[1]))
        if m == "GET" and p == "/api/gleitzeit/saldo":
            return self._gleitzeit_saldo(db)
        g = re.fullmatch(r"/api/krank/(\d{4})", p)
        if m == "GET" and g:
            return bericht.krank(db, int(g[1]))
        g = re.fullmatch(r"/api/steuer/(\d{4})(\.csv|\.xlsx|\.pdf|\.json|\.xml|\.docx|\.odt|\.ods|\.md|\.txt)?", p)
        if m == "GET" and g:
            zf = konfig.CFG["zeitformat"]
            s = bericht.steuer(db, int(g[1]), zf)
            endung = g[2]
            if not endung:
                return s
            name = f"{bericht.UEBERSICHT_DATEI}-{g[1]}"
            if endung in DOKUMENTE:
                bl = dokument.steuer_dokument(s, zf)
                daten, typ = DOKUMENTE[endung](bl)
                self._senden(200, daten, typ, {"Content-Disposition": f'attachment; filename="{name}{endung}"'})
            elif endung == ".json":
                self._senden(200, exportformat.zu_json(s), "application/json; charset=utf-8", {"Content-Disposition": f'attachment; filename="{name}.json"'})
            elif endung == ".xml":
                self._senden(200, exportformat.zu_xml(s, "homeoffice_nachweis"), "application/xml; charset=utf-8", {"Content-Disposition": f'attachment; filename="{name}.xml"'})
            elif endung == ".csv":
                self._senden(200, bericht.steuer_csv(s, zf).encode("utf-8"), "text/csv; charset=utf-8",
                             {"Content-Disposition": f'attachment; filename="{name}.csv"'})
            elif endung == ".xlsx":
                self._senden(200, dokument.steuer_xlsx(s, zf), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             {"Content-Disposition": f'attachment; filename="{name}.xlsx"'})
            else:
                self._senden(200, dokument.steuer_pdf(s, zf), "application/pdf", {"Content-Disposition": f'attachment; filename="{name}.pdf"'})
            return None
        return NICHT_ZUSTAENDIG

    @staticmethod
    def _gleitzeit_verlauf(db, jahr: int) -> dict:
        """GET /api/gleitzeit/verlauf/<J> (funktionen.md 11): Punkte von woche.verlauf (Stand je Sonntag, dazu heute bzw. 31.12.) und die
        Grenzen des Kontos aus den Regeln von heute (woche.saldo_grenzen), dazu die Kappungen des Jahres (woche.verlauf_kappungen). Das Jahr prüft der
        Server (1970–2200). Rückgabe: {jahr, punkte: [{datum, saldo_min}], plus_min, minus_min, kappungen: [{datum, verfallen_min, text}]}."""
        heute = date.today()
        plus, minus = woche.saldo_grenzen(konfig.fuer(heute))
        return {"jahr": jahr, "punkte": woche.verlauf(db, jahr, heute), "plus_min": plus, "minus_min": minus,
                "kappungen": woche.verlauf_kappungen(db, jahr, heute, konfig.CFG["zeitformat"])}

    def _gleitzeit_saldo(self, db) -> dict:
        """GET /api/gleitzeit/saldo?von=JJJJ-MM-TT&bis=JJJJ-MM-TT[&schritt=tag|woche] (Vorgabe tag): Punkte von bericht.saldo_punkte bis heute.
        Fehler 400 mit Meldung bei fehlendem oder falschem Datum (1970–2200), von nach bis, mehr als bericht.SALDO_TAGE_MAX Tagen, unbekanntem Schritt."""
        abfrage = self.path.partition("?")[2]
        def wert(k, vorgabe=""):
            """Wert des Parameters „k“ ohne Dekodieren: Datum und Schritt bestehen nur aus Ziffern, Strichen und Buchstaben, alles andere lehnen die Prüfungen ab."""
            treffer = re.search(rf"(?:^|&){k}=([^&]*)", abfrage)
            return (treffer[1] if treffer else "") or vorgabe
        for k in ("von", "bis"):
            if not ISO_DATUM.fullmatch(wert(k)):                # eigene Meldung ohne Echo der Eingabe
                raise Fehler(SALDO_DATUM_FEHLER.format(k))
        try:
            return bericht.saldo_punkte(db, _datum(wert("von")), _datum(wert("bis")), wert("schritt", "tag"), date.today())
        except konfig.Meldung as e:
            raise Fehler(str(e))

    def _zutun_stand(self) -> dict:
        """Stand für zutun.eintraege: Sync-Stand plus Datum der letzten Sicherung. Das neuere zählt: die Web-App ohne Server schickt ihres mit
        (liegt nur im Browser, ?letzte_sicherung=ISO, nur ein gültiges Datum zählt), sonst die geprüfte Sync-Sicherung und die Nachtsicherung.
        Dazu aus geraet.json die neuere Version laut Update-Prüfung (nur wenn eingeschaltet) und die höchste eines anderen Geräts im Sync;
        beide prüft zutun selbst, weil die Werte von außen kommen."""
        stand = self._sync_stand()
        daten = [self._datum_aus_anfrage()]
        if self.daten_ordner:
            g = sicherung.geraet_lesen(self.daten_ordner)
            letzte = g["letzte"]
            daten.append(g["geprueft"] if letzte and letzte.get("ok") else "")
            stand["update_neueste"], stand["sync_app_neueste"] = update.hinweis(g), g["sync_app_neueste"]
            nacht = sicherung_stand(os.path.join(self.daten_ordner, "sicherung"))
            daten.append(nacht["zeit"] if nacht else "")
        stand["letzte_sicherung"] = max((d[:10] for d in daten if d), default="")
        return stand

    def _datum_aus_anfrage(self) -> str:
        """?letzte_sicherung=JJJJ-MM-TT… aus der Anfrage, nur wenn es ein Datum zwischen 1970 und 2200 ist, sonst leer."""
        treffer = re.search(r"(?:^|&)letzte_sicherung=([0-9-]{10})", self.path.partition("?")[2])   # nur Ziffern und Striche, kein Dekodieren nötig
        wert = treffer[1] if treffer else ""
        try:
            return wert if 1970 <= date.fromisoformat(wert).year <= 2200 else ""
        except ValueError:
            return ""
