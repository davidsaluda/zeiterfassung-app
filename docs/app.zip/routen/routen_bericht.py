# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Berichte (aus server.py geschnitten, Runde 1.4): GET /api/monat/<jahr>/<monat> und /api/steuer/<jahr> (auch als
Datei), GET /api/jahr/<jahr> (auch als PDF), /api/horest/<jahr>/<monat>, /api/gleitzeit/verlauf/<jahr>, /api/gleitzeit/verlauf?von=&bis=, /api/krank/<jahr>, /api/heute, /api/quote/ampel, /api/zutun, dazu /api/buero (PUT ändert).
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import os
import re
from datetime import date, datetime

from kern import bericht
from ausgabe import dokument
from ausgabe import export as exportformat
from kern import regeln
from kern import woche
from daten import konfig
from daten import sicherung
from daten import stempel
from daten import update
from kern import zutun
from daten.db import sicherung_stand
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _datum

ISO_DATUM = re.compile(r"\d{4}-\d{2}-\d{2}")
VERLAUF_DATUM_FEHLER = "„{}“: Datum JJJJ-MM-TT"
VERLAUF_REIHENFOLGE_FEHLER = "„von“ liegt nach „bis“"
VERLAUF_LAENGE_FEHLER = f"Höchstens {woche.VERLAUF_TAEGLICH_TAGE} Tage"
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


class BerichtRouten:
    """Routen für Monat, Jahr, Spielraum, Krank, Steuer, Heute, Büro und Zu tun; Teil der Klasse Handler (Mixin)."""

    def _routen_bericht(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        g = re.fullmatch(r"/api/monat/(\d{4})/(\d{1,2})(\.pdf|\.xlsx|\.csv)?", p)
        if m == "GET" and g:
            j, mo = int(g[1]), int(g[2])
            if not 1 <= mo <= 12:
                raise Fehler("Monat 1 bis 12")
            kopf = {"Content-Disposition": f'attachment; filename="Zeiterfassung-{j}-{mo:02d}{g[3]}"'}
            if g[3] == ".csv":
                md = stempel.mit_eintraegen(db, bericht.monat(db, j, mo, konfig.CFG["zeitformat"]), konfig.CFG["zeitformat"])
                self._senden(200, exportformat.tage_csv_monat(exportformat.monat_zeilen(md)), "text/csv; charset=utf-8", kopf)
                return None
            if g[3] == ".xlsx":
                self._senden(200, dokument.monat_xlsx(db, j, mo, konfig.CFG["zeitformat"]), XLSX, kopf)
                return None
            if g[3]:
                self._senden(200, dokument.monat_pdf(db, j, mo, konfig.CFG["zeitformat"]), "application/pdf", kopf)
                return None
            return stempel.mit_eintraegen(db, bericht.monat(db, j, mo, konfig.CFG["zeitformat"]), konfig.CFG["zeitformat"])
        if p == "/api/buero":
            zeitraum = "jahr"
            if m == "PUT":
                body = self._body()
                zeitraum = body.get("zeitraum", "jahr")
                if not isinstance(zeitraum, str) or zeitraum not in bericht.RATE_SCHLUESSEL:
                    raise Fehler(bericht.ZEITRAUM_FEHLER)
                schluessel = bericht.RATE_SCHLUESSEL[zeitraum]
                w = body.get("rate")
                if w in (None, ""):
                    db.meta_setzen(schluessel, "")
                else:
                    try:
                        w = float(str(w).replace(",", "."))
                    except ValueError:
                        raise Fehler(f"Büro-Tage pro Woche: Zahl von 0 bis {regeln.BUERO_TAGE_MAX} oder leer für automatisch")
                    if not 0 <= w <= regeln.BUERO_TAGE_MAX:
                        raise Fehler(f"Büro-Tage pro Woche: 0 bis {regeln.BUERO_TAGE_MAX}")
                    db.meta_setzen(schluessel, str(w))
            heute = date.today()
            pr = bericht.prognose(db, heute.year, heute.month if zeitraum == "monat" else None)
            return {"zeitraum": zeitraum, "rate_hand": bericht.buero_rate(db, zeitraum), "rate_auto": pr["rate_auto"] if pr else None}
        if m == "GET" and p == "/api/heute":
            return bericht.heute(db, date.today())
        if m == "GET" and p == "/api/quote/ampel":         # Quote-Ampel des laufenden Monats, mit der laufenden Uhr
            return bericht.quote_ampel(db, datetime.now().replace(microsecond=0), konfig.CFG["zeitformat"])
        if m == "GET" and p == "/api/zutun":                 # Karte „Zu tun“ (18.11.2026); in der Demo nichts, sie soll die Übersicht zeigen, nicht mahnen
            return {"eintraege": [] if demo_an else zutun.eintraege(db, datetime.now(), self._zutun_stand())}
        g = re.fullmatch(r"/api/jahr/(\d{4})(\.pdf)?", p)
        if m == "GET" and g:
            if g[2]:
                self._senden(200, dokument.jahr_pdf(db, int(g[1]), konfig.CFG["zeitformat"]), "application/pdf",
                             {"Content-Disposition": f'attachment; filename="{dokument.JAHR_DATEI}-{g[1]}.pdf"'})
                return None
            return bericht.jahr(db, int(g[1]), konfig.CFG["zeitformat"])
        g = re.fullmatch(r"/api/horest/(\d{4})/(\d{1,2})", p)
        if m == "GET" and g:
            if not 1 <= int(g[2]) <= 12:
                raise Fehler("Monat 1 bis 12")
            return bericht.horest(db, int(g[1]), int(g[2]), konfig.CFG["zeitformat"])
        g = re.fullmatch(r"/api/gleitzeit/verlauf/(\d{4})", p)
        if m == "GET" and g:
            return self._gleitzeit_verlauf(db, int(g[1]))
        if m == "GET" and p == "/api/gleitzeit/verlauf":
            return self._gleitzeit_zeitraum(db)
        g = re.fullmatch(r"/api/krank/(\d{4})", p)
        if m == "GET" and g:
            return bericht.krank(db, int(g[1]))
        g = re.fullmatch(r"/api/steuer/(\d{4})(\.xlsx|\.pdf)?", p)
        if m == "GET" and g:
            zf = konfig.CFG["zeitformat"]
            s = bericht.steuer(db, int(g[1]), zf)
            endung = g[2]
            if not endung:
                return s
            kopf = {"Content-Disposition": f'attachment; filename="{bericht.UEBERSICHT_DATEI}-{g[1]}{endung}"'}
            if endung == ".xlsx":
                self._senden(200, dokument.steuer_xlsx(s, zf), XLSX, kopf)
            else:
                self._senden(200, dokument.steuer_pdf(s, zf), "application/pdf", kopf)
            return None
        return NICHT_ZUSTAENDIG

    @staticmethod
    def _verlauf_antwort(db, heute: date, von: date, bis: date) -> dict:
        """Antwort beider Verlauf-Routen: Punkte von woche.verlauf, Grenzen des Kontos aus den Regeln von heute (woche.saldo_grenzen) und die
        Kappungen im Zeitraum (woche.verlauf_kappungen). Rückgabe: {von, bis, punkte: [{datum, saldo_min}], plus_min, minus_min, kappungen: [{datum, verfallen_min, text}]}."""
        plus, minus = woche.saldo_grenzen(konfig.fuer(heute))
        return {"von": von.isoformat(), "bis": bis.isoformat(), "punkte": woche.verlauf(db, heute=heute, von=von, bis=bis), "plus_min": plus, "minus_min": minus,
                "kappungen": woche.verlauf_kappungen(db, heute=heute, zeitformat=konfig.CFG["zeitformat"], von=von, bis=bis)}

    def _gleitzeit_verlauf(self, db, jahr: int) -> dict:
        """GET /api/gleitzeit/verlauf/<J> (funktionen.md 11, Seite Jahr, Kachel Gleitzeit): Verlauf des Jahres (Stand je Sonntag, dazu heute bzw. 31.12.)
        wie _verlauf_antwort, dazu das Jahr. Das Jahr prüft der Server (1970–2200)."""
        return {"jahr": jahr, **self._verlauf_antwort(db, date.today(), date(jahr, 1, 1), date(jahr, 12, 31))}

    def _gleitzeit_zeitraum(self, db) -> dict:
        """GET /api/gleitzeit/verlauf?von=JJJJ-MM-TT&bis=JJJJ-MM-TT (Karten der Seiten Tag, Woche, Monat): Stand je Tag wie _verlauf_antwort, nie nach heute.
        Fehler 400 bei fehlendem oder falschem Datum, von nach bis oder mehr als woche.VERLAUF_TAEGLICH_TAGE Tagen, immer mit fester Meldung ohne Echo
        der Eingabe, auch für ein Datum, das es nicht gibt (etwa 2025-02-30), oder außerhalb 1970–2200 (wie die Suche)."""
        abfrage = self.path.partition("?")[2]
        def wert(k):
            """Wert des Parameters „k“ ohne Dekodieren: ein Datum besteht nur aus Ziffern und Strichen, alles andere lehnt die Prüfung ab."""
            treffer = re.search(rf"(?:^|&){k}=([^&]*)", abfrage)
            return treffer[1] if treffer else ""
        def datum(k):
            """Datum „k“ oder Fehler 400 mit der festen Meldung (ohne Echo der Eingabe)."""
            try:
                if ISO_DATUM.fullmatch(wert(k)):
                    return _datum(wert(k))
            except Fehler:
                pass
            raise Fehler(VERLAUF_DATUM_FEHLER.format(k))
        von, bis = datum("von"), datum("bis")
        if von > bis:
            raise Fehler(VERLAUF_REIHENFOLGE_FEHLER)
        if (bis - von).days >= woche.VERLAUF_TAEGLICH_TAGE:
            raise Fehler(VERLAUF_LAENGE_FEHLER)
        return self._verlauf_antwort(db, date.today(), von, bis)

    def _zutun_stand(self) -> dict:
        """Stand für zutun.eintraege: Sync-Stand plus Datum der letzten Sicherung. Das neuere zählt: die Web-App ohne Server schickt ihres mit
        (liegt nur im Browser, ?letzte_sicherung=ISO, nur ein gültiges Datum zählt), sonst die geprüfte Sync-Sicherung und die Nachtsicherung.
        Dazu aus geraet.json die neuere Version laut Update-Prüfung (nur wenn eingeschaltet) und die höchste eines anderen Geräts im Sync;
        beide prüft zutun selbst, weil die Werte von außen kommen."""
        stand = self._sync_stand()
        daten = [self._datum_aus_anfrage()]
        if self.daten_ordner:
            g = sicherung.geraet_lesen(self.daten_ordner)
            letzte = g["letzte"]
            daten.append(g["geprueft"] if letzte and letzte.get("ok") else "")
            stand["update_neueste"], stand["sync_app_neueste"] = update.hinweis(g), g["sync_app_neueste"]
            nacht = sicherung_stand(os.path.join(self.daten_ordner, "sicherung"))
            daten.append(nacht["zeit"] if nacht else "")
        stand["letzte_sicherung"] = max((d[:10] for d in daten if d), default="")
        return stand

    def _datum_aus_anfrage(self) -> str:
        """?letzte_sicherung=JJJJ-MM-TT… aus der Anfrage, nur wenn es ein Datum zwischen 1970 und 2200 ist, sonst leer."""
        treffer = re.search(r"(?:^|&)letzte_sicherung=([0-9-]{10})", self.path.partition("?")[2])   # nur Ziffern und Striche, kein Dekodieren nötig
        wert = treffer[1] if treffer else ""
        try:
            return wert if 1970 <= date.fromisoformat(wert).year <= 2200 else ""
        except ValueError:
            return ""
