# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Zeiten (aus server.py geschnitten, Runde 1.4): GET und POST /api/stempel, GET /api/woche/<jahr>/<kw>,
GET und PUT /api/gleitzeit und /api/freizeit, PUT /api/tag, POST /api/tage, GET /api/planung, POST /api/planung/vorschau
und /api/planung, DELETE /api/planung/<von>_<bis>_<art>, POST /api/rueckgaengig und /api/rueckgaengig/ende;
dazu tag_speichern, tage_import, krank_phase, attest_fuer_phase.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import functools
import re
from datetime import date, datetime

from kern import bericht
from daten import konfig
from kern import notiz as notizen
from kern import planung
from kern import regeln
from daten import rueckgaengig
from daten import stempel
from kern import urlaub as ur
from kern import woche
from daten.db import Db
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _datum, _ganze_zahl, _text
from kern.regeln import ARTEN, notiz_bereinigen
from kern.zeit import fmt_hhmm, parse_hhmm

ERST_AB = "Angesparter Urlaub aus {herkunft} ist erst ab {ab} nutzbar (bis zur Frist gilt der Resturlaub)"

ORTE = ("ho", "dst", "beides")
# Texte der Rückgängig-Leiste (funktionen.md 1)
GESPEICHERT, GELEERT, GELOESCHT = "Gespeichert.", "Tag geleert.", "Zeitraum gelöscht."
EINGETRAGEN = "{n} {tage} {art} eingetragen."
AUSGEBUCHT = "Ausgebucht um {zeit:%H:%M} Uhr · {gebucht} Std. gebucht."
EINGEBUCHT = "Eingebucht um {start} Uhr · {ort}."
ORT_TEXT = {"ho": "Homeoffice", "dst": "Büro"}
VERMERK_FEHLER = "Vermerk: Dienstreise, Fortbildung oder leer"
GEPRUEFT_FEHLER = "Geprüft: 0 oder 1"


def _kommen_gehen(p: dict, ho, dst, d) -> tuple:
    """(kommen, gehen, pause, ho, dst): Mit Kommen und Gehen ergibt sich die Arbeitszeit aus Gehen − Kommen − Pause (leere Pause: Pausenregel des Tages)
    und geht je nach „ort“ ins Homeoffice, ins Büro oder geteilt („beides“: ho = HO-Anteil, der Rest Büro). Ohne Uhrzeit wie bisher."""
    try:
        kommen, gehen = parse_hhmm(p.get("kommen")), parse_hhmm(p.get("gehen"), 47)
        pause = parse_hhmm(p.get("pause"))
    except konfig.Meldung as e:
        raise Fehler(str(e))
    if kommen is None and gehen is None:
        return regeln.OHNE_UHRZEIT, regeln.OHNE_UHRZEIT, 0, ho, dst
    if kommen is None or gehen is None:
        raise Fehler("Kommen und Gehen bitte zusammen eintragen")
    try:
        pause, arbeit = regeln.arbeitszeit(kommen, gehen, pause, d)
    except konfig.Meldung as e:
        raise Fehler(str(e))
    ort = p.get("ort") or "ho"
    if ort not in ORTE:
        raise Fehler("Ort: Homeoffice, Büro oder beides")
    if ort == "beides":
        if (ho or 0) > arbeit:
            raise Fehler(f"Mehr Homeoffice ({fmt_hhmm(ho)}) als Arbeitszeit ({fmt_hhmm(arbeit)})")
        return kommen, gehen, pause, ho or 0, arbeit - (ho or 0)
    return kommen, gehen, pause, (arbeit if ort == "ho" else 0), (arbeit if ort == "dst" else 0)


def _arten_im_jahr(db: Db, d: date, buendel=None) -> dict:
    """{Datum: Art} der Tage im Jahr von d; beim Sammel-Import (buendel) zählen die Tage davor im selben Zug mit und ersetzen denselben Tag aus der Datenbank."""
    arten = {t.datum: t.art for t in db.tage(d.year)}
    if buendel is not None:
        arten.update({x[0]: x[3] for x in buendel if x[0].year == d.year})
    return arten


def _vermerk_geprueft(p: dict, alt) -> tuple:
    """(vermerk, geprueft) des Tages aus der Anfrage p; alt: der gespeicherte Tag oder None. Ohne Feld bleibt der gespeicherte Wert
    (Planen, Stempeln, alte Oberfläche). Fehler 400 bei einem Vermerk außerhalb von konfig.VERMERKE oder geprueft nicht 0 oder 1."""
    vermerk = p["vermerk"] if "vermerk" in p else (alt.vermerk if alt else "")
    geprueft = p["geprueft"] if "geprueft" in p else (alt.geprueft if alt else 0)
    if not isinstance(vermerk, str) or vermerk not in ("", *konfig.VERMERKE):
        raise Fehler(VERMERK_FEHLER)
    if isinstance(geprueft, bool) or not isinstance(geprueft, int) or geprueft not in (0, 1):
        raise Fehler(GEPRUEFT_FEHLER)
    return vermerk, geprueft


def tag_speichern(db: Db, p: dict, buendel=None) -> dict:
    """Prüft die Angaben eines Tages (Datum, Art, Zeiten, Vermerk, Attest, Gleittage, Familientage, Sonderurlaub, Kind krank, angesparter Urlaub)
        und speichert ihn. Mit „buendel“ wird nur vorgemerkt (Sammel-Import, Planen), sonst sofort geschrieben. Fehler 400 bei ungültigen Angaben."""
    d = _datum(p.get("datum"))
    art = _text(p.get("art"), "Art")
    if art not in ARTEN:
        raise Fehler(f"Unbekannte Art „{art}“")
    try:
        ho, dst = parse_hhmm(p.get("ho")), parse_hhmm(p.get("dst"))
    except konfig.Meldung as e:
        raise Fehler(str(e))
    kommen, gehen, pause, ho, dst = _kommen_gehen(p, ho, dst, d)
    alt = next((t for t in db.tage(d.year) if t.datum == d), None)
    vermerk, geprueft = _vermerk_geprueft(p, alt)
    notiz = notiz_bereinigen(str(p.get("notiz", "") or ""))[:regeln.NOTIZ_MAX]      # Steuerzeichen machen Word/ODT/XML-Exporte ungültig
    if notizen.ueberfluessig(art, notiz, vermerk):
        notiz = ""
    attest = str(p.get("attest", "") or "")
    if attest:
        _datum(attest)
        if art not in regeln.KRANK:
            attest = ""
    konto = 0
    if art == "freizeit":
        if not regeln.ist_soll_tag(d, set(db.jahr_einstellung(d.year)["eigene_frei"]), db.abschnitte()):
            raise Fehler("Freizeitausgleich nur an Arbeitstagen (nicht am Wochenende, an Feiertagen oder freien Tagen)")
    if art in ("gleittag", "familientag"):
        grenze = regeln.gleittage_max(d.year) if art == "gleittag" else regeln.familientage_max(d.year)
        if art == "familientag" and not bericht.familientage_aktiv(db, d.year):
            raise Fehler(f"Familientage sind für {d.year} nicht aktiviert (unter „{konfig.urlaub_seite()} → Erweitert“ einschalten)")
        arten = _arten_im_jahr(db, d, buendel)
        bisher = sum(1 for k, a in arten.items() if a == art and k != d)
        if bisher >= grenze:
            raise Fehler(f"Höchstens {grenze} {'Gleittage' if art == 'gleittag' else 'Familientage'} pro Jahr ({d.year}: schon {bisher} eingetragen)")
    if art in regeln.GANZE_TAGE:
        try:
            regeln.ganzen_tag_pruefen(d, art, (ho or 0) + (dst or 0), set(db.jahr_einstellung(d.year)["eigene_frei"]), db.abschnitte(),
                                      _arten_im_jahr(db, d, buendel), db.startwerte_lesen())
        except konfig.Meldung as e:
            raise Fehler(str(e))
    if art == "angespart":
        genommen = bericht.angespart_genommen(db, ohne=d)
        for x in buendel or ():                         # Planen in einem Zug: die Tage davor zählen mit, sonst bekäme jeder Tag dasselbe Konto
            if x[3] == "angespart" and x[5]:
                genommen[x[5]] = genommen.get(x[5], 0) + 1
        alle = bericht.konten(db, d.year)
        verf = ur.buchbar(alle, d, genommen)
        spaeter = ur.erst_ab(alle, d, genommen)
        try:
            wunsch = int(p.get("konto") or 0)
        except (TypeError, ValueError):
            raise Fehler("Konto: Herkunftsjahr als Zahl")
        if wunsch:
            if wunsch not in verf:
                if spaeter and spaeter.herkunft == wunsch:
                    raise Fehler(ERST_AB.format(herkunft=wunsch, ab=spaeter.zuschlag_ab.strftime("%d.%m.%Y")))
                raise Fehler(f"Konto {wunsch} hat keinen freien Tag für {d.year}")
            konto = wunsch
        else:
            konto = ur.naechstes_konto(verf)
            if konto is None and spaeter:
                raise Fehler(ERST_AB.format(herkunft=spaeter.herkunft, ab=spaeter.zuschlag_ab.strftime("%d.%m.%Y")))
            if konto is None:
                raise Fehler(f"Kein angesparter Urlaub verfügbar (unter „{konfig.urlaub_seite()} → Erweitert“ ein Konto anlegen)")
    if (ho or 0) + (dst or 0) > regeln.TAG_MIN:
        raise Fehler(f"{regeln.TAG_VOLL}; eingetragen wären {fmt_hhmm((ho or 0) + (dst or 0))} am {d.strftime('%d.%m.%Y')}")
    freigabe = 1 if p.get("freigabe") else 0
    if (ho or 0) + (dst or 0) > regeln.MAX_TAG_MIN and not freigabe:
        raise Fehler(f"Mehr als 10 Stunden an einem Tag gehen nur mit Freigabe („Über 10 Stunden freigegeben“ ankreuzen). Eingetragen wären {fmt_hhmm((ho or 0) + (dst or 0))}.")
    if buendel is not None:
        buendel.append((d, ho or 0, dst or 0, art, notiz, konto, attest, freigabe, kommen, gehen, pause, vermerk, geprueft))
        return {"ok": True}
    db.tag_setzen(d, ho or 0, dst or 0, art, notiz, konto, attest, freigabe, kommen, gehen, pause, vermerk, geprueft)
    if art in regeln.KRANK and (attest or (alt and alt.attest)):
        attest_fuer_phase(db, d, attest)       # Attest gilt für alle zusammenhängenden Kranktage; Löschen räumt die ganze Phase
    return {"ok": True, "konto": konto}


def krank_phase(db: Db, d: date) -> list:
    """Alle Krank-Tage (ohne „Krank im Dienst“) in einer Folge mit d, getrennt wie die Zeiträume der Übersicht (regeln.unterbricht_krank):
    ein Arbeitstag laut Abschnitt oder ein Werktag in Elternzeit mit 0 h ohne Krank-Eintrag trennt; Wochenenden, freie Tage und der freie Tag
    bei Teilzeit nicht. Eingaben: Db, Tag d. Rückgabe: sortierte Tage der Phase, mindestens [d]. Gesucht wird im Vorjahr, im Jahr und im Folgejahr von d.
    Keine Fehler."""
    jahre = (d.year - 1, d.year, d.year + 1)
    krank = {t.datum for j in jahre for t in db.tage(j) if t.art in regeln.KRANK} | {d}
    trenner = functools.partial(regeln.unterbricht_krank, eigene=bericht.eigene_frei(db, jahre), abschnitte=db.abschnitte())
    gruppen = regeln.zeitraeume_bilden(sorted(krank), trenner)
    return next(g for g in gruppen if d in g)


def attest_fuer_phase(db: Db, d: date, attest: str) -> None:
    """Setzt oder entfernt das Attest für alle Tage der Krankheitsphase, zu der der Tag „d“ gehört."""
    jahre = (d.year - 1, d.year, d.year + 1)
    tage = {t.datum: t for j in jahre for t in db.tage(j)}
    for x in krank_phase(db, d):
        t = tage[x]
        db.tag_setzen(x, t.ho, t.dst, regeln.KRANK_ATTEST if attest else "krank", t.notiz, t.konto, attest, t.freigabe, t.kommen, t.gehen, t.pause, t.vermerk, t.geprueft)


def tage_import(db: Db, p: dict) -> dict:
    """Viele Tage in einem Zug speichern (Sammel-Import). Prüft alle Tage zuerst, schreibt erst dann in einer Transaktion."""
    liste = p.get("tage")
    if not isinstance(liste, list) or len(liste) > 20000:
        raise Fehler("tage: Liste mit höchstens 20000 Einträgen erwartet")
    buendel = []
    for t in liste:
        if not isinstance(t, dict):
            raise Fehler("tage: jeder Eintrag muss ein Objekt sein")
        if (t.get("art") or "") == "angespart":
            raise Fehler("Beim Sammel-Import ist „Angesparter Urlaub“ nicht erlaubt")
        tag_speichern(db, t, buendel)
    db.tage_setzen(buendel)
    return {"ok": True, "tage": len(buendel)}


def _merken(db: Db, text: str, aufnahme: dict, stempel_alt: dict = None):
    """Merkt das Rückgängig einer Aktion (rueckgaengig.merken), ohne die Tage, die sie geschrieben, aber nicht verändert hat.
    Eingaben: Text der Leiste, {iso: (vorher, nachher)} aus db.aufnahme(), beim Gehen die alte Stempeluhr. Rückgabe: {"id", "text"} oder None."""
    return rueckgaengig.merken(db, text, {iso: paar for iso, paar in aufnahme.items() if paar[0] != paar[1]}, stempel_alt)


def tag_mit_rueckgaengig(db: Db, p: dict) -> dict:
    """PUT /api/tag: speichert den Tag wie tag_speichern und merkt das Rückgängig, auch für die Tage der Krank-Phase, deren Attest mitgeändert wurde.
    Rückgabe: wie tag_speichern, dazu "rueckgaengig" ({"id", "text"} oder None). Fehler 400 wie tag_speichern; dann ist nichts gemerkt."""
    with db.aufnahme() as aufnahme:
        r = tag_speichern(db, p)
    geleert = aufnahme.get(_datum(p.get("datum")).isoformat(), (None, None))[1] is None
    return {**r, "rueckgaengig": _merken(db, GELEERT if geleert else GESPEICHERT, aufnahme)}


def planen(db: Db, art: str, vorschau: dict) -> dict:
    """POST /api/planung: trägt die Tage der Vorschau in einer Transaktion ein (scheitert ein Tag, ist nichts geschrieben) und merkt das Rückgängig.
    Rückgabe: {"ok", "eingetragen", "uebersprungen", "rueckgaengig"}. Fehler 400 aus tag_speichern."""
    buendel, notiz = [], {t.datum.isoformat(): t.notiz for t in db.tage_alle() if t.notiz}     # Plan-Tage tragen höchstens eine Notiz, die bleibt
    with db.aufnahme() as aufnahme:
        for iso in vorschau["neu"]:
            tag_speichern(db, {"datum": iso, "art": art, "notiz": notiz.get(iso, "")}, buendel)
        if buendel:
            db.tage_setzen(buendel)
    text = EINGETRAGEN.format(n=len(buendel), tage="Tag" if len(buendel) == 1 else "Tage", art=planung.PLAN_ARTEN[art])
    return {"ok": True, "eingetragen": len(buendel), "uebersprungen": vorschau["uebersprungen"], "rueckgaengig": _merken(db, text, aufnahme)}


def zeitraum_loeschen(db: Db, von: date, bis: date, art: str) -> dict:
    """DELETE /api/planung/…: löscht die Tage der Art im Zeitraum in einer Transaktion und merkt das Rückgängig. Notiz, Vermerk und „geprüft“ bleiben,
    ein Tag mit Notiz oder Vermerk bleibt also ohne Art stehen. Rückgabe: {"ok", "geloescht", "rueckgaengig"}."""
    ohne = regeln.OHNE_UHRZEIT
    zeilen = [(t.datum, 0, 0, "", t.notiz, 0, "", 0, ohne, ohne, 0, t.vermerk, t.geprueft) for t in db.tage_alle() if von <= t.datum <= bis and t.art == art]
    with db.aufnahme() as aufnahme:
        if zeilen:
            db.tage_setzen(zeilen)
    return {"ok": True, "geloescht": len(zeilen), "rueckgaengig": _merken(db, GELOESCHT, aufnahme)}


def ausbuchen(db: Db, b: dict, jetzt: datetime) -> dict:
    """POST /api/stempel mit „stop“: bucht die laufende Zeit (stempel.stop) und merkt das Rückgängig samt der alten Stempeluhr.
    Rückgabe: wie stempel.stop, dazu "rueckgaengig". Fehler: StempelFehler, ValueError (die Route meldet sie als 400)."""
    uhr = db.stempel_lesen()
    pause = None if b.get("pause") in (None, "") else _ganze_zahl(b["pause"], "Pause (Minuten)")
    with db.aufnahme() as aufnahme:
        r = stempel.stop(db, jetzt, str(b.get("ende") or ""), pause, b.get("art") or "", bool(b.get("freigabe")))
    return {**r, "rueckgaengig": _merken(db, AUSGEBUCHT.format(zeit=jetzt, gebucht=r["gebucht"]), aufnahme, uhr)}


def einbuchen(db: Db, b: dict, jetzt: datetime) -> dict:
    """POST /api/stempel mit „start“: startet die Uhr (stempel.start) und merkt das Rückgängig, das sie wieder anhält; die Tage bleiben, wie sie sind.
    Rückgabe: wie stempel.start, dazu "rueckgaengig". Fehler: StempelFehler (die Route meldet sie als 400); dann bleibt ein offenes Rückgängig stehen."""
    r = stempel.start(db, b.get("art") or "ho", jetzt, str(b.get("beginn") or ""))
    text = EINGEBUCHT.format(start=r["start_text"], ort=ORT_TEXT[r["art"]])
    return {**r, "rueckgaengig": rueckgaengig.merken(db, text, {}, stempel_neu=db.stempel_lesen())}


class ZeitenRouten:
    """Routen für Stempeluhr, Woche, Gleitzeit, Freizeit, Tage, Planung und Rückgängig; Teil der Klasse Handler (Mixin)."""

    def _routen_zeiten(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        # Stempeluhr
        if p == "/api/stempel":
            jetzt = datetime.now().replace(microsecond=0)
            if m == "GET":
                return stempel.status(db, jetzt)
            if m == "POST":
                b = self._body()
                aktion = b.get("aktion")
                try:
                    if aktion == "start":
                        return einbuchen(db, b, jetzt)
                    if aktion == "stop":
                        return ausbuchen(db, b, jetzt)
                    if aktion == "verwerfen":
                        return stempel.verwerfen(db, jetzt)
                except konfig.Meldung as e:                 # StempelFehler und Meldungen des Rechenkerns
                    raise Fehler(str(e))
                raise Fehler("Unbekannte Aktion der Stempeluhr. Möglich: start, stop, verwerfen")
        # Wochenansicht und Gleitzeit-Konto
        g = re.fullmatch(r"/api/woche/(\d{4})/(\d{1,2})", p)
        if m == "GET" and g:
            try:
                return bericht.woche(db, int(g[1]), int(g[2]), konfig.CFG["zeitformat"])
            except konfig.Meldung as e:
                raise Fehler(str(e))
        if p == "/api/gleitzeit":
            if m == "GET":
                return bericht.gleitzeit(db, konfig.CFG["zeitformat"])
            if m == "PUT":
                b = self._body()
                mm = re.fullmatch(r"([+\-−]?)\s*(\d{1,3}):([0-5]\d)", str(b.get("stand", "")).strip())
                if not mm:
                    raise Fehler("Stand: Format hh:mm, zum Beispiel 57:40 oder -03:15")
                stand, vorz = int(mm[2]) * 60 + int(mm[3]), (-1 if mm[1] in ("-", "−") else 1)
                try:
                    woche.stand_setzen(db, vorz * stand, _datum(b.get("datum") or date.today().isoformat()))
                except konfig.KonfigFehler as e:            # Datum vor „Erfassung gültig ab“, Konto über der Grenze; andere Fehler ohne Text (500)
                    raise Fehler(str(e))
                return bericht.gleitzeit(db, konfig.CFG["zeitformat"])
        if m == "PUT" and p == "/api/tag":
            return tag_mit_rueckgaengig(db, self._body())
        if m == "POST" and p == "/api/tage":
            return tage_import(db, self._body())
        if p == "/api/freizeit":
            if m == "GET":
                return bericht.gleitzeit(db, konfig.CFG["zeitformat"])
            if m == "PUT":
                b = self._body()
                mm = re.fullmatch(r"([+\-−]?)\s*(\d{1,3}):([0-5]\d)", str(b.get("stand", "")).strip())
                if not mm:
                    raise Fehler("Stand: Format hh:mm, zum Beispiel 12:30 oder -02:00")
                try:
                    woche.freizeit_stand_setzen(db, (-1 if mm[1] in ("-", "−") else 1) * (int(mm[2]) * 60 + int(mm[3])), _datum(b.get("datum") or date.today().isoformat()))
                except konfig.KonfigFehler as e:            # Datum vor „Erfassung gültig ab“, Konto über der Grenze; andere Fehler ohne Text (500)
                    raise Fehler(str(e))
                return bericht.gleitzeit(db, konfig.CFG["zeitformat"])
        # Urlaubsplanung: künftige Urlaubs-/Gleit-/Familientage (normale Tageseinträge)
        if m == "GET" and p == "/api/planung":
            return {"zeitraeume": planung.zeitraeume(db)}
        if m == "POST" and p in ("/api/planung/vorschau", "/api/planung"):
            b = self._body()
            art, von, bis = _text(b.get("art"), "Art"), _datum(b.get("von")), _datum(b.get("bis") or b.get("von"))
            try:
                v = planung.vorschau(db, art, von, bis)
            except planung.PlanFehler as e:
                raise Fehler(str(e))
            if p.endswith("vorschau"):
                return v
            if v["gesperrt"]:
                raise Fehler(next(x["warnung"] for x in v["jahre"] if x["gesperrt"]))
            return planen(db, art, v)
        g = re.fullmatch(r"/api/planung/(\d{4}-\d{2}-\d{2})_(\d{4}-\d{2}-\d{2})_(\w+)", p)
        if m == "DELETE" and g:
            von, bis, art = _datum(g[1]), _datum(g[2]), g[3]
            if art not in planung.PLAN_ARTEN or von < date.today():
                raise Fehler("Nur künftige Plan-Tage können gelöscht werden")
            return zeitraum_loeschen(db, von, bis, art)
        # Rückgängig der letzten Aktion (eine Stufe, nur im Speicher des Dienstes)
        if m == "POST" and p == "/api/rueckgaengig":
            try:
                return rueckgaengig.anwenden(db, self._body().get("id"))
            except rueckgaengig.RueckgaengigFehler as e:
                raise Fehler(str(e), e.status)
        if m == "POST" and p == "/api/rueckgaengig/ende":
            rueckgaengig.ende(db, self._body().get("id"))
            return {"ok": True}
        return NICHT_ZUSTAENDIG
