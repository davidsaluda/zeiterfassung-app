# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen des Urlaubs (aus server.py geschnitten, Runde 1.4): GET /api/urlaub/<jahr>, PUT /api/urlaub, PUT /api/familientage,
GET /api/jahreswechsel, POST /api/jahreswechsel/ansparen und /erledigt;
dazu urlaub_speichern.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import re
from datetime import date

from daten import konfig
from kern import bericht
from kern import regeln
from kern import urlaub as ur
from kern import zutun
from daten.db import Db, RESTURLAUB_BEHALTEN
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _datum, _jahr, _zahl

JAHRESWECHSEL_WEGE = ("/api/jahreswechsel/ansparen", "/api/jahreswechsel/erledigt")
EIGENE_FREI_MAX = 366                                        # Einträge in eigene_frei (ein Jahr)
EIGENE_FREI_FORM = "eigene_frei: Liste mit höchstens 366 Tagen, je Tag ein Datum oder {datum, name}"
EIGENE_FREI_NAME = f"Name eines freien Tags: höchstens {konfig.FEIERTAG_NAME_MAX} Zeichen, ohne Steuerzeichen"


def _frei_eintrag(x) -> tuple:
    """Ein Eintrag aus eigene_frei: Datumstext -> (Datum, None = Name bleibt), {"datum", "name"} -> (Datum, Name ohne Rand). Fehler 400 sonst."""
    name = None
    if isinstance(x, dict):
        if set(x) != {"datum", "name"} or not isinstance(x["name"], str):
            raise Fehler(EIGENE_FREI_FORM)
        x, name = x["datum"], x["name"].strip()
        if len(name) > konfig.FEIERTAG_NAME_MAX or konfig.STEUERZEICHEN.search(name):
            raise Fehler(EIGENE_FREI_NAME)
    if not isinstance(x, str):                               # date.fromisoformat nähme auch die Zahl 20310509
        raise Fehler(EIGENE_FREI_FORM)
    return _datum(x), name


def _eigene_frei(db: Db, jahr: int, p: dict) -> tuple:
    """Einmalige eigene freie Tage der Anfrage (R4b): Liste aus Datumstexten oder {"datum", "name"} (Name bis konfig.FEIERTAG_NAME_MAX Zeichen,
    ohne Steuerzeichen, "" = ohne Namen). Rückgabe (Daten, {Datum: Name}); ein Text behält den gespeicherten Namen. Fehlt „eigene_frei“,
    bleiben die gespeicherten Tage samt Namen (U18: PUT /api/urlaub schreibt das ganze Jahr). Fehler 400 bei jeder anderen Form."""
    namen = {x["datum"]: x["name"] for x in db.eigene_feiertage(jahr)}
    if "eigene_frei" not in p:
        return list(namen), namen
    liste = p["eigene_frei"]
    if not isinstance(liste, list) or len(liste) > EIGENE_FREI_MAX:
        raise Fehler(EIGENE_FREI_FORM)
    frei = []
    for x in liste:
        datum, name = _frei_eintrag(x)
        frei.append(datum)
        if name is not None:
            namen[datum] = name
    return frei, namen


def urlaub_speichern(db: Db, p: dict) -> dict:
    # erst alles prüfen, dann schreiben (kein halb gespeicherter Stand bei einem Fehler)
    """Speichert die Urlaubsangaben eines Jahres (Anspruch, eigene freie Tage, Übertrag …). Prüft zuerst alles; Fehler 400 bei ungültigen Werten."""
    jahr = _jahr(p.get("jahr"))
    anspruch = _zahl(p.get("anspruch", db.jahr_einstellung(jahr)["anspruch"]), "Anspruch")   # ohne Angabe: eigener Wert des Jahres, sonst Regel „Urlaubstage pro Jahr“
    if not 0 <= anspruch <= regeln.ANSPRUCH_MAX:
        raise Fehler(f"Anspruch: 0 bis {regeln.ANSPRUCH_MAX} Tage")
    frei, namen = _eigene_frei(db, jahr, p)
    if "resturlaub_behalten" in p and not isinstance(p["resturlaub_behalten"], bool):
        raise Fehler("Resturlaub behalten: an oder aus")
    uebertrag = None
    if p.get("uebertrag") not in (None, ""):
        uebertrag = _zahl(p["uebertrag"], "Übertrag")
        if not 0 <= uebertrag <= regeln.UEBERTRAG_MAX:
            raise Fehler(f"Übertrag: 0 bis {regeln.UEBERTRAG_MAX} Tage")
    konten = []
    if "konten" in p:
        if not isinstance(p["konten"], list) or len(p["konten"]) > 50:
            raise Fehler("konten: Liste erwartet")
        for k in p["konten"]:
            if not isinstance(k, dict):
                raise Fehler("konten: jeder Eintrag muss ein Objekt sein")
            herkunft, tage = _jahr(k.get("herkunft")), _zahl(k.get("tage"), "Tage")
            try:
                ur.pruefe_konto(herkunft, tage)
            except konfig.Meldung as e:
                raise Fehler(str(e))
            konten.append((herkunft, tage))
    db.jahr_setzen(jahr, anspruch, frei, namen)
    if "resturlaub_behalten" in p:
        db.meta_setzen(RESTURLAUB_BEHALTEN.format(jahr), "1" if p["resturlaub_behalten"] else "0")
    if "uebertrag" in p:
        db.uebertrag_setzen(jahr, uebertrag)
    for herkunft, tage in konten:
        db.konto_setzen(herkunft, tage)
    return {"ok": True}


class UrlaubRouten:
    """Routen für Urlaub und Familientage; Teil der Klasse Handler (Mixin)."""

    def _routen_urlaub(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if p == "/api/familientage" and m == "PUT":
            b = self._body()
            j = _jahr(b.get("jahr"))
            aktiv = bool(b.get("aktiv"))
            if not aktiv and any(t.art == "familientag" for t in db.tage(j)):
                raise Fehler(f"Für {j} sind noch Familientage eingetragen. Bitte erst diese Tage ändern.")
            db.meta_setzen(f"familientage_{j}", "1" if aktiv else "0")
            return {"jahr": j, "aktiv": aktiv}
        g = re.fullmatch(r"/api/urlaub/(\d{4})", p)
        if m == "GET" and g:
            return {**bericht.urlaub_stand(db, int(g[1])), "brueckentage": bericht.brueckentage(db, int(g[1]))}
        if m == "PUT" and p == "/api/urlaub":
            return urlaub_speichern(db, self._body())
        if p == "/api/jahreswechsel" or p.startswith("/api/jahreswechsel/"):
            return self._jahreswechsel(m, p, db, demo_an)
        return NICHT_ZUSTAENDIG

    def _jahreswechsel(self, m, p, db, demo_an):
        """Jahreswechsel-Helfer (funktionen.md 4): GET /api/jahreswechsel (Karte oder null; in der Demo immer null),
        POST /api/jahreswechsel/ansparen {"tage": ganze Zahl}, POST /api/jahreswechsel/erledigt {"id": Schritt oder "aus"}. Fehler 400 bei falscher Eingabe."""
        if m == "GET" and p == "/api/jahreswechsel":
            self._senden(200, None if demo_an else zutun.jahreswechsel(db, date.today(), self._zutun_stand()))
            return None
        if m != "POST" or p not in JAHRESWECHSEL_WEGE:
            return NICHT_ZUSTAENDIG
        b = self._body()
        try:
            if p == "/api/jahreswechsel/ansparen":
                return zutun.jahreswechsel_ansparen(db, date.today(), b.get("tage"))
            db.jahreswechsel_abhaken(date.today().year - 1, b.get("id"))
        except konfig.Meldung as e:                           # AnsparFehler, KonfigFehler; andere ValueError: allgemeine Meldung (server)
            raise Fehler(str(e))
        return {"ok": True}
