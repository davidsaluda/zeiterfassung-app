# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Ziele der Synchronisierung (aus server.py geschnitten, Runde 1.4): eigenes GitHub-Repo, Server hinter dem Anmeldedienst (Anmeldung mit
Benutzername und Passwort, nur der Geräte-Schlüssel wird gemerkt), eigene Ablage und Ablage-Ordner mit Prüfsummen."""
import hashlib
import hmac
import os
import re
import socket

from daten import sicherung
from routen.eingabe import Fehler, MIT_ADRESSE, plattform

ABLAGE_GERAETE = 20                                          # so viele Sync-Dateien nimmt die Ablage des Servers höchstens an
ADRESSE = re.compile(r"https?://[A-Za-z0-9.\-]+(:\d{1,5})?/?")  # Adresse des eigenen Servers für den Sync (Desktop)
ANMELDE_MAX = 200                                         # längster Benutzername für die Anmeldung am Anmeldedienst
NICHT_ERREICHBAR = "Unter dieser Adresse antwortet die Zeiterfassung nicht. Bitte Adresse und Verbindung prüfen."


def _github_angaben(w) -> tuple:
    """Repo und Token, wenn beide wie bei GitHub aussehen (sonst ValueError). Geprüft wird die ganze Zeichenkette: nichts, was Adresse oder Kopfzeile verändert."""
    if not isinstance(w, dict) or not isinstance(w.get("repo"), str) or not isinstance(w.get("token"), str):
        raise ValueError
    repo, token = w["repo"].strip(), w["token"].strip()
    if not sicherung.GITHUB_REPO.fullmatch(repo) or not sicherung.GITHUB_TOKEN.fullmatch(token):
        raise ValueError
    return repo, token


def github_verbinden(w) -> dict:
    """Die Angaben für geraet.json: verbinden (nach einer Probe bei GitHub) oder trennen (None)."""
    if w is None:
        return {"github_repo": "", "github_token": "", "github_privat": True}
    try:
        repo, token = _github_angaben(w)
    except ValueError:
        raise Fehler("GitHub: das Repo als konto/name angeben (zum Beispiel ich/zeiterfassung-daten) und das Token ganz einfügen")
    try:
        probe = sicherung.GitHubZiel(repo, token).pruefen()
    except FileNotFoundError:
        raise Fehler("Dieses Repo gibt es bei GitHub nicht, oder das Token darf es nicht sehen.")
    except OSError:
        raise Fehler("GitHub ist nicht erreichbar oder lehnt das Token ab. Bitte Verbindung und Token prüfen.")
    if not probe["schreiben"]:
        raise Fehler("Das Token darf in dieses Repo nicht schreiben. Es braucht für dieses Repo die Berechtigung „Contents: Read and write“.")
    return {"github_repo": repo, "github_token": token, "github_privat": probe["privat"], "abgleich_auto": True}     # verbunden heißt: synchronisiert von selbst


def github_ziel(daten: str, pruefen: bool = False, warten: float = None):
    """GitHub als Speicherort, wenn ein Repo verbunden ist. pruefen (Automatik): nur, wenn es gerade erreichbar ist (unterwegs ohne Netz: kein Fehler).
    warten: kürzere Zeitgrenze je Anfrage in Sekunden (Abmelden vor den Werkseinstellungen), sonst die Vorgabe des Ziels."""
    g = sicherung.geraet_lesen(daten)
    if not g["github_repo"] or not g["github_token"]:
        return None
    ziel = sicherung.GitHubZiel(g["github_repo"], g["github_token"])
    ziel.warten = warten or ziel.warten
    if pruefen:
        try:
            ziel.sync_namen()
        except OSError:
            return None
    return ziel


_summen = {}                                               # (Ordner, Name, Datei, Zeit, Größe) -> SHA-256


def _ablage_liste(ziel, namen) -> list:
    """Liste der Ablage mit Prüfsummen. Eine Datei, die währenddessen verschwindet (ein Gerät meldet sich ab), fehlt nur selbst in der Liste."""
    liste = []
    for n in namen:
        try:
            liste.append({"name": n, "summe": _ablage_summe(ziel, n)})
        except FileNotFoundError:
            continue
    return liste


def _ablage_summe(ziel, name: str) -> str:
    """Prüfsumme einer Datei der Ablage, gemerkt je Stand der Datei: Die Liste soll nicht bei jedem Abruf alle Dateien (bis 8 MB je Gerät) lesen."""
    st = os.stat(os.path.join(ziel.ordner, name))
    stand = (ziel.ordner, name, st.st_ino, st.st_mtime_ns, st.st_size)
    summe = _summen.get(stand)                              # lokal halten: ein anderer Faden kann den Merker dazwischen leeren
    if summe is None:
        if len(_summen) > 4 * ABLAGE_GERAETE:
            _summen.clear()
        summe = _summen[stand] = hashlib.sha256(ziel.lesen(name)).hexdigest()
    return summe


def schreiben_pruefen(daten: str, ziel, name: str, roh: bytes, nachweis):
    """Darf diese Datei unter diesem Namen in die Ablage (seit 21.11.2026, Befund klein 5)? Ja, wenn der Nachweis mit dem Schlüssel dieses Hosts
    stimmt (der Schreiber kennt das Passwort). Ohne Passwort auf dem Host gibt es nichts zu prüfen (Stand vorher; 8793 öffnet dann nicht,
    anschluesse.FREIGABE_OHNE_PASSWORT). Seit 22.11.2026 (Entscheidung) kein anderer Weg mehr, auch nicht für ältere Geräte ohne Feld „nachweis“: Gekoppelte kennen den Schlüssel des Hosts, alle anderen
    fragen nach dem Passwort. Fehler(ABLAGE_NACHWEIS, 403) sonst; dann bleibt alles, wie es war."""
    g = sicherung.geraet_lesen(daten)
    if not g["schluessel"]:
        return
    vorher = _vorhanden(ziel, name)
    summe = hashlib.sha256(vorher).hexdigest() if vorher is not None else ""
    erwartet = sicherung.schreib_nachweis(bytes.fromhex(g["schluessel"]), bytes.fromhex(g["salz"]), name, roh, summe)
    if isinstance(nachweis, str) and nachweis.isascii() and hmac.compare_digest(erwartet, nachweis):   # compare_digest nimmt nur ASCII-Text
        return
    raise Fehler(sicherung.ABLAGE_NACHWEIS, 403, sicherung.NACHWEIS_KENNUNG)


def _vorhanden(ziel, name: str):
    """Die Datei, die unter diesem Namen schon in der Ablage liegt (frisch gelesen, nicht aus dem Merker der Liste), sonst None."""
    try:
        return ziel.lesen(name)
    except ValueError:                                     # noch keine Datei unter diesem Namen (SicherungFehler)
        return None


def eigene_ablage(daten: str):
    """Die Ablage einer lokalen App, die sich als Speicherort freigibt (derselbe Ordner wie auf dem Server)."""
    ziel = ablage_des_servers(daten)
    ziel.merk = "ablage:"
    return ziel


def ablage_des_servers(daten: str):
    """Der Ordner, in dem der Server die Synchronisierungsdateien aller Geräte hält (und seine eigene)."""
    ordner = os.path.join(daten, "abgleich")
    os.makedirs(ordner, exist_ok=True)
    return sicherung.OrdnerZiel(ordner, "lokal")


def adresse_vervollstaendigen(adresse: str) -> str:
    """Server-Adresse ohne Schrägstrich am Ende; ohne Schema (nur Name oder IP) gilt https, weil Anmeldung und Schlüssel nur dort erlaubt sind."""
    adresse = adresse.strip().rstrip("/")
    return adresse if not adresse or "://" in adresse else "https://" + adresse


def ablage_einrichten(daten: str, adresse: str, benutzer: str = "", passwort: str = "") -> dict:
    """Prüft die Server-Adresse und gibt die Felder für geraet.json zurück. Verlangt der Anmeldedienst davor eine Anmeldung, meldet sich dieses Gerät
    mit Benutzername und Passwort an (POST /pfoertner/geraet) und merkt sich nur den Geräte-Schlüssel; das Passwort wird verworfen.
    Ein gültiger Schlüssel für dieselbe Adresse bleibt. Fehler: Fehler mit Text für die Person (nie Schlüssel oder Passwort)."""
    adresse = adresse_vervollstaendigen(adresse)
    if not adresse:
        return {"ablage_adresse": ""}
    g = sicherung.geraet_lesen(daten)
    alt = g["ablage_schluessel"] if g["ablage_adresse"] == adresse else ""
    ziel = sicherung.NetzZiel(adresse, schluessel=alt)
    try:                                                     # jetzt prüfen: Später gilt „nicht erreichbar“ als „unterwegs“ und bleibt stumm
        try:
            ziel.sync_namen()
            return {"ablage_adresse": adresse, "ablage_schluessel": alt, "ablage_geraet": g["ablage_geraet"] if alt else "", "ablage_fehler": ""}
        except sicherung.AnmeldeFehler as e:
            if e.grund not in sicherung.ANMELDUNG_RUHT or not (benutzer and passwort):
                raise
        if not sicherung.bearer_erlaubt(adresse):
            raise Fehler(sicherung.NUR_HTTPS)
        name = f"{plattform()} {socket.gethostname()}"[:sicherung.GERAETE_NAME_MAX]
        ziel.schluessel = ziel.anmelden(benutzer, passwort, name)
        ziel.sync_namen()
    except (sicherung.NurIpFehler, sicherung.AnmeldeFehler) as e:
        raise Fehler(str(e))
    except OSError:
        raise Fehler(NICHT_ERREICHBAR)
    return {"ablage_adresse": adresse, "ablage_schluessel": ziel.schluessel, "ablage_geraet": name, "ablage_fehler": ""}


def netz_ziel(daten: str, warten: float = None):
    """Desktop und Handy: der eigene Server als zweite Speicherort, wenn eine Adresse eingetragen und er gerade erreichbar ist (unterwegs ist er
    das nicht: kein Fehler). Lässt der Anmeldedienst das Gerät nicht herein, steht der Grund in ablage_fehler (Wolke rot); nach „anmeldung“ oder
    „geraet-ungueltig“ fragt die Automatik den Server erst nach einer neuen Anmeldung wieder. warten: kürzere Zeitgrenze je Anfrage in Sekunden."""
    g = sicherung.geraet_lesen(daten)
    adresse = g["ablage_adresse"] if plattform() in MIT_ADRESSE else ""
    if not adresse or g["ablage_fehler"] in sicherung.ANMELDUNG_RUHT:
        return None
    ziel = sicherung.NetzZiel(adresse, schluessel=g["ablage_schluessel"])
    ziel.warten = warten or ziel.warten
    try:
        ziel.sync_namen()
    except sicherung.AnmeldeFehler as e:
        sicherung.geraet_aendern(daten, ablage_fehler=e.grund)
        return None
    except OSError:
        return None
    if g["ablage_fehler"]:
        sicherung.geraet_aendern(daten, ablage_fehler="")
    return ziel
