# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen des Exports (aus server.py geschnitten, Runde 1.4): GET /api/zeitraeume, GET /api/planung/<von>_<bis>,….ics,
GET /api/kalender[/<jahr>[/<monat>]].ics, GET /api/export.json (nur Daten der Seite Export, kein Download) und .csv (Download), GET /api/monatsnachweis/<jahr>/<monat>[[/mit-zeiten].pdf|.docx]
und GET/PUT /api/nachweiskopf.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import re
import urllib.parse
from datetime import date

from ausgabe import dokument
from ausgabe import export as exportformat
from daten import db as dbmod
from daten import konfig
from kern import planung
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _jahr
from kern.feiertage import ist_frei
from kern.regeln import notiz_bereinigen

KALENDER_ARTEN_FEHLER = "Kalender: mindestens eine bekannte Art wählen"
NACHWEIS_TYPEN = {"pdf": "application/pdf", "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
# „/mit-zeiten“ nur mit Endung: Die Vorschau (JSON) enthält Kommen, Gehen und Pause immer
NACHWEIS_PFAD = re.compile(r"/api/monatsnachweis/(\d{4})/(\d{1,2})(?:(/mit-zeiten)?\.(pdf|docx))?")
# Abfrage der Unterschrift (?name=…&datum=…&ort=…&zweite=…&vorgesetzt=…): Name und eigenes Datum gelten nur für einen Nachweis; Ort, Wahl und zweite
# Unterschrift trägt der Link, solange ihr Speichern noch läuft (Klick direkt nach dem Ändern). Fehlt ein Wert, gelten die Personendaten.
NACHWEIS_ABFRAGE_TEXT = ("name", "ort", "vorgesetzt")
NACHWEIS_ABFRAGE_FEHLER = "Unterschrift: ungültige Angabe"


class ExportRouten:
    """Routen für Zeiträume, Kalender (.ics) und Export; Teil der Klasse Handler (Mixin)."""

    def _routen_export(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if m == "GET" and p == "/api/zeitraeume":            # Monate mit Einträgen, neueste zuerst: Der Export bietet nur diese an
            return {"monate": sorted({t.datum.isoformat()[:7] for t in db.tage_alle()}, reverse=True)}
        g = re.fullmatch(r"/api/planung/([\d_,\-]+)\.ics", p)
        if m == "GET" and g:                                  # nur die angehakten Zeiträume als Kalender
            try:
                tage = planung.auswahl_tage(db, g[1])
            except planung.PlanFehler as e:
                raise Fehler(str(e))
            eigene = {}

            def frei_p(d):
                """True, wenn der Tag frei ist (Wochenende, Feiertag oder eigener freier Tag)."""
                if d.year not in eigene:
                    eigene[d.year] = set(db.jahr_einstellung(d.year)["eigene_frei"])
                return ist_frei(d, eigene[d.year])
            self._senden(200, exportformat.kalender_ics(tage, frei_p), "text/calendar; charset=utf-8", self._kalender_kopf("zeiterfassung-planung.ics"))
            return None
        g = re.fullmatch(r"/api/kalender(?:/(\d{4})(?:/(\d{1,2}))?)?\.ics", p)
        if m == "GET" and g:                                  # Abwesenheiten als Ganztagstermine (alle Jahre, ein Jahr oder ein Monat; ?arten=urlaub,krank)
            monat = int(g[2]) if g[2] else None
            if monat is not None and not 1 <= monat <= 12:
                raise Fehler("Monat 1 bis 12")
            arten = self._kalender_arten()
            tage = [t for t in db.tage_alle() if t.art in arten and (not g[1] or t.datum.year == int(g[1])) and (monat is None or t.datum.month == monat)]
            eigene = {}

            def frei(d):
                """True, wenn der Tag frei ist (Wochenende, Feiertag oder eigener freier Tag)."""
                if d.year not in eigene:
                    eigene[d.year] = set(db.jahr_einstellung(d.year)["eigene_frei"])
                return ist_frei(d, eigene[d.year])
            name = f"zeiterfassung-kalender-{g[1] or 'alle'}{f'-{monat:02d}' if monat else ''}.ics"
            self._senden(200, exportformat.kalender_ics(tage, frei), "text/calendar; charset=utf-8", self._kalender_kopf(name))
            return None
        g = NACHWEIS_PFAD.fullmatch(p)
        if m == "GET" and g:
            return self._monatsnachweis(db, _jahr(g[1]), int(g[2]), g[4], bool(g[3]))
        if p == "/api/nachweiskopf" and m in ("GET", "PUT"):
            if m == "GET":
                return db.nachweis_kopf()
            try:
                return db.nachweis_kopf_setzen(self._body())
            except konfig.KonfigFehler as e:
                raise Fehler(str(e))
        g = re.fullmatch(r"/api/export(\.json|\.csv)", p)
        if m == "GET" and g:                                  # alle erfassten Tage; JSON nur noch für Vorschau und Kalender der Seite Export (kein Knopf)
            zeilen = exportformat.alle_tage(db, konfig.CFG["zeitformat"])
            if g[1] == ".json":                               # nur Daten, kein Download mehr
                self._senden(200, exportformat.zu_json({"exportiert": date.today().isoformat(), "anzahl": len(zeilen), "tage": zeilen}), "application/json; charset=utf-8")
            else:
                self._senden(200, exportformat.tage_csv(zeilen), "text/csv; charset=utf-8",
                             {"Content-Disposition": f'attachment; filename="zeiterfassung-alle-tage-{date.today().isoformat()}.csv"'})
            return None
        return NICHT_ZUSTAENDIG

    def _monatsnachweis(self, db, j: int, mo: int, endung, mit_zeiten: bool):
        """Monatsnachweis (funktionen.md 3): ohne Endung die Daten als JSON (Vorschau), sonst die Datei Monatsnachweis-<J>-<MM>.pdf|.docx.
        Kopf und Unterschrift aus den Personendaten, für diese Ausgabe überschrieben durch die Abfrage (_nachweis_abfrage), Zeitformat, das heute gilt (konfig.CFG), Tage vor „Erfassung gültig ab“ leer. Fehler 400 bei Monat außerhalb 1–12."""
        if not 1 <= mo <= 12:
            raise Fehler("Monat 1 bis 12")
        daten = dokument.nachweis_daten(db, j, mo, {**db.nachweis_kopf(), **self._nachweis_abfrage()}, konfig.CFG["zeitformat"])   # „Erfassung gültig ab“ liest nachweis_daten selbst
        if not endung:
            return daten
        self._senden(200, dokument.nachweis_datei(daten, endung, mit_zeiten), NACHWEIS_TYPEN[endung],
                     {"Content-Disposition": f'attachment; filename="Monatsnachweis-{j}-{mo:02d}.{endung}"'})
        return None

    def _nachweis_abfrage(self) -> dict:
        """Unterschrift-Angaben aus der Abfrage, geprüft wie Eingaben: name, ort, vorgesetzt ohne Steuer- und Bidi-Zeichen, höchstens
        dokument.NACHWEIS_KOPF_MAX Zeichen; datum leer, „heute“, „letzter“ oder ein echtes Datum 1970 bis 2200; zweite "" oder "1". Wird nie gespeichert.
        Ein überschriebener Name gilt auch im Kopf dieses Nachweises. Fehler (400) bei doppeltem oder ungültigem Wert."""
        q = urllib.parse.parse_qs(self.path.partition("?")[2], keep_blank_values=True)
        if any(len(w) != 1 for w in q.values()):
            raise Fehler(NACHWEIS_ABFRAGE_FEHLER)
        werte = {k: notiz_bereinigen(q[k][0]) for k in NACHWEIS_ABFRAGE_TEXT if k in q}
        if any(len(v) > dokument.NACHWEIS_KOPF_MAX for v in werte.values()) or q.get("zweite", [""])[0] not in dbmod.NACHWEIS_WAHL["zweite"]:
            raise Fehler(NACHWEIS_ABFRAGE_FEHLER)
        if "zweite" in q:
            werte["zweite"] = q["zweite"][0]
        if "datum" in q:
            datum = q["datum"][0]
            if datum not in dbmod.NACHWEIS_WAHL["datum"] and dokument.eigenes_datum(datum) is None:
                raise Fehler(NACHWEIS_ABFRAGE_FEHLER)
            werte["datum"] = datum
        return werte

    def _kalender_arten(self) -> set:
        """Arten für die Kalender-Ausgabe aus „?arten=a,b“; ohne Angabe alle. Fehler (400) bei leerer Liste oder unbekannter Art."""
        wahl = urllib.parse.parse_qs(self.path.partition("?")[2], keep_blank_values=True).get("arten")
        if wahl is None:
            return set(exportformat.ICS_ARTEN)
        arten = wahl[0].split(",")
        if len(wahl) != 1 or not set(arten) <= set(exportformat.ICS_ARTEN):
            raise Fehler(KALENDER_ARTEN_FEHLER)
        return set(arten)

    def _kalender_kopf(self, name: str) -> dict:
        """„?ansehen=1“ (Knopf „In Kalender übernehmen“): zum Anzeigen statt als Download. iPhone und iPad zeigen dann „Alle hinzufügen“, Android öffnet die Kalender-App."""
        ansehen = urllib.parse.parse_qs(self.path.partition("?")[2]).get("ansehen") == ["1"]
        return {"Content-Disposition": f'{"inline" if ansehen else "attachment"}; filename="{name}"'}
