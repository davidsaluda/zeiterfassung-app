# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Gemeinsame Bausteine der Routen (aus server.py geschnitten, Runde 1.4): Fehler mit Status, Plattform der Fassung, Prüfung von
Datum, Jahr, Zahl und Text, dazu der Merker NICHT_ZUSTAENDIG. Enthält keine Routen; server.py und alle routen_*.py binden es ein."""
import os
from datetime import date

from kern.regeln import JAHR_MAX, JAHR_MIN

MIT_ADRESSE = ("desktop", "android")                       # Fassungen, die den eigenen Server direkt ansprechen (auch über IP und Port ohne https, z. B. im VPN)
MIT_UPDATE_PRUEFUNG = ("desktop", "android")               # nur die Windows- und die Android-App fragen nach einer neuen Version (CLAUDE.md, Ausnahme „Update-Prüfung“)
NUR_AM_RECHNER = "Das stellst du am Rechner ein, in der App dort."     # Meldung an der freigegebenen Oberfläche (8794)


def plattform() -> str:
    """Wo die App läuft: server (Vorgabe), desktop, android oder browser (Umgebungsvariable HO_PLATTFORM). Die lokalen Fassungen synchronisieren sich über den
    Cloud-Ordner der Person (DESKTOP.md), die Handy-Fassungen sichern dorthin (mobil/README.md). Die Web-App auf einem Server hat keine Cloud-Funktion.
    browser: die eigenständige Web-App ohne Server (mobil/web, auch auf iPhone und iPad); sie gibt die verschlüsselte Sicherung als Datei heraus und synchronisiert nicht.
    Unbekannte Werte (auch „ios“ der entfernten iOS-Hülle) gelten als server."""
    p = os.environ.get("HO_PLATTFORM", "server").strip().lower()
    return p if p in ("desktop", "android", "browser") else "server"


class Fehler(Exception):
    """Eingabefehler mit Status (Vorgabe 400); der Text geht als Meldung an die Person. kennung: feste Kennung neben dem Text („kennung“ in der
    Antwort), an der ein Gerät den Fall erkennt, ohne den Wortlaut zu vergleichen (leer: keine)."""
    def __init__(self, text, status=400, kennung=""):
        """Merkt sich den Meldetext, den HTTP-Status und die Kennung."""
        super().__init__(text)
        self.status, self.kennung = status, kennung


def _datum(text):
    """Wandelt JJJJ-MM-TT in ein Datum; Fehler 400 bei falschem Format oder Jahr außerhalb des erlaubten Bereichs."""
    try:
        d = date.fromisoformat(str(text))
    except ValueError:
        raise Fehler(f"Ungültiges Datum „{str(text)[:20]}“ (erwartet JJJJ-MM-TT)")
    if not JAHR_MIN <= d.year <= JAHR_MAX:
        raise Fehler(f"Datum außerhalb von {JAHR_MIN} bis {JAHR_MAX}")
    return d


def _jahr(wert):
    """Wandelt den Wert in ein Jahr im erlaubten Bereich; Fehler 400 sonst."""
    try:
        j = int(wert)
    except (TypeError, ValueError):
        raise Fehler("Jahr fehlt oder ist keine Zahl")
    if not JAHR_MIN <= j <= JAHR_MAX:
        raise Fehler(f"Jahr {JAHR_MIN} bis {JAHR_MAX}")
    return j


def _zahl(text, name):
    """Liest eine Kommazahl (auch mit Komma); Fehler 400, wenn es keine endliche Zahl ist. „name“ steht in der Meldung."""
    try:
        z = float(str(text).replace(",", "."))
    except ValueError:
        raise Fehler(f"{name}: keine Zahl")
    if z != z or z in (float("inf"), float("-inf")):
        raise Fehler(f"{name}: keine Zahl")
    return z


def _ganze_zahl(wert, name: str) -> int:
    """Eine ganze Zahl der Anfrage (auch als Text); Kommazahlen, ja/nein, Listen und Objekte sind Eingabefehler."""
    if isinstance(wert, float) and wert.is_integer():
        wert = int(wert)
    if isinstance(wert, bool) or not isinstance(wert, (int, str)):
        raise Fehler(f"{name}: ganze Zahl erwartet")
    try:
        return int(wert)
    except ValueError:
        raise Fehler(f"{name}: ganze Zahl erwartet")


def _text(wert, name: str) -> str:
    """Ein Textfeld der Anfrage: fehlend oder null gilt als leer, alles andere als Text ist ein Eingabefehler (kein interner Fehler)."""
    if wert is None:
        return ""
    if not isinstance(wert, str):
        raise Fehler(f"{name}: Text erwartet")
    return wert


NICHT_ZUSTAENDIG = object()                 # Antwort einer Routen-Gruppe „gehört nicht zu mir“; None heißt „schon gesendet“
