# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Paket routen (Teamplan B6): Module der Schicht routen; Importe als `from routen import <modul>`."""
