# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Ablage für andere Geräte (aus server.py geschnitten, Runde 1.4): /api/ablage, /api/ablage/koppeln und
/api/ablage/<Synchronisierungsdatei>, nur auf dem Server oder dem Anschluss der Freigabe (8793).
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import base64
import binascii
import time

from daten import konfig
from daten import sync
from daten import sicherung
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _text, plattform
from routen.kopplung import KOPPEL_VERSUCHE, _KOPPEL_SCHLOSS, _koppel_merken, _kopplung
from routen.ziele import ABLAGE_GERAETE, _ablage_liste, eigene_ablage, schreiben_pruefen


class AblageRouten:
    """Routen für Ablage der verschlüsselten Synchronisierungsdateien für andere Geräte; Teil der Klasse Handler (Mixin)."""

    def _routen_ablage(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if p == "/api/ablage" or p.startswith("/api/ablage/"):
            if self.daten_ordner and sync.aus(self.daten_ordner):   # auch nicht als Speicherort für andere Geräte
                raise Fehler(sync.ABGESCHALTET, 403)
            return self._ablage(m, p)
        return NICHT_ZUSTAENDIG

    def _ablage(self, m: str, p: str):
        """Nur auf dem Server: die Ablage für die verschlüsselten Synchronisierungsdateien aller Geräte (wie sonst der Cloud-Ordner). Der Server kann sie ohne das
        Passwort nicht lesen. Angenommen wird nur, was wie eine Synchronisierungsdatei heißt und beginnt und den Schreib-Nachweis besteht (schreiben_pruefen):
        Wer das Heimnetz erreicht, kann ohne das Passwort nichts ablegen oder ersetzen."""
        if not (plattform() == "server" or self.nur_ablage) or not self.daten_ordner:
            raise Fehler("Nicht gefunden", 404)
        if p == "/api/ablage/koppeln":                          # Kopplung per Code (koppeln_starten): nur auf dem freigegebenen Anschluss, nur solange der Code gilt
            with _KOPPEL_SCHLOSS:                                # Prüfen und Zählen gehören zusammen: Gleichzeitige Versuche zählen einzeln
                if _kopplung and (time.monotonic() > _kopplung["bis"] or _kopplung["versuche"] >= KOPPEL_VERSUCHE):
                    _kopplung.clear()
                if not self.nur_ablage or not _kopplung or m not in ("GET", "PUT"):
                    raise Fehler("Nicht gefunden", 404)
                if m == "PUT":                                   # nur ein eingegebener Code ist ein Versuch; Abrufe des Pakets dürfen die Kopplung nicht abbrechen
                    _kopplung["versuche"] += 1
                paket, schluessel = _kopplung["paket"], _kopplung["schluessel"]
            if m == "GET":
                self._senden(200, paket, "application/octet-stream")
                return None
            try:
                kopf, inhalt = sicherung.auspacken(base64.b64decode(_text(self._body().get("daten"), "daten"), validate=True), schluessel=schluessel)
                if kopf["art"] != "kopplung":
                    raise ValueError
            except ValueError:                                   # falscher Code, kaputtes Paket (auch SicherungFehler, binascii.Error)
                raise Fehler("Der Code stimmt nicht")
            _koppel_merken(self.daten_ordner, inhalt, uebernehmen=False)
            with _KOPPEL_SCHLOSS:
                _kopplung.clear()                                # ein Code koppelt genau ein Gerät
            return {"ok": True}
        ziel = eigene_ablage(self.daten_ordner) if self.nur_ablage else self._ziel()
        try:
            namen = sorted(ziel.sync_namen())
            if m == "GET" and p == "/api/ablage":
                ankuendigung = sicherung.nachweis_ankuendigung(sicherung.geraet_lesen(self.daten_ordner))
                return {"dateien": _ablage_liste(ziel, namen), **({"nachweis": ankuendigung} if ankuendigung else {})}
            name = p[len("/api/ablage/"):]
            if not sicherung.SYNC_NAME.fullmatch(name):
                raise Fehler("Nicht gefunden", 404)
            if m == "GET":
                if name not in namen:
                    raise Fehler("Nicht gefunden", 404)
                self._senden(200, ziel.lesen(name), "application/octet-stream")
                return None
            if m not in ("PUT", "DELETE"):
                raise Fehler("Nicht gefunden", 404)
            if name == sicherung.sync_name(sicherung.geraet_lesen(self.daten_ordner)["geraet"]):
                raise Fehler("Das ist die Synchronisierungsdatei des Servers selbst. Sie lässt sich nicht von außen ersetzen.")
            if m == "DELETE":
                return self._ablage_loeschen(ziel, name, namen)
            if name not in namen and len(namen) >= ABLAGE_GERAETE:
                raise Fehler(f"Die Ablage nimmt höchstens {ABLAGE_GERAETE} Geräte an")
            b = self._body()
            try:
                roh = base64.b64decode(_text(b.get("daten"), "daten"), validate=True)
            except (binascii.Error, ValueError):
                raise Fehler("daten: Datei als Base64 erwartet")
            try:
                sicherung.kopf_lesen(roh)
            except konfig.Meldung as e:                          # nur bewusste Meldungen; ein anderer ValueError bleibt intern (Server: „Ungültige Eingabe“)
                raise Fehler(str(e))
            schreiben_pruefen(self.daten_ordner, ziel, name, roh, b.get("nachweis"))
            ziel.ablegen(name, roh)
            return {"ok": True}
        except OSError:
            raise Fehler(sicherung.ZIEL_WEG, 503)

    def _ablage_loeschen(self, ziel, name: str, namen: list) -> dict:
        """DELETE /api/ablage/<Datei> (seit 22.11.2026): ein Gerät nimmt ein anderes aus der Synchronisierung. Nur mit Schreib-Nachweis über die Datei,
        die dort liegt, und einen leeren Inhalt (sicherung.LOESCH_INHALT); ohne Passwort auf dem Host löscht die Ablage nichts (strenger als beim Ablegen,
        denn Löschen holt kein Nachweis zurück). Fehler 404 ohne Datei, 403 ohne gültigen Nachweis."""
        if name not in namen:
            raise Fehler("Nicht gefunden", 404)
        if not sicherung.geraet_lesen(self.daten_ordner)["schluessel"]:
            raise Fehler(sicherung.ABLAGE_NACHWEIS, 403, sicherung.NACHWEIS_KENNUNG)
        schreiben_pruefen(self.daten_ordner, ziel, name, sicherung.LOESCH_INHALT, self._body().get("nachweis"))
        ziel.loeschen(name)
        return {"ok": True}
