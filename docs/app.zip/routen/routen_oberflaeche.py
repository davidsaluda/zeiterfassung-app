# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Oberfläche (aus server.py geschnitten, Runde 1.4): GET /health, GET /api/version, GET und PUT /api/desktop/browser,
POST /api/desktop/beenden, GET und POST /api/demo, GET und PUT /api/einrichtung, POST /api/selbsttest („App prüfen“); dazu die Demo-Sperre _DEMO_SCHLOSS, die Handler._demo_db mitbenutzt.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import os
import threading

from daten import demo
from daten import konfig
from daten import sicherung
from kern import zutun
from routen.eingabe import Fehler, NICHT_ZUSTAENDIG, _text, plattform
from urheber import VERSION

# eine Demo-Datenbank, einmal befüllt: Die Seite schickt beim Laden viele Anfragen auf einmal, ohne Schloss legte jede ihre eigene an und befüllte sie
_DEMO_SCHLOSS = threading.RLock()                          # RLock: POST /api/demo hält es und ruft darin _demo_db
DEMO_EINRICHTUNG = "Im Demo-Modus lässt sich die Einrichtung nicht ändern"
# ein Lauf von „App prüfen“ je Prozess: jeder rechnet rund 1 s, beliebig viele zugleich belegten nur Rechenzeit
_SELBSTTEST_SCHLOSS = threading.Lock()
SELBSTTEST_LAEUFT = "App prüfen läuft schon. Bitte kurz warten."
SELBSTTEST_BESETZT = 429


class OberflaecheRouten:
    """Routen für Gesundheit, Version, Demo und Desktop-Hülle; Teil der Klasse Handler (Mixin)."""

    def _routen_oberflaeche(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if m == "GET" and p == "/health":
            self.db.pruefen()                                 # eine unlesbare Datenbank macht die Prüfung rot (503), nicht erst die nächste Eingabe
            return {"ok": True, "version": VERSION}
        if m == "POST" and p == "/api/selbsttest":            # POST: Herkunftsprüfung wie jeder Schreibzugriff, eine fremde Seite löst ihn nicht aus
            return self._selbsttest()
        if m == "GET" and p == "/api/version":
            return {"version": VERSION, "plattform": plattform(), "fern": self.fern}
        if p == "/api/desktop/browser" and m in ("GET", "PUT"):    # in welchem Browser die Desktop-Fassung ihr Fenster öffnet
            if plattform() != "desktop" or self.fern or not self.daten_ordner or os.environ.get("HO_FENSTER") == "app":   # eigenes App-Fenster: keine Browser-Wahl
                if m == "GET":
                    return {"desktop": False, "wahl": "", "vorhanden": []}
                raise Fehler("Nicht gefunden", 404)
            import desktop
            if m == "PUT":
                wahl = _text(self._body().get("wahl"), "wahl")
                if wahl not in (*desktop.BROWSER, "standard"):
                    raise Fehler("Unbekannter Browser")
                sicherung.geraet_aendern(self.daten_ordner, browser=wahl)
            return {"desktop": True, "wahl": sicherung.geraet_lesen(self.daten_ordner).get("browser", ""), "vorhanden": list(desktop.browser_vorhanden())}
        if m == "POST" and p == "/api/desktop/beenden":      # nur die Desktop-Fassung: der Starter (desktop.py) beendet daraufhin den Dienst
            if plattform() != "desktop" or self.fern or self.beenden is None:
                raise Fehler("Nicht gefunden", 404)
            threading.Timer(0.4, self.beenden).start()       # erst die Antwort senden, dann beenden
            return {"ok": True}
        if p == "/api/demo":
            if m == "GET":                                     # leer: echte Datenbank ohne Einträge; aktiv: dieser Browser nutzt die Demo
                angebot = self._erster_start(demo_an) and bool(konfig.gewaehlt(self.db) or self.db.einrichtung_stand())   # erst mit Regeln der Person
                return {"leer": not self.db.tage_alle(), "aktiv": demo_an, "angebot": angebot}
            if m == "POST":                                    # Demo neu mit Beispieldaten füllen (die echte Datenbank bleibt unberührt)
                with _DEMO_SCHLOSS:                            # zwischen Leeren und Befüllen sähe eine Anfrage sonst eine leere Demo und befüllte sie ein zweites Mal
                    demo.zuruecksetzen(self._demo_db())
                return {"ok": True}
        if p == "/api/einrichtung":                            # gilt je Gerät: immer die echte Datenbank, deshalb im Demo-Modus nur lesen
            if m == "PUT":
                if demo_an:
                    raise Fehler(DEMO_EINRICHTUNG)
                try:
                    self.db.einrichtung_setzen(self._body().get("stand"))
                except konfig.KonfigFehler as e:
                    raise Fehler(str(e))
            if m in ("GET", "PUT"):
                return {"zeigen": self._erster_start(demo_an) and not self.db.einrichtung_stand()}
        return NICHT_ZUSTAENDIG

    def _selbsttest(self) -> dict:
        """„App prüfen“: rechnet den Prüfdatensatz (A und B) in Wegwerf-Datenbanken, nie in der echten.
        Rückgabe {"anzahl": Zahl aller Rechenwerte, "abweichungen": [{"name", "erwartet", "gerechnet"}]} (Werte als Text, leer = alles stimmt).
        Fehler: Fehler mit Status 429, solange schon ein Lauf rechnet."""
        import pruefdaten
        if not _SELBSTTEST_SCHLOSS.acquire(blocking=False):
            raise Fehler(SELBSTTEST_LAEUFT, SELBSTTEST_BESETZT)
        try:                                                 # ohne db.lock: nur Wegwerf-Datenbanken und ein eigener Regelstand, andere Anfragen laufen weiter
            funde = pruefdaten.selbsttest()
        finally:
            _SELBSTTEST_SCHLOSS.release()
        return {"anzahl": pruefdaten.anzahl(),
                "abweichungen": [{"name": name, "erwartet": str(soll), "gerechnet": str(ist)} for name, soll, ist in funde]}

    def _erster_start(self, demo_an: bool) -> bool:
        """Leere echte Datenbank, keine Demo in diesem Browser und keine Synchronisierung eingerichtet (funktionen.md 6.1 und 6.4):
        Dann bieten Übersicht und Einstellungen die Einrichtung bzw. die Demo an. Am Handy der freigegebenen Oberfläche wie am Rechner."""
        if demo_an or self.db.tage_alle():
            return False
        return not (self.daten_ordner and zutun._sync_eingerichtet(self._sync_stand()))
