# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Kopplung zweier Geräte per Code (aus server.py geschnitten, Runde 1.4): Zustand _kopplung unter _KOPPEL_SCHLOSS, Code lesen,
Kopplung starten und annehmen. Zustände nur an Ort und Stelle ändern (clear, update), nie neu binden: Andere Dateien halten den Namen."""
import base64
import binascii
import ipaddress
import json
import re
import secrets
import socket
import threading
import time

from routen import anschluesse
from daten import sicherung
from routen.anschluesse import freigabe_schalten
from routen.eingabe import Fehler
from routen.ziele import _github_angaben

KOPPEL_DAUER = 300                                         # Sekunden, die ein Kopplungs-Code gilt
KOPPEL_VERSUCHE = 5
_KOPPEL_SCHLOSS = threading.Lock()
_kopplung = {}                                             # laufende Kopplung dieses Geräts: {"schluessel", "paket", "bis", "versuche"}


def koppel_lesen(code) -> tuple:
    """Code vom Bildschirm des anderen Geräts -> (IP, Code ohne Trennzeichen). Im Code stecken die Adresse (4 Byte) und ein Einmal-Geheimnis (6 Byte).
    Nur Adressen im eigenen Netz (WLAN, VPN): Der Code kann die App nicht ins Internet schicken."""
    glatt = re.sub(r"[^A-Z2-7]", "", str(code).upper().replace("0", "O").replace("1", "I").replace("8", "B"))
    try:
        ip = ipaddress.ip_address(base64.b32decode(glatt)[:4]) if len(glatt) == 16 else None
    except (binascii.Error, ValueError):
        ip = None
    if ip is None or ip.is_global or ip.is_multicast or ip.is_unspecified:
        raise Fehler("Der Code stimmt nicht. Bitte genau so eingeben, wie ihn das andere Gerät zeigt (16 Zeichen).")
    return str(ip), glatt


def _koppel_inhalt(g: dict) -> bytes:
    """Der Inhalt für das Koppeln eines anderen Geräts (Salz, Schlüssel, Runden, ggf. GitHub-Angaben) als JSON in Bytes. Nur für den Koppel-Code gedacht."""
    github = {"github": {"repo": g["github_repo"], "token": g["github_token"], "privat": g["github_privat"]}} if g["github_repo"] else {}
    return json.dumps({"salz": g["salz"], "schluessel": g["schluessel"], "runden": g["runden"], **github}).encode()


def _koppel_merken(daten: str, inhalt: bytes, uebernehmen: bool) -> None:
    """Den Schlüssel des anderen Geräts merken, damit die Synchronisierung seine Datei ohne Passwort liest. uebernehmen: Dieses Gerät hat noch kein Passwort und
    nimmt den Schlüssel des anderen als eigenen (dann öffnet dasselbe Passwort die Sicherungen beider Geräte). Runden nur in den Grenzen, in denen
    sicherung.kopf_lesen Dateien liest. Lesen und Schreiben unter sicherung._schloss: Ein gleichzeitiger Passwortwechsel oder eine neue GitHub-Verbindung
    ginge sonst verloren (PUT /api/ablage/koppeln hält nur db.lock)."""
    try:
        d = json.loads(inhalt)
        salz, schluessel, runden = bytes.fromhex(d["salz"]), bytes.fromhex(d["schluessel"]), int(d["runden"])
        if len(salz) != 16 or len(schluessel) != 64 or not sicherung.RUNDEN_MIN <= runden <= sicherung.RUNDEN_MAX:
            raise ValueError
    except (ValueError, KeyError, TypeError):
        raise Fehler("Das andere Gerät hat nicht wie die Zeiterfassung geantwortet.")
    with sicherung._schloss:
        g = sicherung.geraet_lesen(daten)
        if not g["github_repo"]:                             # das andere Gerät synchronisiert über GitHub: die Verbindung mitnehmen, wenn hier noch keine besteht
            try:
                repo, token = _github_angaben(d.get("github"))
                sicherung.geraet_aendern(daten, github_repo=repo, github_token=token, github_privat=d["github"].get("privat") is not False, **{"abgleich_auto": True})
            except ValueError:
                pass
        if uebernehmen and not g["schluessel"]:
            sicherung.geraet_aendern(daten, salz=salz.hex(), schluessel=schluessel.hex(), runden=runden, inhalt="", **{"abgleich_inhalt": ""})
        elif salz.hex() != g["salz"]:
            sicherung.fremden_schluessel_merken(daten, salz.hex(), schluessel.hex())


def koppeln_starten(h, daten: str) -> None:
    """Dieses Gerät zeigt einen Code. Es gibt dafür seine Ablage frei und hält seinen Schlüssel fünf Minuten lang bereit, verschlüsselt mit dem Code.
    Der Code selbst geht nie über das Netz: Wer mitliest, sieht nur das verschlüsselte Paket."""
    g = sicherung.geraet_lesen(daten)
    if not g["schluessel"]:
        raise Fehler(sicherung.KEIN_PASSWORT)
    ip = anschluesse.netz_adresse()
    if not ip:
        raise Fehler(anschluesse.KEIN_NETZ)
    try:
        freigabe_schalten(h, True, ausdruecklich=True, adresse=ip)
    except OSError:
        raise Fehler(f"Der Anschluss {anschluesse.FREIGABE_PORT} ist auf diesem Gerät belegt. Die Kopplung geht gerade nicht.")
    anschluesse.freigabe_merken(daten, ip)                   # an in diesem Netz (siehe freigabe_merken)
    code = base64.b32encode(socket.inet_aton(ip) + secrets.token_bytes(6)).decode()
    salz = secrets.token_bytes(16)
    schluessel = sicherung.schluessel_ableiten(code, salz)
    paket = sicherung.packen(_koppel_inhalt(g), "kopplung", schluessel, salz, geraet=g["geraet"])
    with _KOPPEL_SCHLOSS:                                    # GET /api/abgleich und die Ablage lesen _kopplung aus anderen Fäden
        _kopplung.clear()
        _kopplung.update(code="-".join(code[i:i + 4] for i in range(0, 16, 4)), schluessel=schluessel, bis=time.monotonic() + KOPPEL_DAUER, versuche=0, paket=paket)


def koppeln_beenden() -> None:
    """Die laufende Kopplung dieses Geräts verwerfen (Werkseinstellungen): Paket und Code mit dem alten Schlüssel gelten danach nicht mehr."""
    with _KOPPEL_SCHLOSS:
        _kopplung.clear()


def koppeln_annehmen(daten: str, code, ersetzen: bool = False) -> None:
    """Dieses Gerät hat den Code des anderen bekommen: dessen Schlüssel holen, den eigenen zurückgeben, die Adresse eintragen.
    ersetzen: Die Person hat bestätigt, dass die Kopplung den eigenen Server (Adresse und Anmeldung) ersetzt. Fehler 409 (sicherung.SERVER_STATT_KOPPELN),
    solange das fehlt: Die Verbindung zum Server ginge sonst ohne Meldung verloren (Regel: sicherung.koppeln_pruefen)."""
    ip, glatt = koppel_lesen(code)
    if not ersetzen:
        try:
            sicherung.koppeln_pruefen(daten)
        except sicherung.SicherungFehler as e:
            raise Fehler(str(e), 409)
    ziel = sicherung.NetzZiel(f"http://{ip}:{anschluesse.FREIGABE_PORT}", warten=8)
    try:
        roh = ziel._holen("/koppeln")
    except OSError:
        raise Fehler("Das andere Gerät antwortet nicht. Beide Geräte müssen im selben WLAN oder VPN sein, und der Code darf nicht älter als fünf Minuten sein.")
    try:
        k = sicherung.kopf_lesen(roh)
        if k["runden"] > sicherung.RUNDEN:                   # ein fremdes Gerät soll dieses nicht minutenlang rechnen lassen
            raise ValueError
        schluessel = sicherung.schluessel_ableiten(glatt, k["salz"], k["runden"])
        kopf, inhalt = sicherung.auspacken(roh, schluessel=schluessel)
        if kopf["art"] != "kopplung":
            raise ValueError
    except ValueError:                                       # auch SicherungFehler
        raise Fehler("Der Code stimmt nicht oder ist abgelaufen. Bitte am anderen Gerät einen neuen Code anzeigen.")
    _koppel_merken(daten, inhalt, uebernehmen=True)
    g = sicherung.geraet_lesen(daten)
    antwort = sicherung.packen(_koppel_inhalt(g), "kopplung", schluessel, k["salz"], k["runden"], g["geraet"])
    try:
        ziel._holen("/koppeln", json.dumps({"daten": base64.b64encode(antwort).decode()}).encode())
    except OSError:
        raise Fehler("Das andere Gerät hat die Antwort nicht angenommen. Bitte dort einen neuen Code anzeigen und es noch einmal versuchen.")
    sicherung.geraet_aendern(daten, ablage_adresse=f"http://{ip}:{anschluesse.FREIGABE_PORT}")
