# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Routen der Einstellungen (aus server.py geschnitten, Runde 1.4): GET /api/abschnitte, POST /api/abschnitt,
DELETE /api/abschnitt/<id>, GET und PUT /api/konfig, DELETE /api/konfig/<JJJJ-MM-TT>, GET und POST /api/profile
mit /loeschen, /schalten, /import, /wahl, GET /api/profile/<nr>.json, GET und PUT /api/update, GET /api/feiertage/<J>,
GET und PUT /api/startwerte (GET/PUT /api/nachweiskopf: routen_export); davor die Sperren im Demo-Modus.
Mixin der Klasse server.Handler: Der Einstieg gibt ein dict (wird JSON), None (Antwort schon gesendet) oder NICHT_ZUSTAENDIG zurück.
Importiert nie server (beim Start als Skript entstünde eine zweite Kopie mit eigenem Fehler). Hängt eine neue Route von der Uhr oder
von Dateien ab, gehört ihr Pfad in server.NICHT_MERKEN."""
import json
import re
from datetime import date, timedelta

from daten import sync
from kern import bericht
from kern import feiertage
from daten import konfig
from kern import regeln
from daten import sicherung
from daten import update
from daten.db import Db
from routen.eingabe import Fehler, MIT_UPDATE_PRUEFUNG, NICHT_ZUSTAENDIG, NUR_AM_RECHNER, _datum, _ganze_zahl, _text, _zahl, plattform
from kern.feiertage import eigene_pruefen
from kern.regeln import ABSCHNITT_ARTEN, Abschnitt, WT
from kern.zeit import dauer_lesen, fmt_dauer

PROFIL_PFADE = ("/api/profile", "/api/profile/loeschen", "/api/profile/schalten", "/api/profile/import", "/api/profile/wahl")
DEMO_PROFILE = "Im Demo-Modus lassen sich keine Profile ändern"
STUNDEN_JE_TAG = "Stunden je Tag: je Arbeitstag (Mo bis Fr) eine Dauer von 0:01 bis 10:00, zum Beispiel 6:30 oder 6,5"
STUNDEN_NICHT_GEWAEHLT = "Stunden je Tag: {tag} ist kein gewählter Arbeitstag. Erst bei den Arbeitstagen wählen oder das Feld leeren."
STUNDEN_NULL = "Stunden je Tag: {tag} hat 0 Stunden. Tag abwählen, wenn an dem Tag keine Arbeit ist."
STUNDEN_TEILWEISE = "Stunden je Tag: bitte für jeden gewählten Arbeitstag Stunden eintragen (fehlt: {tage}) oder alle Felder leeren."
DEMO_STARTWERTE = "Im Demo-Modus lassen sich die Startwerte nicht ändern"
STARTWERTE_SALDO = re.compile(r"([+\-−]?)\s*(\d{1,3}):([0-5]\d)")  # Gleitzeit wie PUT /api/gleitzeit, höchstens ±999:59
STARTWERTE_AB = re.compile(r"(?:^|&)ab=([^&]*)")                    # ?ab= der Vorbelegung, ohne Dekodieren (ein Datum braucht keins)
STARTWERTE_ZEIT_FEHLER = "{name}: Stunden, zum Beispiel 300:00 oder 300,5"
STARTWERTE_VERSCHOBEN = ("Erfassung gültig ab jetzt {neu} (vorher {alt}): Gleitzeit- und Freizeitkonto zeigen den Stand vom {vortag}, "
                         "Einträge vor dem {neu} zählen nicht.")
STARTWERTE_SALDO_FEHLER = "Gleitzeit: Format hh:mm, zum Beispiel 12:30 oder -03:15"
UMLAUTE = str.maketrans({"ä": "ae", "ö": "oe", "ü": "ue", "Ä": "Ae", "Ö": "Oe", "Ü": "Ue", "ß": "ss"})   # Dateinamen beim Profil-Export lesbar in ASCII


def _stunden_je_tag(roh, tage: list) -> dict:
    """Stunden je Tag der Anfrage ({"Mo": "8", "Di": "6:30", "Mi": 4.5}) in Minuten je gewähltem Arbeitstag (R4, Weg 3); ohne Angabe oder mit
    lauter leeren Feldern {} (Weg 1 oder 2). Prüft in der Reihenfolge von R4: höchstens 5 Schlüssel Mo bis Fr, nur gewählte Tage, Dauer über
    zeit.dauer_lesen bis TAGESMINUTEN_MAX, mehr als 0, alle gewählten Tage gefüllt. Die Summe bleibt so bei 5 × 600 unter WOCHENSTUNDEN_MAX.
    Fehler 400 mit Meldung, dann ist nichts gespeichert."""
    if roh is None:
        return {}
    if not isinstance(roh, dict) or len(roh) > len(WT[:5]) or any(t not in WT[:5] for t in roh):
        raise Fehler(STUNDEN_JE_TAG)
    gefuellt = {t: w for t, w in roh.items() if w not in ("", None)}
    if not gefuellt:
        return {}
    fremd = [t for t in WT[:5] if t in gefuellt and t not in tage]
    if fremd:
        raise Fehler(STUNDEN_NICHT_GEWAEHLT.format(tag=fremd[0]))
    minuten = {t: _tagesdauer(w) for t, w in gefuellt.items()}
    null = [t for t in WT[:5] if minuten.get(t) == 0]
    if null:
        raise Fehler(STUNDEN_NULL.format(tag=null[0]))
    fehlt = [t for t in tage if t not in minuten]
    if fehlt:
        raise Fehler(STUNDEN_TEILWEISE.format(tage=", ".join(fehlt)))
    return {t: minuten[t] for t in tage}


def _tagesdauer(wert) -> int:
    """Eine Dauer der Stunden je Tag (Text oder Zahl, nie ja/nein) in Minuten, höchstens TAGESMINUTEN_MAX. Fehler 400 (STUNDEN_JE_TAG) sonst."""
    if isinstance(wert, bool) or not isinstance(wert, (str, int, float)):
        raise Fehler(STUNDEN_JE_TAG)
    try:
        minuten = dauer_lesen(str(wert))
    except ValueError:
        raise Fehler(STUNDEN_JE_TAG)
    if minuten > konfig.TAGESMINUTEN_MAX:
        raise Fehler(STUNDEN_JE_TAG)
    return minuten


def abschnitt_speichern(db: Db, p: dict) -> dict:
    """Legt einen Abschnitt (Zeitraum mit Art, Arbeitstagen und Wochenstunden oder Stunden je Tag) an oder ändert ihn (mit „id“); drei Wege nach R4:
    nur Wochenstunden (keine Tage: verteilt auf die Arbeitstage der Regeln), Tage ohne Stunden je Tag, Stunden je Tag (Wochenstunden = Summe).
    Gibt {"ok", "id"} zurück; Fehler 400 bei ungültigen Angaben, dann ist nichts gespeichert."""
    von, bis = _datum(p.get("von")), _datum(p.get("bis"))
    if von > bis:
        raise Fehler("Von-Datum liegt nach dem Bis-Datum")
    art = p.get("art", "normal")
    if art not in ABSCHNITT_ARTEN:
        raise Fehler("Unbekannte Art. Möglich: " + ", ".join(ABSCHNITT_ARTEN))
    try:
        tage = konfig.arbeitstage_lesen(p.get("arbeitstage", ""))
    except konfig.KonfigFehler as e:
        raise Fehler(str(e))
    if any(t not in WT[:5] for t in tage):
        raise Fehler("Arbeitstage: nur Mo,Di,Mi,Do,Fr")
    je_tag = _stunden_je_tag(p.get("stunden_je_tag"), tage)
    if je_tag:                                               # Weg 3: die Wochenstunden zeigt die Oberfläche nur an, sie folgen aus der Summe
        stunden = sum(je_tag.values()) / 60
    else:
        stunden = _zahl(p.get("wochenstunden", konfig.CFG["wochenstunden"]), "Wochenstunden")
        if not 0 <= stunden <= regeln.WOCHENSTUNDEN_MAX:
            raise Fehler(f"Wochenstunden: 0 bis {regeln.WOCHENSTUNDEN_MAX}")
    try:
        aid = int(p.get("id") or 0)
    except (TypeError, ValueError):
        raise Fehler("id: Zahl erwartet")
    tagesminuten = ",".join(f"{t}:{m}" for t, m in je_tag.items())
    try:
        aid = db.abschnitt_speichern(Abschnitt(von, bis, stunden, art, ",".join(tage), aid, tagesminuten))
    except konfig.Meldung as e:                              # Netz für alle Wege (auch Synchronisierung und Sicherung): Stunden je Tag passen nicht, Tag doppelt
        raise Fehler(str(e))
    return {"ok": True, "id": aid}


def abschnitte_json(db: Db):
    """Alle Abschnitte als JSON-Antwort (R4): stunden_je_tag {Wochentag: Minuten} (leer bei Weg 1 und 2), wochensoll_min, wochensoll (Zeit)
    und weg (1 nur Wochenstunden, 2 Tage ohne Stunden je Tag, 3 Stunden je Tag); wochensoll im Zeitformat, das heute gilt (Regel „zeitformat“)."""
    return {"abschnitte": [_abschnitt_json(a) for a in db.abschnitte()]}


def _abschnitt_json(a) -> dict:
    """Ein Abschnitt als JSON-Zeile für abschnitte_json; das Wochensoll wird einmal gerechnet."""
    soll = regeln.wochensoll_min(a)
    return {"id": a.id, "von": a.von.isoformat(), "bis": a.bis.isoformat(), "wochenstunden": a.wochenstunden, "art": a.art,
            "arbeitstage": a.arbeitstage, "stunden_je_tag": konfig.tagesminuten_lesen(a.tagesminuten),
            "wochensoll_min": soll, "wochensoll": fmt_dauer(soll, konfig.CFG["zeitformat"]), "weg": regeln.weg(a)}


def feiertage_json(db: Db, jahr: int) -> list:
    """GET /api/feiertage/<J> (R4b): Liste aus feiertage.liste mit den einmaligen eigenen freien Tagen des Jahres."""
    return feiertage.liste(jahr, db.eigene_feiertage(jahr))


def _startwerte_zeit(wert, name: str) -> int:
    """HO- oder Büro-Zeit der Startwerte („300:00“ oder „300,5“, zeit.dauer_lesen) in Minuten. Fehler 400 bei anderer Form oder anderem Typ
    (die Grenzen prüft konfig.startwerte_pruefen)."""
    try:
        if not isinstance(wert, str):
            raise ValueError(name)
        return dauer_lesen(wert)
    except ValueError:
        raise Fehler(STARTWERTE_ZEIT_FEHLER.format(name=name))


def _verschoben(alt, werte: dict) -> list:
    """Hinweis, wenn PUT /api/startwerte „Erfassung gültig ab“ verschiebt (Auflage Prüfung Stufe c): Die Konten zeigen dann den Stand vom neuen
    Vortag, Einträge davor zählen nicht. Eingaben: Startwerte vor dem Speichern (oder None) und die gespeicherten Felder. Rückgabe: [] oder [Text]."""
    if alt is None or not werte["ab"] or werte["ab"] == alt.ab.isoformat():
        return []
    neu = date.fromisoformat(werte["ab"])
    return [STARTWERTE_VERSCHOBEN.format(neu=bericht.de(neu), alt=bericht.de(alt.ab), vortag=bericht.de(neu - timedelta(days=1)))]


def _startwerte_saldo(wert):
    """Gleitzeit der Startwerte („+12:30“, „-03:15“) in Minuten; fehlt sie (None oder ""), None = Konto am Vortag. Fehler 400 sonst."""
    if wert is None or wert == "":
        return None
    treffer = STARTWERTE_SALDO.fullmatch(wert.strip()) if isinstance(wert, str) else None
    if not treffer:
        raise Fehler(STARTWERTE_SALDO_FEHLER)
    return (-1 if treffer[1] in ("-", "−") else 1) * (int(treffer[2]) * 60 + int(treffer[3]))


def startwerte_eingabe(p: dict) -> dict:
    """PUT /api/startwerte (R6): {ab, ho, dst, urlaub, gleittage, krank, kind_krank, gleitzeit?} in die Felder von bericht.startwerte_speichern.
    ab "" = löschen (nur genau so: ein fehlendes Feld oder false löscht nichts). Fehler 400 bei falscher Form (Datum 1970 bis 2200,
    Zeiten hh:mm, ganze Tage); Grenzen prüfen konfig und db."""
    if p.get("ab") == "":
        return {"ab": ""}
    werte = {"ab": _datum(p.get("ab")).isoformat(), "gleitzeit_min": _startwerte_saldo(p.get("gleitzeit"))}
    for feld, eingabe in zip(konfig.STARTWERTE_ZEITEN, ("ho", "dst")):
        werte[feld] = _startwerte_zeit(p.get(eingabe), konfig.STARTWERTE_NAMEN[feld])
    for feld in konfig.STARTWERTE_TAGE:
        werte[feld] = _ganze_zahl(p.get(feld, 0), konfig.STARTWERTE_NAMEN[feld])
    return werte


class EinstellungenRouten:
    """Routen für Abschnitte, Regeln (Konfig), Profile und die Update-Prüfung; Teil der Klasse Handler (Mixin)."""

    def _routen_einstellungen(self, m, p, db, demo_an):
        """Bedient Methode „m“ und Pfad „p“, wenn er zu diesem Bereich gehört; sonst NICHT_ZUSTAENDIG."""
        if m == "GET" and p == "/api/abschnitte":
            return abschnitte_json(db)
        if m == "POST" and p == "/api/abschnitt":
            return abschnitt_speichern(db, self._body())
        g = re.fullmatch(r"/api/abschnitt/(\d{1,9})", p)
        if m == "DELETE" and g:
            db.abschnitt_loeschen(int(g[1]))
            return {"ok": True}
        if p == "/api/update" and m in ("GET", "PUT") and self.daten_ordner:
            return self._update(m)
        g = re.fullmatch(r"/api/feiertage/(\d{4})", p)
        if m == "GET" and g:
            return feiertage_json(db, int(g[1]))
        if p == "/api/startwerte" and m in ("GET", "PUT"):
            return self._startwerte(m, db, demo_an)
        if demo_an and p.startswith("/api/konfig") and m != "GET":
            raise Fehler("Im Demo-Modus lassen sich die Regeln nicht ändern")
        if demo_an and p in PROFIL_PFADE and m != "GET":          # jede schreibende Methode, nicht nur POST
            raise Fehler(DEMO_PROFILE)
        if p == "/api/konfig":
            if m == "GET":
                return self._konfig_antwort(db)
            if m == "PUT":                                    # {"werte": {...}, "modus": "ab_heute|ab_datum|rueckwirkend", "ab": "JJJJ-MM-TT"}
                b = self._body()
                werte = b.get("werte") or {}
                if not isinstance(werte, dict):
                    raise Fehler("werte: Objekt mit Regeln erwartet")
                ab_aus = None                                 # Modul „Sync“: gilt nur für dieses Gerät, steht nicht in den (synchronisierten) Regeln
                if isinstance(werte.get("module_aus"), list) and self.daten_ordner:
                    ab_aus = None if self.fern else "abgleich" in werte["module_aus"]   # das Handy an der freigegebenen Oberfläche schaltet den Sync des Rechners nicht
                    werte = {**werte, "module_aus": [x for x in werte["module_aus"] if x != "abgleich"]}
                modus = _text(b.get("modus"), "Modus") or "ab_heute"
                try:
                    self._feiertage_pruefen(werte, modus, b.get("ab"))
                    konfig.aendern(werte, modus, b.get("ab"))
                except konfig.KonfigFehler as e:
                    raise Fehler(str(e))
                konfig.speichern(db)
                if ab_aus is not None:
                    sync.modul_setzen(self.daten_ordner, ab_aus)
                return self._konfig_antwort(db)
        g = re.fullmatch(r"/api/profile/(\d{1,3})\.json", p)
        if m == "GET" and g:                                 # ein Profil als Datei (zum Übernehmen auf einem anderen Gerät)
            liste = konfig.profile(db)
            if int(g[1]) >= len(liste):
                raise Fehler("Nicht gefunden", 404)
            x = liste[int(g[1])]
            datei = "Profil-" + (re.sub(r"[^A-Za-z0-9_-]+", "_", x["name"].translate(UMLAUTE)).strip("_") or "eigen") + ".json"     # Dateiname nur ASCII
            self._senden(200, json.dumps(konfig.profil_datei(x), ensure_ascii=False, indent=1).encode(), "application/json; charset=utf-8",
                         {"Content-Disposition": f'attachment; filename="{datei}"'})
            return None
        if p in PROFIL_PFADE:                                # Vorbelegungen für die Regeln: feste und eigene Profile
            if m == "POST":
                b = self._body()
                try:
                    if p == "/api/profile":
                        konfig.profil_speichern(db, b.get("name"), b.get("akzent") or "", b.get("farbe") or "")
                    elif p == "/api/profile/loeschen":
                        konfig.profil_loeschen(db, b.get("name"))
                    elif p == "/api/profile/schalten":
                        konfig.profil_schalten(db, b.get("name"), b.get("aktiv"))
                    elif p == "/api/profile/wahl":
                        konfig.profil_waehlen(db, b.get("name"))
                    else:
                        konfig.profil_importieren(db, b)
                except konfig.KonfigFehler as e:
                    raise Fehler(str(e))
            elif m != "GET" or p != "/api/profile":
                raise Fehler("Nicht gefunden", 404)
            n = konfig.voreinstellung(db)
            vor = {"name": n, "akzent": konfig.PROFILE_FEST[n]["akzent"], "farbe": konfig.PROFILE_FEST[n]["farbe"]} if n else None
            return {"profile": konfig.profile(db), "voreinstellung": vor, "gewaehlt": konfig.gewaehlt(db)}
        g = re.fullmatch(r"/api/konfig/(\d{4}-\d{2}-\d{2})", p)
        if m == "DELETE" and g:
            try:
                konfig.loeschen(g[1])
            except konfig.KonfigFehler as e:
                raise Fehler(str(e))
            konfig.speichern(db)
            return self._konfig_antwort(db)
        return NICHT_ZUSTAENDIG

    def _update(self, m: str) -> dict:
        """GET und PUT /api/update (funktionen.md 8.1): Stand der Update-Prüfung lesen, mit {"an": true|false} schalten (je Gerät, geraet.json).
        Rückgabe: update.stand, nie geraet.json selbst (dort stehen Schlüssel und Token). Fehler: 400, wenn „an“ kein Wahrheitswert ist;
        403 über die freigegebene Oberfläche (8794), dort wird nichts eingestellt."""
        if m == "PUT":
            if self.fern:
                raise Fehler(NUR_AM_RECHNER, 403)
            try:
                update.schalten(self.daten_ordner, self._body().get("an"))
            except konfig.Meldung as e:
                raise Fehler(str(e))
        return update.stand(self.daten_ordner, plattform() in MIT_UPDATE_PRUEFUNG and not self.fern)

    def _feiertage_pruefen(self, werte: dict, modus: str, ab) -> None:
        """M10: eigener jährlicher Feiertag auf einem gesetzlichen (feiertage.eigene_pruefen) gegen die Regeln, die am Tag der Änderung gelten.
        Nur neue oder geänderte eigene Feiertage: ein schon gespeichertes Doppel (alte Fassung, Synchronisierung) sperrt sonst das ganze Formular.
        Vor konfig.aendern, damit bei einem Fehler nichts im Speicher geändert ist. Fehler: Fehler 400 mit Datum und Name."""
        if "feiertage_eigen" not in werte:
            return
        neu = konfig.pruefen(werte)                           # KonfigFehler meldet die Route wie bei konfig.aendern
        tag = _datum(ab) if modus in ("ab_datum", "ab_datum_folgend") else date.today()
        try:
            # shortcut: prüft nur die Version am Tag der Änderung; bei ab_datum_folgend mit späterem anderem Bundesland bleibt ein Doppel möglich (harmlos); aufrüsten, wenn die Oberfläche das anbietet
            gilt = konfig.fuer(tag)
            bekannt = {tuple(e) for e in gilt["feiertage_eigen"]}
            eigene = [e for e in neu["feiertage_eigen"] if tuple(e) not in bekannt]
            eigene_pruefen({**gilt, **neu, "feiertage_eigen": eigene}, tag.year)
        except konfig.Meldung as e:
            raise Fehler(str(e))

    def _startwerte(self, m: str, db, demo_an: bool) -> dict:
        """GET /api/startwerte[?ab=JJJJ-MM-TT] (Stand oder Vorbelegung für ab, schreibt nichts) und PUT /api/startwerte (setzen, ändern,
        löschen ohne stille Sprünge, bericht.startwerte_speichern). Rückgabe: bericht.startwerte_stand bzw. {"ok", "hinweise"}.
        Fehler 400 bei ungültigem oder künftigem Datum und Werten außerhalb der Grenzen (dann ist nichts geschrieben), im Demo-Modus beim Schreiben."""
        heute = date.today()
        try:
            if m == "PUT":
                if demo_an:
                    raise Fehler(DEMO_STARTWERTE)
                werte, alt = startwerte_eingabe(self._body()), db.startwerte_lesen()
                return {"ok": True, "hinweise": bericht.startwerte_speichern(db, werte, heute) + _verschoben(alt, werte)}
            treffer = STARTWERTE_AB.search(self.path.partition("?")[2])
            ab = _datum(treffer[1]) if treffer else None
            return bericht.startwerte_stand(db, ab, heute)
        except konfig.KonfigFehler as e:
            raise Fehler(str(e))

    def _konfig_antwort(self, db) -> dict:
        """Regeln für die Oberfläche. Das Modul „Synchronisierung“ steht je Gerät in geraet.json und kommt hier dazu."""
        u = konfig.uebersicht(db)
        if self.daten_ordner:
            g = sicherung.geraet_lesen(self.daten_ordner)
            if g["abgleich_aus"]:
                u["werte"]["module_aus"] = [m for m in konfig.MODULE if m in u["werte"]["module_aus"] or m == "abgleich"]
            u["abgleich_allein"] = bool(g["abgleich_allein"])
        return u
