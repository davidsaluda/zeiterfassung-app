# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Weitere Anschlüsse einer lokalen App (aus server.py geschnitten, Runde 1.4): Dienst, Freigabe der Ablage auf FREIGABE_PORT (8793),
Freigabe der Oberfläche auf OBERFLAECHE_PORT (8794) und die eigenen Adressen. Tests binden die zwei Ports hier um:
Andere Dateien lesen sie nur als anschluesse.<Name>, nie über from-Import."""
import os
import secrets
import socket
import sys
import threading
from http.server import ThreadingHTTPServer

from ausgabe import qr
from daten import sicherung
from routen.eingabe import MIT_ADRESSE, plattform

OBERFLAECHE_PORT = 8794                                    # Anschluss, auf dem die Desktop-Fassung ihre Oberfläche für das eigene Handy im selben Netz freigibt (nur mit Zugangsgeheimnis)
FREIGABE_PORT = sicherung.FREIGABE_PORT                    # 8793: Anschluss, auf dem eine lokale App als Speicherort für andere Geräte lauscht (nur die Ablage); Tests binden ihn hier um
KEIN_NETZ = "Dieses Gerät ist gerade in keinem Netz. Bitte WLAN oder VPN einschalten."   # Freigabe und Kopplung merken sich das Netz: ohne Netz abgelehnt
# Ohne Passwort nähme die Ablage jede Datei ohne Nachweis an (ziele.schreiben_pruefen): 8793 öffnet darum nur mit Passwort (Nachprüfung 22.11.2026)
FREIGABE_OHNE_PASSWORT = "Erst ein Sync-Passwort festlegen. Ohne Passwort könnte jedes Gerät im Netz die Sync-Dateien ersetzen."


class Dienst(ThreadingHTTPServer):
    """HTTP-Server mit einem Thread je Verbindung."""
    daemon_threads = True
    request_queue_size = 128                               # Vorgabe wäre 5: Kommen mehr Anfragen im selben Augenblick, bricht Linux einzelne Verbindungen ab
    allow_reuse_address = os.name != "nt"                  # unter Windows dürften sich sonst zwei Programme denselben Port teilen (Anfragen landen dann beim falschen)

    def handle_error(self, request, client_address):
        """Trennt die Gegenseite eine wartende Verbindung, ist das kein Fehler des Dienstes: nichts ins Protokoll schreiben."""
        if not isinstance(sys.exc_info()[1], (ConnectionError, TimeoutError)):
            super().handle_error(request, client_address)


_freigabe = {"dienst": None, "handler": None}               # handler: Klasse für 8793, gemerkt beim Einschalten (auch wenn der Anschluss zu bleibt), None nach dem Ausschalten
_FREIGABE_SCHLOSS = threading.Lock()                       # Schalter, Kopplung und Automatik öffnen und schließen 8793 aus verschiedenen Fäden


def freigabe_an(daten: str) -> bool:
    """True, wenn die Freigabe der Ablage (zweiter Anschluss) eingeschaltet ist und läuft."""
    return plattform() in MIT_ADRESSE and bool(sicherung.geraet_lesen(daten).get("freigabe")) and _freigabe["dienst"] is not None


def freigabe_schalten(h, an: bool, ausdruecklich: bool = False, adresse: str = "") -> None:
    """Zweiter Anschluss für die anderen Geräte im selben Netz (WLAN, VPN): Er kennt nur die Ablage der verschlüsselten Synchronisierungsdateien,
    keine Oberfläche und keine Daten. Ohne Zugangsgeheimnis und ohne Adressliste, denn die anderen Geräte kennen beides nicht. OSError: Anschluss belegt.
    ausdruecklich: Die Person schaltet gerade ein (Schalter, Kopplung). Sonst (Start der App) öffnet der Anschluss nur in dem Netz, in dem sie ihn
    eingeschaltet hat: Ohne Anmeldung stünde er sonst in jedem Café- oder Hotel-WLAN offen. geraet.json „freigabe“: False (aus), die eigene Adresse
    beim Einschalten (an in diesem Netz) oder True (Netz unbekannt: nur aus einer älteren Fassung, denn ohne Netz lehnt das Einschalten ab (KEIN_NETZ)).
    True gilt als pausiert und wird nie still umgeschrieben: Der erste Start nach dem Update in einem fremden WLAN machte sonst dieses Netz zu
    „zu Hause“ (Entscheidung der Leitung, 19.11.2026). Erst das ausdrückliche Einschalten oder ein neues Koppeln merkt das Netz.
    Wechselt das Netz später, gleicht freigabe_angleichen den Anschluss an.
    adresse: beim ausdrücklichen Einschalten die eigene Adresse im Netz (netz_adresse, wird danach gemerkt); 8793 lauscht nur dort."""
    if an:
        _freigabe["handler"] = h
        if not ausdruecklich:
            adresse = _gemerkt_hier(_freigabe_gemerkt(sicherung.geraet_lesen(h.daten_ordner)))
            if not adresse:
                return
    else:
        with _FREIGABE_SCHLOSS:                            # Ausschalten wirkt sofort: Ohne Handler öffnet auch die Automatik nicht mehr
            _freigabe["handler"] = None
    _dienst_schalten(an, adresse)


def freigabe_merken(daten: str, ip: str) -> None:
    """Gleich nach dem ausdrücklichen Schalten das Netz merken (ip, leer = aus), noch bevor ein späterer Teil der Anfrage scheitern kann:
    Offen beim alten Wert True folgte 8793 sonst dem Netz nicht mehr. OSError (geraet.json nicht schreibbar): 8793 wieder zu, Fehler weiter."""
    try:
        sicherung.geraet_aendern(daten, freigabe=ip or False)
    except OSError:
        freigabe_schalten(None, False)
        raise


def freigabe_angleichen(daten: str) -> None:
    """Je Durchgang der Automatik: 8793 (Ablage) und 8794 (Oberfläche) offen genau dann, wenn dieses Gerät in dem Netz ist, in dem die Person
    die Freigabe eingeschaltet hat, und dann an genau dieser Adresse. So schließen sie bei laufender App im fremden Netz (Ruhezustand, Café)
    und öffnen zu Hause wieder, auch nach einem Start ohne Netz. geraet.json bleibt unverändert."""
    g = sicherung.geraet_lesen(daten)
    _angleichen(_freigabe_gemerkt(g), _freigabe, _dienst_schalten)
    _angleichen(g.get("oberflaeche"), _oberflaeche, lambda an, adresse: _oberflaeche_dienst(daten, an, adresse))


def _freigabe_gemerkt(g: dict):
    """Der gemerkte Wert der Freigabe (geraet.json „freigabe“), ohne Sync-Passwort aber False: Dann bleibt 8793 zu, der Merkwert bleibt stehen."""
    return g.get("freigabe") if g["schluessel"] else False


def _angleichen(gemerkt, stand: dict, schalten) -> None:
    """Gleicht einen Anschluss (stand: _freigabe oder _oberflaeche) an das gemerkte Netz an; schalten(an, adresse) öffnet bzw. schließt ihn.
    Wert True (Netz unbekannt, ältere Fassung): nichts tun, pausiert bleibt zu, ein ausdrücklich geöffneter bleibt offen (Schalter und Kopplung
    öffnen erst und schreiben die Adresse danach, freigabe_merken). Lauscht er an einer anderen als der gemerkten Adresse, bindet er neu
    (Merkwert und Bindung gleich). Fiele das genau zwischen Öffnen und Merken, bindet der nächste Durchgang wieder an die neue Adresse.
    Belegter Anschluss: kein Fehler, der nächste Durchgang versucht es wieder."""
    if gemerkt is True or stand["handler"] is None:
        return
    # shortcut: erkennt das Netz an der eigenen Adresse; ein fremdes Netz, das dieselbe Adresse vergibt, gilt als eigenes. Upgrade: Kennung des Netzes (z. B. Router-MAC), falls ohne Zusatzrechte lesbar.
    soll = bool(gemerkt) and gemerkt in eigene_adressen()
    try:
        schalten(soll, gemerkt)                            # tut nichts, wenn der Anschluss schon so steht
    except OSError:
        pass


def _dienst_schalten(an: bool, adresse: str = "") -> None:
    """Öffnet 8793 an der Adresse des Netzes mit dem gemerkten Handler (keiner: ausgeschaltet, bleibt zu) oder schließt ihn; unter Schloss,
    damit nie zwei Dienste entstehen und ein Ausschalten nicht überholt wird. Lauscht er schon an einer anderen Adresse, bindet er neu. Nur an dieser Adresse, nicht an allen: Über andere Adapter
    (VPN daneben, fremdes WLAN nach dem Aufwachen) ist er so nie erreichbar. OSError: Anschluss belegt oder Adresse nicht (mehr) da."""
    with _FREIGABE_SCHLOSS:
        _anschluss_schalten(_freigabe, an, adresse, lambda: Dienst((adresse, FREIGABE_PORT), type("A", (_freigabe["handler"],),
                            {"nur_ablage": True, "erlaubte_hosts": frozenset(), "zugang": "", "antworten": {}})))


def _anschluss_schalten(stand: dict, an: bool, adresse: str, bauen) -> None:
    """Gemeinsamer Teil von 8793 und 8794, nur unter dem Schloss des Anschlusses: öffnet (bauen() -> neuer Dienst an adresse), schließt oder
    bindet neu, wenn er an einer anderen Adresse lauscht (Adresswechsel: sonst stünden gemerkte Adresse und Bindung auseinander, und die
    Person sperrte sich aus). Erst der neue, dann der alte zu: Scheitert der neue Bind, bleibt der alte offen. OSError: Anschluss belegt
    oder Adresse nicht (mehr) da."""
    alt = stand["dienst"]
    if an and stand["handler"] is not None and (alt is None or alt.server_address[0] != adresse):
        if not adresse:                                    # "" hieße für socket.bind alle Adressen
            raise OSError("Freigabe ohne Adresse im Netz")
        d = bauen()
        stand["dienst"] = d                                # erst eintragen, dann starten: _bearbeiten beantwortet nur Anfragen des eingetragenen Dienstes
        threading.Thread(target=d.serve_forever, daemon=True).start()
        _schliessen(alt)
    elif not an and alt is not None:
        stand["dienst"] = None
        _schliessen(alt)


def _schliessen(d) -> None:
    """Beendet einen Dienst (None: nichts zu tun)."""
    if d is not None:
        d.shutdown()
        d.server_close()


def _gemerkt_hier(gemerkt) -> str:
    """Die gemerkte Adresse einer Freigabe (geraet.json „freigabe“ bzw. „oberflaeche“), wenn dieses Gerät gerade in dem Netz ist, in dem die
    Person sie eingeschaltet hat; sonst "". Wert True (Netz unbekannt) steht in keiner Adressliste, gilt also immer als anderes Netz (pausiert)."""
    return gemerkt if isinstance(gemerkt, str) and gemerkt in eigene_adressen() else ""


def freigabe_adressen() -> list:
    """Die Adresse, unter der die anderen Geräte 8793 gerade erreichen (nur die gebundene), leer, wenn er zu ist."""
    d = _freigabe["dienst"]
    return [f"http://{d.server_address[0]}:{FREIGABE_PORT}"] if d is not None else []


_oberflaeche = {"dienst": None, "handler": None}           # handler: wie bei 8793, damit die Automatik zu Hause wieder öffnen kann
_OBERFLAECHE_SCHLOSS = threading.Lock()                    # Schalter und Automatik öffnen und schließen 8794 aus verschiedenen Fäden


def oberflaeche_schalten(h, daten: str, an: bool, adresse: str = "") -> None:
    """Dritter Anschluss, nur Desktop-Fassung: die ganze Oberfläche für das eigene Handy im selben Netz (WLAN, VPN). Gedacht für iPhone und iPad:
    Safari lässt die Web-App nicht mit einem Rechner im Netz synchronisieren, kann seine Oberfläche aber öffnen. Zugang nur mit dem Geheimnis aus dem
    QR-Code (128 Bit, bleibt über Neustarts gleich, bis die Freigabe aus- und wieder eingeschaltet wird). Kein „App beenden“ und keine Einrichtung
    der Synchronisierung von dort. Die Verbindung ist nicht verschlüsselt, deshalb nur im eigenen Netz und nur an dessen Adresse.
    adresse: beim Einschalten durch die Person die eigene Adresse im Netz (die Route merkt sie in geraet.json „oberflaeche“). Leer (Start):
    die gemerkte, nur wenn das Gerät gerade in diesem Netz ist; sonst bleibt 8794 zu, bis freigabe_angleichen ihn dort öffnet.
    Wert True (ältere Fassung, Netz unbekannt): pausiert wie bei 8793, bis die Person neu einschaltet. OSError: Anschluss belegt."""
    if an:
        _oberflaeche["handler"] = h
        adresse = adresse or _gemerkt_hier(sicherung.geraet_lesen(daten).get("oberflaeche"))
        if not adresse:
            return
    else:
        with _OBERFLAECHE_SCHLOSS:                         # Ausschalten wirkt sofort: Ohne Handler öffnet auch die Automatik nicht mehr
            _oberflaeche["handler"] = None
    _oberflaeche_dienst(daten, an, adresse)


def _oberflaeche_dienst(daten: str, an: bool, adresse: str = "") -> None:
    """Öffnet 8794 an der Adresse des Netzes mit dem gemerkten Handler (keiner: ausgeschaltet, bleibt zu), bindet neu oder schließt ihn;
    unter Schloss wie bei 8793. OSError: Anschluss belegt oder Adresse nicht (mehr) da."""
    with _OBERFLAECHE_SCHLOSS:
        _anschluss_schalten(_oberflaeche, an, adresse, lambda: _oberflaeche_bauen(daten, adresse))


def _oberflaeche_bauen(daten: str, adresse: str) -> Dienst:
    """Neuer Dienst für 8794 an der Adresse; das Zugangsgeheimnis bleibt, neu nur, wenn noch keines da ist."""
    zugang = sicherung.geraet_lesen(daten).get("oberflaeche_zugang") or secrets.token_hex(16)
    sicherung.geraet_aendern(daten, oberflaeche_zugang=zugang)
    return Dienst((adresse, OBERFLAECHE_PORT), type("O", (_oberflaeche["handler"],), {"fern": True, "erlaubte_hosts": frozenset(), "zugang": zugang, "antworten": {}}))


def oberflaeche_stand(daten: str):
    """-> None (aus) oder Adresse und QR-Code für das Handy. Die Adresse enthält das Zugangsgeheimnis: Nur die Desktop-Fassung selbst zeigt sie.
    Es ist die Adresse, an der 8794 lauscht, nicht die, die das System gerade vorzöge."""
    g, d = sicherung.geraet_lesen(daten), _oberflaeche["dienst"]
    if d is None or not g.get("oberflaeche"):
        return None
    ip, port = d.server_address[:2]
    adresse = f"http://{ip}:{port}/?z={g['oberflaeche_zugang']}"
    return {"adresse": adresse, "qr": qr.svg(adresse, bezeichnung="QR-Code: diese Zeiterfassung am Handy öffnen")}


def netz_adresse() -> str:
    """Die Adresse, über die dieses Gerät gerade im Netz erreichbar ist; "" ohne Netz. Es wird nichts gesendet."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.0.2.1", 9))                        # UDP ohne Senden: Das System nennt nur die Adresse, die es dafür nähme
            return s.getsockname()[0]
    except OSError:
        return ""


def eigene_adressen() -> list:
    """Die Adressen dieses Geräts im Netz (für die Anzeige, damit die anderen Geräte sie eintragen können). Es wird nichts gesendet."""
    gefunden = [netz_adresse()]
    if gefunden[0]:
        try:
            gefunden += [a[4][0] for a in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)]
        except OSError:
            pass
    return sorted({ip for ip in gefunden if ip and not ip.startswith("127.")})
