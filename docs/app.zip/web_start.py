# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Start der Zeiterfassung im Browser (eigenständige Web-App ohne Server, siehe README.md in diesem Ordner).

Python läuft dort als WebAssembly (Pyodide) auf dem Gerät. Ports und Netz gibt es nicht: Die Seite reicht jede Anfrage der Oberfläche an anfrage()
weiter, und der unveränderte Dienst der App (server.Handler) beantwortet sie aus dem Arbeitsspeicher. Es ist derselbe Weg wie in allen anderen
Fassungen, nur ohne Anschluss dazwischen. Diese Datei läuft auch unter normalem Python (tests/test_browser.py)."""
import io
import os
import re

METHODEN = ("GET", "PUT", "POST", "DELETE")
SICHER = re.compile(r"[\x21-\x7e]*")                       # sichtbare ASCII-Zeichen ohne Leerzeichen: nichts, was eine Kopfzeile beenden könnte
SICHER_MIT_LEER = re.compile(r"[\x20-\x7e\x80-￿]*")   # Cookie und Inhaltsart dürfen Leerzeichen und Umlaute enthalten, aber keine Steuerzeichen
ZIEL_ORDNER = "verschluesselt"                             # hier liegen die verschlüsselten Sicherungen, bis die Person sie als Datei speichert
_zustand = {}


class _Verbindung:
    """Steht für die Netz-Verbindung: Der Dienst liest die Anfrage aus dem Speicher und schreibt die Antwort in den Speicher."""

    def __init__(self, anfrage: bytes):
        """Legt die Anfrage zum Lesen und einen leeren Speicher für die Antwort an."""
        self.ein, self.aus = io.BytesIO(anfrage), io.BytesIO()

    def makefile(self, art, *_, **__):
        """Gibt den Lese- oder Schreibspeicher zurück, wie es der Dienst von einer Verbindung erwartet."""
        return self.ein if "r" in art else self.aus

    def sendall(self, daten):
        """Schreibt Antwortdaten in den Speicher."""
        self.aus.write(daten)

    def settimeout(self, _):
        """Ohne Wirkung: Im Speicher gibt es keine Wartezeit."""
        pass

    def setsockopt(self, *_):
        """Ohne Wirkung: Es gibt keinen Anschluss."""
        pass


def starten(daten: str, plattform: str = "browser") -> None:
    """daten: Ordner der Datenbank (im Browser ein Ordner, den die Seite dauerhaft im Gerät speichert)."""
    if "handler" in _zustand:
        return
    ziel = os.path.join(daten, ZIEL_ORDNER)
    os.makedirs(ziel, exist_ok=True)
    os.environ.update(HO_DATEN=daten, HO_PLATTFORM=plattform, HO_SICHERUNG_ZIEL=ziel, HO_SICHERUNG_ART="browser")
    import server
    handler, db = server.handler_erstellen(daten)
    server.tagessicherung(db, daten)
    _zustand.update(handler=handler, db=db)


def beenden() -> None:
    """Vergisst Dienst und Datenbank (für Tests)."""
    _zustand.clear()


def anfrage(methode: str, pfad: str, typ: str = "", cookie: str = "", koerper: bytes = b""):
    """Eine Anfrage der Oberfläche beantworten -> (Status, [(Kopfzeile, Wert), …], Inhalt).
    Die Angaben kommen von der eigenen Seite; trotzdem wird nichts übernommen, was die Kopfzeilen verändern könnte."""
    if methode not in METHODEN or not pfad.startswith("/") or not SICHER.fullmatch(pfad) or not SICHER_MIT_LEER.fullmatch(typ) or not SICHER_MIT_LEER.fullmatch(cookie):
        raise ValueError("Ungültige Anfrage")
    koerper = bytes(koerper)
    kopf = [f"{methode} {pfad} HTTP/1.1", "Host: app", "Connection: close", "Sec-Fetch-Site: same-origin", f"Content-Length: {len(koerper)}"]
    if typ:
        kopf.append(f"Content-Type: {typ}")
    if cookie:
        kopf.append(f"Cookie: {cookie}")
    verbindung = _Verbindung("\r\n".join(kopf).encode("utf-8") + b"\r\n\r\n" + koerper)
    _zustand["handler"](verbindung, ("browser", 0), None)
    return _zerlegen(verbindung.aus.getvalue())


def _zerlegen(antwort: bytes):
    """Teilt die rohe Antwort in (Status, Kopfzeilen, Inhalt)."""
    kopf, _, inhalt = antwort.partition(b"\r\n\r\n")
    zeilen = kopf.decode("iso-8859-1").split("\r\n")
    return int(zeilen[0].split(" ", 2)[1]), [tuple(z.split(": ", 1)) for z in zeilen[1:] if ": " in z], inhalt


def selbsttest() -> str:
    """Rechnet den festen Prüfdatensatz auf diesem Gerät nach (Wegwerf-Datenbank, die echten Daten bleiben unberührt) und prüft die Verschlüsselung.
    Derselbe Text wie in der Android-Fassung (handy_start.selbsttest)."""
    from daten import aes
    import pruefdaten
    return f"{pruefdaten.anzahl()} Rechenwerte, {len(pruefdaten.selbsttest())} Abweichungen, AES-256-GCM {'in Ordnung' if aes.selbsttest() else 'FEHLT'}"
