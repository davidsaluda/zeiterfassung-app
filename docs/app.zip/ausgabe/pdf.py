# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Eingebauter PDF-Erzeuger (nur Standardbibliothek): baut Monatsbericht und Homeoffice-Übersicht direkt als PDF, ohne Gotenberg, ohne Browser,
ohne Zusatzpakete. Damit funktioniert der PDF-Export überall, auch in der Android-App und wenn der PDF-Dienst nicht erreichbar ist.

Eingabe sind dieselben Blöcke wie für Word/ODT (dokument.py): ("h", Überschrift), ("p", Absatz), ("t", Kopfzeile, Zeilen).
Gestaltung in der Akzentfarbe der App (design.Palette): Titelband, Kennzahl-Kacheln, Tabellen mit farbiger Kopfzeile und gestreiften Zeilen,
graue Wochenenden, Fußzeile mit Version, Urheberhinweis und „Seite x von y“. Schrift: Helvetica (in jedem PDF-Betrachter vorhanden, nichts eingebettet)."""
import unicodedata
import zlib

from ausgabe import design
from urheber import FUSS

BREITE, HOEHE = 595.28, 841.89                              # A4 in Punkt
RAND_L, RAND_R, RAND_O, RAND_U = 40.0, 40.0, 36.0, 46.0
NUTZ = BREITE - RAND_L - RAND_R
ZEILENABSTAND = 10.0                                        # Abstand der Zeilen einer umbrochenen Tabellenzelle (Schrift 8,5 pt)

# Zeichenbreiten von Helvetica und Helvetica-Bold (Tausendstel der Schriftgröße) für die Zeichen 32 bis 126
_W_NORMAL = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584,
             556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278,
             469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260,
             334, 584]
_W_FETT = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584,
           611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333,
           584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280,
           389, 584]
_W_SONDER = {"ß": 611, "„": 333, "“": 333, "”": 333, "‚": 222, "‘": 222, "’": 222, "–": 556, "—": 1000, "·": 278, "€": 556, "…": 1000, "§": 556, "°": 400, "•": 350}
_ERSATZ = {"−": "-", "→": "->", "←": "<-", "✕": "x", "≥": ">=", "≤": "<=", " ": " ", " ": " ", " ": " ", "\t": " "}


def _klar(text) -> str:
    """Text auf den Zeichenvorrat der PDF-Standardschrift (Windows-1252) bringen; Unbekanntes wird ersetzt, nie ein Fehler."""
    t = "".join(_ERSATZ.get(z, z) for z in str(text))
    t = "".join(z for z in t if z >= " ")
    return t.encode("cp1252", "replace").decode("cp1252")


def breite(text: str, groesse: float, fett: bool = False) -> float:
    """Breite eines Textes in Punkt für Helvetica (normal oder fett) aus der Zeichentabelle; Umlaute zählen wie der Grundbuchstabe."""
    tab, summe = (_W_FETT if fett else _W_NORMAL), 0
    for z in text:
        n = ord(z)
        if 32 <= n <= 126:
            summe += tab[n - 32]
        elif z in _W_SONDER:
            summe += _W_SONDER[z]
        else:                                               # Umlaute und Akzente: so breit wie der Grundbuchstabe
            g = unicodedata.normalize("NFD", z)[0]
            summe += tab[ord(g) - 32] if 32 <= ord(g) <= 126 else 556
    return summe * groesse / 1000


ZEILE_MAX = 400                                            # mehr Zeichen passen in keiner Schriftgröße in eine Zeile der Seite


def _kuerzen(text: str, platz: float, groesse: float, fett: bool = False) -> str:
    """Kürzt den Text mit „…“, bis er in den Platz passt; riesige Texte werden vorher auf ZEILE_MAX Zeichen begrenzt."""
    if breite(text, groesse, fett) <= platz + 0.6:                # kleine Zugabe gegen Rundung
        return text
    text = text[:ZEILE_MAX]                                       # sonst kostet ein riesiger Text (Anmerkung aus einer Sicherung) Minuten
    while text and breite(text + "…", groesse, fett) > platz:
        text = text[:-1]
    return text.rstrip() + "…" if text else ""


def _umbrechen(text: str, platz: float, groesse: float, fett: bool = False) -> list:
    """Bricht den Text an Wortgrenzen in Zeilen, die in den Platz passen (zu lange Zeilen werden gekürzt). Gibt die Zeilen zurück."""
    zeilen, zeile = [], ""
    for wort in text.split():
        probe = (zeile + " " + wort).strip()
        if breite(probe, groesse, fett) <= platz or not zeile:
            zeile = probe
        else:
            zeilen.append(zeile)
            zeile = wort
    if zeile:
        zeilen.append(zeile)
    return [_kuerzen(z, platz, groesse, fett) for z in zeilen] or [""]


def _wort_teilen(wort: str, platz: float, groesse: float, fett: bool = False) -> list:
    """Teilt ein Wort, das breiter als der Platz ist, in Stücke, die einzeln hineinpassen. Gibt die Stücke zurück (ein passendes Wort bleibt ganz)."""
    teile = [""]
    for z in wort:
        if teile[-1] and breite(teile[-1] + z, groesse, fett) > platz:
            teile.append("")
        teile[-1] += z
    return teile


def _umbrechen_ganz(text: str, platz: float, groesse: float, fett: bool = False) -> list:
    """Wie _umbrechen, aber zu lange Wörter werden geteilt statt gekürzt: kein Zeichen geht verloren. Gibt die Zeilen zurück."""
    return _umbrechen(" ".join(t for w in text.split() for t in _wort_teilen(w, platz, groesse, fett)), platz, groesse, fett)


def _zelle(text: str, platz: float, groesse: float, fett: bool, umbrechen: bool) -> list:
    """Zeilen einer Tabellenzelle: umbrochen ohne Verlust oder (ab Werk) eine Zeile, mit „…“ gekürzt."""
    return _umbrechen_ganz(text, platz, groesse, fett) if umbrechen else [_kuerzen(text, platz, groesse, fett)]


def _rgb(c: str) -> str:
    """Farbe „#rrggbb“ als drei Zahlen von 0 bis 1 für den PDF-Befehl."""
    return " ".join(f"{int(c[i:i + 2], 16) / 255:.3f}" for i in (1, 3, 5))


class _Blatt:
    """Eine Seite: sammelt die Zeichenbefehle. y zählt wie im PDF von unten."""

    def __init__(self):
        """Beginnt mit einer leeren Liste von Zeichenbefehlen."""
        self.ops = []

    def flaeche(self, x, y, w, h, farbe):
        """Gefülltes Rechteck."""
        self.ops.append(f"{_rgb(farbe)} rg {x:.2f} {y:.2f} {w:.2f} {h:.2f} re f")

    def linie(self, x1, y1, x2, y2, farbe, staerke=0.5):
        """Linie von (x1, y1) nach (x2, y2)."""
        self.ops.append(f"{_rgb(farbe)} RG {staerke:.2f} w {x1:.2f} {y1:.2f} m {x2:.2f} {y2:.2f} l S")

    def text(self, x, y, text, groesse, farbe="#111318", fett=False, rechts=False):
        """rechts=True: x ist die rechte Kante."""
        if not text:
            return
        if rechts:
            x -= breite(text, groesse, fett)
        roh = text.encode("cp1252", "replace").replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)").decode("latin-1")
        self.ops.append(f"BT {_rgb(farbe)} rg /F{2 if fett else 1} {groesse:.2f} Tf {x:.2f} {y:.2f} Td ({roh}) Tj ET")


class _Dokument:
    """Das ganze PDF-Dokument: Seiten, Schreibposition und die Bausteine (Titelband, Überschrift, Absatz, Kacheln, Tabelle)."""
    def __init__(self, palette):
        """Merkt die Farben und legt die erste Seite an."""
        self.p = palette
        self.seiten = []
        self.y = 0.0
        self.neue_seite()

    def neue_seite(self):
        """Beginnt eine neue Seite; die Schreibposition rutscht nach oben."""
        self.blatt = _Blatt()
        self.seiten.append(self.blatt)
        self.y = HOEHE - RAND_O

    def platz(self, hoehe: float) -> bool:
        """Passt noch ein Block dieser Höhe auf die Seite (über den unteren Rand)?"""
        return self.y - hoehe >= RAND_U

    # ---- Bausteine
    def titelband(self, titel: str, unterzeile: str = ""):
        """Farbiges Band mit Titel und optionaler Unterzeile."""
        h = 58 if unterzeile else 44
        self.blatt.flaeche(RAND_L, self.y - h, NUTZ, h, self.p.akzent)
        self.blatt.text(RAND_L + 14, self.y - (27 if unterzeile else 28), _kuerzen(titel, NUTZ - 28, 18, True), 18, self.p.auf_akzent, True)
        if unterzeile:
            self.blatt.text(RAND_L + 14, self.y - 44, _kuerzen(unterzeile, NUTZ - 28, 9), 9, self.p.auf_akzent)
        self.y -= h + 12

    def ueberschrift(self, text: str):
        """Zwischenüberschrift mit Linie darunter; bei Platzmangel auf einer neuen Seite."""
        if not self.platz(40):
            self.neue_seite()
        self.y -= 8
        self.blatt.text(RAND_L, self.y - 12, _kuerzen(text, NUTZ, 12.5, True), 12.5, self.p.titel, True)
        self.blatt.linie(RAND_L, self.y - 17, RAND_L + NUTZ, self.y - 17, self.p.linie, 0.6)
        self.y -= 26

    def absatz(self, text: str):
        """Fließtext, in Zeilen umbrochen; wechselt bei Bedarf die Seite."""
        for zeile in _umbrechen(text, NUTZ, 9.5):
            if not self.platz(13):
                self.neue_seite()
            self.blatt.text(RAND_L, self.y - 10, zeile, 9.5, "#333a45")
            self.y -= 13
        self.y -= 5

    def kacheln(self, paare: list, je_reihe: int = 3):
        """Kennzahlen als Kacheln: großer Wert, kleine Bezeichnung darunter."""
        luecke, h = 8.0, 36.0
        w = (NUTZ - luecke * (je_reihe - 1)) / je_reihe
        for i in range(0, len(paare), je_reihe):
            if not self.platz(h + luecke):
                self.neue_seite()
            for n, (name, wert) in enumerate(paare[i:i + je_reihe]):
                x = RAND_L + n * (w + luecke)
                self.blatt.flaeche(x, self.y - h, w, h, self.p.weich)
                self.blatt.flaeche(x, self.y - h, 2.5, h, self.p.akzent)
                self.blatt.text(x + 11, self.y - 16, _kuerzen(wert, w - 20, 12.5, True), 12.5, self.p.tief, True)
                self.blatt.text(x + 11, self.y - 28, _kuerzen(name, w - 20, 7.5), 7.5, self.p.grau)
            self.y -= h + luecke
        self.y -= 4

    def tabelle(self, kopf: list, zeilen: list, zahlen: set, frei=(), umbrechen=False):
        """frei: je Zeile True, wenn sie grau erscheint (Wochenende, Feiertag); fehlende Angaben gelten als nicht frei.
        umbrechen: Textspalten in mehrere Zeilen umbrechen statt kürzen (die Zeile wird höher)."""
        g, pad, zh, kh = 8.5, 6.0, 14.2, 17.0
        n = len(kopf)
        zeilen = [[(z[i] if i < len(z) else "") for i in range(n)] for z in zeilen]
        wunsch = [max([breite(kopf[i], g, True)] + [breite(z[i], g, i == 0 and n > 2) for z in zeilen]) + 2 * pad + 1 for i in range(n)]
        text_spalten = [i for i in range(n) if i not in zahlen] or list(range(n))
        rest = NUTZ - sum(wunsch)
        if rest < 0:                                        # zu breit: die Textspalten geben nach (lange Hinweise werden gekürzt)
            fest = sum(wunsch[i] for i in range(n) if i not in text_spalten)
            teil = max(40.0, (NUTZ - fest) / len(text_spalten))
            knapp = [i for i in text_spalten if wunsch[i] > teil]
            frei_platz = NUTZ - sum(wunsch[i] for i in range(n) if i not in knapp)
            for i in knapp:
                wunsch[i] = max(30.0, frei_platz / len(knapp))
        else:                                               # Platz übrig: die letzte Textspalte füllt die Seite, Zahlen bleiben schmal
            wunsch[text_spalten[-1]] += rest
        skala = NUTZ / sum(wunsch)
        w = [x * skala for x in wunsch]
        x0 = [RAND_L + sum(w[:i]) for i in range(n)]

        def kopfzeile():
            """Zeichnet die Kopfzeile der Tabelle (auch auf Folgeseiten)."""
            self.blatt.flaeche(RAND_L, self.y - kh, NUTZ, kh, self.p.akzent)
            for i in range(n):
                t = _kuerzen(kopf[i], w[i] - 2 * pad, g, True)
                if i in zahlen:
                    self.blatt.text(x0[i] + w[i] - pad, self.y - 11.6, t, g, self.p.auf_akzent, True, rechts=True)
                else:
                    self.blatt.text(x0[i] + pad, self.y - 11.6, t, g, self.p.auf_akzent, True)
            self.y -= kh

        if not self.platz(kh + 2 * zh):
            self.neue_seite()
        kopfzeile()
        for nr, z in enumerate(zeilen):
            zellen = [_zelle(z[i], w[i] - 2 * pad, g, i == 0 and n > 2, umbrechen and i not in zahlen) for i in range(n)]
            hoehe = zh + ZEILENABSTAND * (max(len(c) for c in zellen) - 1)
            if not self.platz(hoehe):
                self.neue_seite()
                kopfzeile()
            ist_frei = nr < len(frei) and frei[nr]
            if ist_frei:
                self.blatt.flaeche(RAND_L, self.y - hoehe, NUTZ, hoehe, self.p.frei)
            elif nr % 2 == 1:
                self.blatt.flaeche(RAND_L, self.y - hoehe, NUTZ, hoehe, self.p.weich)
            farbe = self.p.grau if ist_frei else "#111318"
            for i in range(n):
                for k, t in enumerate(zellen[i]):
                    y = self.y - 10.2 - k * ZEILENABSTAND
                    if i in zahlen:
                        self.blatt.text(x0[i] + w[i] - pad, y, t, g, farbe, i == 0 and n > 2, rechts=True)
                    else:
                        self.blatt.text(x0[i] + pad, y, t, g, farbe, i == 0 and n > 2)
            self.blatt.linie(RAND_L, self.y - hoehe, RAND_L + NUTZ, self.y - hoehe, self.p.linie, 0.3)
            self.y -= hoehe
        self.y -= 12

    # ---- Ausgabe
    def bytes(self, titel: str) -> bytes:
        """Fertiges PDF als Bytes. Setzt zuerst die Fußzeile mit „Seite x von y“ auf jede Seite, schreibt dann Katalog, Schriften, Seiten (Inhalt mit zlib gepackt) und die Verweistabelle."""
        gesamt = len(self.seiten)
        for nr, blatt in enumerate(self.seiten, 1):         # Fußzeile erst jetzt: die Seitenzahl „von y“ steht erst am Ende fest
            blatt.linie(RAND_L, 30, RAND_L + NUTZ, 30, self.p.akzent, 0.8)
            blatt.text(RAND_L, 19, _kuerzen(_klar(FUSS), NUTZ - 80, 7), 7, self.p.grau)
            blatt.text(RAND_L + NUTZ, 19, f"Seite {nr} von {gesamt}", 7, self.p.grau, rechts=True)
        objekte = {1: b"<< /Type /Catalog /Pages 2 0 R /Lang (de-DE) >>",
                   3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
                   4: b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"}
        def hexa(t):
            """Text als PDF-Textfolge in UTF-16 (hexadezimal) für Titel und Autor."""
            return b"<FEFF" + t.encode("utf-16-be").hex().upper().encode("ascii") + b">"
        objekte[5] = b"<< /Title " + hexa(titel) + b" /Author " + hexa("Zeiterfassung") + b" /Producer " + hexa("Zeiterfassung (eingebauter PDF-Export)") + b" >>"
        kinder = []
        for nr, blatt in enumerate(self.seiten):
            inhalt = zlib.compress("\n".join(blatt.ops).encode("latin-1"), 9)
            ci, pi = 6 + 2 * nr, 7 + 2 * nr
            objekte[ci] = b"<< /Length " + str(len(inhalt)).encode() + b" /Filter /FlateDecode >>\nstream\n" + inhalt + b"\nendstream"
            objekte[pi] = (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {BREITE:.2f} {HOEHE:.2f}] /Contents {ci} 0 R "
                           f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>").encode()
            kinder.append(f"{pi} 0 R")
        objekte[2] = f"<< /Type /Pages /Kids [{' '.join(kinder)}] /Count {gesamt} >>".encode()
        aus = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        orte = {}
        for nr in sorted(objekte):
            orte[nr] = len(aus)
            aus += str(nr).encode() + b" 0 obj\n" + objekte[nr] + b"\nendobj\n"
        xref = len(aus)
        hoechste = max(objekte)
        aus += f"xref\n0 {hoechste + 1}\n".encode() + b"0000000000 65535 f \n"
        for nr in range(1, hoechste + 1):
            aus += f"{orte[nr]:010d} 00000 n \n".encode()
        aus += f"trailer\n<< /Size {hoechste + 1} /Root 1 0 R /Info 5 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
        return bytes(aus)


def _block(d: _Dokument, b: tuple, umbrechen: bool):
    """Zeichnet einen Block (Überschrift, Absatz, Tabelle oder Kacheln) an die Schreibposition."""
    from ausgabe import dokument                                          # hier, damit pdf.py für sich allein ladbar bleibt
    if b[0] == "h":
        d.ueberschrift(_klar(b[1]))
    elif b[0] == "p":
        d.absatz(_klar(b[1]))
    elif b[0] == "t":
        kopf = [_klar(k) for k in b[1]]
        frei = [dokument._frei_zeile(zeile) for zeile in b[2]]     # vor dem Umformen: die Zeile weiß selbst, ob sie ein Feiertag ist
        zeilen = [[_klar(z) for z in zeile] for zeile in b[2]]
        if kopf[:2] == ["Kennzahl", "Wert"] and len(kopf) == 2:
            d.kacheln([(z[0], z[1]) for z in zeilen])
        elif zeilen:
            d.tabelle(kopf, zeilen, dokument._zahlspalten(kopf, zeilen), frei, umbrechen)
        else:
            d.absatz("keine Einträge")


def _passt_zusammen(d: _Dokument, bloecke: list, umbrechen: bool) -> bool:
    """Passen die Blöcke ungeteilt auf den Rest der Seite? Misst per Probelauf auf einer leeren Seite (gleiche Bausteine, keine doppelte Rechnung).
    Blöcke, die selbst länger als eine Seite sind, gelten als passend: eine neue Seite hilft ihnen nicht."""
    probe = _Dokument(d.p)
    for b in bloecke:
        _block(probe, b, umbrechen)
    return len(probe.seiten) > 1 or d.platz(HOEHE - RAND_O - probe.y)


def aus_bloecken(bloecke: list, palette=None, umbrechen=False, zusammen=0) -> bytes:
    """Blöcke (wie für Word/ODT) als fertiges PDF. Der erste Block „h“ wird das Titelband, ein direkt folgender Absatz seine Unterzeile;
    eine Tabelle mit der Kopfzeile Kennzahl/Wert wird zu Kacheln. umbrechen: lange Texte in Tabellen umbrechen statt kürzen (Monatsnachweis).
    zusammen: so viele letzte Blöcke stehen gemeinsam auf einer Seite (Summen und Unterschrift nie allein auf der nächsten Seite)."""
    d = _Dokument(palette or design.Palette())
    titel, i = "Zeiterfassung", 0
    if bloecke and bloecke[0][0] == "h":
        titel = _klar(bloecke[0][1])
        unter = _klar(bloecke[1][1]) if len(bloecke) > 1 and bloecke[1][0] == "p" else ""
        d.titelband(titel, unter)
        i = 2 if unter else 1
    ende = max(i, len(bloecke) - zusammen) if zusammen else len(bloecke)
    for b in bloecke[i:ende]:
        _block(d, b, umbrechen)
    if ende < len(bloecke) and not _passt_zusammen(d, bloecke[ende:], umbrechen):
        d.neue_seite()
    for b in bloecke[ende:]:
        _block(d, b, umbrechen)
    return d.bytes(titel)
