# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Daten-Exporte: CSV für Monat und alle Tage, JSON der Tage für die Seite Export, Kalender (.ics). Nur Standardbibliothek."""
import csv
import io
import json

from daten import stempel
from daten.konfig import VERMERKE
from kern.regeln import notiz_bereinigen
from kern.zeit import fmt_dauer, fmt_hhmm


def _csv_sicher(w):
    """Text ohne Steuer- und Bidi-Zeichen; beginnt er mit = + - @, würde eine Tabellenkalkulation ihn als Formel ausführen: mit Hochkomma entschärfen."""
    if not isinstance(w, str):
        return w
    w = notiz_bereinigen(w)
    return "'" + w if w[:1] in ("=", "+", "-", "@") else w


def zu_json(obj) -> bytes:
    """Objekt als eingerücktes JSON (UTF-8)."""
    return json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")


JA_NEIN = {False: "nein", True: "ja"}
TAGESSUMME = "Summe {}"                     # letzte Blockzeile eines Tages mit mehreren Blöcken (CSV und Monatsnachweis)
# Kopfzeile der CSV ist Text für die Person („Büro“); JSON-Schlüssel bleiben „dienststelle*“, weil Programme sie lesen (namen.md 5, S18a)
CSV_KOPF = {"dienststelle": "buero", "dienststelle_minuten": "buero_minuten"}


def _kappzeit(db, t, zeitformat: str) -> dict:
    """{"kappzeit": Summe im Zeitformat}, wenn der Tag t Kappzeit hat (stempel.kappzeit), sonst {} (die Spalte gibt es nur, wenn sie etwas zeigt)."""
    summe = sum(stempel.kappzeit(db, t).values()) if t.kommen >= 0 else 0
    return {"kappzeit": fmt_dauer(summe, zeitformat)} if summe else {}


def alle_tage(db, zeitformat: str = "hhmm") -> list:
    """Alle erfassten Tage (eine Zeile je Tag) für den Gesamtexport; HO und Büro im Zeitformat („hhmm“ oder „dezimal“), dazu immer die Minuten;
    Kommen, Gehen und Pause als Uhrzeit hh:mm; Vermerk als Text (z. B. „Fortbildung“), geprüft als ja/nein (funktionen.md 5); Kappzeit nur an Tagen mit Kappzeit."""
    return [{"datum": t.datum.isoformat(), "art": t.art, "ho": fmt_dauer(t.ho, zeitformat) if t.ho else "", "dienststelle": fmt_dauer(t.dst, zeitformat) if t.dst else "",
             "ho_minuten": t.ho, "dienststelle_minuten": t.dst,
             **({"kommen": fmt_hhmm(t.kommen), "gehen": fmt_hhmm(t.gehen), "pause": fmt_hhmm(t.pause)} if t.kommen >= 0 else {"kommen": "", "gehen": "", "pause": ""}),
             **_kappzeit(db, t, zeitformat),
             "notiz": notiz_bereinigen(t.notiz), "attest": t.attest, "konto": t.konto, "vermerk": VERMERKE.get(t.vermerk, ""), "geprueft": JA_NEIN[bool(t.geprueft)]}
            for t in db.tage_alle()]


def mit_kappzeit(felder: list, zeilen: list) -> list:
    """Spalten einer Tabelle, dazu „kappzeit“ nach „pause“, wenn eine Zeile Kappzeit hat (Auftrag vom 25.11.2026); sonst unverändert wie bisher."""
    if not any(z.get("kappzeit") for z in zeilen):
        return felder
    i = felder.index("pause") + 1
    return [*felder[:i], "kappzeit", *felder[i:]]


def tage_csv(zeilen: list) -> bytes:
    """Alle Tage als CSV (Semikolon, mit BOM, Kopfzeile über CSV_KOPF). Jeder Text wird gegen Formeln in Tabellenkalkulationen entschärft (`_csv_sicher`)."""
    o = io.StringIO()
    w = csv.writer(o, delimiter=";", lineterminator="\r\n")
    felder = mit_kappzeit(["datum", "art", "ho", "dienststelle", "ho_minuten", "dienststelle_minuten", "kommen", "gehen", "pause", "notiz", "attest", "konto", "vermerk", "geprueft"], zeilen)
    w.writerow([CSV_KOPF.get(f, f) for f in felder])
    for z in zeilen:
        w.writerow([_csv_sicher(z.get(f, "")) for f in felder])
    return ("\ufeff" + o.getvalue()).encode("utf-8")


def _mit_bloecken(z: dict, zeile: dict) -> dict:
    """Exportzeile eines Tages mit mehreren Blöcken (stempel.mit_eintraegen): dazu „eintraege“ [{art, kommen, gehen, dauer, pause}] und „tagessumme“
    (Arbeitszeit aller Blöcke), und die Pause ist nur die eigene (die Lücke zwischen den Blöcken ist keine Pause). Andere Tage bleiben, wie sie sind."""
    if not z.get("eintraege"):
        return zeile
    return {**zeile, "pause": z["eintraege_pause"], "tagessumme": z["eintraege_summe"], "eintraege": [dict(e) for e in z["eintraege"]]}


def monat_zeilen(m: dict) -> list:
    """Tage eines Monats aus bericht.monat() (mit den Blöcken aus stempel.mit_eintraegen): nur die Felder, die ein Export braucht; Notiz und Feiertagsname ohne Steuerzeichen."""
    return [_mit_bloecken(z, {"datum": z["datum"], "wochentag": z["wt"], "feiertag": notiz_bereinigen(z["feiertag"]), "arbeitstag": z["soll"], "soll": z["soll_zeit"], "ho": z["ho"],
             "dienststelle": z["dst"], "kommen": z["kommen"], "gehen": z["gehen"], "pause": z["pause"], "art": z["art"], "notiz": notiz_bereinigen(z["notiz"]), "attest": z["attest"], "aufgefuellt": z["aufgefuellt"],
             **({"kappzeit": z["kappzeit"]} if z.get("kappzeit") else {})})
            for z in m["tage"]]


def _csv_tag(z: dict) -> list:
    """CSV-Zeilen eines Tages: ohne Blöcke die eine Zeile; mit Blöcken je Block eine (Kommen, Gehen, eigene Pause, Stunden bei HO oder Büro),
    die Angaben des Tages nur in der ersten, das Datum nicht wiederholt, die Tagessumme als Notiz der letzten (TAGESSUMME, wie im Nachweis).
    So ergibt die Summe der Spalten HO und Büro weiter den Monat."""
    if not z.get("eintraege"):
        return [z]
    leer, letzte = dict.fromkeys(z, ""), len(z["eintraege"]) - 1
    return [{**(z if i == 0 else leer), "kommen": e["kommen"], "gehen": e["gehen"], "pause": e["pause"],
             "ho": e["dauer"] if e["art"] == "ho" else "", "dienststelle": e["dauer"] if e["art"] == "dst" else "",
             **({"notiz": TAGESSUMME.format(z["tagessumme"])} if i == letzte else {})}
            for i, e in enumerate(z["eintraege"])]


def tage_csv_monat(zeilen: list) -> bytes:
    """Tage eines Monats als CSV (Semikolon, mit BOM, Kopfzeile über CSV_KOPF; Tage mit Blöcken über _csv_tag); „arbeitstag“ wird zu ja/nein,
    Texte werden gegen Formeln entschärft."""
    o = io.StringIO()
    w = csv.writer(o, delimiter=";", lineterminator="\r\n")
    felder = mit_kappzeit(["datum", "wochentag", "feiertag", "arbeitstag", "soll", "ho", "dienststelle", "kommen", "gehen", "pause", "art", "notiz", "attest", "aufgefuellt"], zeilen)
    w.writerow([CSV_KOPF.get(f, f) for f in felder])
    for z in (x for tag in zeilen for x in _csv_tag(tag)):
        w.writerow([JA_NEIN[bool(z[f])] if f == "arbeitstag" and z[f] != "" else _csv_sicher(z.get(f, "")) for f in felder])
    return ("\ufeff" + o.getvalue()).encode("utf-8")


# ---------------------------------------------------------------- Kalender (.ics)
ICS_ARTEN = {"urlaub": "Urlaub", "angespart": "Urlaub (angespart)", "gleittag": "Gleittag", "krank": "Krank", "krank_attest": "Krank (mit Attest)",
             "familientag": "Familientag", "elternzeit": "Elternzeit", "freizeit": "Freizeitausgleich", "sonderurlaub_tag": "Sonderurlaub", "kind_krank": "Kind krank"}


def _ics_text(s: str) -> str:
    """Text für .ics maskieren (Backslash, Semikolon, Komma, Zeilenumbruch)."""
    return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def kalender_ics(tage: list, ist_frei_fn, jetzt=None) -> bytes:
    """Ganztagstermine für Urlaub, Gleittage, Krank, Familientage und Elternzeit. Aufeinanderfolgende Tage gleicher Art
    (über freie Tage hinweg) werden zu einem Termin. Notizen und Attest-Daten kommen nicht in die Datei."""
    from datetime import datetime, timedelta, timezone
    jetzt = jetzt or datetime.now(timezone.utc)
    if jetzt.tzinfo is not None:                             # der Zeitstempel der Datei steht immer in Weltzeit (das „Z“ am Ende)
        jetzt = jetzt.astimezone(timezone.utc)
    stempel = jetzt.strftime("%Y%m%dT%H%M%SZ")
    gruppen = []
    for t in sorted((t for t in tage if t.art in ICS_ARTEN), key=lambda t: t.datum):
        titel = ICS_ARTEN[t.art]
        if gruppen and gruppen[-1][0] == titel:
            ende = gruppen[-1][2] + timedelta(days=1)
            while ende < t.datum and ist_frei_fn(ende):
                ende += timedelta(days=1)
            if ende == t.datum:
                gruppen[-1][2] = t.datum
                continue
        gruppen.append([titel, t.datum, t.datum])
    z = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Zeiterfassung//DE", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Zeiterfassung"]
    for titel, von, bis in gruppen:
        z += ["BEGIN:VEVENT", f"UID:zeiterfassung-{von.isoformat()}-{titel.split()[0].lower()}@zeiterfassung", f"DTSTAMP:{stempel}",
              f"DTSTART;VALUE=DATE:{von.strftime('%Y%m%d')}", f"DTEND;VALUE=DATE:{(bis + timedelta(days=1)).strftime('%Y%m%d')}",
              f"SUMMARY:{_ics_text(titel)}", "TRANSP:TRANSPARENT", "END:VEVENT"]
    z.append("END:VCALENDAR")
    return ("\r\n".join(z) + "\r\n").encode("utf-8")
