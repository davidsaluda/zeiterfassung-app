# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Zusätzliche Exportformate (JSON, XML, CSV) für Homeoffice-Übersicht, Monat und alle Tage. Nur Standardbibliothek."""
import csv
import io
import json
import re
from xml.sax.saxutils import escape

from daten.konfig import STEUERZEICHEN_XML, VERMERKE
from kern.regeln import notiz_bereinigen
from kern.zeit import fmt_dauer, fmt_hhmm


def _csv_sicher(w):
    """Text ohne Steuer- und Bidi-Zeichen; beginnt er mit = + - @, würde eine Tabellenkalkulation ihn als Formel ausführen: mit Hochkomma entschärfen."""
    if not isinstance(w, str):
        return w
    w = notiz_bereinigen(w)
    return "'" + w if w[:1] in ("=", "+", "-", "@") else w


def zu_json(obj) -> bytes:
    """Objekt als eingerücktes JSON (UTF-8)."""
    return json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")


def _name(k) -> str:
    """Macht aus einem Schlüssel einen gültigen XML-Namen (Sonderzeichen werden zu „_“, am Anfang ein Buchstabe oder „_“)."""
    n = re.sub(r"[^0-9A-Za-zÄÖÜäöüß_.-]", "_", str(k))
    return n if re.match(r"[A-Za-z_]", n) else "_" + n


def _xml(obj, name: str, ebene: int) -> str:
    """Baut XML-Text für Wörterbuch, Liste oder Wert; Steuerzeichen werden entfernt und Sonderzeichen maskiert."""
    ein = "  " * ebene
    if isinstance(obj, dict):
        inner = "".join(_xml(v, _name(k), ebene + 1) for k, v in obj.items())
        return f"{ein}<{name}>\n{inner}{ein}</{name}>\n"
    if isinstance(obj, (list, tuple)):
        inner = "".join(_xml(v, "eintrag", ebene + 1) for v in obj)
        return f"{ein}<{name}>\n{inner}{ein}</{name}>\n"
    if obj is None:
        return f"{ein}<{name}/>\n"
    if isinstance(obj, bool):
        obj = "true" if obj else "false"
    return f"{ein}<{name}>{escape(STEUERZEICHEN_XML.sub('', str(obj)))}</{name}>\n"


def zu_xml(obj, wurzel: str) -> bytes:
    """Objekt als XML-Datei (UTF-8) unter dem Wurzelelement `wurzel`."""
    return ('<?xml version="1.0" encoding="UTF-8"?>\n' + _xml(obj, _name(wurzel), 0)).encode("utf-8")


JA_NEIN = {False: "nein", True: "ja"}
# Kopfzeile der CSV ist Text für die Person („Büro“); JSON- und XML-Schlüssel bleiben „dienststelle*“, weil Programme sie lesen (namen.md 5, S18a)
CSV_KOPF = {"dienststelle": "buero", "dienststelle_minuten": "buero_minuten"}


def alle_tage(db, zeitformat: str = "hhmm") -> list:
    """Alle erfassten Tage (eine Zeile je Tag) für den Gesamtexport; HO und Büro im Zeitformat („hhmm“ oder „dezimal“), dazu immer die Minuten;
    Kommen, Gehen und Pause als Uhrzeit hh:mm; Vermerk als Text (z. B. „Fortbildung“), geprüft als ja/nein (funktionen.md 5)."""
    return [{"datum": t.datum.isoformat(), "art": t.art, "ho": fmt_dauer(t.ho, zeitformat) if t.ho else "", "dienststelle": fmt_dauer(t.dst, zeitformat) if t.dst else "",
             "ho_minuten": t.ho, "dienststelle_minuten": t.dst,
             **({"kommen": fmt_hhmm(t.kommen), "gehen": fmt_hhmm(t.gehen), "pause": fmt_hhmm(t.pause)} if t.kommen >= 0 else {"kommen": "", "gehen": "", "pause": ""}),
             "notiz": notiz_bereinigen(t.notiz), "attest": t.attest, "konto": t.konto, "vermerk": VERMERKE.get(t.vermerk, ""), "geprueft": JA_NEIN[bool(t.geprueft)]}
            for t in db.tage_alle()]


def tage_csv(zeilen: list) -> bytes:
    """Alle Tage als CSV (Semikolon, mit BOM, Kopfzeile über CSV_KOPF). Jeder Text wird gegen Formeln in Tabellenkalkulationen entschärft (`_csv_sicher`)."""
    o = io.StringIO()
    w = csv.writer(o, delimiter=";", lineterminator="\r\n")
    felder = ["datum", "art", "ho", "dienststelle", "ho_minuten", "dienststelle_minuten", "kommen", "gehen", "pause", "notiz", "attest", "konto", "vermerk", "geprueft"]
    w.writerow([CSV_KOPF.get(f, f) for f in felder])
    for z in zeilen:
        w.writerow([_csv_sicher(z.get(f, "")) for f in felder])
    return ("﻿" + o.getvalue()).encode("utf-8")


def monat_zeilen(m: dict) -> list:
    """Tage eines Monats aus bericht.monat(): nur die Felder, die ein Export braucht; Notiz und Feiertagsname ohne Steuerzeichen."""
    return [{"datum": z["datum"], "wochentag": z["wt"], "feiertag": notiz_bereinigen(z["feiertag"]), "arbeitstag": z["soll"], "soll": z["soll_zeit"], "ho": z["ho"],
             "dienststelle": z["dst"], "kommen": z["kommen"], "gehen": z["gehen"], "pause": z["pause"], "art": z["art"], "notiz": notiz_bereinigen(z["notiz"]), "attest": z["attest"], "aufgefuellt": z["aufgefuellt"]} for z in m["tage"]]


def tage_csv_monat(zeilen: list) -> bytes:
    """Tage eines Monats als CSV (Semikolon, mit BOM, Kopfzeile über CSV_KOPF); „arbeitstag“ wird zu ja/nein, Texte werden gegen Formeln entschärft."""
    o = io.StringIO()
    w = csv.writer(o, delimiter=";", lineterminator="\r\n")
    felder = ["datum", "wochentag", "feiertag", "arbeitstag", "soll", "ho", "dienststelle", "kommen", "gehen", "pause", "art", "notiz", "attest", "aufgefuellt"]
    w.writerow([CSV_KOPF.get(f, f) for f in felder])
    for z in zeilen:
        w.writerow([("ja" if z[f] else "nein") if f == "arbeitstag" else _csv_sicher(z[f]) for f in felder])
    return ("﻿" + o.getvalue()).encode("utf-8")


# ---------------------------------------------------------------- Kalender (.ics)
ICS_ARTEN = {"urlaub": "Urlaub", "angespart": "Urlaub (angespart)", "gleittag": "Gleittag", "krank": "Krank", "krank_attest": "Krank (mit Attest)",
             "familientag": "Familientag", "elternzeit": "Elternzeit", "freizeit": "Freizeitausgleich", "sonderurlaub_tag": "Sonderurlaub", "kind_krank": "Kind krank"}


def _ics_text(s: str) -> str:
    """Text für .ics maskieren (Backslash, Semikolon, Komma, Zeilenumbruch)."""
    return s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def kalender_ics(tage: list, ist_frei_fn, jetzt=None) -> bytes:
    """Ganztagstermine für Urlaub, Gleittage, Krank, Familientage und Elternzeit. Aufeinanderfolgende Tage gleicher Art
    (über freie Tage hinweg) werden zu einem Termin. Notizen und Attest-Daten kommen nicht in die Datei."""
    from datetime import datetime, timedelta, timezone
    jetzt = jetzt or datetime.now(timezone.utc)
    if jetzt.tzinfo is not None:                             # der Zeitstempel der Datei steht immer in Weltzeit (das „Z“ am Ende)
        jetzt = jetzt.astimezone(timezone.utc)
    stempel = jetzt.strftime("%Y%m%dT%H%M%SZ")
    gruppen = []
    for t in sorted((t for t in tage if t.art in ICS_ARTEN), key=lambda t: t.datum):
        titel = ICS_ARTEN[t.art]
        if gruppen and gruppen[-1][0] == titel:
            ende = gruppen[-1][2] + timedelta(days=1)
            while ende < t.datum and ist_frei_fn(ende):
                ende += timedelta(days=1)
            if ende == t.datum:
                gruppen[-1][2] = t.datum
                continue
        gruppen.append([titel, t.datum, t.datum])
    z = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Zeiterfassung//DE", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Zeiterfassung"]
    for titel, von, bis in gruppen:
        z += ["BEGIN:VEVENT", f"UID:zeiterfassung-{von.isoformat()}-{titel.split()[0].lower()}@zeiterfassung", f"DTSTAMP:{stempel}",
              f"DTSTART;VALUE=DATE:{von.strftime('%Y%m%d')}", f"DTEND;VALUE=DATE:{(bis + timedelta(days=1)).strftime('%Y%m%d')}",
              f"SUMMARY:{_ics_text(titel)}", "TRANSP:TRANSPARENT", "END:VEVENT"]
    z.append("END:VCALENDAR")
    return ("\r\n".join(z) + "\r\n").encode("utf-8")
