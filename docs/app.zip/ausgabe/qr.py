# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Kleiner QR-Code-Erzeuger (nur Standardbibliothek, kein Netz): für den Kopplungs-Code und für die Adresse der freigegebenen Oberfläche.
shortcut: Byte-Modus, Maske 0, je Version ein einziger Block: Version 2 mit Fehlerkorrektur M (bis 26 Zeichen), darüber Version 3 bis 5 mit Stufe L
(bis 106 Zeichen). Für längere Inhalte Blockteilung und Maskenwahl ergänzen."""

# Version -> (Datenwörter, Prüfwörter, Bits der Stufe in der Formatangabe, Mitte des Ausrichtungsmusters)
VERSIONEN = {2: (28, 16, 0b00, 18), 3: (55, 15, 0b01, 22), 4: (80, 20, 0b01, 26), 5: (108, 26, 0b01, 30)}
MAX_ZEICHEN = 106


def _mal(a: int, b: int) -> int:
    """Multiplikation im Körper GF(256) des QR-Codes (Polynom 0x11D)."""
    r = 0
    for i in range(7, -1, -1):
        r = (r << 1) ^ ((r >> 7) * 0x11D)
        r ^= ((b >> i) & 1) * a
    return r


def _korrektur(daten: list, anzahl: int) -> list:
    """Reed-Solomon-Prüfwörter."""
    teiler = [0] * (anzahl - 1) + [1]
    wurzel = 1
    for _ in range(anzahl):
        for j in range(anzahl):
            teiler[j] = _mal(teiler[j], wurzel) ^ (teiler[j + 1] if j + 1 < anzahl else 0)
        wurzel = _mal(wurzel, 2)
    rest = [0] * anzahl
    for b in daten:
        faktor = b ^ rest.pop(0)
        rest.append(0)
        rest = [r ^ _mal(t, faktor) for r, t in zip(rest, teiler)]
    return rest


def matrix(text: str) -> list:
    """-> Zeilen mit Wahrheitswerten (True = dunkel); 25 x 25 bis 37 x 37 Felder, je nach Länge."""
    roh = text.encode("utf-8")
    if not 0 < len(roh) <= MAX_ZEICHEN:
        raise ValueError(f"QR-Code: 1 bis {MAX_ZEICHEN} Zeichen")
    version = next(v for v, w in VERSIONEN.items() if len(roh) <= w[0] - 2)      # 2 Wörter für Modus, Länge und Schluss
    worte_daten, worte_pruef, stufe, mitte = VERSIONEN[version]
    bits = "0100" + f"{len(roh):08b}" + "".join(f"{b:08b}" for b in roh) + "0000"
    bits += "0" * (-len(bits) % 8)
    daten = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)][:worte_daten]
    daten += [(0xEC, 0x11)[i % 2] for i in range(worte_daten - len(daten))]
    worte = daten + _korrektur(daten, worte_pruef)
    n = 17 + 4 * version
    m = [[False] * n for _ in range(n)]
    fest = [[False] * n for _ in range(n)]

    def setze(x, y, dunkel):
        """Setzt ein Feld auf hell oder dunkel und merkt es als fest (Werte außerhalb der Matrix werden ignoriert)."""
        if 0 <= x < n and 0 <= y < n:
            m[y][x], fest[y][x] = bool(dunkel), True

    for i in range(n):                                       # Taktlinien
        setze(6, i, i % 2 == 0)
        setze(i, 6, i % 2 == 0)
    for mx, my in ((3, 3), (n - 4, 3), (3, n - 4)):          # die drei Suchmuster samt hellem Rand
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                setze(mx + dx, my + dy, max(abs(dx), abs(dy)) not in (2, 4))
    for dy in range(-2, 3):                                  # Ausrichtungsmuster
        for dx in range(-2, 3):
            setze(mitte + dx, mitte + dy, max(abs(dx), abs(dy)) != 1)
    kopf = stufe << 3                                        # Formatangabe: Stufe und Maske 0
    rest = kopf
    for _ in range(10):
        rest = (rest << 1) ^ ((rest >> 9) * 0x537)
    fmt = ((kopf << 10) | rest) ^ 0x5412
    bit = lambda i: (fmt >> i) & 1
    for i in range(6):
        setze(8, i, bit(i))
    setze(8, 7, bit(6))
    setze(8, 8, bit(7))
    setze(7, 8, bit(8))
    for i in range(9, 15):
        setze(14 - i, 8, bit(i))
    for i in range(8):
        setze(n - 1 - i, 8, bit(i))
    for i in range(8, 15):
        setze(8, n - 15 + i, bit(i))
    setze(8, n - 8, True)
    i, rechts = 0, n - 1                                     # Daten im Zickzack von unten rechts
    while rechts >= 1:
        if rechts == 6:
            rechts = 5
        for v in range(n):
            for j in (0, 1):
                x = rechts - j
                y = n - 1 - v if ((rechts + 1) & 2) == 0 else v
                if not fest[y][x]:
                    if i < len(worte) * 8:
                        m[y][x] = bool((worte[i >> 3] >> (7 - (i & 7))) & 1)
                    i += 1
                    if (x + y) % 2 == 0:                     # Maske 0
                        m[y][x] = not m[y][x]
        rechts -= 2
    return m


def svg(text: str, rand: int = 4, bezeichnung: str = "QR-Code zum Koppeln") -> str:
    """Der QR-Code als SVG mit weißem Grund (so liest ihn die Kamera auch im dunklen Design)."""
    m = matrix(text)
    seite = len(m) + 2 * rand
    weg = "".join(f"M{x + rand} {y + rand}h1v1h-1z" for y, zeile in enumerate(m) for x, dunkel in enumerate(zeile) if dunkel)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {seite} {seite}" role="img" aria-label="{bezeichnung}" shape-rendering="crispEdges">'
            f'<rect width="{seite}" height="{seite}" fill="#fff"/><path d="{weg}" fill="#000"/></svg>')
