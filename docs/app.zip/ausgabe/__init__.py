# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Paket ausgabe (Teamplan B6): Module der Schicht ausgabe; Importe als `from ausgabe import <modul>`."""
