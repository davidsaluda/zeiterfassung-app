# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Gestaltung der Exportdateien (PDF, Word, ODT, ODS, Excel) in der Akzentfarbe der App.
Die Oberfläche merkt sich die gewählte Farbe in einem Cookie (ho_akzent_hex); der Server setzt sie je Anfrage (Thread) und die Exportfunktionen lesen sie hier."""
import re
import threading

STANDARD = "#007aff"
_L = threading.local()


def setze(farbe) -> None:
    """Merkt die Akzentfarbe für diesen Thread; ungültige Werte werden zur Standardfarbe."""
    _L.farbe = farbe if re.fullmatch(r"#[0-9a-fA-F]{6}", str(farbe or "")) else STANDARD


def farbe() -> str:
    """Die gemerkte Akzentfarbe dieses Threads (klein geschrieben)."""
    return getattr(_L, "farbe", STANDARD).lower()


def rgb(c: str):
    """Farbe „#rrggbb“ als Tupel (r, g, b) von 0 bis 255."""
    return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5))


def _hex(t) -> str:
    """Tupel (r, g, b) als „#rrggbb“, auf 0 bis 255 begrenzt."""
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in t)


def mischen(c: str, mit: str, anteil: float) -> str:
    """Farbe c zu 'anteil' (0..1) mit der Farbe 'mit' mischen."""
    a, b = rgb(c), rgb(mit)
    return _hex(tuple(a[i] * (1 - anteil) + b[i] * anteil for i in range(3)))


def hell(c: str, anteil: float) -> str:
    """Farbe c mit Weiß mischen (heller)."""
    return mischen(c, "#ffffff", anteil)


def dunkel(c: str, anteil: float) -> str:
    """Farbe c mit Schwarz mischen (dunkler)."""
    return mischen(c, "#000000", anteil)


def leuchtkraft(c: str) -> float:
    """Relative Helligkeit einer Farbe (0 bis 1) nach WCAG."""
    r, g, b = [v / 255 for v in rgb(c)]
    lin = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def text_auf(c: str) -> str:
    """Lesbare Schriftfarbe auf der Akzentfarbe (wie in der Oberfläche)."""
    return "#111318" if leuchtkraft(c) > 0.4 else "#ffffff"


def kontrast_zu_weiss(c: str) -> str:
    """Akzentfarbe für Schrift auf weißem Papier: sehr helle Farben werden abgedunkelt, damit Überschriften lesbar bleiben."""
    return dunkel(c, 0.35) if leuchtkraft(c) > 0.45 else c


class Palette:
    """Alle Farben eines Dokuments aus der Akzentfarbe abgeleitet."""

    def __init__(self, c: str = None):
        """Leitet alle Farben aus der Akzentfarbe ab (Standard: die gemerkte Farbe)."""
        c = c or farbe()
        self.akzent = c
        self.auf_akzent = text_auf(c)
        self.titel = kontrast_zu_weiss(c)                 # Überschriften auf Papier
        self.tief = dunkel(self.titel, 0.25)               # Kennzahlen
        self.weich = hell(c, 0.90)                         # Kacheln, gestreifte Zeilen
        self.linie = hell(c, 0.72)                         # feine Linien
        self.grau = "#667085"                              # Nebentext
        self.frei = "#eceef3"                              # Wochenende, Feiertag

    def ohne(self, c: str) -> str:
        """Farbe ohne „#“ in Großbuchstaben (so wollen es Word und Excel)."""
        return c.lstrip("#").upper()
