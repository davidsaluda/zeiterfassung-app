# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Word (.docx, nur Monatsnachweis), PDF und Excel ohne Zusatzpakete: ein einfaches Dokumentmodell aus Überschriften, Absätzen und Tabellen.
Blöcke: ("h", text) · ("p", text) · ("t", kopfzeile, zeilen) · ("u", [(über der Linie, Beschriftung, Name)], Breiten-Gewichte) für Unterschriften
(nur PDF und Word). Die erste Überschrift ist der Titel. Word wird in der Akzentfarbe der App
gestaltet (design.Palette) und hat eine Fußzeile mit Version, Urheberhinweis und Seitenzahl."""
import io
import re
import zipfile
from datetime import date, timedelta
from xml.sax.saxutils import escape

from daten import konfig
from daten.konfig import STEUERZEICHEN_XML
from daten import stempel
from kern import bericht
from kern import woche
from ausgabe import design
from ausgabe import pdf
from ausgabe.export import TAGESSUMME
from kern.regeln import ARTEN, JAHR_MAX, JAHR_MIN, TAG_MIN, VERMERKE, notiz_bereinigen
from urheber import FUSS, VERMERK
from kern.zeit import fmt_dauer, fmt_hhmm


def _min(t: str) -> int:
    """Zeit „HH:MM“ in Minuten; leerer Text ergibt 0."""
    return int(t[:2]) * 60 + int(t[3:5]) if t else 0


class Zeile(list):
    """Eine Tabellenzeile, die sich merkt, ob der Tag frei ist (Feiertag)."""
    frei = False


AUFGEFUELLT = "aufgefüllt"                                  # Hinweis bei „Krank im Dienst“: Fehlzeit bis zum Tagessoll (R3)


def monat_dokument(db, j: int, m: int, zeitformat: str = "hhmm") -> list:
    """Monatsbericht als Blöcke (Titel, Kennzahlen, Tagestabelle) für PDF und Excel; Dauern im Zeitformat „hhmm“ oder „dezimal“.
    Spalte Kappzeit nur, wenn ein Tag des Monats Kappzeit hat (stempel.mit_eintraegen)."""
    d = stempel.mit_eintraegen(db, bericht.monat(db, j, m, zeitformat), zeitformat)
    kapp = any(z.get("kappzeit") for z in d["tage"])
    t, s = d["text"], d["summe"]
    kopf = [("HO-Stunden", t["ho"]), ("Büro-Stunden", t["dst"]), ("Ist-Zeit", t["ist"]), ("HO-Quote", t["quote"]), ("Tage HO", s["ho_tage"]),
            ("Tage Büro", s["dst_tage"]), ("Urlaub", s["urlaub"]), ("Gleittage", s["gleittage"]), ("Krank", s["krank"])]
    zeilen = []
    for z in d["tage"]:
        ist = z["ist_min"]
        auf = f"{AUFGEFUELLT} {z['aufgefuellt']}" if z["aufgefuellt"] else ""
        info = " · ".join(x for x in (z["feiertag"], ARTEN[z["art"]] if z["art"] else "", auf, z["notiz"]) if x)
        zeile = Zeile([f"{z['tag']}. {z['wt']}", z["ho"] or "", z["dst"] or "", fmt_dauer(ist, zeitformat) if ist else "", z["soll_zeit"],
                       *([z.get("kappzeit", "")] if kapp else []), info])
        zeile.frei = bool(z["feiertag"])                     # Feiertage erscheinen grau wie Samstag und Sonntag
        zeilen.append(zeile)
    return [("h", f"Zeiterfassung {d['name']} {j}"), ("p", f"Erstellt am {date.today().strftime('%d.%m.%Y')}"),
            ("t", ["Kennzahl", "Wert"], [[a, str(b)] for a, b in kopf]),
            ("t", ["Tag", "HO", "Büro", "Ist", "Soll", *([KAPPZEIT] if kapp else []), "Hinweis"], zeilen)]


def steuer_dokument(s: dict, zeitformat: str = "hhmm") -> list:
    """Homeoffice-Übersicht als Blöcke: Tabelle der Angaben (bericht.uebersicht_zeilen wie CSV und Excel, mit „davon vor Beginn der Erfassung“
    und dem Block der Startwerte im Zeitformat), dazu Elternzeit und Kranktage als Tabellen, wenn es welche gibt."""
    rows = [[t, str(w)] for t, w in bericht.uebersicht_zeilen(s, zeitformat)]
    bl = [("h", f"{bericht.UEBERSICHT} {s['jahr']}"), ("p", f"Zeiterfassung · erstellt am {date.today().strftime('%d.%m.%Y')}"), ("t", ["Angabe", "Anzahl"], rows)]
    for titel, kopf, zeilen in bericht.zeitraum_tabellen(s):
        if zeilen:
            bl += [("h", titel), ("t", kopf, [[str(x) for x in z] for z in zeilen])]      # Tabellen der Dokumente erwarten Text
    return bl


JAHR_TITEL = "Jahresrückblick"
JAHR_DATEI = "Jahresrueckblick"                             # derselbe Titel im Dateinamen (nur ASCII)
EIN_ORT = ("kein", "nur")                                   # Homeoffice-Modus mit nur einem Arbeitsort: keine Quote, keine Spalten HO und Büro (wie einOrt())
OHNE_WERT = "–"


def _jahr_spalten(ein_ort: bool, aus: set) -> list:
    """Spalten der Monatstabelle als (Kopf, Wert aus Text und Summe), gefiltert nach Homeoffice-Modus und Modulen."""
    sp = [("Ist", lambda t, s: t["ist"])]
    if not ein_ort:
        sp += [("HO", lambda t, s: t["ho"]), ("Büro", lambda t, s: t["dst"]), ("Quote", lambda t, s: t["quote"])]
    if "urlaub" not in aus:
        sp.append(("Urlaub", lambda t, s: str(s["urlaub"])))
    if "krank" not in aus:
        sp.append(("Krank", lambda t, s: str(s["krank"])))
    return sp


def _start_zeile(st: dict, spalten: list, zeitformat: str) -> list:
    """Zeile „Startwerte bis TT.MM.JJJJ“ vor der Summe (R6): Ohne sie ginge die Jahressumme nicht auf; ohne Tage keine Quote („–“)."""
    werte = {"Ist": fmt_dauer(st["ho_min"] + st["dst_min"], zeitformat), "HO": fmt_dauer(st["ho_min"], zeitformat), "Büro": fmt_dauer(st["dst_min"], zeitformat),
             "Urlaub": str(st["urlaub"]), "Krank": str(st["krank"])}
    name = f"Startwerte bis {bericht.de(date.fromisoformat(st['ab']) - timedelta(days=1))}"
    return [name] + [werte.get(k, OHNE_WERT) for k, _ in spalten]


def _gleitzeit_zeilen(punkte: list, zeitformat: str) -> list:
    """Gleitzeit-Verlauf je Monat: der letzte Punkt von woche.verlauf in jedem Monat (Monat, Datum, Stand); nur Auswahl, keine Rechnung."""
    letzte = {}
    for p in punkte:
        letzte[int(p["datum"][5:7])] = p
    return [[bericht.MONATE[m - 1], bericht.de(date.fromisoformat(p["datum"])), woche.fmt_saldo(p["saldo_min"], zeitformat)] for m, p in sorted(letzte.items())]


def jahr_dokument(db, j: int, zeitformat: str = "hhmm", heute: date = None) -> list:
    """Jahresrückblick als Blöcke: Kennzahlen, Monate (Ist, HO, Büro, Quote, Urlaub, Krank) und der Gleitzeit-Verlauf je Monat bis heute.
    Alle Zahlen aus bericht.jahr und woche.verlauf; Spalten und Zeilen nach Homeoffice-Modus und Modulen, die heute gelten (wie die Seite Jahr)."""
    heute = heute or date.today()
    regel = konfig.fuer(heute)
    aus, ein_ort = set(regel["module_aus"]), regel["ho_modus"] in EIN_ORT
    d = bericht.jahr(db, j, zeitformat)
    t, g = d["text"], d["gesamt"]
    spalten = _jahr_spalten(ein_ort, aus)
    kennzahlen = [("Ist-Zeit", t["ist"])]
    if not ein_ort:
        kennzahlen += [("HO-Stunden", t["ho"]), ("Büro-Stunden", t["dst"]), ("HO-Quote", t["quote"]), ("Tage HO", g["ho_tage"]), ("Tage Büro", g["dst_tage"])]
    kennzahlen += [(k, g[f]) for k, f, mod in (("Urlaub", "urlaub", "urlaub"), ("Gleittage", "gleittage", "gleittage"), ("Krank", "krank", "krank")) if mod not in aus]
    punkte = [] if "gleitzeit" in aus else woche.verlauf(db, j, heute)
    if punkte:
        kennzahlen.append(("Gleitzeit-Konto", woche.fmt_saldo(punkte[-1]["saldo_min"], zeitformat)))
        kennzahlen += [("Kappung", k["text"]) for k in woche.verlauf_kappungen(db, j, heute, zeitformat)]
    zeilen = [[m["name"], bericht.VOR_BEGINN] + [""] * (len(spalten) - 1) if m["vor_beginn"] else [m["name"]] + [f(m["text"], m["summe"]) for _, f in spalten]
              for m in d["monate"]]
    if g["start"]:
        zeilen.append(_start_zeile(g["start"], spalten, zeitformat))
    zeilen.append(["Summe"] + [f(t, g) for _, f in spalten])
    bl = [("h", f"{JAHR_TITEL} {j}"), ("p", f"Erstellt am {bericht.de(heute)}"), ("t", ["Kennzahl", "Wert"], [[a, str(b)] for a, b in kennzahlen]),
          ("t", ["Monat"] + [k for k, _ in spalten], zeilen)]
    if punkte:
        bl += [("h", f"Gleitzeit-Verlauf {j}"), ("t", ["Monat bis", "Datum", "Stand"], _gleitzeit_zeilen(punkte, zeitformat))]
    return bl


def jahr_pdf(db, j: int, zeitformat: str = "hhmm", heute: date = None) -> bytes:
    """Jahresrückblick als fertiges PDF (Bytes) vom eingebauten Erzeuger (pdf.py)."""
    return pdf.aus_bloecken(jahr_dokument(db, j, zeitformat, heute))


def _t(x) -> str:
    """Text für XML: entfernt Steuer- und Bidi-Zeichen (eine Quelle mit export.py) und maskiert Sonderzeichen."""
    return escape(STEUERZEICHEN_XML.sub("", str(x)))       # Steuerzeichen machen die Datei ungültig, Bidi-Zeichen verdrehen den Text


_ZAHL = re.compile(r"^[\d:.,+−\-% ]+( \(\+1\))?$")             # „(+1)“: Gehen nach Mitternacht im Monatsnachweis


def _zahlspalten(kopf: list, zeilen: list) -> set:
    """Spalten, deren Werte überwiegend Zahlen oder Zeiten sind (rechtsbündig); Tabellen mit Fließtext in der ersten Spalte bleiben linksbündig."""
    r = set()
    for i in range(1, len(kopf)):
        werte = [str(z[i]) for z in zeilen if i < len(z) and str(z[i]).strip()]
        if werte and all(_ZAHL.match(w) for w in werte):
            r.add(i)
    return r


def _breiten(kopf: list, zeilen: list, gesamt: float) -> list:
    """Spaltenbreiten nach Textlänge (mindestens 4, höchstens 40 Zeichen Gewicht), zusammen 'gesamt'."""
    gew = []
    for i, k in enumerate(kopf):
        n = max([len(str(k))] + [len(str(z[i])) for z in zeilen if i < len(z)])
        gew.append(max(4, min(40, n)))
    s = sum(gew)
    return [gesamt * g / s for g in gew]


def _frei_zeile(z) -> bool:
    """Ist die Zeile ein freier Tag (als Feiertag markiert oder Sa/So am Zeilenanfang)? Dann wird sie grau."""
    return bool(z) and (getattr(z, "frei", False) or re.match(r"^\d+\. (Sa|So)\b", str(z[0])) is not None)


# ---------------------------------------------------------------- Word
def zu_docx(bloecke: list) -> bytes:
    """Baut aus den Blöcken eine Word-Datei (.docx, ZIP mit XML) in der Akzentfarbe, mit Fußzeile und Seitenzahl. Gibt die Bytes zurück."""
    p = design.Palette()
    A, AT, WEICH, LINIE, TITEL, GRAU, FREI = (p.ohne(x) for x in (p.akzent, p.auf_akzent, p.weich, p.linie, p.titel, p.grau, p.frei))
    SCHRIFT = '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'

    def lauf(text, fett=False, gross=18, farbe=None):
        """Ein Textlauf in Word mit Schrift, Größe, Fettdruck und Farbe."""
        return (f'<w:r><w:rPr>{SCHRIFT}{"<w:b/>" if fett else ""}{f"<w:color w:val={chr(34)}{farbe}{chr(34)}/>" if farbe else ""}<w:sz w:val="{gross}"/></w:rPr>'
                f'<w:t xml:space="preserve">{_t(text)}</w:t></w:r>')

    teile, titel_da = [], False
    for nr, b in enumerate(bloecke):
        if b[0] == "h" and not titel_da:
            titel_da = True
            teile.append(f'<w:p><w:pPr><w:keepNext/><w:pBdr><w:bottom w:val="single" w:sz="18" w:space="4" w:color="{A}"/></w:pBdr><w:spacing w:before="0" w:after="100"/></w:pPr>{lauf(b[1], True, 40, TITEL)}</w:p>')
        elif b[0] == "h":
            teile.append(f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="280" w:after="100"/></w:pPr>{lauf(b[1], True, 26, TITEL)}</w:p>')
        elif b[0] == "p":
            teile.append(f'<w:p><w:pPr><w:spacing w:before="0" w:after="140"/></w:pPr>{lauf(b[1], False, 18, GRAU)}</w:p>')
        elif b[0] == "u":
            teile.append(_docx_unterschrift(b[1], b[2], lauf, GRAU))
        else:
            kopf, zeilen = b[1], b[2]
            rechts = _zahlspalten(kopf, zeilen)
            # vor Unterschriften: die Tabelle bleibt mit ihnen auf einer Seite (wie pdf.aus_bloecken mit zusammen)
            halten = "<w:keepNext/>" if nr + 1 < len(bloecke) and bloecke[nr + 1][0] == "u" else ""
            breiten = [int(x) for x in _breiten(kopf, zeilen, 9900)]
            rahmen = "".join(f'<w:{k} w:val="single" w:sz="4" w:space="0" w:color="{LINIE}"/>' for k in ("top", "bottom", "insideH"))
            t = [f'<w:tbl><w:tblPr><w:tblW w:w="9900" w:type="dxa"/><w:tblBorders>{rahmen}</w:tblBorders><w:tblLayout w:type="fixed"/>'
                 '<w:tblCellMar><w:top w:w="50" w:type="dxa"/><w:left w:w="90" w:type="dxa"/><w:bottom w:w="50" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tblCellMar></w:tblPr>']
            t.append("<w:tblGrid>" + "".join(f'<w:gridCol w:w="{w}"/>' for w in breiten) + "</w:tblGrid>")

            def zelle(i, c, fuellung, fett=False, farbe=None, gross=18):
                """Eine Tabellenzelle in Word (rechtsbündig bei Zahlenspalten, mit optionaler Füllfarbe)."""
                jc = '<w:jc w:val="right"/>' if i in rechts else ""
                shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{fuellung}"/>' if fuellung else ""
                return (f'<w:tc><w:tcPr><w:tcW w:w="{breiten[i]}" w:type="dxa"/>{shd}<w:vAlign w:val="center"/></w:tcPr>'
                        f'<w:p><w:pPr>{halten}<w:spacing w:before="0" w:after="0"/>{jc}</w:pPr>{lauf(c, fett, gross, farbe)}</w:p></w:tc>')
            t.append('<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>' + "".join(zelle(i, c, A, True, AT) for i, c in enumerate(kopf)) + "</w:tr>")
            for n, z in enumerate(zeilen):
                frei = _frei_zeile(z)
                fuell = FREI if frei else (WEICH if n % 2 else None)
                t.append('<w:tr><w:trPr><w:cantSplit/></w:trPr>' + "".join(zelle(i, c, fuell, False, "667085" if frei else None) for i, c in enumerate(z)) + "</w:tr>")
            t.append(f'</w:tbl><w:p><w:pPr>{halten}<w:spacing w:before="0" w:after="60"/></w:pPr></w:p>')
            teile.append("".join(t))
    ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
    doc = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {ns}><w:body>' + "".join(teile)
           + '<w:sectPr><w:footerReference w:type="default" r:id="rId2"/><w:pgSz w:w="11906" w:h="16838"/>'
             '<w:pgMar w:top="1000" w:right="1000" w:bottom="1100" w:left="1000" w:header="708" w:footer="500" w:gutter="0"/></w:sectPr></w:body></w:document>')

    def klein(text):
        """Kleiner grauer Text für die Fußzeile."""
        return f'<w:r><w:rPr>{SCHRIFT}<w:color w:val="{GRAU}"/><w:sz w:val="15"/></w:rPr><w:t xml:space="preserve">{_t(text)}</w:t></w:r>'

    def feld(code):
        """Seitenfeld der Fußzeile (z. B. PAGE oder NUMPAGES)."""
        return (f'<w:fldSimple w:instr=" {code} "><w:r><w:rPr>{SCHRIFT}<w:color w:val="{GRAU}"/><w:sz w:val="15"/></w:rPr><w:t>1</w:t></w:r></w:fldSimple>')
    fuss = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr {ns}><w:p><w:pPr><w:pBdr><w:top w:val="single" w:sz="8" w:space="4" w:color="{A}"/></w:pBdr>'
            f'<w:tabs><w:tab w:val="right" w:pos="9900"/></w:tabs></w:pPr>{klein(FUSS)}<w:r><w:tab/></w:r>{klein("Seite ")}{feld("PAGE")}{klein(" von ")}{feld("NUMPAGES")}</w:p></w:ftr>')
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
          '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
    doc_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
    o = io.BytesIO()
    with zipfile.ZipFile(o, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", doc)
        z.writestr("word/footer1.xml", fuss)
        z.writestr("word/_rels/document.xml.rels", doc_rels)
    return o.getvalue()


DOCX_BREITE = 9900                                          # Satzspiegel in Twips (A4 mit den Rändern aus sectPr)
DOCX_UNTERSCHRIFT_LUFT = 1418                               # 2,5 cm in Twips: Platz über der Linie zum Unterschreiben
DOCX_LINIE = "333A45"


def _docx_unterschrift(spalten: list, gewichte: tuple, lauf, grau: str) -> str:
    """Unterschriften als Tabelle ohne Rahmen: je Spalte 2,5 cm Platz, der Wert (Ort, Datum) über einer Linie, darunter klein die Beschriftung
    und fett der Name. Eine Zeile, die nicht über die Seite geteilt wird."""
    breiten = [DOCX_BREITE * g // sum(gewichte) for g in gewichte]
    ohne = "".join(f'<w:{k} w:val="nil"/>' for k in ("top", "left", "bottom", "right", "insideH", "insideV"))

    def spalte(w, oben, klein, gross):
        """Eine Spalte: die Linie ist der untere Rand des ersten Absatzes, darunter Beschriftung und Name."""
        return (f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/></w:tcPr>'
                f'<w:p><w:pPr><w:keepNext/><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="{DOCX_LINIE}"/></w:pBdr>'
                f'<w:spacing w:before="{DOCX_UNTERSCHRIFT_LUFT}" w:after="40"/></w:pPr>{lauf(oben, False, 19)}</w:p>'
                f'<w:p><w:pPr><w:keepNext/><w:spacing w:before="0" w:after="0"/></w:pPr>{lauf(klein, False, 15, grau)}</w:p>'
                f'<w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>{lauf(gross, True, 18)}</w:p></w:tc>')
    return (f'<w:tbl><w:tblPr><w:tblW w:w="{DOCX_BREITE}" w:type="dxa"/><w:tblBorders>{ohne}</w:tblBorders><w:tblLayout w:type="fixed"/>'
            '<w:tblCellMar><w:left w:w="140" w:type="dxa"/><w:right w:w="140" w:type="dxa"/></w:tblCellMar></w:tblPr>'
            "<w:tblGrid>" + "".join(f'<w:gridCol w:w="{w}"/>' for w in breiten) + "</w:tblGrid><w:tr><w:trPr><w:cantSplit/></w:trPr>"
            + "".join(spalte(w, *sp) for w, sp in zip(breiten, spalten)) + "</w:tr></w:tbl>")


# ---------------------------------------------------------------- Monatsnachweis
NACHWEIS_KOPF = (("name", "Name"), ("arbeitgeber", "Arbeitgeber"), ("personalnummer", "Personalnummer"))
NACHWEIS_KOPF_MAX = 80
NACHWEIS_ABWESEND = "abwesend"
NACHWEIS_KRANK = ("krank", "krank_attest", "kind_krank")
# Kranktage ohne Notiz und ohne Vermerk: eine Anmerkung wie „Grippe“ oder „Arzt“ verriete die Krankheit (Auftrag: „keine Kranktage“).
NACHWEIS_OHNE_NOTIZ = NACHWEIS_KRANK + ("krank_dienst",)
# Arten ohne Arbeitsstunden. Bewusst kein Rückgriff auf regeln.ARTEN: eine neue Art darf nie als „Krank …“ im Nachweis landen.
NACHWEIS_ARTEN = {"urlaub": "Urlaub", "angespart": "Urlaub", "gleittag": "Gleittag (Überstundenabbau)", "freizeit": "Freizeitausgleich (Überstundenabbau)",
                  **dict.fromkeys(NACHWEIS_KRANK, NACHWEIS_ABWESEND), "familientag": "Familientag", "elternzeit": "Elternzeit", "sonderurlaub_tag": "Sonderurlaub"}
NACHWEIS_URLAUB = ("urlaub", "angespart")
NACHWEIS_SPALTEN = ["Tag", "Stunden", "Anmerkung"]
NACHWEIS_SPALTEN_ZEITEN = ["Tag", "Kommen", "Gehen", "Pause", "Stunden", "Anmerkung"]
KAPPZEIT = "Kappzeit"                                       # Spalte nur, wenn ein Tag Kappzeit hat (Auftrag vom 25.11.2026)
# Summen in einer Zeile statt vier: so passt die Unterschrift mit 2,5 cm Platz auch bei 31 Tagen auf die erste Seite
NACHWEIS_SUMMEN = ["Arbeitsstunden gesamt", "Urlaubstage", "Gleittage", "Freizeitausgleich (Tage)"]
NACHWEIS_ORT_DATUM, NACHWEIS_UNTERSCHRIFT, NACHWEIS_VORGESETZT = "Ort, Datum", "Unterschrift", "Vorgesetzter/Vorgesetzte"
NACHWEIS_GEWICHTE = {2: (1, 2), 3: (1, 1, 1)}           # Ort und Datum schmal, die Unterschrift breit; mit Vorgesetzter/Vorgesetzte drei gleiche Spalten
NACHWEIS_ISO = re.compile(r"\d{4}-\d{2}-\d{2}")
DATUM_DE = "%d.%m.%Y"
NACHWEIS_ENDUNG_FEHLER = "Format: pdf oder docx"
NACHWEIS_ZUSAMMEN = 2                       # Summen und Unterschrift stehen auf einer Seite
NACHWEIS_TAGESSUMME = TAGESSUMME            # letzte Blockzeile eines Tages mit mehreren Blöcken, wie in der CSV


def _nachweis_kopf(kopf) -> dict:
    """Name, Arbeitgeber und Personalnummer bereinigt (ohne Steuerzeichen, höchstens 80 Zeichen); Fehlendes bleibt leer zum Ausfüllen von Hand.
    Bereinigt selbst, weil Werte aus alten Sicherungen oder von fremden Geräten kommen können."""
    kopf = kopf or {}
    return {k: notiz_bereinigen(str(kopf.get(k, "") or ""))[:NACHWEIS_KOPF_MAX] for k, _ in NACHWEIS_KOPF}


def _nachweis_text(kopf: dict, feld: str) -> str:
    """Ein Text der Personendaten bereinigt (ohne Steuerzeichen, höchstens NACHWEIS_KOPF_MAX Zeichen); fehlt = leer."""
    return notiz_bereinigen(str(kopf.get(feld, "") or ""))[:NACHWEIS_KOPF_MAX]


def eigenes_datum(text: str):
    """Ein eigenes Datum „JJJJ-MM-TT“ für die Unterschrift als date, wenn es echt ist und zwischen 1970 und 2200 liegt; sonst None."""
    try:
        d = date.fromisoformat(text) if NACHWEIS_ISO.fullmatch(text) else None
    except ValueError:
        return None
    return d if d and JAHR_MIN <= d.year <= JAHR_MAX else None


def _letzter_arbeitstag(tage: list) -> date:
    """Letzter Tag mit Soll im Monat (nach Arbeitstagen, Feiertagen und Abschnitten der Person; Zeilen aus bericht.monat).
    Ohne Soll-Tag (Elternzeit, alles vor Beginn der Erfassung) der letzte Tag, der nicht frei ist, sonst der Monatsletzte."""
    for passt in (lambda z: z["soll"], lambda z: not z["frei"], lambda z: True):
        treffer = [z for z in tage if passt(z)]
        if treffer:
            return date.fromisoformat(treffer[-1]["datum"])


def _unterschrift_datum(wahl: str, tage: list) -> str:
    """Datum der Unterschrift als TT.MM.JJJJ: „heute“, „letzter“ (Arbeitstag des Monats) oder ein eigenes Datum; sonst leer (Linie zum Ausfüllen)."""
    d = date.today() if wahl == "heute" else _letzter_arbeitstag(tage) if wahl == "letzter" else eigenes_datum(wahl)
    return d.strftime(DATUM_DE) if d else ""


def _unterschrift(kopf: dict, tage: list) -> dict:
    """Angaben der Unterschrift aus Personendaten und Wahl: {ort_datum, name (Großbuchstaben), zweite, vorgesetzt (Großbuchstaben)}.
    Ort ohne Datum endet mit Komma, damit das Datum von Hand dazukommt. Unbekannte Werte (fremde Geräte, alte Sicherungen) gelten wie ab Werk."""
    ort, datum = _nachweis_text(kopf, "ort"), _unterschrift_datum(_nachweis_text(kopf, "datum"), tage)
    zweite = kopf.get("zweite") == "1"
    return {"ort_datum": ", ".join(t for t in (ort, datum) if t) + ("," if ort and not datum else ""), "name": _nachweis_text(kopf, "name").upper(),
            "zweite": zweite, "vorgesetzt": _nachweis_text(kopf, "vorgesetzt").upper() if zweite else ""}


def _gehen_text(gehen: str) -> str:
    """Gehen als Uhrzeit hh:mm; nach Mitternacht (ab 24:00) als „02:00 (+1)“; leer bleibt leer."""
    return f"{fmt_hhmm(_min(gehen) - TAG_MIN)} (+1)" if gehen and _min(gehen) >= TAG_MIN else gehen


def _uhrzeiten(z: dict) -> dict:
    """Kommen, Gehen und Pause einer Monatszeile; Gehen nach Mitternacht als „02:00 (+1)“."""
    return {"kommen": z["kommen"], "gehen": _gehen_text(z["gehen"]), "pause": z["pause"]}


def _nachweis_bloecke(z: dict, anmerkung: str, stunden: str) -> list:
    """Blöcke eines Tages mit mehreren Einträgen (stempel.mit_eintraegen): je Block Kommen, Gehen, eigene Pause (die Lücke ist keine) und Stunden;
    die Anmerkung des Tages steht beim ersten, die Tagessumme beim letzten Block. Ohne Einträge eine leere Liste."""
    bl = z.get("eintraege") or []
    return [{"kommen": e["kommen"], "gehen": _gehen_text(e["gehen"]), "pause": e["pause"], "stunden": e["dauer"],
             "anmerkung": anmerkung if i == 0 else NACHWEIS_TAGESSUMME.format(stunden) if i == len(bl) - 1 else ""} for i, e in enumerate(bl)]


def _anmerkung(z: dict) -> str:
    """Anmerkung eines Tages: Feiertag, Art, Vermerk und Notiz mit „ · “; an Kranktagen nur „abwesend“ (bei Krank im Dienst nichts), ohne Vermerk und Notiz."""
    feiertag = z["feiertag"] if z["frei"] else ""          # an Soll-Tagen (Faschingsdienstag) steht dort das Soll, das der Nachweis nicht zeigt
    art = NACHWEIS_ARTEN.get(z["art"], "")
    if z["art"] in NACHWEIS_OHNE_NOTIZ:
        return " · ".join(t for t in (feiertag, art) if t)
    return " · ".join(t for t in (feiertag, art, VERMERKE.get(z["vermerk"], ""), notiz_bereinigen(z["notiz"])) if t)


def _nachweis_tag(z: dict, zeitformat: str) -> tuple:
    """Eine Zeile des Nachweises aus der Monatszeile (bericht.monat) und die Minuten, die in die Summe zählen.
    Stunden = HO + Büro (ohne Auffüllung von Krank im Dienst), auch an Urlaubs- oder Elternzeittagen mit eingetragener Zeit (wie bericht.monat);
    leer bei 0, an Kranktagen und vor Beginn der Erfassung. Dazu „bloecke“ (_nachweis_bloecke), nur wenn Stunden zählen."""
    vor_beginn = z["vor_beginn"]
    minuten = 0 if vor_beginn or z["art"] in NACHWEIS_KRANK else z["ist_min"]
    zeiten = {"kommen": "", "gehen": "", "pause": ""} if vor_beginn else _uhrzeiten(z)
    stunden, anmerkung = fmt_dauer(minuten, zeitformat) if minuten else "", bericht.VOR_BEGINN if vor_beginn else _anmerkung(z)
    return ({"datum": z["datum"], "tag": z["tag"], "wt": z["wt"], "frei": z["frei"], **zeiten, "stunden": stunden, "anmerkung": anmerkung,
             "kappzeit": "" if vor_beginn else z.get("kappzeit", ""),
             "bloecke": _nachweis_bloecke(z, anmerkung, stunden) if minuten else []}, minuten)


def nachweis_daten(db, j: int, m: int, kopf=None, zeitformat: str = "hhmm") -> dict:
    """Monatsnachweis als Daten (Vorschau und Grundlage der Dateien): alle Kalendertage, Kopf, Summen. Keine eigene Rechnung, nur bericht.monat.
    Eingaben: Db, Jahr, Monat 1–12, Kopf {name, arbeitgeber, personalnummer, ort, datum, zweite, vorgesetzt} (fehlt = leer), Zeitformat „hhmm“/„dezimal“. Tage vor „Erfassung gültig ab“
    (Startwerte der Datenbank) bleiben leer und zählen nicht in die Summen. Rückgabe: {jahr, monat, name, kopf, tage: [{datum, tag, wt, frei, kommen, gehen,
    pause, stunden, anmerkung, bloecke: [{kommen, gehen, pause, stunden, anmerkung}]}], summe: {stunden, urlaub, gleittage, freizeit}, unterschrift: siehe _unterschrift}. Urlaub und Gleittage zählen nur an Werktagen, Freizeitausgleich nur
    an Soll-Tagen (wie regeln.summe). Fehler: ValueError bei Monat außerhalb 1–12 oder unbekanntem Zeitformat."""
    d = stempel.mit_eintraegen(db, bericht.monat(db, j, m), zeitformat)
    tage, minuten, summe = [], 0, {"urlaub": 0, "gleittage": 0, "freizeit": 0}
    for z in d["tage"]:
        zeile, n = _nachweis_tag(z, zeitformat)
        tage.append(zeile)
        minuten += n
        if not z["vor_beginn"]:
            summe["urlaub"] += z["art"] in NACHWEIS_URLAUB and not z["frei"]
            summe["gleittage"] += z["art"] == "gleittag" and not z["frei"]
            summe["freizeit"] += z["art"] == "freizeit" and z["soll"]
    return {"jahr": j, "monat": m, "name": d["name"], "kopf": _nachweis_kopf(kopf), "tage": tage, "summe": {"stunden": fmt_dauer(minuten, zeitformat), **summe},
            "unterschrift": _unterschrift(kopf or {}, d["tage"])}


def _nachweis_zeilen(t: dict, mit_zeiten: bool, kapp: bool = False) -> list:
    """Tabellenzeilen eines Tages aus nachweis_daten: mit Beginn und Ende je Block eine (das Datum nur in der ersten), sonst die eine Zeile des Tages;
    kapp: dazu die Spalte Kappzeit (beim letzten Block, bei der Tagessumme)."""
    tag = f"{t['tag']}. {t['wt']}"
    if mit_zeiten and t["bloecke"]:
        letzte = len(t["bloecke"]) - 1
        return [Zeile([tag if i == 0 else "", b["kommen"], b["gehen"], b["pause"], b["stunden"], *([t["kappzeit"] if i == letzte else ""] if kapp else []), b["anmerkung"]])
                for i, b in enumerate(t["bloecke"])]
    return [Zeile([tag, *((t["kommen"], t["gehen"], t["pause"]) if mit_zeiten else ()), t["stunden"], *([t["kappzeit"]] if kapp else []), t["anmerkung"]])]


def nachweis_dokument(daten: dict, mit_zeiten: bool = False) -> list:
    """Monatsnachweis als Blöcke: Titel, Kopf (Angabe/Wert), Tagestabelle (mit_zeiten: dazu Kommen, Gehen, Pause und, wenn ein Tag sie hat, Kappzeit), Summen in einer Zeile und
    die Unterschrift („u“: Ort, Datum · Unterschrift mit Name · auf Wunsch Vorgesetzter/Vorgesetzte). Tage mit mehreren Blöcken: siehe _nachweis_zeilen.
    Eingabe: Ergebnis von nachweis_daten. Wochenenden und Feiertage erscheinen grau (Zeile.frei)."""
    zeilen, kapp = [], mit_zeiten and any(t.get("kappzeit") for t in daten["tage"])
    for t in daten["tage"]:
        for zeile in _nachweis_zeilen(t, mit_zeiten, kapp):
            zeile.frei = t["frei"]
            zeilen.append(zeile)
    s, u = daten["summe"], daten["unterschrift"]
    spalten = [(u["ort_datum"], NACHWEIS_ORT_DATUM, ""), ("", NACHWEIS_UNTERSCHRIFT, u["name"])] + ([("", NACHWEIS_VORGESETZT, u["vorgesetzt"])] if u["zweite"] else [])
    return [("h", f"Monatsnachweis {daten['name']} {daten['jahr']}"), ("p", f"Erstellt am {date.today().strftime('%d.%m.%Y')}"),
            ("t", ["Angabe", "Wert"], [[text, daten["kopf"][k]] for k, text in NACHWEIS_KOPF]),
            ("t", (NACHWEIS_SPALTEN_ZEITEN[:-1] + [KAPPZEIT, NACHWEIS_SPALTEN_ZEITEN[-1]] if kapp else NACHWEIS_SPALTEN_ZEITEN) if mit_zeiten else NACHWEIS_SPALTEN, zeilen),
            ("t", NACHWEIS_SUMMEN, [[s["stunden"], str(s["urlaub"]), str(s["gleittage"]), str(s["freizeit"])]]),
            ("u", spalten, NACHWEIS_GEWICHTE[len(spalten)])]


NACHWEIS_FORMATE = {"pdf": lambda bl: pdf.aus_bloecken(bl, umbrechen=True, zusammen=NACHWEIS_ZUSAMMEN), "docx": zu_docx}


def nachweis_datei(daten: dict, endung: str, mit_zeiten: bool = False) -> bytes:
    """Monatsnachweis als Datei: „pdf“ (lange Anmerkungen umbrochen statt gekürzt) oder „docx“. Eingabe: Ergebnis von nachweis_daten.
    Rückgabe: Bytes. Fehler: ValueError bei einer anderen Endung."""
    if endung not in NACHWEIS_FORMATE:
        raise ValueError(NACHWEIS_ENDUNG_FEHLER)
    return NACHWEIS_FORMATE[endung](nachweis_dokument(daten, mit_zeiten))


def steuer_xlsx(s: dict, zeitformat: str = "hhmm") -> bytes:
    """Excel-Mappe mit drei Blättern, gebaut vom eingebauten Erzeuger (xlsx.py, nur Standardbibliothek). Eingabe: Ergebnis von bericht.steuer
    und dessen Zeitformat (für den Block der Startwerte)."""
    from ausgabe import xlsx
    zeilen = bericht.uebersicht_zeilen(s, zeitformat)
    return xlsx.mappe([
        {"name": "Übersicht", "titel": f"{bericht.UEBERSICHT} {s['jahr']}", "unter": f"Zeiterfassung · erstellt am {bericht.de(date.today())}",
         "kopf": ["Angabe", "Anzahl"], "zeilen": zeilen, "breiten": [58, 14], "vermerk": VERMERK},
        {"name": "Elternzeit", "titel": bericht.ELTERNZEIT_TITEL, "kopf": bericht.ELTERNZEIT_KOPF, "zeilen": bericht.elternzeit_zeilen(s),
         "breiten": [14, 14, 8, 22]},
        {"name": "Krank", "titel": bericht.KRANK_TITEL, "kopf": bericht.KRANK_KOPF, "zeilen": bericht.krank_zeilen(s), "breiten": [14, 14, 8, 34, 22, 22]},
    ])


MONAT_BREITEN = ([24, 14], [10, 8, 8, 8, 8, 44])          # Spaltenbreiten in Zeichen: Kennzahlen, Tagestabelle (Hinweis breit)


def monat_xlsx(db, j: int, m: int, zeitformat: str = "hhmm") -> bytes:
    """Monatsbericht als Excel-Mappe (xlsx.py) aus denselben Blöcken wie das PDF: Blatt „Monat“ mit den Kennzahlen, Blatt „Tage“ mit der Tagestabelle.
    Texte stehen nur als Inline-Text in den Zellen, nie als Formel. Eingaben wie monat_dokument; Rückgabe: Bytes."""
    from ausgabe import xlsx
    (_, titel), (_, unter), (_, kopf, kennzahlen), (_, tage_kopf, tage) = monat_dokument(db, j, m, zeitformat)
    return xlsx.mappe([{"name": "Monat", "titel": titel, "unter": unter, "kopf": kopf, "zeilen": kennzahlen, "breiten": MONAT_BREITEN[0], "vermerk": VERMERK},
                       {"name": "Tage", "titel": titel, "kopf": tage_kopf, "zeilen": tage, "breiten": MONAT_BREITEN[1]}])


def steuer_pdf(s: dict, zeitformat: str = "hhmm") -> bytes:
    """PDF vom eingebauten Erzeuger (pdf.py, nur Standardbibliothek): kein PDF-Dienst, kein Netz. Eingabe: Ergebnis von bericht.steuer."""
    return pdf.aus_bloecken(steuer_dokument(s, zeitformat))


def monat_pdf(db, j: int, m: int, zeitformat: str = "hhmm") -> bytes:
    """Monatsbericht als fertiges PDF (Bytes) im Zeitformat „hhmm“ oder „dezimal“."""
    return pdf.aus_bloecken(monat_dokument(db, j, m, zeitformat))
