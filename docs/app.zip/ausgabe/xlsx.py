# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Eingebauter Excel-Erzeuger (nur Standardbibliothek): schreibt eine .xlsx-Mappe direkt als ZIP mit XML, ohne Zusatzpakete.
Damit braucht die App nichts aus dem Internet und läuft überall gleich (Server, Desktop, Android, Web-App).

Ein Blatt ist ein dict: name (Reiter), titel, unter (kleine Zeile unter dem Titel, optional), kopf (Liste), zeilen (Liste von Listen; Zahlen bleiben Zahlen),
breiten (Spaltenbreiten in Zeichen), vermerk (kleine Zeile am Ende, optional). Gestaltung in der Akzentfarbe (design.Palette): farbige Kopfzeile,
gestreifte Zeilen, feine Linien, A4 hoch auf eine Seitenbreite, Fußzeile mit Version und „Seite x von y“."""
import io
import re
import zipfile
from xml.sax.saxutils import escape

from ausgabe import design
from urheber import FUSS

_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_PKG = "http://schemas.openxmlformats.org/package/2006"
# Formatnummern (cellXfs in _styles)
TITEL, UNTER, KOPF_L, KOPF_R, ZELLE_L, ZELLE_R, STREIF_L, STREIF_R, VERMERK = 1, 2, 3, 4, 5, 6, 7, 8, 9
_UNERLAUBT = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f￾￿]")


def _t(wert) -> str:
    """Text für XML: unerlaubte Zeichen entfernen, Sonderzeichen und Anführungszeichen maskieren."""
    return escape(_UNERLAUBT.sub("", str(wert)), {'"': "&quot;"})


def _spalte(n: int) -> str:
    """0 → A, 25 → Z, 26 → AA."""
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _zelle(zeile: int, spalte: int, wert, stil: int) -> str:
    """Eine Zelle als XML: leer, Wahrheitswert, Zahl oder Text (als Inline-Text, nie als Formel)."""
    ort = f"{_spalte(spalte)}{zeile}"
    if isinstance(wert, bool) or wert is None or wert == "":
        return f'<c r="{ort}" s="{stil}"/>' if wert in (None, "") else f'<c r="{ort}" s="{stil}" t="b"><v>{int(wert)}</v></c>'
    if isinstance(wert, (int, float)):
        return f'<c r="{ort}" s="{stil}"><v>{wert!r}</v></c>'
    return f'<c r="{ort}" s="{stil}" t="inlineStr"><is><t xml:space="preserve">{_t(wert)}</t></is></c>'


def _styles(p) -> str:
    """styles.xml der Mappe: Schriften, Füllungen und Rahmen in der Akzentfarbe; die Formate stehen als Nummern bereit (TITEL, KOPF_L usw.)."""
    f = lambda c: "FF" + c.lstrip("#").upper()
    schrift = lambda groesse, farbe="", fett=False: (f'<font>{"<b/>" if fett else ""}<sz val="{groesse}"/>{f"<color rgb={chr(34)}{f(farbe)}{chr(34)}/>" if farbe else ""}'
                                                     '<name val="Calibri"/><family val="2"/></font>')
    fuell = lambda c: f'<fill><patternFill patternType="solid"><fgColor rgb="{f(c)}"/><bgColor indexed="64"/></patternFill></fill>'
    xf = lambda font=0, fill=0, border=0, rechts=False, mitte=False: (
        f'<xf numFmtId="0" fontId="{font}" fillId="{fill}" borderId="{border}" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
        f'<alignment horizontal="{"right" if rechts else "left"}"{" vertical=" + chr(34) + "center" + chr(34) if mitte else ""} indent="1"/></xf>')
    xfs = [xf(), xf(1), xf(2), xf(3, 2, mitte=True), xf(3, 2, rechts=True, mitte=True), xf(0, 0, 1), xf(0, 0, 1, True), xf(0, 3, 1), xf(0, 3, 1, True), xf(4)]
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="{_NS}">'
            f'<fonts count="5">{schrift(11)}{schrift(15, p.titel, True)}{schrift(9, p.grau)}{schrift(11, p.auf_akzent, True)}{schrift(8, p.grau)}</fonts>'
            f'<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>{fuell(p.akzent)}{fuell(p.weich)}</fills>'
            f'<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>'
            f'<border><left/><right/><top/><bottom style="thin"><color rgb="{f(p.linie)}"/></bottom><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            f'<cellXfs count="{len(xfs)}">{"".join(xfs)}</cellXfs>'
            '<cellStyles count="1"><cellStyle name="Standard" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def _blatt(b: dict, p) -> str:
    """Ein Tabellenblatt als XML: Titel, Kopfzeile, gestreifte Zeilen, Vermerk, Spaltenbreiten und Fußzeile."""
    kopf, zeilen = list(b.get("kopf") or []), [list(z) for z in (b.get("zeilen") or [])]
    spalten = max([len(kopf)] + [len(z) for z in zeilen] + [1])
    breiten = list(b.get("breiten") or []) + [16] * spalten
    aus, nr = [], 1
    aus.append(f'<row r="1" ht="24" customHeight="1">{_zelle(1, 0, b.get("titel", ""), TITEL)}</row>')
    if b.get("unter"):
        nr = 2
        aus.append(f'<row r="2">{_zelle(2, 0, b["unter"], UNTER)}</row>')
    nr += 2                                                 # eine Leerzeile, dann die Tabelle
    rechts = lambda i, wert: i > 0 and isinstance(wert, (int, float)) and not isinstance(wert, bool)
    if kopf:
        zellen = "".join(_zelle(nr, i, k, KOPF_R if (i > 0 and k in ("Anzahl", "Wert")) else KOPF_L) for i, k in enumerate(kopf))
        aus.append(f'<row r="{nr}" ht="20" customHeight="1">{zellen}</row>')
        nr += 1
    for n, z in enumerate(zeilen, 1):
        streif = n % 2 == 0
        zellen = "".join(_zelle(nr, i, w, (STREIF_R if streif else ZELLE_R) if rechts(i, w) else (STREIF_L if streif else ZELLE_L)) for i, w in enumerate(z))
        aus.append(f'<row r="{nr}">{zellen}</row>')
        nr += 1
    if b.get("vermerk"):
        nr += 2
        aus.append(f'<row r="{nr}">{_zelle(nr, 0, b["vermerk"], VERMERK)}</row>')
    cols = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{breiten[i]}" customWidth="1"/>' for i in range(spalten))
    fuss = _t("&L&8" + FUSS.replace("&", "&&") + "&R&8Seite &P von &N")
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="{_NS}">'
            f'<sheetPr><tabColor rgb="FF{p.akzent.lstrip("#").upper()}"/><pageSetUpPr fitToPage="1"/></sheetPr>'
            '<sheetViews><sheetView showGridLines="0" workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>'
            f'<cols>{cols}</cols><sheetData>{"".join(aus)}</sheetData>'
            '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>'
            '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>'
            f'<headerFooter><oddFooter>{fuss}</oddFooter></headerFooter></worksheet>')


def _reiter(name: str, vergeben: set) -> str:
    """Excel erlaubt im Reiter höchstens 31 Zeichen und einige Zeichen nicht; Namen müssen eindeutig sein."""
    n = re.sub(r"[\[\]:*?/\\]", " ", _UNERLAUBT.sub("", str(name))).strip().strip("'")[:31] or "Blatt"
    basis, i = n, 2
    while n.lower() in vergeben:
        n = f"{basis[:28]} {i}"
        i += 1
    vergeben.add(n.lower())
    return n


def mappe(blaetter: list, palette=None) -> bytes:
    """Mehrere Blätter als fertige .xlsx-Datei."""
    p = palette or design.Palette()
    blaetter = blaetter or [{"name": "Blatt", "titel": ""}]
    vergeben = set()
    namen = [_reiter(b.get("name", "Blatt"), vergeben) for b in blaetter]
    n = range(1, len(blaetter) + 1)
    typen = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="{_PKG}/content-types">'
             '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
             '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
             '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
             + "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in n)
             + "</Types>")
    wurzel = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{_PKG}/relationships">'
              f'<Relationship Id="rId1" Type="{_REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    buch = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="{_NS}" xmlns:r="{_REL}"><sheets>'
            + "".join(f'<sheet name="{_t(namen[i - 1])}" sheetId="{i}" r:id="rId{i}"/>' for i in n) + "</sheets></workbook>")
    buch_rels = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="{_PKG}/relationships">'
                 + "".join(f'<Relationship Id="rId{i}" Type="{_REL}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in n)
                 + f'<Relationship Id="rId{len(blaetter) + 1}" Type="{_REL}/styles" Target="styles.xml"/></Relationships>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", typen)
        z.writestr("_rels/.rels", wurzel)
        z.writestr("xl/workbook.xml", buch)
        z.writestr("xl/_rels/workbook.xml.rels", buch_rels)
        z.writestr("xl/styles.xml", _styles(p))
        for i, b in zip(n, blaetter):
            z.writestr(f"xl/worksheets/sheet{i}.xml", _blatt(b, p))
    return buf.getvalue()
