# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Feiertage je Bundesland (Einstellung bundesland mit Gültig-ab-Datum, Voreinstellung Bayern ohne Mariä Himmelfahrt), nur Standardbibliothek.
24.12. und 31.12. sind einzeln als freie Tage einstellbar, dazu eigene jährliche Feiertage und abgewählte gesetzliche (Regeln, ab einem Jahr)."""
from datetime import date, timedelta
from functools import lru_cache

from daten import konfig


def ostern(jahr: int) -> date:
    """Ostersonntag nach der Gaußschen Osterformel."""
    a, b, c = jahr % 19, jahr // 100, jahr % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    monat = (h + l - 7 * m + 114) // 31
    tag = (h + l - 7 * m + 114) % 31 + 1
    return date(jahr, monat, tag)


EINHEIT = "Tag der Dt. Einheit"              # bis 1990 am 17.06., ab 1990 am 03.10. (1990 beide)
EINHEIT_JAHR = 1990
REFORMATION_JUBILAEUM = 2017                  # 500 Jahre Reformation: einmalig in allen Ländern frei
BUSS_UND_BETTAG_BIS = 1994                    # danach nur noch in Sachsen
# Herkunft eines Tags in der Feiertagsliste (R4b, Karte „Eigene Feiertage“); SONDERTAG (24.12./31.12.) kommt in der Liste nicht vor
GESETZLICH, JAEHRLICH, EINMALIG, ABGEWAEHLT, SONDERTAG = "gesetzlich", "jaehrlich", "einmalig", "abgewaehlt", "sondertag"
EIGENER_FREIER_TAG = "Eigener freier Tag"                    # Name eines einmaligen freien Tags ohne eigenen Namen (alte Daten)


@lru_cache(maxsize=256)
def _feiertage(jahr: int, bl: str) -> dict:
    """Gesetzliche Feiertage eines Bundeslandes (Kürzel wie „BY“) im Jahr: {Datum: Name}, ohne Sonderregel für Mariä Himmelfahrt in Bayern und ohne 24.12./31.12.
    Mit den Jahren, in denen sie galten (für alte Daten ab 1970): 17.06. bis 1990, 03.10. ab 1990, Reformationstag 2017 überall, Frauentag BE
    und Weltkindertag TH ab 2019, Buß- und Bettag bis 1994 überall."""
    o = ostern(jahr)
    t = timedelta
    r = {date(jahr, 1, 1): "Neujahr", o - t(days=2): "Karfreitag", o + t(days=1): "Ostermontag", date(jahr, 5, 1): "Tag der Arbeit",
         o + t(days=39): "Christi Himmelfahrt", o + t(days=50): "Pfingstmontag",
         date(jahr, 12, 25): "1. Weihnachtstag", date(jahr, 12, 26): "2. Weihnachtstag"}
    if jahr <= EINHEIT_JAHR:
        r[date(jahr, 6, 17)] = EINHEIT
    if jahr >= EINHEIT_JAHR:
        r[date(jahr, 10, 3)] = EINHEIT
    if bl in ("BW", "BY", "ST"):
        r[date(jahr, 1, 6)] = "Heilige Drei Könige"
    if (bl == "BE" and jahr >= 2019) or (bl == "MV" and jahr >= 2023):
        r[date(jahr, 3, 8)] = "Frauentag"
    if bl in ("BW", "BY", "HE", "NW", "RP", "SL"):
        r[o + t(days=60)] = "Fronleichnam"
    if bl == "SL":
        r[date(jahr, 8, 15)] = "Mariä Himmelfahrt"
    if bl == "TH" and jahr >= 2019:
        r[date(jahr, 9, 20)] = "Weltkindertag"
    if bl in ("BB", "MV", "SN", "ST", "TH") or (bl in ("HB", "HH", "NI", "SH") and jahr >= 2018) or jahr == REFORMATION_JUBILAEUM:
        r[date(jahr, 10, 31)] = "Reformationstag"
    if bl in ("BW", "BY", "NW", "RP", "SL"):
        r[date(jahr, 11, 1)] = "Allerheiligen"
    if bl == "SN" or jahr <= BUSS_UND_BETTAG_BIS:        # Buß- und Bettag: Mittwoch vor dem 23.11.
        d = date(jahr, 11, 22)
        while d.weekday() != 2:
            d -= t(days=1)
        r[d] = "Buß- und Bettag"
    return r


@lru_cache(maxsize=64)
def _verzeichnis(jahr: int, rev: int, mit_sondertagen: bool) -> tuple:
    """Feiertage (und optional 24.12./31.12.) des Jahres mit Herkunft: ((Datum, Name, Quelle), …); jeder Tag nach den Regeln, die an
    diesem Tag gelten. Abgewählte Feiertage (Regel feiertage_aus) stehen mit ABGEWAEHLT darin, eigene jährliche (feiertage_eigen) mit JAEHRLICH (R4b)."""
    vs = konfig.VERSIONEN
    r = {}
    for i, v in enumerate(vs):
        ende = vs[i + 1]["ab"] if i + 1 < len(vs) else "9999-12-31"
        w = v["werte"]
        tage = dict(_feiertage(jahr, w["bundesland"]))
        if w.get("himmelfahrt_frei") and w["bundesland"] == "BY":   # Bayern: nur in Gemeinden mit überwiegend katholischer Bevölkerung, deshalb einstellbar
            tage[date(jahr, 8, 15)] = "Mariä Himmelfahrt"
        aus = set(w.get("feiertage_aus", ()))
        tage = {d: (n, ABGEWAEHLT if n in aus else GESETZLICH) for d, n in tage.items()}
        tage.update({d: (n, JAEHRLICH) for d, n in _eigene_jaehrlich(jahr, w.get("feiertage_eigen", ())).items()})
        if mit_sondertagen:
            if w["heiligabend_frei"]:
                tage[date(jahr, 12, 24)] = ("Heiligabend", SONDERTAG)
            if w["silvester_frei"]:
                tage[date(jahr, 12, 31)] = ("Silvester", SONDERTAG)
        for d, nq in tage.items():
            if v["ab"] <= d.isoformat() < ende:
                r[d] = nq
    return tuple((d, n, q) for d, (n, q) in r.items())


@lru_cache(maxsize=64)
def _freie(jahr: int, rev: int, mit_sondertagen: bool) -> tuple:
    """Die freien Tage aus _verzeichnis als ((Datum, Name), …), ohne die abgewählten."""
    return tuple((d, n) for d, n, q in _verzeichnis(jahr, rev, mit_sondertagen) if q != ABGEWAEHLT)


def _eigene_jaehrlich(jahr: int, eigene) -> dict:
    """Eigene jährliche Feiertage [[MM-TT, Name], …] (geprüft in konfig) als {Datum: Name} im Jahr. Der 29.02. gilt nur in Schaltjahren,
    in anderen Jahren gibt es keinen Ersatztag (Festlegung R4b)."""
    r = {}
    for tag, name in eigene:
        try:
            r[date(jahr, int(tag[:2]), int(tag[3:]))] = name
        except ValueError:
            continue
    return r


FEIERTAG_DOPPELT = "Am {tag} ist schon ein Feiertag ({name})"


def _feste_gesetzliche(werte: dict, jahr: int) -> dict:
    """Gesetzliche Feiertage mit festem Datum nach den Regeln „werte“ als {MM-TT: Name}, ohne abgewählte, mit Mariä Himmelfahrt nach Einstellung.
    Fest heißt: im Jahr und im Folgejahr am selben Tag mit demselben Namen; Ostern und der Buß- und Bettag wandern jedes Jahr."""
    bl, aus, je_jahr = werte["bundesland"], set(werte.get("feiertage_aus", ())), []
    for j in (jahr, jahr + 1):
        tage = dict(_feiertage(j, bl))
        if werte.get("himmelfahrt_frei") and bl == "BY":
            tage[date(j, 8, 15)] = "Mariä Himmelfahrt"
        je_jahr.append({f"{d:%m-%d}": n for d, n in tage.items() if n not in aus})
    return {tag: n for tag, n in je_jahr[0].items() if je_jahr[1].get(tag) == n}


def eigene_pruefen(werte: dict, jahr: int) -> None:
    """Eingabe der Person (R4b): Ein eigener jährlicher Feiertag darf nicht auf einem gesetzlichen mit festem Datum liegen, der nach den Regeln
    „werte“ (bundesland, feiertage_eigen, feiertage_aus, himmelfahrt_frei) ab dem Jahr gilt. Ein abgewählter gesetzlicher Tag ist erlaubt.
    Bewegliche Feiertage prüft es nicht: der eigene Tag fällt nur in manchen Jahren darauf. Fehler: konfig.Meldung mit Datum und Name."""
    fest = _feste_gesetzliche(werte, jahr)
    for tag, _name in werte.get("feiertage_eigen", ()):
        if tag in fest:
            raise konfig.Meldung(FEIERTAG_DOPPELT.format(tag=f"{tag[3:]}.{tag[:2]}.", name=fest[tag]))


def feiertage(jahr: int) -> dict:
    """Feiertage des Jahres {Datum: Name} nach den Regeln, die an jedem Tag gelten (Bundesland je Version, ohne 24.12./31.12.)."""
    return dict(_freie(jahr, konfig.regelstand_nr(), False))


def liste(jahr: int, einmalige) -> list:
    """Feiertagsliste eines Jahres für die Karte „Eigene Feiertage“ (GET /api/feiertage/<J>), ohne 24.12./31.12. (eigene Schalter).
    Eingaben: Jahr, einmalige eigene freie Tage des Jahres wie Db.eigene_feiertage ([{"datum": date, "name": Text}], leerer Name wird
    EIGENER_FREIER_TAG). Rückgabe: [{"datum": "JJJJ-MM-TT", "name", "quelle": GESETZLICH|JAEHRLICH|EINMALIG|ABGEWAEHLT, "frei": bool}] nach Datum;
    nur abgewählte sind nicht frei. Keine Fehler."""
    r = [{"datum": d.isoformat(), "name": n, "quelle": q, "frei": q != ABGEWAEHLT} for d, n, q in _verzeichnis(jahr, konfig.regelstand_nr(), False)]
    r += [{"datum": x["datum"].isoformat(), "name": x["name"] or EIGENER_FREIER_TAG, "quelle": EINMALIG, "frei": True} for x in einmalige]
    return sorted(r, key=lambda x: x["datum"])


def freie_tage(jahr: int) -> dict:
    """Feiertage plus (je nach Einstellung) Heiligabend und Silvester."""
    return dict(_freie(jahr, konfig.regelstand_nr(), True))


@lru_cache(maxsize=256)
def _freie_menge(jahr: int, rev: int) -> frozenset:
    """Die freien Tage des Jahres als Menge (für die häufige Frage „ist der Tag frei?“, ohne jedes Mal ein Verzeichnis zu bauen)."""
    return frozenset(d for d, _name in _freie(jahr, rev, True))


def ist_frei(d: date, eigene=frozenset()) -> bool:
    """Wochenende, Feiertag, (einstellbar) 24.12./31.12. oder eigener freier Tag."""
    return d.weekday() >= 5 or d in _freie_menge(d.year, konfig.regelstand_nr()) or d in eigene


@lru_cache(maxsize=256)
def _faschingsdienstag(jahr: int) -> date:
    """Datum des Faschingsdienstags im Jahr (47 Tage vor Ostern)."""
    return ostern(jahr) - timedelta(days=47)


def ist_faschingsdienstag(d: date) -> bool:
    """Faschingsdienstag = 47 Tage vor Ostern; Arbeitstag mit begrenzter Sollzeit (Einstellung fasching_std, leer = keine Begrenzung)."""
    return d == _faschingsdienstag(d.year) and konfig.fuer(d)["fasching_std"] is not None
