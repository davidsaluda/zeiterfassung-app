# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Zählregeln, Quote und HO-Rest (Regeln des Büros: 80-%-Grenze für Homeoffice, Gleittage, Familientage)."""
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache

from daten import konfig
from kern.feiertage import ist_faschingsdienstag, ist_frei

WT = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"]
STANDARD_WOCHENSTUNDEN = 40.0
STANDARD_TAGE = "Mo,Di,Mi,Do,Fr"
WEG_WOCHENSTUNDEN, WEG_TAGE, WEG_JE_TAG = 1, 2, 3                # Teilzeit (R4): nur Wochenstunden, gewählte Tage, Stunden je Tag
KRANK_ATTEST = "krank_attest"
SONDERURLAUB, KIND_KRANK = "sonderurlaub_tag", "kind_krank"   # ganze Tage ohne Soll und ohne Abzug vom Urlaub, je mit eigenem Zähler (R5)
ELTERNZEIT = "elternzeit"                                  # Tages-Art: kein Soll, wie ein Tag im Elternzeit-Abschnitt mit 0 h
# Arten ohne Soll und ohne geplante Arbeitszeit; der Gleittag behält sein Soll nur fürs Gleitzeit-Konto (woche.ENTFALLEN)
ABWESEND = ("urlaub", "angespart", "gleittag", "krank", KRANK_ATTEST, "familientag", "freizeit", SONDERURLAUB, KIND_KRANK, ELTERNZEIT)
KRANK = ("krank", KRANK_ATTEST)
KRANK_IM_DIENST = "krank_dienst"                           # kein Kranktag (ein Arbeitstag), füllt bis zum Tagessoll auf, steht in der Krank-Liste und in der Phase
BUERO_TAGE_MAX = 5                                         # Annahme „Büro-Tage pro Woche“ der Prognose: 0 bis 5
ABSCHNITT_ARTEN = ("normal", "teilzeit", "elternzeit", "elternteilzeit", "altersteilzeit", "altersteilzeit_frei", "pflegezeit", "sonderurlaub", "mutterschutz")
# Nur „elternzeit“ mit 0 h zählt in der Homeoffice-Übersicht als Tag in Elternzeit; bei allen anderen Arten ergibt sich das Soll allein aus Wochenstunden und Arbeitstagen.
JAHR_MIN, JAHR_MAX = 1970, 2200                            # Grenzen für jedes Datum, das von außen kommt (Oberfläche, Sync)
STEUERZEICHEN = konfig.STEUERZEICHEN                      # in Notizen nicht erlaubt (machen Word- und Excel-Dateien ungültig); eine Quelle mit den Feiertagsnamen
VERMERKE = konfig.VERMERKE                                 # Vermerk am Tag (Dienstreise, Fortbildung), ohne Wirkung auf die Rechnung
tagesminuten_lesen = konfig.tagesminuten_lesen             # Stunden je Tag eines Abschnitts lesen (Mo:480,Di:360 = Weg 3)
Startwerte = konfig.Startwerte                             # „Erfassung gültig ab“ (R6): ab und der Stand des Jahres bis zum Vortag
startwerte_lesen = konfig.startwerte_lesen                 # gespeicherten Text der Startwerte prüfen und lesen (ValueError)
NOTIZ_MAX = 300                                            # Zeichen einer Anmerkung (Eingabe, Sync, Wiederherstellen)


def notiz_bereinigen(text: str) -> str:
    """Eine Anmerkung ohne Steuerzeichen (auch ohne Zeilenumbruch) und ohne unsichtbare Formatzeichen (konfig.UNSICHTBAR, entfernt statt ersetzt,
    sonst stünde mitten im Wort ein Leerzeichen): gleich bei Eingabe, Synchronisierung und beim Bereinigen alter Datenbanken.
    Gilt auch für den Kopf des Monatsnachweises (Speichern und Lesen)."""
    return STEUERZEICHEN.sub(" ", konfig.UNSICHTBAR.sub("", text)).strip()


ARTEN = {"": "", "urlaub": "Erholungsurlaub", "angespart": "Angesparter Urlaub", "gleittag": "Gleittag", "krank": "Krank",
         "krank_attest": "Krank mit Attest", "krank_dienst": "Krank im Dienst", ELTERNZEIT: "Elternzeit", "familientag": "Familientag", "freizeit": "Freizeitausgleich",
         SONDERURLAUB: "Sonderurlaub", KIND_KRANK: "Kind krank"}


def kind_krank_max(jahr: int) -> int:
    """Höchstzahl der Tage „Kind krank“ im Jahr (R5, N5). Eingabe: Kalenderjahr. Rückgabe: Limit nach den Regeln, die für das Jahr gelten,
    also Vorgabe nach Gesetz, Jahr und Dienstverhältnis (kind_krank_dienst) oder der eigene Wert kind_krank_max (konfig.kind_krank_grenze)."""
    return konfig.kind_krank_grenze(konfig.fuer_jahr(jahr), jahr)


def gleittage_max(jahr: int) -> int:
    """Höchstzahl Gleittage im Jahr nach den Regeln, die für dieses Jahr gelten."""
    return konfig.fuer_jahr(jahr)["gleittage_max"]


def familientage_max(jahr: int) -> int:
    """Höchstzahl Familientage im Jahr nach den Regeln, die für dieses Jahr gelten."""
    return konfig.fuer_jahr(jahr)["familientage_max"]


def ho_grenze(d=None) -> int:
    """Obergrenze des HO-Anteils in Prozent (ganzzahlig gerechnet) nach den Regeln, die am Tag d (Standard: heute) gelten.
    Ohne Grenze, kein oder nur Homeoffice: 100, also nie eine Überschreitung."""
    k = konfig.fuer(d or date.today())
    return k["ho_grenze"] if k["ho_modus"] == "grenze" else 100


MAX_TAG_MIN = 600           # höchstens 10 Stunden Arbeitszeit pro Tag (sonst nur mit Freigabe)
TAG_MIN = 1440              # ein Tag hat 24 Stunden: mehr nimmt kein Eingang an, auch nicht mit Freigabe
TAG_VOLL = "Ein Tag hat höchstens 24 Stunden"
PAUSE_HAND_MAX_MIN = 600    # von Hand angegebene Pause höchstens 10 Stunden
OHNE_UHRZEIT = -1           # Tag ohne Kommen/Gehen (nur Dauer eingetragen, z. B. alte Einträge)
GEHEN_MAX_MIN = 2 * 1440    # Gehen nach Mitternacht zählt weiter (26:00 = 2 Uhr am Folgetag)


URLAUB_MAX = 366            # Obergrenze für Urlaubstage (Anspruch, Übertrag, Konto), die nicht aus der Oberfläche kommen
ANSPRUCH_MAX = 60           # Obergrenzen der Oberfläche für den Jahresanspruch und den Übertrag (Tage)
UEBERTRAG_MAX = 120
WOCHENSTUNDEN_MAX = konfig.WOCHENSTUNDEN_MAX


def zahl_gueltig(w, von, bis) -> bool:
    """Eine Zahl, die nicht aus der Oberfläche kommt (Synchronisierung, Sicherung): kein Wahrheitswert, kein Text, nicht unendlich, innerhalb der Grenzen."""
    return not isinstance(w, bool) and isinstance(w, (int, float)) and von <= w <= bis


def tageszeit_gueltig(ho, dst, art: str = "") -> bool:
    """Minuten eines Tages, die nicht aus der Oberfläche kommen (Synchronisierung, Sicherung): ganze Zahlen ab 0, zusammen höchstens 24 Stunden;
    Sonderurlaub und Kind krank (GANZE_TAGE, R5) ohne Minuten. Arbeitstag und Jahreslimit prüft nur die Eingabe (ganzen_tag_pruefen),
    weil sie von Abschnitten und anderen Tagen abhängen, die in der Synchronisierung erst später oder gar nicht mitkommen."""
    if not all(isinstance(m, int) and not isinstance(m, bool) and 0 <= m <= TAG_MIN for m in (ho, dst)) or ho + dst > TAG_MIN:
        return False
    return not (art in GANZE_TAGE and ho + dst)


def arbeitszeit(kommen: int, gehen: int, pause, d=None) -> tuple:
    """(Pause, Arbeitszeit) in Minuten aus Kommen und Gehen (Minuten ab Mitternacht des Tages). pause None: die 6-Stunden-Regel (pause_auto)
    setzt sie und sie wird als Pause gebucht; eine eigene Angabe (auch 0) ersetzt die Regel. konfig.Meldung bei unmöglichen Angaben."""
    if not all(isinstance(x, int) and not isinstance(x, bool) for x in (kommen, gehen)) or not 0 <= kommen < 1440:
        raise konfig.Meldung("Kommen: Uhrzeit zwischen 00:00 und 23:59")
    if not kommen < gehen <= GEHEN_MAX_MIN:
        raise konfig.Meldung("Gehen muss nach Kommen liegen")
    spanne = gehen - kommen
    p = pause_auto(spanne, d) if pause is None else pause
    if not isinstance(p, int) or isinstance(p, bool) or not 0 <= p <= PAUSE_HAND_MAX_MIN:
        raise konfig.Meldung(f"Pause: 0 bis {PAUSE_HAND_MAX_MIN // 60} Stunden")
    if p > spanne:
        raise konfig.Meldung("Die Pause ist länger als die Zeit von Kommen bis Gehen")
    return p, spanne - p


def uhrzeiten_gueltig(kommen, gehen, pause) -> bool:
    """Kommen, Gehen, Pause aus Synchronisierung oder Sicherung: entweder ohne Uhrzeit (-1, -1, Pause 0) oder eine mögliche Angabe."""
    if (kommen, gehen, pause) == (OHNE_UHRZEIT, OHNE_UHRZEIT, 0):
        return True
    try:
        arbeitszeit(kommen, gehen, pause)
        return True
    except ValueError:
        return False


def pause_auto(dauer_min: int, d=None) -> int:
    """Pause nach der Pausenregel am Tag d (Regeln, Voreinstellung: über 6 Stunden 30 Minuten). Je Stufe anteilig, damit die Arbeitszeit nie
    unter die Schwelle fällt: Stufen 6:00/0:30 und 9:00/0:45 geben bei 6:25 -> 25, 8:30 -> 30, 9:10 -> 40, 10:00 -> 45 Minuten."""
    p = vorher = 0
    for ab, pause in konfig.fuer(d or date.today())["pausen"]:
        if dauer_min > ab:
            p = max(p, min(pause, int(dauer_min) - ab + vorher))
        vorher = pause
    return p


# Pause und Kappzeit (Auftrag vom 25.11.2026): gilt für Tage ab dem Release (K4c); ältere Tage rechnen beim Ändern ohne Kappzeit, über 10 Stunden
# bleibt dort ein Fehler wie bisher (zehn_stunden_fehler). Kappzeit je Grund: vor dem Beginn, nach dem Ende der Regelarbeitszeit, über der Tagesgrenze.
KAPPZEIT_AB = date(2026, 11, 26)
KAPP_GRUENDE = ("vor", "nach", "ueber")


def kappzeit_regeln(d: date) -> tuple:
    """(Regelarbeitszeit (Beginn, Ende) oder None, Tagesgrenze in Minuten oder None) am Tag d; vor KAPPZEIT_AB beides None."""
    if d < KAPPZEIT_AB:
        return None, None
    w = konfig.fuer(d)
    return (tuple(w["regelzeit"]) if w["regelzeit_an"] else None), (w["tagesgrenze_min"] if w["tagesgrenze_an"] else None)


def tagesgrenze(d: date):
    """Höchste Arbeitszeit netto ohne Freigabe am Tag d in Minuten: vor KAPPZEIT_AB MAX_TAG_MIN, danach die Tagesgrenze der Regeln, abgeschaltet None."""
    return MAX_TAG_MIN if d < KAPPZEIT_AB else kappzeit_regeln(d)[1]


def zehn_stunden_fehler(d: date, minuten: int, freigabe) -> bool:
    """Ist minuten am Tag d ohne Freigabe ein Eingabefehler? Vor KAPPZEIT_AB über MAX_TAG_MIN wie bisher; danach über der Tagesgrenze nur noch,
    wenn tag_rechnen nicht kappen konnte (Stunden ohne Uhrzeit), mit abgeschalteter Tagesgrenze nie."""
    grenze = tagesgrenze(d)
    return bool(grenze) and minuten > grenze and not freigabe


def _abziehen(liste: list, minuten: int) -> None:
    """Zieht minuten vom zeitlich letzten Eintrag ab, reicht er nicht, vom Eintrag davor usw.; kein Eintrag wird negativ. Ändert liste (Index 4)."""
    for e in reversed(liste):
        weg = min(minuten, e[4])
        e[4] -= weg
        minuten -= weg


def _ausserhalb_kappen(mit: list, regelzeit) -> dict:
    """Schritt 1: Zeit vor dem Beginn und nach dem Ende der Regelarbeitszeit verfällt (zählt auch nicht auf die Pause an). Setzt je Eintrag
    die Minuten innerhalb minus Pause von Hand (nie unter 0). Rückgabe: {"vor", "nach"} in Minuten."""
    beginn, ende = regelzeit or (0, GEHEN_MAX_MIN)
    kapp = {"vor": 0, "nach": 0}
    for e in mit:
        kapp["vor"] += max(0, min(e[2], beginn) - e[1])
        kapp["nach"] += max(0, e[2] - max(e[1], ende))
        e[4] = max(0, min(e[2], ende) - max(e[1], beginn) - e[3])
    return kapp


def _pflichtpause(mit: list, regelzeit, d: date) -> None:
    """Schritt 2: Mindestpause nach pause_auto über die Zeit innerhalb der Regelarbeitszeit (erstes Kommen bis letztes Gehen, also mit Lücken).
    Lücken und Pausen von Hand zählen an, eine Pause von Hand nur bis zur Zeit ihres Eintrags innerhalb (K1); der Rest geht vom letzten Eintrag rückwärts ab."""
    beginn, ende = regelzeit or (0, GEHEN_MAX_MIN)
    von, bis = max(mit[0][1], beginn), min(max(e[2] for e in mit), ende)
    gesamt = max(0, bis - von)
    innen = [max(0, min(e[2], ende) - max(e[1], beginn)) for e in mit]
    luecken = max(0, gesamt - sum(innen))               # überlappende Einträge (Stempeluhr über einen Eintrag hinweg) sind keine negative Lücke
    _abziehen(mit, max(0, pause_auto(gesamt, d) - luecken - sum(min(e[3], i) for e, i in zip(mit, innen))))


def _ueber_grenze_kappen(liste: list, mit: list, grenze) -> int:
    """Schritt 3: Netto über der Tagesgrenze (alle Einträge, auch ohne Uhrzeit) verfällt, abgezogen von den Einträgen mit Uhrzeit rückwärts.
    Rückgabe: gekappte Minuten."""
    ueber = max(0, sum(e[4] for e in liste) - grenze) if grenze else 0
    vorher = sum(e[4] for e in mit)
    _abziehen(mit, ueber)
    return vorher - sum(e[4] for e in mit)


def _rechnen(liste: list, d: date, freigabe) -> tuple:
    """Die drei Schritte der Tagesrechnung (siehe tag_rechnen). Rückgabe: (Kopie der Liste mit Minuten netto, Kappzeit je Grund,
    Pause je Eintrag = Pause von Hand plus Abzug der Pflichtpause, in der Reihenfolge der Liste)."""
    liste = [list(e) for e in liste]
    mit = sorted((e for e in liste if e[1] != OHNE_UHRZEIT), key=lambda e: e[1])
    if not mit:
        return liste, dict.fromkeys(KAPP_GRUENDE, 0), [0] * len(liste)
    regelzeit, grenze = kappzeit_regeln(d)
    kapp = _ausserhalb_kappen(mit, regelzeit)
    vorher = [e[4] for e in liste]
    _pflichtpause(mit, regelzeit, d)
    pausen = [e[3] + v - e[4] if e[1] != OHNE_UHRZEIT else 0 for e, v in zip(liste, vorher)]
    kapp["ueber"] = 0 if freigabe else _ueber_grenze_kappen(liste, mit, grenze)
    return liste, kapp, pausen


def tag_rechnen(liste: list, d: date, freigabe) -> tuple:
    """Die eine Tagesrechnung für Stempeluhr, Blatt, „+ Eintrag“ und Formular (Zählregel Pause und Kappzeit in CLAUDE.md).
    Eingabe: Einträge [Ort, Kommen, Gehen, Pause von Hand, Minuten] (Minuten ab Mitternacht; ohne Uhrzeit Kommen = Gehen = OHNE_UHRZEIT, dann
    zählen die Minuten netto ohne Abzug), der Tag d und die Genehmigung über der Tagesgrenze. Reihenfolge: Kappzeit außerhalb der Regelarbeitszeit,
    Pflichtpause, Kappzeit über der Tagesgrenze ohne Genehmigung. Rückgabe: (Kopie der Liste mit den Minuten netto je Eintrag, {"vor", "nach", "ueber"}).
    Keine Fehler; gültige Einträge prüft der Aufrufer."""
    return _rechnen(liste, d, freigabe)[:2]


def pausen_je_eintrag(liste: list, d: date, freigabe) -> list:
    """Pause je Eintrag für die Anzeige (Pause von Hand plus der Teil der Pflichtpause, den die Tagesrechnung dort abzieht), Reihenfolge der Liste."""
    return _rechnen(liste, d, freigabe)[2]


@dataclass
class Tag:
    """Ein Tageseintrag: HO- und Büro-Zeit in Minuten, Art (z. B. Urlaub), Anmerkung und optional Kommen, Gehen und Pause."""
    datum: date
    ho: int = 0
    dst: int = 0
    art: str = ""
    notiz: str = ""
    konto: int = 0      # Herkunftsjahr des angesparten Urlaubs (nur bei art == "angespart")
    attest: str = ""    # Datum (JJJJ-MM-TT), an dem das Attest abgegeben wurde (nur Krankheit)
    freigabe: int = 0   # 1 = Arbeitszeit über 10 Stunden an diesem Tag ist freigegeben
    kommen: int = -1    # Minuten ab Mitternacht, -1 = ohne Uhrzeit (ho und dst bleiben immer die reine Arbeitszeit)
    gehen: int = -1     # Minuten ab Mitternacht des Tages, nach Mitternacht über 1440
    pause: int = 0      # Minuten Pause zwischen Kommen und Gehen (auch die von der 6-Stunden-Regel gesetzte)
    vermerk: str = ""   # "" oder ein Schlüssel aus VERMERKE (nur ein Hinweis, zählt nicht anders)
    geprueft: int = 0   # 1 = Zeiten des Tages mit Vermerk sind geprüft


@dataclass
class Abschnitt:
    """Ein Zeitraum (von bis bis) mit eigenen Wochenstunden und Arbeitstagen, z. B. Teilzeit oder Elternzeit.
    Drei Wege (R4): nur Wochenstunden (arbeitstage leer: Tage der Regeln), Tage ohne Stunden, Stunden je Tag (tagesminuten)."""
    von: date
    bis: date
    wochenstunden: float = STANDARD_WOCHENSTUNDEN
    art: str = "normal"            # eine aus ABSCHNITT_ARTEN
    arbeitstage: str = STANDARD_TAGE
    id: int = 0
    tagesminuten: str = ""         # Stunden je Tag in Minuten, z. B. "Mo:480,Di:360" (Weg 3); "" = Weg 1 oder 2


def abschnitt_fuer(d: date, abschnitte):
    """Gültiger Abschnitt für den Tag (bei Überschneidung der mit dem spätesten Beginn), sonst None = Standardarbeitszeit (Einstellung, Voreinstellung 40 h Mo–Fr)."""
    treffer = [a for a in abschnitte if a.von <= d <= a.bis]
    return max(treffer, key=lambda a: a.von) if treffer else None


@lru_cache(maxsize=256)
def _minuten_je_tag(text: str) -> dict:
    """Stunden je Tag eines Abschnitts als {Wochentag: Minuten}, je Text nur einmal gelesen (jeder Soll-Tag fragt danach). Ergebnis nicht verändern."""
    return tagesminuten_lesen(text)


def _regeltage(d: date) -> list:
    """Die Arbeitstage der Regeln, die am Tag d gelten (z. B. ["Mo", "Di", "Mi", "Do", "Fr"])."""
    return konfig.fuer(d)["arbeitstage"].split(",")


def _gewaehlte_tage(a) -> list:
    """Die gewählten Arbeitstage des Abschnitts (Spalte arbeitstage), leer bei Weg 1."""
    return [t for t in a.arbeitstage.split(",") if t]


def weg(a) -> int:
    """Welcher der drei Wege (R4) für den Abschnitt gilt. Eingabe: Abschnitt. Rückgabe: WEG_JE_TAG mit Stunden je Tag,
    WEG_WOCHENSTUNDEN ohne gewählte Tage bei Wochenstunden über 0, sonst WEG_TAGE (auch 0 h ohne Tage, z. B. Elternzeit).
    Fehler: ValueError nur bei einem ungültigen tagesminuten."""
    if _minuten_je_tag(a.tagesminuten):
        return WEG_JE_TAG
    return WEG_WOCHENSTUNDEN if not _gewaehlte_tage(a) and a.wochenstunden > 0 else WEG_TAGE


def minuten_je_tag(a) -> dict:
    """Stunden je Tag des Abschnitts als {Wochentag: Minuten} wie gespeichert (Weg 3), sonst {}. Eingabe: Abschnitt.
    Rückgabe: eine Kopie, die der Aufrufer ändern darf. Fehler: ValueError nur bei einem ungültigen tagesminuten."""
    return dict(_minuten_je_tag(a.tagesminuten))


def arbeitstage_am(d: date, a) -> list:
    """Zählregel Teilzeit (R4): die Arbeitstage des Abschnitts a am Tag d.
    Eingaben: Tag, Abschnitt. Rückgabe: Weg 3 (Stunden je Tag) die Tage mit mehr als 0 Minuten (0 kommt nur über Synchronisierung oder Sicherung);
    Weg 1 (keine Tage, Wochenstunden über 0) die Arbeitstage der Regeln, die am Tag d gelten; sonst (Weg 2) die gewählten Tage.
    Fehler: ValueError nur bei einem ungültigen tagesminuten (Datenbank und Synchronisierung prüfen es vorher)."""
    w = weg(a)
    if w == WEG_JE_TAG:
        return [t for t, m in _minuten_je_tag(a.tagesminuten).items() if m > 0]
    return _regeltage(d) if w == WEG_WOCHENSTUNDEN else _gewaehlte_tage(a)


def wochensoll_min(a) -> int:
    """Sollzeit je Woche eines Abschnitts in Minuten (R4). Eingabe: Abschnitt. Rückgabe: Weg 3 die Summe der Stunden je Tag,
    Weg 1 und 2 round(Wochenstunden × 60). Fehler: ValueError nur bei einem ungültigen tagesminuten."""
    minuten = _minuten_je_tag(a.tagesminuten)
    return sum(minuten.values()) if minuten else int(round(a.wochenstunden * 60))


def ist_soll_tag(d: date, eigene, abschnitte) -> bool:
    """True, wenn am Tag gearbeitet werden soll: nicht frei (Wochenende, Feiertag, eigener freier Tag), Wochenstunden über 0
    und der Wochentag gehört zu den Arbeitstagen des gültigen Abschnitts (arbeitstage_am; ohne Abschnitt: zu den Arbeitstagen der Regeln).
    Fehler: ValueError nur bei einem ungültigen tagesminuten (wie arbeitstage_am)."""
    return not ist_frei(d, eigene) and ist_planmaessiger_arbeitstag(d, abschnitte)


def ist_planmaessiger_arbeitstag(d: date, abschnitte) -> bool:
    """True, wenn der Wochentag laut gültigem Abschnitt (ohne Abschnitt: laut Regeln) ein Arbeitstag mit Wochenstunden über 0 ist,
    ohne Rücksicht auf Feiertage und freie Tage. Fehler: ValueError nur bei einem ungültigen tagesminuten (wie arbeitstage_am)."""
    a = abschnitt_fuer(d, abschnitte)
    if a is None:
        return konfig.fuer(d)["wochenstunden"] > 0 and WT[d.weekday()] in _regeltage(d)
    return a.wochenstunden > 0 and WT[d.weekday()] in arbeitstage_am(d, a)


def arbeitstage_je_woche(d: date, abschnitte) -> int:
    """n(d) der Prognose (R7): Zahl der Arbeitstage je Woche, die am Tag d gilt, laut gültigem Abschnitt (arbeitstage_am, alle drei Wege),
    ohne Abschnitt laut Regeln (Voreinstellung Mo–Fr: 5). Eingaben: Tag, Abschnitte. Rückgabe: 0 bis 7 (0 bei einem Abschnitt mit 0 h
    ohne Arbeitstage). Fehler: ValueError nur bei einem ungültigen tagesminuten (wie arbeitstage_am)."""
    a = abschnitt_fuer(d, abschnitte)
    return len(arbeitstage_am(d, a)) if a else len(_regeltage(d))


def tagessoll_min(d: date, abschnitte) -> int:
    """Zählregel Tagessoll (R4) in Minuten. Eingaben: Tag, Abschnitte. Rückgabe: Weg 3 (Stunden je Tag) die Minuten dieses Wochentags
    (0, wenn er fehlt); sonst das Wochensoll (Abschnitt oder Regeln) in ganzen Minuten verteilt (_verteilt_min), 0 ohne Arbeitstage.
    Am Faschingsdienstag höchstens die Stunden aus der Einstellung fasching_std. Ob der Tag ein Soll-Tag ist, sagt ist_soll_tag.
    Fehler: ValueError nur bei einem ungültigen tagesminuten (wie arbeitstage_am)."""
    a = abschnitt_fuer(d, abschnitte)
    minuten = _minuten_je_tag(a.tagesminuten) if a else {}
    soll = minuten.get(WT[d.weekday()], 0) if minuten else _verteilt_min(d, a)
    return min(soll, int(round(konfig.fuer(d)["fasching_std"] * 60))) if ist_faschingsdienstag(d) else soll


def _verteilt_min(d: date, a) -> int:
    """Weg 1 und 2: das Wochensoll in ganzen Minuten auf die Arbeitstage verteilt, damit ihre Summe genau das Wochensoll ist.
    Die Rest-Minuten (Wochensoll mod Zahl der Arbeitstage) bekommen die ersten Arbeitstage der Woche (Mo zuerst), je eine; ein Wochentag
    außerhalb der Arbeitstage bekommt den Grundwert. Eingaben: Tag, Abschnitt oder None (Regeln). Rückgabe: Minuten, 0 ohne Arbeitstage. Keine Fehler."""
    tage = sorted(arbeitstage_am(d, a) if a else _regeltage(d), key=WT.index)
    if not tage:
        return 0
    stunden = a.wochenstunden if a else konfig.fuer(d)["wochenstunden"]
    basis, rest = divmod(int(round(stunden * 60)), len(tage))
    return basis + (WT[d.weekday()] in tage[:rest])


def ist_werktag(d: date, eigene) -> bool:
    """Zählregel Werktag für Urlaub, Gleittag, Familientag und Elternzeit: Mo–Fr und nicht frei (Feiertag, 24./31.12. laut Regeln,
    eigener freier Tag), unabhängig von Teilzeit-Arbeitstagen. Eingaben: Tag, eigene freie Tage. Rückgabe: True oder False. Keine Fehler."""
    return d.weekday() < 5 and not ist_frei(d, eigene)


GANZE_TAGE = (SONDERURLAUB, KIND_KRANK)
WERKTAG_ARTEN = ("urlaub", "angespart", "gleittag", "familientag")   # summe zählt sie nach der Zählregel Werktag, also nur dort eintragbar
NUR_ARBEITSTAGE = "{name} nur an Arbeitstagen"
NUR_WERKTAGE = "{name} nur an Werktagen (nicht am Wochenende, an Feiertagen oder freien Tagen)"
OHNE_ARBEITSZEIT = "{name} ist ein ganzer Tag ohne Arbeitszeit"
LIMIT_TEXT = "Höchstens {grenze} {name} pro Jahr ({jahr}: schon {bisher} eingetragen)"
LIMIT_NAMEN = {"gleittag": "Gleittage", "familientag": "Familientage", KIND_KRANK: "Tage „Kind krank“"}


def ganzen_tag_pruefen(d: date, art: str, minuten: int, eigene, abschnitte, arten: dict, startwerte=None) -> None:
    """Eingabeprüfung ganzer Tage. Urlaub, angesparter Urlaub, Gleittag und Familientag nur an Werktagen (ist_werktag, so zählt sie summe);
    Sonderurlaub und Kind krank (R5) nur an Arbeitstagen laut Abschnitt und ohne Minuten; andere Arten lässt sie durch. Die Jahreslimits für
    Gleittag, Familientag und Kind krank zählen dieselben Tage wie summe (limit_bisher). Ob Familientage im Jahr an sind, prüft der Aufrufer.
    Eingaben: Tag d, Art, Minuten des Tages (HO + Büro), eigene freie Tage, Abschnitte, arten {Datum: Art} der Tage im Jahr von d
    (beim Sammel-Import mit den Tagen davor im selben Zug), startwerte (konfig.Startwerte oder None). Rückgabe: None.
    Fehler: konfig.Meldung, wenn d kein Werktag bzw. Arbeitstag ist, ein Tag nach R5 Minuten hat oder das Jahreslimit erreicht ist."""
    if art in WERKTAG_ARTEN and not ist_werktag(d, eigene):
        raise konfig.Meldung(NUR_WERKTAGE.format(name=ARTEN[art]))
    if art in GANZE_TAGE:
        if not ist_soll_tag(d, eigene, abschnitte):
            raise konfig.Meldung(NUR_ARBEITSTAGE.format(name=ARTEN[art]))
        if minuten:
            raise konfig.Meldung(OHNE_ARBEITSZEIT.format(name=ARTEN[art]))
    if art in LIMIT_NAMEN:
        grenze = {"gleittag": gleittage_max, "familientag": familientage_max, KIND_KRANK: kind_krank_max}[art](d.year)
        bisher = limit_bisher(d, art, arten, eigene, abschnitte, startwerte)
        if bisher >= grenze:
            raise konfig.Meldung(LIMIT_TEXT.format(grenze=grenze, name=LIMIT_NAMEN[art], jahr=d.year, bisher=bisher))


def limit_bisher(d: date, art: str, arten: dict, eigene, abschnitte, startwerte=None) -> int:
    """Zählregel Jahreslimit: bisher_im_jahr mit denselben Tagen wie der Zähler in summe, Kind krank nur an Arbeitstagen laut Abschnitt
    (ist_soll_tag), Gleittag und Familientag nur an Werktagen (ist_werktag; ein später frei gewordener Tag zählt nicht mehr).
    Eingaben: wie bisher_im_jahr, dazu eigene freie Tage und Abschnitte. Rückgabe: Anzahl der Tage. Keine Fehler."""
    if art == KIND_KRANK:
        return bisher_im_jahr(d, art, arten, startwerte, lambda k: ist_soll_tag(k, eigene, abschnitte))
    return bisher_im_jahr(d, art, arten, startwerte, lambda k: ist_werktag(k, eigene))


START_TAGE = {"gleittag": "gleittage", KIND_KRANK: "kind_krank"}      # Arten mit Jahreslimit und Startwert (R6); Familientage haben keinen


def bisher_im_jahr(d: date, art: str, arten: dict, startwerte=None, zaehlt=None) -> int:
    """Zählregel Jahreslimit mit Startwerten (R6) für Gleittage, Familientage und Kind krank: wie viele Tage der Art im Jahr von d schon eingetragen sind.
    Eingaben: Tag d, Art, arten {Datum: Art} der Tage (auch anderer Jahre), startwerte (konfig.Startwerte oder None), zaehlt (Funktion Datum → bool
    oder None: nur diese Einträge zählen, z. B. nur Arbeitstage bei Kind krank).
    Rückgabe: Einträge der Art im Jahr von d außer d selbst, ab „ab“ (Einträge davor zählen nicht), dazu im Jahr von „ab“ der Startwert
    der Art (Gleittage, Kind krank; Familientage haben keinen). Keine Fehler."""
    ab = startwerte.ab if startwerte else None
    n = sum(1 for k, a in arten.items() if a == art and k != d and k.year == d.year and (ab is None or k >= ab) and (zaehlt is None or zaehlt(k)))
    if startwerte and startwerte.gilt_im_jahr(d.year) and art in START_TAGE:
        n += getattr(startwerte, START_TAGE[art])
    return n


def ist_elternzeit_tag(d: date, eigene, abschnitte) -> bool:
    """Werktag (Mo–Fr, nicht frei) in einem Elternzeit-Abschnitt ohne Arbeit (0 h)."""
    a = abschnitt_fuer(d, abschnitte)
    return bool(a and a.art == "elternzeit" and a.wochenstunden == 0 and ist_werktag(d, eigene))


def zaehlt_als_krank(d: date, art: str, eigene, abschnitte) -> bool:
    """Zählregel Kranktag, gleich für Kennzahl, Krank-Seite, Liste und Zeiträume.
    Eingaben: Tag, Art des Eintrags (leer ohne Eintrag), eigene freie Tage, Abschnitte. Rückgabe: True bei Krank oder Krank mit Attest an einem
    Arbeitstag laut Abschnitt (ist_soll_tag): der freie Freitag bei Teilzeit Mo–Do, Wochenende, Feiertag und Elternzeit mit 0 h zählen nicht.
    „Krank im Dienst“ ist ein Arbeitstag und zählt nie. Keine Fehler."""
    return art in KRANK and ist_soll_tag(d, eigene, abschnitte)


def unterbricht_krank(d: date, eigene, abschnitte) -> bool:
    """Trenner zweier Krankphasen, gleich für Phasen der Krank-Seite, Zeiträume der Übersicht und das Attest einer Phase.
    Eingaben: Tag, eigene freie Tage, Abschnitte. Rückgabe: True an einem Arbeitstag laut Abschnitt (ist_soll_tag) und an einem Werktag
    in einem Abschnitt mit 0 h (Elternzeit): Der hat keinen Arbeitstag, soll Kranktage davor und danach aber trotzdem trennen. Keine Fehler."""
    if ist_soll_tag(d, eigene, abschnitte):
        return True
    a = abschnitt_fuer(d, abschnitte)
    return a is not None and a.wochenstunden == 0 and ist_werktag(d, eigene)


def zaehlt_als_elternzeit(d: date, art: str, eigene, abschnitte) -> bool:
    """Zählregel Elternzeit-Tag, gleich für Kennzahl und Zeiträume.
    Eingaben: Tag, Art des Eintrags (leer ohne Eintrag), eigene freie Tage, Abschnitte. Rückgabe: True an einem Werktag (Mo–Fr, nicht frei)
    mit Art „Elternzeit“ oder in einem Elternzeit-Abschnitt mit 0 h (dort gibt es keine Arbeitstage, daher Werktag statt ist_soll_tag). Keine Fehler."""
    return (art == ELTERNZEIT and ist_werktag(d, eigene)) or ist_elternzeit_tag(d, eigene, abschnitte)


def aufgefuellt_min(d: date, t, eigene, abschnitte, ab=None) -> int:
    """Zählregel „Krank im Dienst“ (R3): die fehlende Zeit bis zum Tagessoll dieses Tages, gutgeschrieben für Ist (Soll/Ist) und Gleitzeit,
    nicht für die Quote. Eingaben: Tag, Eintrag (oder None), eigene freie Tage, Abschnitte, ab = Beginn der Erfassung (None: ohne).
    Rückgabe: max(0, Tagessoll − HO − Büro) an einem Soll-Tag ab „ab“ mit Art „Krank im Dienst“, sonst 0. Keine Fehler."""
    if t is None or t.art != KRANK_IM_DIENST or (ab is not None and d < ab) or not ist_soll_tag(d, eigene, abschnitte):
        return 0
    return max(0, tagessoll_min(d, abschnitte) - t.ho - t.dst)


def ueber_grenze(ho_min: int, ist_min: int, grenze: int) -> bool:
    """Zählregel Quote rot (R1): genau auf der Grenze ist erlaubt, rot erst darüber, minutengenau ohne Rundung.
    Eingaben: HO-Minuten, Ist-Minuten (HO + Büro), Grenze in Prozent (100 = ohne Grenze). Rückgabe: True, wenn ho / ist > grenze %. Keine Fehler."""
    return ist_min > 0 and grenze < 100 and ho_min * 100 > grenze * ist_min


def an_grenze(ho_min: int, ist_min: int, grenze: int) -> bool:
    """Quote genau auf der Grenze (der Text „80,00 %“ entsteht auch bei 79,996 %, daher eigenes Kennzeichen).
    Eingaben wie ueber_grenze. Rückgabe: True nur bei ho / ist == grenze %. Keine Fehler."""
    return ist_min > 0 and grenze < 100 and ho_min * 100 == grenze * ist_min


def tage_im_zeitraum(von: date, bis: date):
    """Jeden Tag von „von“ bis einschließlich „bis“ nacheinander liefern."""
    d = von
    while d <= bis:
        yield d
        d += timedelta(days=1)


def zeitraeume_bilden(tage, unterbricht) -> list:
    """Fasst sortierte Tage zu Zeiträumen zusammen. Zwei Tage gehören zusammen, wenn kein Tag dazwischen `unterbricht`
    (z. B. unterbricht_krank); Wochenenden, Feiertage und freie Tage dazwischen trennen also nicht.
    Eingaben: sortierte Tage, Prädikat unterbricht(Tag) -> bool. Rückgabe: Liste von Listen (Zeiträume in Reihenfolge). Keine Fehler."""
    gruppen = []
    for d in tage:
        if gruppen and not any(unterbricht(x) for x in tage_im_zeitraum(gruppen[-1][-1] + timedelta(days=1), d - timedelta(days=1))):
            gruppen[-1].append(d)
        else:
            gruppen.append([d])
    return gruppen


def summe(tage, eigene, abschnitte, von: date, bis: date, stichtag=None, ab=None, start=None) -> dict:
    """Auswertung für einen Zeitraum. 'tage' sind die eingetragenen Tage (beliebig viele, werden gefiltert).
    stichtag: ab diesem Tag zählen Soll-Tage ohne Zeiteintrag und ohne „Krank im Dienst“ als noch geplante Arbeitszeit (Standard: heute).
    ist_min (HO + Büro) ist die Basis der Quote; ist_soll_min = ist_min + aufgefuellt_min ist das Ist neben dem Soll (R3).
    sonderurlaub und kind_krank zählen nur an Arbeitstagen laut Abschnitt (R5), Urlaub und Gleittage nach der Zählregel Werktag.
    ab (R6, „Erfassung gültig ab“): Einträge und Kalendertage vor ab zählen nicht (kein Soll, keine Tage). start (Startwerte, nur für Jahressummen
    im Jahr von ab): Start-HO und Start-Büro kommen zu ho_min und dst_min (also in Quote und Ist), Start-Urlaub, -Gleittage, -Kranktage und
    -Kind krank zu den Zählern; HO- und Büro-Tage zählen nur erfasste Tage. Im Ergebnis zusätzlich krank_start und start (Wörterbuch oder None)."""
    stichtag = stichtag or date.today()
    if ab is not None:
        von = max(von, ab)
    im = {t.datum: t for t in tage if von <= t.datum <= bis}
    r = dict(ho_min=0, dst_min=0, ho_tage=0, dst_tage=0, urlaub=0, angespart=0, gleittage=0, krank=0, krank_attest=0,
             krank_dienst=0, familientage=0, sonderurlaub=0, kind_krank=0, elternzeit_tage=0, soll_tage=0, soll_min=0, geplant_min=0, aufgefuellt_min=0, elternzeit_liste=[])
    for t in im.values():
        r["ho_min"] += t.ho
        r["dst_min"] += t.dst
        if t.dst > 0:
            r["dst_tage"] += 1
        elif t.ho > 0:
            r["ho_tage"] += 1
        if t.art == KRANK_IM_DIENST:
            r["krank_dienst"] += 1
    for d in tage_im_zeitraum(von, bis):
        t = im.get(d)
        art = t.art if t else ""
        if ist_werktag(d, eigene):
            if art == "urlaub":
                r["urlaub"] += 1
            elif art == "angespart":
                r["angespart"] += 1
            elif art == "gleittag":
                r["gleittage"] += 1
            elif art == "familientag":
                r["familientage"] += 1
        if zaehlt_als_krank(d, art, eigene, abschnitte):
            r["krank"] += 1
            r["krank_attest"] += art == KRANK_ATTEST
        if ist_soll_tag(d, eigene, abschnitte):
            r["soll_tage"] += 1
            r["sonderurlaub"] += art == SONDERURLAUB                  # nur an Arbeitstagen laut Abschnitt (R5)
            r["kind_krank"] += art == KIND_KRANK
            if art not in ABWESEND:
                r["soll_min"] += tagessoll_min(d, abschnitte)
                if d >= stichtag and not (t and (t.ho or t.dst or art == KRANK_IM_DIENST)):
                    r["geplant_min"] += tagessoll_min(d, abschnitte)     # noch nicht gearbeitet, aber Soll
        r["aufgefuellt_min"] += aufgefuellt_min(d, t, eigene, abschnitte)
        if zaehlt_als_elternzeit(d, art, eigene, abschnitte):
            r["elternzeit_tage"] += 1
            r["elternzeit_liste"].append(d)
    _start_dazu(r, start)
    ist = r["ho_min"] + r["dst_min"]
    r["ist_min"] = ist
    r["quote"] = r["ho_min"] / ist if ist > 0 else None
    gr = ho_grenze(min(bis, date.today()))
    r["ist_soll_min"] = ist + r["aufgefuellt_min"]
    r["quote_rot"] = ueber_grenze(r["ho_min"], ist, gr)
    r["an_grenze"] = an_grenze(r["ho_min"], ist, gr)
    r["plan_min"] = ist + r["geplant_min"]            # bisher gearbeitet plus noch geplantes Soll
    r["grenze_min"] = grenze_min(r["plan_min"], gr)
    r["ho_rest"] = ho_rest(r["plan_min"], r["ho_min"], gr)
    r["ueberschritten"] = ueberschritten(r["plan_min"], r["ho_min"], gr)
    return r


START_FELDER = ("ho_min", "dst_min", "urlaub", "gleittage", "krank", "kind_krank")   # Startwerte, die in Jahressummen zu den gleichnamigen Feldern zählen


def _start_dazu(r: dict, start) -> None:
    """Startwerte (R6) zu den Summen einer Jahressumme zählen und als start (Wörterbuch, ab als Text) und krank_start vermerken; ohne start nur die Felder."""
    for feld in START_FELDER:
        r[feld] += getattr(start, feld) if start else 0
    r["krank_start"] = start.krank if start else 0
    r["start"] = start.werte() if start else None


def grenze_min(plan_min: int, grenze=None) -> int:
    """HO-Grenze in Minuten: der Anteil (Prozent) der geplanten Gesamtzeit, ganzzahlig; ohne Angabe gilt die heutige Grenze."""
    return plan_min * (grenze or ho_grenze()) // 100


def ho_rest(plan_min: int, ho_min: int, grenze=None) -> int:
    """Wie viel HO-Zeit bis 80 % der Gesamtzeit (bisher gearbeitet plus noch geplantes Soll) noch möglich ist."""
    return max(0, grenze_min(plan_min, grenze) - ho_min)


def ueberschritten(plan_min: int, ho_min: int, grenze=None) -> int:
    """Minuten HO-Zeit über der Grenze; 0, wenn die Grenze nicht überschritten ist."""
    return max(0, ho_min - grenze_min(plan_min, grenze))


AMPEL_GRUEN, AMPEL_GELB, AMPEL_ROT = "gruen", "gelb", "rot"   # Stufen der Quote-Ampel (quote_ampel)


def buero_noetig(ho_min: int, ist_min: int, geplant_min: int, grenze: int) -> int:
    """Zählregel Quote-Ampel: Büro-Minuten, die von der noch geplanten Zeit kommen müssen, damit die Quote am Ende des Zeitraums
    (HO / (Ist + geplant), R1 minutengenau, genau auf der Grenze erlaubt) nicht über der Grenze liegt. Der Rest der geplanten Zeit gilt als HO.
    Eingaben: HO- und Ist-Minuten (HO + Büro) bisher, geplante Minuten (summe: geplant_min), Grenze in Prozent. Rückgabe: 0 bis geplant_min
    (mehr als die geplante Zeit geht nicht; reicht auch die nicht, sagt es quote_ampel). Keine Fehler."""
    return min(geplant_min, max(0, ho_min + geplant_min - grenze_min(ist_min + geplant_min, grenze)))


def quote_ampel(ho_min: int, ist_min: int, geplant_min: int, grenze: int) -> str:
    """Stufe der Quote-Ampel mit denselben Eingaben wie buero_noetig (Entscheidung des Entwicklers vom 25.11.2026): AMPEL_ROT, wenn die Quote
    am Ende auch mit Büro in der ganzen geplanten Zeit über der Grenze liegt (nicht mehr zu halten); AMPEL_GELB, wenn Büro-Zeit nötig ist
    (buero_noetig > 0) und sie noch reicht; sonst AMPEL_GRUEN (im Rahmen: keine Büro-Zeit nötig). Keine Fehler."""
    if ueber_grenze(ho_min, ist_min + geplant_min, grenze):
        return AMPEL_ROT
    return AMPEL_GELB if buero_noetig(ho_min, ist_min, geplant_min, grenze) else AMPEL_GRUEN
