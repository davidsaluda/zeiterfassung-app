# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Paket kern (Teamplan B6): Module der Schicht kern; Importe als `from kern import <modul>`."""
