# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Wochenansicht und Gleitzeit-Konto (Ist minus Soll, laufend aufsummiert).
Soll zählt an Arbeitstagen (laut Abschnitt) außer bei Urlaub, angespartem Urlaub, Krank, Sonderurlaub, Kind krank und Elternzeit; ein Gleittag bleibt Soll-Tag und bucht das Tagessoll vom Konto ab.
„Krank im Dienst“ füllt die fehlende Zeit bis zum Tagessoll auf (regeln.aufgefuellt_min), damit kein Minus entsteht.
Tage ohne Eintrag zählen mit ihrem Soll (fehlende Zeit). Arbeit an Wochenenden und freien Tagen (Feiertage, eigene freie Tage) zählt NICHT zur Gleitzeit,
sondern zum Freizeitkonto; dieses wird mit der Art „Freizeitausgleich“ (Tagessoll) abgebaut. Ein Startsaldo (Korrektur) synchronisiert Altwerte je Konto.
Beide Konten beginnen an „Erfassung gültig ab“ (R6, Startwerte), sonst am ersten Eintrag; Tage davor zählen nicht.
Kappung (23.11.2026): Mit Ablauf jedes Stichtags verfällt das Plus über Grenze plus genehmigter Übernahme. Nur das Gleitzeit-Konto, nie das
Freizeitkonto: das ist eine eigene Summe (freizeit_tag) und wird nirgends mit der Gleitzeit verrechnet."""
import calendar
import threading
from kern.feiertage import ist_frei
from datetime import date, timedelta

from daten import konfig
from kern import regeln
from kern.zeit import fmt_dauer, fmt_hhmm
from daten.db import ALLES, KONTEN

_SCHLOSS = threading.Lock()

ENTFALLEN = tuple(a for a in regeln.ABWESEND if a != "gleittag")      # kein Soll an diesen Tagen; der Gleittag kostet sein Soll


def soll_tag(d: date, t, eigene, abschnitte) -> int:
    """Sollzeit des Tages in Minuten für das Gleitzeit-Konto: 0 bei den Arten in ENTFALLEN (Urlaub, Krank, Familientag, Freizeitausgleich, Sonderurlaub, Kind krank, Elternzeit)
    und an Tagen ohne Soll; ein Gleittag behält das Soll."""
    if t is not None and t.art in ENTFALLEN:
        return 0
    if not regeln.ist_soll_tag(d, eigene, abschnitte):
        return 0
    return regeln.tagessoll_min(d, abschnitte)


def saldo_tag(d: date, t, eigene, abschnitte) -> int:
    """Gleitzeit-Saldo des Tages: Ist (mit Auffüllung bei „Krank im Dienst“) minus Soll. Zeit an freien Tagen (Wochenende, Feiertag) gehört zum Freizeitkonto."""
    ist = 0 if ist_frei(d, eigene) else ((t.ho + t.dst) if t else 0) + regeln.aufgefuellt_min(d, t, eigene, abschnitte)
    return ist - soll_tag(d, t, eigene, abschnitte)


def freizeit_tag(d: date, t, eigene, abschnitte) -> int:
    """Veränderung des Freizeitkontos an diesem Tag: Arbeitszeit an freien Tagen plus, Freizeitausgleich = Tagessoll minus."""
    if t is None:
        return 0
    if ist_frei(d, eigene):
        return t.ho + t.dst
    if t.art == "freizeit":
        return -regeln.tagessoll_min(d, abschnitte)
    return 0


def _beginn(db, alle, ohne_ab: bool = False):
    """Erster Tag der Konten: „ab“ der Startwerte (R6), sonst (oder mit ohne_ab) der erste Eintrag aus alle; None ohne beides."""
    sw = None if ohne_ab else db.startwerte_lesen()
    return sw.ab if sw else (alle[0].datum if alle else None)


def _summe(db, bis: date, fn, ohne_ab: bool = False) -> int:
    """Summe der Tageswerte vom Beginn der Konten (_beginn) bis „bis“, 0 davor. Die laufende Summe je Tag wird gemerkt, solange sich Daten und Regeln
    nicht ändern (eine Wochenansicht fragt das Konto mehrfach ab; ohne Merken wird jedes Mal ab dem ersten Jahr neu gerechnet).
    ohne_ab: so, als gäbe es keine Startwerte (für das Löschen von „ab“), mit eigenem Merker."""
    regelstand = (konfig.regelstand_nr(), date.today())
    with db.lock, _SCHLOSS:                                 # erst die Datenbank, dann der Merker: dieselbe Reihenfolge wie Schreiber unter db.lock
        memo = db.__dict__.setdefault("_summen", {})
        schluessel = (fn.__name__, ohne_ab)
        m = memo.get(schluessel)
        if m is None or m["gen"] != db.gen or m["regelstand"] != regelstand:
            gen = db.gen                                     # vor dem Lesen festhalten: Wird währenddessen gespeichert, gilt der Merker als veraltet
            alle = db.tage_alle()
            start = _beginn(db, alle, ohne_ab)
            seit = db.geaendert_seit(m["gen"]) if m and m["regelstand"] == regelstand else ALLES
            # Die Summe bis zum Tag vor der Änderung bleibt gültig, wenn der Beginn derselbe ist; sonst alles neu.
            kum = m["kum"][:max(0, (seit - start).days)] if m and start and start == m["start"] and seit > start else []
            m = {"gen": gen, "regelstand": regelstand, "nach": {t.datum: t for t in alle}, "start": start, "kum": kum, "eigene": {}, "abschnitte": db.abschnitte()}
            memo[schluessel] = m
        if m["start"] is None or bis < m["start"]:
            return 0
        n, kum = (bis - m["start"]).days + 1, m["kum"]
        while len(kum) < n:
            d = m["start"] + timedelta(days=len(kum))
            if d.year not in m["eigene"]:
                m["eigene"][d.year] = db.eigene_frei_tage(d.year)
            kum.append((kum[-1] if kum else 0) + fn(d, m["nach"].get(d), m["eigene"][d.year], m["abschnitte"]))
        return kum[n - 1]


def startsaldo(db) -> int:
    """Startsaldo des Gleitzeit-Kontos in Minuten: mit Startwerten deren Gleitzeit-Saldo (Stand am Ende von ab − 1), sonst der Korrekturwert (Vorgabe 0)."""
    return db.startkonto("gleitzeit")


def konto(db, bis: date) -> int:
    """Gleitzeit-Konto in Minuten am Ende des Tages „bis“: Startsaldo plus alle Tagessalden (Ist minus Soll) ab dem Beginn, abzüglich der
    Minuten, die an Stichtagen bis einschließlich „bis“ verfallen sind (kappungen); davor der Startsaldo."""
    return _konto(db, bis, startsaldo(db))


def _konto(db, bis: date, start: int, ohne_ab: bool = False) -> int:
    """Konto am Ende von „bis“ mit dem Startsaldo „start“ (für konto und die Suche in _start_fuer)."""
    return start + _summe(db, bis, saldo_tag, ohne_ab) - sum(k["verfallen_min"] for k in _kappungen(db, bis, start, ohne_ab))


KAPPUNG_TEXT = "gekappt am {datum:%d.%m.}: {verfallen} Std. verfallen"
KAPPUNG_STAND_FEHLER = "Nach der Kappung am {datum:%d.%m.%Y} geht höchstens {stand} (Grenze, genehmigte Übernahme und Saldo seitdem)"
SUCHE_MAX = 10 ** 6                                        # Minuten: so weit sucht _start_fuer über die lineare Schätzung hinaus


def stichtag_im_jahr(jahr: int, monatstag: str) -> date:
    """Stichtag „MM-TT“ im Jahr; der 29.02. ist außerhalb von Schaltjahren der 28.02. (letzter Tag des Februars)."""
    monat, tag = int(monatstag[:2]), int(monatstag[3:])
    return date(jahr, monat, min(tag, calendar.monthrange(jahr, monat)[1]))


def kappungstage(von: date, bis: date) -> list:
    """Zählregel Kappung: die Stichtage von „von“ bis „bis“, an denen gekappt wird. Ein Tag zählt, wenn die Regeln genau dieses Tages
    (konfig.fuer, also zeitabhängig wie jede Regel) ihn als Stichtag nennen, die Kappung an ist (konfig.kappung_an) und sein Jahr nicht vor
    kappung_ab_jahr liegt. Rückgabe: sortierte Liste. Keine Fehler."""
    stichtage = {v["werte"]["kappung_stichtag"] for v in konfig.VERSIONEN}
    r = set()
    for jahr in range(von.year, bis.year + 1):
        for monatstag in stichtage:
            d = stichtag_im_jahr(jahr, monatstag)
            w = konfig.fuer(d)
            if von <= d <= bis and w["kappung_stichtag"] == monatstag and konfig.kappung_an(w) and jahr >= w["kappung_ab_jahr"]:
                r.add(d)
    return sorted(r)


def _kappungen(db, bis: date, start: int, ohne_ab: bool = False) -> list:
    """Die Kappungen vom Beginn des Kontos bis „bis“ der Reihe nach: Stand am Ende des Stichtags (mit früheren Kappungen), Grenze, Übernahme,
    verfallen = max(0, Stand − Grenze − Übernahme). Ein Minus und ein Plus bis zur Grenze bleiben (verfallen 0)."""
    beginn = _beginn(db, db.tage_alle(), ohne_ab)
    if beginn is None or bis < beginn:
        return []
    r, weg = [], 0
    for d in kappungstage(beginn, bis):
        stand = start + _summe(db, d, saldo_tag, ohne_ab) - weg
        grenze, dazu = konfig.fuer(d)["kappung_grenze_min"], db.kappung_uebernahme(d.year)
        verfallen = max(0, stand - grenze - dazu)
        weg += verfallen
        r.append({"datum": d, "stand_min": stand, "verfallen_min": verfallen, "grenze_min": grenze, "uebernahme_min": dazu})
    return r


def kappungen(db, bis: date) -> list:
    """Kappungen des Gleitzeit-Kontos bis einschließlich „bis“: [{datum, stand_min (vor der Kappung), verfallen_min, grenze_min, uebernahme_min}]."""
    return _kappungen(db, bis, startsaldo(db))


def kappung_text(k: dict, zeitformat: str = "hhmm") -> str:
    """„gekappt am 30.09.: 07:30 Std. verfallen“ zu einer Kappung."""
    return KAPPUNG_TEXT.format(datum=k["datum"], verfallen=fmt_dauer(k["verfallen_min"], zeitformat))


def _start_fuer(db, ziel: int, datum: date, ohne_ab: bool = False) -> int:
    """Startsaldo, mit dem das Konto am Ende von „datum“ genau „ziel“ zeigt. Ohne Kappung linear (ziel − Tagessalden); mit Kappung steigt das
    Konto mit dem Startsaldo um 0 oder 1 je Minute, deshalb der kleinste passende Wert per Halbierung ab der linearen Schätzung.
    Fehler: konfig.KonfigFehler, wenn eine Kappung den Stand nach oben begrenzt."""
    lo = ziel - _summe(db, datum, saldo_tag, ohne_ab)                  # verfallen ist nie negativ: hier ist das Konto höchstens ziel
    if _konto(db, datum, lo, ohne_ab) == ziel:
        return lo
    hi = lo + SUCHE_MAX
    if _konto(db, datum, hi, ohne_ab) < ziel:
        letzte = _kappungen(db, datum, hi, ohne_ab)[-1]["datum"]
        raise konfig.KonfigFehler(KAPPUNG_STAND_FEHLER.format(datum=letzte, stand=fmt_saldo(_konto(db, datum, hi, ohne_ab))))
    while hi - lo > 1:
        mitte = (lo + hi) // 2
        lo, hi = (mitte, hi) if _konto(db, datum, mitte, ohne_ab) < ziel else (lo, mitte)
    return hi


VOR_BEGINN_FEHLER = "Datum vor Beginn der Erfassung ({:%d.%m.%Y})"


def _nicht_vor_beginn(db, datum: date) -> None:
    """Ein Stand lässt sich nur ab „Erfassung gültig ab“ setzen (davor gibt es kein Konto). Fehler: konfig.KonfigFehler mit dem Datum von ab."""
    sw = db.startwerte_lesen()
    if sw and datum < sw.ab:
        raise konfig.KonfigFehler(VOR_BEGINN_FEHLER.format(sw.ab))


def stand_setzen(db, stand_min: int, datum: date):
    """Das Konto soll am Ende von „datum“ genau „stand_min“ zeigen: Startsaldo entsprechend einstellen (mit Startwerten in deren Gleitzeit-Saldo).
    Fehler: konfig.KonfigFehler bei einem Datum vor ab oder einem Startsaldo über ±999:59 (nur mit Startwerten)."""
    _nicht_vor_beginn(db, datum)
    db.startkonto_setzen("gleitzeit", _start_fuer(db, stand_min, datum))


def freizeit_start(db) -> int:
    """Startsaldo des Freizeitkontos in Minuten: mit Startwerten deren eingefrorener Stand, sonst der Korrekturwert (Vorgabe 0)."""
    return db.startkonto("freizeit")


def freizeit_konto(db, bis: date) -> int:
    """Freizeitkonto in Minuten am Ende des Tages „bis“: Startsaldo plus Arbeit an freien Tagen minus Freizeitausgleich ab dem Beginn."""
    return freizeit_start(db) + _summe(db, bis, freizeit_tag)


def freizeit_stand_setzen(db, stand_min: int, datum: date):
    """Das Freizeitkonto soll am Ende von „datum“ genau „stand_min“ zeigen: Startsaldo entsprechend einstellen. Fehler wie stand_setzen."""
    _nicht_vor_beginn(db, datum)
    db.startkonto_setzen("freizeit", stand_min - _summe(db, datum, freizeit_tag))


def konten_ohne_startwerte(db, heute: date) -> dict:
    """Startstände beider Konten für das Löschen von „ab“ (R6, keine stillen Sprünge): so gewählt, dass Gleitzeit- und Freizeitkonto am Ende von heute
    ohne Startwerte denselben Stand zeigen wie jetzt mit. Rückgabe {gleitzeit_start_min, freizeit_start_min} für Db.startwerte_setzen(None, konten=…)."""
    return {KONTEN["gleitzeit"][1]: _start_fuer(db, konto(db, heute), heute, ohne_ab=True),
            KONTEN["freizeit"][1]: freizeit_konto(db, heute) - _summe(db, heute, freizeit_tag, ohne_ab=True)}


def _zwischen(db, von: date, bis: date, fn) -> int:
    """Summe der Tageswerte von „von“ bis „bis“ ohne Rücksicht auf den Beginn der Konten und ohne Merker (selten: nur beim Vorverlegen von „ab“);
    0, wenn „von“ nach „bis“ liegt."""
    nach = {t.datum: t for t in db.tage_alle()}
    abschnitte = db.abschnitte()
    return sum(fn(d, nach.get(d), db.eigene_frei_tage(d.year), abschnitte) for d in regeln.tage_im_zeitraum(von, bis))


def konten_am_vortag(db, ab: date) -> dict:
    """Zählregel Vorbelegung der Startwerte (R6, keine stillen Sprünge): Stand beider Konten am Ende von ab − 1 mit den jetzt geltenden Einstellungen.
    Liegt ab vor dem bisherigen „ab“, zählen die Tage von ab bis zum bisherigen ab − 1 neu; ihre Tageswerte werden abgezogen, damit beide Konten
    ab dem bisherigen „ab“ denselben Stand zeigen wie vorher. Ohne bisheriges „ab“ bleibt es beim Konto am Vortag (fehlende Tage ab „ab“ zählen
    dann als Minus). Eingaben: Db, neues „ab“. Rückgabe: {gleitzeit_min, freizeit_min} in Minuten. Keine Fehler."""
    vortag = ab - timedelta(days=1)
    sw = db.startwerte_lesen()
    bisher = sw.ab - timedelta(days=1) if sw else vortag            # ohne bisheriges „ab“ ist der Bereich leer
    return {KONTEN["gleitzeit"][0]: konto(db, vortag) - _zwischen(db, ab, bisher, saldo_tag),
            KONTEN["freizeit"][0]: freizeit_konto(db, vortag) - _zwischen(db, ab, bisher, freizeit_tag)}


SONNTAG = 6                                                # date.weekday()


def verlauf(db, jahr: int, heute: date = None) -> list:
    """Gleitzeit-Verlauf eines Jahres (funktionen.md 11): Stand des Kontos (konto) an jedem Sonntag des Jahres ab dem Beginn des Kontos (ab bzw.
    erster Eintrag) bis min(heute, 31.12.), dazu dieser letzte Tag, wenn er kein Sonntag ist (laufendes Jahr: heute, vergangenes: 31.12.);
    an einem Stichtag mit verfallenen Minuten zwei Punkte (vor und nach der Kappung).
    Eingaben: Db, Jahr, heute (Vorgabe: heute). Rückgabe: [{"datum": JJJJ-MM-TT, "saldo_min": Minuten}], leer ohne Beginn, für Jahre vor dem
    Beginn und für künftige Jahre. Keine Fehler."""
    heute = heute or date.today()
    beginn = _beginn(db, db.tage_alle())
    ende = min(heute, date(jahr, 12, 31))
    erster = max(beginn, date(jahr, 1, 1)) if beginn else None
    if erster is None or erster > ende:
        return []
    tage = set(list(regeln.tage_im_zeitraum(erster + timedelta(days=SONNTAG - erster.weekday()), ende))[::7] + [ende])
    vorher = {k["datum"]: k["stand_min"] for k in kappungen(db, ende) if k["datum"] >= erster and k["verfallen_min"]}
    punkte = []
    for d in sorted(tage | set(vorher)):
        if d in vorher:                                    # Sprung: Stand am Stichtag vor der Kappung, danach derselbe Tag gekappt
            punkte.append({"datum": d.isoformat(), "saldo_min": vorher[d]})
        punkte.append({"datum": d.isoformat(), "saldo_min": konto(db, d)})
    return punkte


def verlauf_kappungen(db, jahr: int, heute: date = None, zeitformat: str = "hhmm") -> list:
    """Kappungen eines Jahres bis min(heute, 31.12.) mit verfallenen Minuten: [{datum, verfallen_min, text}] (Text wie kappung_text)."""
    ende = min(heute or date.today(), date(jahr, 12, 31))
    return [{"datum": k["datum"].isoformat(), "verfallen_min": k["verfallen_min"], "text": kappung_text(k, zeitformat)}
            for k in kappungen(db, ende) if k["datum"].year == jahr and k["verfallen_min"]]


def fmt_saldo(min_: int, zeitformat: str = "hhmm") -> str:
    """Minuten als Saldo mit Vorzeichen im Zeitformat (zeit.fmt_dauer): +hh:mm oder −hh:mm, dezimal +7,50 oder −1,70 (0 ergibt +00:00 bzw. +0,00).
    Fehler: ValueError bei einem unbekannten Zeitformat."""
    return ("" if min_ < 0 else "+") + fmt_dauer(min_, zeitformat)


MINUTEN_JE_STUNDE = 60


def saldo_grenzen(regeln_tag: dict) -> tuple:
    """Grenzen des Gleitzeit-Kontos in Minuten (funktionen.md 11) aus den Regeln eines Tages: (Plus, Minus). 0 heißt kein Hinweis und keine
    Grenzlinie in dieser Richtung (seit 23.11.2026); Minus fehlend gilt wie Plus (alte Regeln mit Minus 0 stellt konfig._saldo_minus_alt um). Eingabe: Regeln mit zutun_saldo_grenze (Stunden). Rückgabe: zwei ganze Zahlen ab 0. Keine Fehler."""
    plus = regeln_tag["zutun_saldo_grenze"]
    return plus * MINUTEN_JE_STUNDE, regeln_tag.get("zutun_saldo_minus", plus) * MINUTEN_JE_STUNDE


TAG_ENDE_MIN = 1440                                        # Gehen ab 24:00 ist nicht mehr „heute“
PROZENT = 100
ZIEL_OFFEN = "Bis {gehen} für dein Tagessoll"                    # ohne Punkt wie die anderen Zeilen der Kachel (Entscheidung 24.11.2026)
ZIEL_ERREICHT = "Tagessoll erreicht ({plus})"
ZIEL_NOCH = "Noch {fehlt} bis Tagessoll"


def _netto(dauer_min: int, d: date) -> int:
    """Arbeitszeit eines Blocks von dauer_min Minuten nach der Pausenregel am Tag d (wie die Stempeluhr beim Gehen)."""
    return dauer_min - regeln.pause_auto(dauer_min, d)


def _dauer_fuer(arbeit_min: int, d: date) -> int:
    """Kleinste Dauer eines Blocks, dessen Arbeitszeit nach der Pausenregel arbeit_min erreicht. Die Arbeitszeit wächst nie rückwärts
    (pause_auto ist anteilig), deshalb reicht Hochzählen; die Pause beträgt höchstens ein paar Stunden."""
    dauer = arbeit_min
    while _netto(dauer, d) < arbeit_min:
        dauer += 1
    return dauer


def _anteil(teil: int, ganz: int) -> int:
    """teil von ganz in Prozent, abgerundet, 0 bis 100; 0 bei ganz 0."""
    return min(PROZENT, max(0, teil) * PROZENT // ganz) if ganz > 0 else 0


def wochenziel_balken(soll_min: int, ist_min: int, soll_heute_min: int, zeitformat: str = "hhmm") -> dict:
    """Balken des Wochenziels (Wunsch 22.11.2026): Ist gegen das Soll der ganzen Woche (ohne Urlaub, Krank, Gleittage), dazu die Marke
    „Soll bis heute“ (Montag bis einschließlich heute; vergangene Woche = ganzes Soll, künftige = 0). Rückgabe: soll_min, ist_min, soll, ist,
    soll_heute_min, soll_heute (Zeitformat), prozent und marke (0–100, abgerundet). Keine Fehler."""
    return {"soll_min": soll_min, "ist_min": ist_min, "soll": fmt_dauer(soll_min, zeitformat), "ist": fmt_dauer(ist_min, zeitformat),
            "soll_heute_min": soll_heute_min, "soll_heute": fmt_dauer(soll_heute_min, zeitformat),
            "prozent": _anteil(ist_min, soll_min), "marke": _anteil(soll_heute_min, soll_min)}


def tagesziel_satz(fehlt_min: int, gebucht_min: int, beginn_min, lauf_min: int, d: date, zeitformat: str = "hhmm") -> dict:
    """Satz der Kachel „Heute“ am Tag d (Entscheidung des Entwicklers vom 24.11.2026): bis wann man bei laufender Uhr bleibt, damit das Tagessoll erreicht ist.
    Eingaben: fehlt_min (Tagessoll minus gebuchtes Ist des Tages, mit Auffüllung „Krank im Dienst“; negativ = Plus), gebucht_min (heute schon
    gebuchte Arbeitszeit), beginn_min (Beginn der heute gestarteten Uhr, Minuten ab Mitternacht; None: die Uhr läuft heute nicht), lauf_min (Minuten
    der laufenden Uhr, sonst 0). Pause nach der Regel über den ganzen Block wie beim Gehen der Stempeluhr. Ist das Soll mit der laufenden Uhr heute
    nicht zu schaffen (mehr als regeln.MAX_TAG_MIN Arbeitszeit am Tag oder Gehen nach 23:59), steht wie bei angehaltener Uhr, was noch fehlt.
    Rückgabe: satz und gehen (hh:mm nur, wenn heute erreichbar und noch offen). Keine Fehler."""
    rest = fehlt_min - _netto(lauf_min, d)
    if rest <= 0:
        return {"satz": ZIEL_ERREICHT.format(plus=fmt_saldo(-rest, zeitformat)), "gehen": ""}
    noch = {"satz": ZIEL_NOCH.format(fehlt=fmt_dauer(rest, zeitformat)), "gehen": ""}
    if beginn_min is None or gebucht_min + fehlt_min > regeln.MAX_TAG_MIN:
        return noch
    gehen = beginn_min + _dauer_fuer(fehlt_min, d)
    if gehen >= TAG_ENDE_MIN:
        return noch
    return {"satz": ZIEL_OFFEN.format(gehen=fmt_hhmm(gehen)), "gehen": fmt_hhmm(gehen)}
