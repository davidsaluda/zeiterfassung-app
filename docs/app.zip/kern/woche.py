# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Wochenansicht und Gleitzeit-Konto (Ist minus Soll, laufend aufsummiert).
Soll zählt an Arbeitstagen (laut Abschnitt) außer bei Urlaub, angespartem Urlaub, Krank, Sonderurlaub, Kind krank und Elternzeit; ein Gleittag bleibt Soll-Tag und bucht das Tagessoll vom Konto ab.
„Krank im Dienst“ füllt die fehlende Zeit bis zum Tagessoll auf (regeln.aufgefuellt_min), damit kein Minus entsteht.
Tage ohne Eintrag zählen mit ihrem Soll (fehlende Zeit). Arbeit an Wochenenden und freien Tagen (Feiertage, eigene freie Tage) zählt NICHT zur Gleitzeit,
sondern zum Freizeitkonto; dieses wird mit der Art „Freizeitausgleich“ (Tagessoll) abgebaut. Ein Startsaldo (Korrektur) synchronisiert Altwerte je Konto.
Beide Konten beginnen an „Erfassung gültig ab“ (R6, Startwerte), sonst am ersten Eintrag; Tage davor zählen nicht."""
import threading
from kern.feiertage import ist_frei
from datetime import date, timedelta

from daten import konfig
from kern import regeln
from kern.zeit import fmt_dauer, fmt_hhmm
from daten.db import ALLES, KONTEN

_SCHLOSS = threading.Lock()

ENTFALLEN = tuple(a for a in regeln.ABWESEND if a != "gleittag")      # kein Soll an diesen Tagen; der Gleittag kostet sein Soll


def soll_tag(d: date, t, eigene, abschnitte) -> int:
    """Sollzeit des Tages in Minuten für das Gleitzeit-Konto: 0 bei den Arten in ENTFALLEN (Urlaub, Krank, Familientag, Freizeitausgleich, Sonderurlaub, Kind krank, Elternzeit)
    und an Tagen ohne Soll; ein Gleittag behält das Soll."""
    if t is not None and t.art in ENTFALLEN:
        return 0
    if not regeln.ist_soll_tag(d, eigene, abschnitte):
        return 0
    return regeln.tagessoll_min(d, abschnitte)


def saldo_tag(d: date, t, eigene, abschnitte) -> int:
    """Gleitzeit-Saldo des Tages: Ist (mit Auffüllung bei „Krank im Dienst“) minus Soll. Zeit an freien Tagen (Wochenende, Feiertag) gehört zum Freizeitkonto."""
    ist = 0 if ist_frei(d, eigene) else ((t.ho + t.dst) if t else 0) + regeln.aufgefuellt_min(d, t, eigene, abschnitte)
    return ist - soll_tag(d, t, eigene, abschnitte)


def freizeit_tag(d: date, t, eigene, abschnitte) -> int:
    """Veränderung des Freizeitkontos an diesem Tag: Arbeitszeit an freien Tagen plus, Freizeitausgleich = Tagessoll minus."""
    if t is None:
        return 0
    if ist_frei(d, eigene):
        return t.ho + t.dst
    if t.art == "freizeit":
        return -regeln.tagessoll_min(d, abschnitte)
    return 0


def _beginn(db, alle, ohne_ab: bool = False):
    """Erster Tag der Konten: „ab“ der Startwerte (R6), sonst (oder mit ohne_ab) der erste Eintrag aus alle; None ohne beides."""
    sw = None if ohne_ab else db.startwerte_lesen()
    return sw.ab if sw else (alle[0].datum if alle else None)


def _summe(db, bis: date, fn, ohne_ab: bool = False) -> int:
    """Summe der Tageswerte vom Beginn der Konten (_beginn) bis „bis“, 0 davor. Die laufende Summe je Tag wird gemerkt, solange sich Daten und Regeln
    nicht ändern (eine Wochenansicht fragt das Konto mehrfach ab; ohne Merken wird jedes Mal ab dem ersten Jahr neu gerechnet).
    ohne_ab: so, als gäbe es keine Startwerte (für das Löschen von „ab“), mit eigenem Merker."""
    regelstand = (konfig.regelstand_nr(), date.today())
    with db.lock, _SCHLOSS:                                 # erst die Datenbank, dann der Merker: dieselbe Reihenfolge wie Schreiber unter db.lock
        memo = db.__dict__.setdefault("_summen", {})
        schluessel = (fn.__name__, ohne_ab)
        m = memo.get(schluessel)
        if m is None or m["gen"] != db.gen or m["regelstand"] != regelstand:
            gen = db.gen                                     # vor dem Lesen festhalten: Wird währenddessen gespeichert, gilt der Merker als veraltet
            alle = db.tage_alle()
            start = _beginn(db, alle, ohne_ab)
            seit = db.geaendert_seit(m["gen"]) if m and m["regelstand"] == regelstand else ALLES
            # Die Summe bis zum Tag vor der Änderung bleibt gültig, wenn der Beginn derselbe ist; sonst alles neu.
            kum = m["kum"][:max(0, (seit - start).days)] if m and start and start == m["start"] and seit > start else []
            m = {"gen": gen, "regelstand": regelstand, "nach": {t.datum: t for t in alle}, "start": start, "kum": kum, "eigene": {}, "abschnitte": db.abschnitte()}
            memo[schluessel] = m
        if m["start"] is None or bis < m["start"]:
            return 0
        n, kum = (bis - m["start"]).days + 1, m["kum"]
        while len(kum) < n:
            d = m["start"] + timedelta(days=len(kum))
            if d.year not in m["eigene"]:
                m["eigene"][d.year] = db.eigene_frei_tage(d.year)
            kum.append((kum[-1] if kum else 0) + fn(d, m["nach"].get(d), m["eigene"][d.year], m["abschnitte"]))
        return kum[n - 1]


def _roh(db, bis: date) -> int:
    """Summe der Gleitzeit-Tagessalden vom Beginn des Kontos bis einschließlich „bis“ (ohne Startsaldo)."""
    return _summe(db, bis, saldo_tag)


def startsaldo(db) -> int:
    """Startsaldo des Gleitzeit-Kontos in Minuten: mit Startwerten deren Gleitzeit-Saldo (Stand am Ende von ab − 1), sonst der Korrekturwert (Vorgabe 0)."""
    return db.startkonto("gleitzeit")


def konto(db, bis: date) -> int:
    """Gleitzeit-Konto in Minuten am Ende des Tages „bis“: Startsaldo plus alle Tagessalden (Ist minus Soll) ab dem Beginn; davor der Startsaldo."""
    return startsaldo(db) + _roh(db, bis)


VOR_BEGINN_FEHLER = "Datum vor Beginn der Erfassung ({:%d.%m.%Y})"


def _nicht_vor_beginn(db, datum: date) -> None:
    """Ein Stand lässt sich nur ab „Erfassung gültig ab“ setzen (davor gibt es kein Konto). Fehler: konfig.KonfigFehler mit dem Datum von ab."""
    sw = db.startwerte_lesen()
    if sw and datum < sw.ab:
        raise konfig.KonfigFehler(VOR_BEGINN_FEHLER.format(sw.ab))


def stand_setzen(db, stand_min: int, datum: date):
    """Das Konto soll am Ende von „datum“ genau „stand_min“ zeigen: Startsaldo entsprechend einstellen (mit Startwerten in deren Gleitzeit-Saldo).
    Fehler: konfig.KonfigFehler bei einem Datum vor ab oder einem Startsaldo über ±999:59 (nur mit Startwerten)."""
    _nicht_vor_beginn(db, datum)
    db.startkonto_setzen("gleitzeit", stand_min - _roh(db, datum))


def freizeit_start(db) -> int:
    """Startsaldo des Freizeitkontos in Minuten: mit Startwerten deren eingefrorener Stand, sonst der Korrekturwert (Vorgabe 0)."""
    return db.startkonto("freizeit")


def freizeit_konto(db, bis: date) -> int:
    """Freizeitkonto in Minuten am Ende des Tages „bis“: Startsaldo plus Arbeit an freien Tagen minus Freizeitausgleich ab dem Beginn."""
    return freizeit_start(db) + _summe(db, bis, freizeit_tag)


def freizeit_stand_setzen(db, stand_min: int, datum: date):
    """Das Freizeitkonto soll am Ende von „datum“ genau „stand_min“ zeigen: Startsaldo entsprechend einstellen. Fehler wie stand_setzen."""
    _nicht_vor_beginn(db, datum)
    db.startkonto_setzen("freizeit", stand_min - _summe(db, datum, freizeit_tag))


def konten_ohne_startwerte(db, heute: date) -> dict:
    """Startstände beider Konten für das Löschen von „ab“ (R6, keine stillen Sprünge): so gewählt, dass Gleitzeit- und Freizeitkonto am Ende von heute
    ohne Startwerte denselben Stand zeigen wie jetzt mit. Rückgabe {gleitzeit_start_min, freizeit_start_min} für Db.startwerte_setzen(None, konten=…)."""
    return {KONTEN["gleitzeit"][1]: konto(db, heute) - _summe(db, heute, saldo_tag, ohne_ab=True),
            KONTEN["freizeit"][1]: freizeit_konto(db, heute) - _summe(db, heute, freizeit_tag, ohne_ab=True)}


def _zwischen(db, von: date, bis: date, fn) -> int:
    """Summe der Tageswerte von „von“ bis „bis“ ohne Rücksicht auf den Beginn der Konten und ohne Merker (selten: nur beim Vorverlegen von „ab“);
    0, wenn „von“ nach „bis“ liegt."""
    nach = {t.datum: t for t in db.tage_alle()}
    abschnitte = db.abschnitte()
    return sum(fn(d, nach.get(d), db.eigene_frei_tage(d.year), abschnitte) for d in regeln.tage_im_zeitraum(von, bis))


def konten_am_vortag(db, ab: date) -> dict:
    """Zählregel Vorbelegung der Startwerte (R6, keine stillen Sprünge): Stand beider Konten am Ende von ab − 1 mit den jetzt geltenden Einstellungen.
    Liegt ab vor dem bisherigen „ab“, zählen die Tage von ab bis zum bisherigen ab − 1 neu; ihre Tageswerte werden abgezogen, damit beide Konten
    ab dem bisherigen „ab“ denselben Stand zeigen wie vorher. Ohne bisheriges „ab“ bleibt es beim Konto am Vortag (fehlende Tage ab „ab“ zählen
    dann als Minus). Eingaben: Db, neues „ab“. Rückgabe: {gleitzeit_min, freizeit_min} in Minuten. Keine Fehler."""
    vortag = ab - timedelta(days=1)
    sw = db.startwerte_lesen()
    bisher = sw.ab - timedelta(days=1) if sw else vortag            # ohne bisheriges „ab“ ist der Bereich leer
    return {KONTEN["gleitzeit"][0]: konto(db, vortag) - _zwischen(db, ab, bisher, saldo_tag),
            KONTEN["freizeit"][0]: freizeit_konto(db, vortag) - _zwischen(db, ab, bisher, freizeit_tag)}


SONNTAG = 6                                                # date.weekday()


def verlauf(db, jahr: int, heute: date = None) -> list:
    """Gleitzeit-Verlauf eines Jahres (funktionen.md 11): Stand des Kontos (konto) an jedem Sonntag des Jahres ab dem Beginn des Kontos (ab bzw.
    erster Eintrag) bis min(heute, 31.12.), dazu dieser letzte Tag, wenn er kein Sonntag ist (laufendes Jahr: heute, vergangenes: 31.12.).
    Eingaben: Db, Jahr, heute (Vorgabe: heute). Rückgabe: [{"datum": JJJJ-MM-TT, "saldo_min": Minuten}], leer ohne Beginn, für Jahre vor dem
    Beginn und für künftige Jahre. Keine Fehler."""
    heute = heute or date.today()
    beginn = _beginn(db, db.tage_alle())
    ende = min(heute, date(jahr, 12, 31))
    erster = max(beginn, date(jahr, 1, 1)) if beginn else None
    if erster is None or erster > ende:
        return []
    tage = list(regeln.tage_im_zeitraum(erster + timedelta(days=SONNTAG - erster.weekday()), ende))[::7]
    if not tage or tage[-1] != ende:
        tage.append(ende)
    return [{"datum": d.isoformat(), "saldo_min": konto(db, d)} for d in tage]


def fmt_saldo(min_: int, zeitformat: str = "hhmm") -> str:
    """Minuten als Saldo mit Vorzeichen im Zeitformat (zeit.fmt_dauer): +hh:mm oder −hh:mm, dezimal +7,50 oder −1,70 (0 ergibt +00:00 bzw. +0,00).
    Fehler: ValueError bei einem unbekannten Zeitformat."""
    return ("" if min_ < 0 else "+") + fmt_dauer(min_, zeitformat)


MINUTEN_JE_STUNDE = 60


def saldo_grenzen(regeln_tag: dict) -> tuple:
    """Grenzen des Gleitzeit-Kontos in Minuten (funktionen.md 11) aus den Regeln eines Tages: (Plus, Minus). Minus 0 oder fehlend (alte Regeln)
    gilt wie Plus. Eingabe: Regeln mit zutun_saldo_grenze (Stunden). Rückgabe: zwei ganze Zahlen ab 0. Keine Fehler."""
    plus = regeln_tag["zutun_saldo_grenze"]
    return plus * MINUTEN_JE_STUNDE, (regeln_tag.get("zutun_saldo_minus") or plus) * MINUTEN_JE_STUNDE


TAG_ENDE_MIN = 1440                                        # Gehen ab 24:00 ist nicht mehr „heute“
PROZENT = 100
ZIEL_OFFEN = "Heute bis {gehen}, dann bist du im Wochensoll"
ZIEL_ERREICHT = "Wochensoll bis heute erreicht, {plus}"
ZIEL_ZU_LANG = "Heute nicht erreichbar (höchstens {stunden} Std.), fehlt {fehlt}"
ZIEL_UNERREICHBAR = "Heute nicht mehr erreichbar, fehlt {fehlt}"
OHNE_SATZ = {"satz": "", "gehen": ""}


def _netto(dauer_min: int, d: date) -> int:
    """Arbeitszeit eines Blocks von dauer_min Minuten nach der Pausenregel am Tag d (wie die Stempeluhr beim Gehen)."""
    return dauer_min - regeln.pause_auto(dauer_min, d)


def _dauer_fuer(arbeit_min: int, d: date) -> int:
    """Kleinste Dauer eines Blocks, dessen Arbeitszeit nach der Pausenregel arbeit_min erreicht. Die Arbeitszeit wächst nie rückwärts
    (pause_auto ist anteilig), deshalb reicht Hochzählen; die Pause beträgt höchstens ein paar Stunden."""
    dauer = arbeit_min
    while _netto(dauer, d) < arbeit_min:
        dauer += 1
    return dauer


def _anteil(teil: int, ganz: int) -> int:
    """teil von ganz in Prozent, abgerundet, 0 bis 100; 0 bei ganz 0."""
    return min(PROZENT, max(0, teil) * PROZENT // ganz) if ganz > 0 else 0


def wochenziel_balken(soll_min: int, ist_min: int, soll_heute_min: int, zeitformat: str = "hhmm") -> dict:
    """Balken des Wochenziels (Wunsch 22.11.2026): Ist gegen das Soll der ganzen Woche (ohne Urlaub, Krank, Gleittage), dazu die Marke
    „Soll bis heute“ (Montag bis einschließlich heute; vergangene Woche = ganzes Soll, künftige = 0). Rückgabe: soll_min, ist_min, soll, ist,
    soll_heute_min, soll_heute (Zeitformat), prozent und marke (0–100, abgerundet). Keine Fehler."""
    return {"soll_min": soll_min, "ist_min": ist_min, "soll": fmt_dauer(soll_min, zeitformat), "ist": fmt_dauer(ist_min, zeitformat),
            "soll_heute_min": soll_heute_min, "soll_heute": fmt_dauer(soll_heute_min, zeitformat),
            "prozent": _anteil(ist_min, soll_min), "marke": _anteil(soll_heute_min, soll_min)}


def wochenziel_satz(fehlt_min: int, gebucht_min: int, anker_min, lauf_min: int, d: date, zeitformat: str = "hhmm") -> dict:
    """Satz des Wochenziels am Tag d: bis wann man heute bleibt, damit das Soll von Montag bis heute erreicht ist.
    Eingaben: fehlt_min (Soll bis heute minus gebuchtes Ist bis heute, mit Auffüllung „Krank im Dienst“; negativ = Plus), gebucht_min (heute schon
    gebuchte Arbeitszeit), anker_min (Beginn der heute laufenden Uhr oder jetzt, Minuten ab Mitternacht; None: kein Satz, etwa ohne Soll heute oder
    in einer anderen Woche), lauf_min (Minuten der laufenden Uhr, sonst 0). Pause nach der Regel über den ganzen Block wie beim Gehen der Stempeluhr;
    mehr als regeln.MAX_TAG_MIN Arbeitszeit am Tag zählt als nicht erreichbar (fehlt: was über die Grenze hinaus fehlt).
    Rückgabe: satz ("" ohne Satz) und gehen (hh:mm nur, wenn heute erreichbar und noch offen; die Übersicht zeigt den Satz nur dann). Keine Fehler."""
    if anker_min is None:
        return dict(OHNE_SATZ)
    rest = fehlt_min - _netto(lauf_min, d)
    if rest <= 0:
        return {**OHNE_SATZ, "satz": ZIEL_ERREICHT.format(plus=fmt_saldo(-rest, zeitformat))}
    zu_viel = gebucht_min + fehlt_min - regeln.MAX_TAG_MIN
    if zu_viel > 0:
        return {**OHNE_SATZ, "satz": ZIEL_ZU_LANG.format(stunden=regeln.MAX_TAG_MIN // MINUTEN_JE_STUNDE, fehlt=fmt_dauer(zu_viel, zeitformat))}
    gehen = anker_min + _dauer_fuer(fehlt_min, d)
    if gehen >= TAG_ENDE_MIN:
        return {**OHNE_SATZ, "satz": ZIEL_UNERREICHBAR.format(fehlt=fmt_dauer(rest, zeitformat))}
    return {"satz": ZIEL_OFFEN.format(gehen=fmt_hhmm(gehen)), "gehen": fmt_hhmm(gehen)}
