# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Urlaubsplanung: künftige Urlaubs-, Gleit-, Familien- und Sonderurlaubstage vorab berechnen, eintragen, als Zeiträume auflisten und löschen.
Geplante Tage sind ganz normale Tageseinträge (Art urlaub, angespart, gleittag, familientag, sonderurlaub_tag); es gibt keinen zweiten Datenbestand."""
from datetime import date, timedelta

from kern import bericht
from daten import konfig
from kern import regeln
from kern import urlaub as ur
from kern.zeit import fmt_tage, fmt_zahl

PLAN_ARTEN = {"urlaub": "Urlaub", "angespart": "Urlaub (angespart)", "gleittag": "Gleittag", "familientag": "Familientag",
              regeln.SONDERURLAUB: "Sonderurlaub"}                # „Kind krank“ ist nicht planbar
NUR_ARBEITSTAGE = (regeln.SONDERURLAUB,)    # nur an Arbeitstagen laut Abschnitt planbar und ohne Jahreslimit (R5); die anderen nach der Zählregel Werktag


class PlanFehler(Exception):
    """Fehler bei der Urlaubsplanung; die Meldung ist für die Person lesbar."""
    pass


def _eigene(db, cache, jahr):
    """Die eigenen freien Tage des Jahres als Menge; je Jahr nur einmal aus der Datenbank gelesen (cache)."""
    if jahr not in cache:
        cache[jahr] = db.eigene_frei_tage(jahr)
    return cache[jahr]


def _planbar(db, art: str):
    """Prüffunktion Tag -> bool, an welchen Tagen sich die Art planen lässt: Sonderurlaub an Arbeitstagen laut Abschnitt (regeln.ist_soll_tag),
    sonst an Werktagen (Mo–Fr, nicht frei; regeln.ist_werktag)."""
    cache, abschnitte = {}, db.abschnitte()
    if art in NUR_ARBEITSTAGE:
        return lambda d: regeln.ist_soll_tag(d, _eigene(db, cache, d.year), abschnitte)
    return lambda d: regeln.ist_werktag(d, _eigene(db, cache, d.year))


def _plan_tage(db, art: str, von: date, bis: date) -> list:
    """Die Tage von „von“ bis „bis“, an denen sich die Art planen lässt (_planbar), als Liste von Daten."""
    planbar = _planbar(db, art)
    return [d for d in regeln.tage_im_zeitraum(von, bis) if planbar(d)]


def _pruefe(art, von, bis, heute):
    """Prüft Art, Zeitraum (von nicht nach bis, nicht vor heute, höchstens 400 Tage); sonst PlanFehler."""
    if art not in PLAN_ARTEN:
        raise PlanFehler("Unbekannte Art. Möglich: " + ", ".join(PLAN_ARTEN))
    if von > bis:
        raise PlanFehler("Das Von-Datum liegt nach dem Bis-Datum")
    if von < heute:
        raise PlanFehler("Geplant werden können nur heutige und künftige Tage")
    if (bis - von).days > 400:
        raise PlanFehler("Zeitraum höchstens etwa ein Jahr")


class _MitPlan:
    """Der Datenstand, als wären die Plan-Tage schon eingetragen: liest aus der Datenbank und legt die Tage nur im Speicher darüber.
    Damit rechnet die Vorschau den Stand danach mit derselben Rechnung wie die Seite Urlaub nach dem Eintragen (bericht.urlaub_stand),
    samt Übertrag ins Folgejahr. Eingaben: Db, Plan-Tage (regeln.Tag, nur an Tagen ohne Eintrag). Schreibt nichts; nur zum Lesen weitergeben."""

    def __init__(self, db, plan):
        """Merkt die Datenbank und die Plan-Tage je Datum."""
        self._db, self._plan = db, {t.datum: t for t in plan}

    def __getattr__(self, name):
        """Alles außer den Tagen kommt unverändert aus der Datenbank (bericht.angespart_genommen zählt über tage_alle, also samt Plan-Tagen)."""
        return getattr(self._db, name)

    def _mit_plan(self, tage, jahr=None):
        """Die Tage der Datenbank samt den Plan-Tagen (nur die des Jahres, ohne Jahr alle), nach Datum sortiert."""
        plan = [t for t in self._plan.values() if jahr in (None, t.datum.year)]
        return sorted([t for t in tage if t.datum not in self._plan] + plan, key=lambda t: t.datum)

    def tage(self, jahr: int):
        """Alle Tage des Jahres samt Plan-Tagen, nach Datum sortiert."""
        return self._mit_plan(self._db.tage(jahr), jahr)

    def tage_alle(self):
        """Alle Tage samt Plan-Tagen, nach Datum sortiert."""
        return self._mit_plan(self._db.tage_alle())


def _plan_eintraege(db, art: str, tage: list):
    """Die Tage als Einträge, wie das Eintragen sie anlegt, ohne zu schreiben. Angesparter Urlaub bucht je Tag vom ältesten Konto mit einem
    ganzen freien Tag (ur.buchbar, wie tag_speichern), frühere Tage des Plans zählen mit.
    Rückgabe: (Einträge als regeln.Tag, Tage ohne freies Konto). Keine Fehler."""
    if art != "angespart":
        return [regeln.Tag(d, art=art) for d in tage], []
    konten, genommen, eintraege, ohne_konto = db.konten(), bericht.angespart_genommen(db), [], []
    for d in tage:
        konto = ur.naechstes_konto(ur.buchbar(konten, d.year, genommen))
        if konto is None:
            ohne_konto.append(d)
            continue
        genommen[konto] = genommen.get(konto, 0) + 1
        eintraege.append(regeln.Tag(d, art=art, konto=konto))
    return eintraege, ohne_konto


def _angespart_frei(stand: dict) -> float:
    """Freie Tage angesparten Urlaubs eines Jahres: Summe der Reste der nutzbaren Konten aus bericht.urlaub_stand."""
    return sum(k["rest"] for k in stand["konten"] if k["nutzbar"])


def vorschau(db, art: str, von: date, bis: date, heute=None) -> dict:
    """Welche Tage würden eingetragen, was ist danach noch übrig? Schreibt nichts.
    Eingaben: Db, Art aus PLAN_ARTEN, Zeitraum, heute (für Tests). Rückgabe: neue Tage, übersprungene Tage und je Jahr mit neuen Tagen der Stand
    vorher („vor“) und nach dem ganzen Plan („nach“, wie ihn die Seite Urlaub nach dem Eintragen zeigt): Urlaubstage im alten Jahr senken auch
    den automatischen Übertrag ins neue, angesparter Urlaub bucht in allen Jahren von denselben Konten. Bei Arten mit fester Grenze heißt ein
    negatives „nach“: so viele Tage fehlen, das Jahr ist gesperrt. Fehler: PlanFehler bei ungültiger Art oder ungültigem Zeitraum."""
    heute = heute or date.today()
    _pruefe(art, von, bis, heute)
    vorhanden = {t.datum: t for t in db.tage_alle() if von <= t.datum <= bis}
    neu, schon, uebersprungen = [], 0, []
    for d in _plan_tage(db, art, von, bis):
        t = vorhanden.get(d)
        if t and t.art == art:
            schon += 1
        elif t and (t.ho or t.dst or t.art):
            uebersprungen.append({"datum": d.isoformat(), "grund": "schon eingetragen: " + (regeln.ARTEN.get(t.art) or "Arbeitszeit")})
        else:
            neu.append(d)
    eintraege, ohne_konto = _plan_eintraege(db, art, neu)
    mit_plan = _MitPlan(db, eintraege)
    jahre = []
    for j in sorted({d.year for d in neu} if art not in NUR_ARBEITSTAGE else ()):     # Sonderurlaub hat kein Limit, also keinen Stand
        n = sum(1 for d in neu if d.year == j)
        st, danach = bericht.urlaub_stand(db, j), bericht.urlaub_stand(mit_plan, j)
        nach = None
        if art == "urlaub":
            vor, nach, text, hart = st["rest"], danach["rest"], "Resturlaub", False
        elif art == "gleittag":
            vor, text, hart = st["gleittage_rest"], "Gleittage", True
        elif art == "familientag":
            vor, text, hart = st["familientage_rest"], "Familientage", True
            if not st["familientage_aktiv"]:
                raise PlanFehler(f"Familientage sind für {j} nicht aktiviert (unter „{konfig.urlaub_seite()} → Erweitert“ einschalten)")
        else:
            fehlen = sum(1 for d in ohne_konto if d.year == j)
            vor, nach, text, hart = _angespart_frei(st), -fehlen if fehlen else _angespart_frei(danach), "Angesparter Urlaub", True
        if nach is None:                                 # Gleit- und Familientage: eigene Grenze je Jahr, der Stand der Seite fällt nie unter 0
            nach = vor - n
        warn = ""
        if nach < 0:
            warn = f"{text}: {fmt_tage(n)} geplant, nur {fmt_zahl(n + nach)} frei" if hart else f"{text}: {fmt_tage(-nach)} zu viel geplant"
        jahre.append({"jahr": j, "neu": n, "bezeichnung": text, "vor": vor, "nach": nach, "warnung": warn, "gesperrt": bool(warn) and hart})
    return {"art": art, "titel": PLAN_ARTEN[art], "von": von.isoformat(), "bis": bis.isoformat(), "neu": [d.isoformat() for d in neu],
            "schon": schon, "uebersprungen": uebersprungen, "jahre": jahre, "gesperrt": any(x["gesperrt"] for x in jahre)}


def zeitraeume(db, heute=None) -> list:
    """Künftige Plan-Tage ab heute, zu Zeiträumen gleicher Art zusammengefasst (Tage, an denen sich die Art nicht planen lässt, unterbrechen nicht:
    Wochenenden und freie Tage, bei Sonderurlaub auch freie Wochentage der Teilzeit)."""
    heute = heute or date.today()
    tage = [t for t in db.tage_alle() if t.datum >= heute and t.art in PLAN_ARTEN]
    planbar, gruppen = {}, []
    for t in tage:
        if gruppen and gruppen[-1]["art"] == t.art:
            if t.art not in planbar:
                planbar[t.art] = _planbar(db, t.art)
            d = gruppen[-1]["_bis"] + timedelta(days=1)
            while d < t.datum and not planbar[t.art](d):
                d += timedelta(days=1)
            if d == t.datum:
                gruppen[-1]["_bis"] = t.datum
                gruppen[-1]["tage"] += 1
                continue
        gruppen.append({"art": t.art, "titel": PLAN_ARTEN[t.art], "_von": t.datum, "_bis": t.datum, "tage": 1})
    for g in gruppen:
        g["von"], g["bis"] = g.pop("_von").isoformat(), g.pop("_bis").isoformat()
    return gruppen


def auswahl_tage(db, z: str) -> list:
    """z = 'von_bis,von_bis,…' (ISO-Daten): die Plan-Tage dieser Zeiträume für den Kalender-Export."""
    bereiche = []
    for teil in z.split(","):
        try:
            v, b = teil.split("_")
            bereiche.append((date.fromisoformat(v), date.fromisoformat(b)))
        except ValueError:
            raise PlanFehler("Auswahl: von_bis mit Datum JJJJ-MM-TT")
    return [t for t in db.tage_alle() if t.art in PLAN_ARTEN and any(v <= t.datum <= b for v, b in bereiche)]
