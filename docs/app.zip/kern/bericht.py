# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Auswertungen: Monat, Jahr, HO-Rest, Urlaub, Krank und Homeoffice-Übersicht (mit Export PDF, Excel, CSV)."""
import calendar
import threading
from urheber import VERMERK
from collections import Counter
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from functools import partial

from kern import feiertage
from daten import konfig
from kern import regeln
from kern import urlaub as ur
from kern import woche as wo
from daten.db import ALLES, RESTURLAUB_BEHALTEN
from kern.feiertage import EIGENER_FREIER_TAG, freie_tage, ist_frei
from kern.regeln import WT, ARTEN, summe
from kern.zeit import fmt_dauer, fmt_hhmm, fmt_prozent

_UEBERTRAG_SCHLOSS = threading.Lock()
MONATE = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]


def de(d: date) -> str:
    """Datum als TT.MM.JJJJ."""
    return d.strftime("%d.%m.%Y")


def eigene_frei(db, jahre) -> set:
    """Die eigenen freien Tage mehrerer Jahre als eine Menge (für Rechnungen, die ins Nachbarjahr reichen). Eingaben: Db, Jahreszahlen. Keine Fehler."""
    return set().union(*(db.eigene_frei_tage(y) for y in jahre))




def tag_namen(db, jahre) -> dict:
    """Namen freier Tage mehrerer Jahre für Monat und Woche: {Datum: Name}. Ein gesetzlicher oder jährlicher Feiertag (freie_tage) geht vor,
    sonst der Name des einmaligen eigenen freien Tags (leer: EIGENER_FREIER_TAG). Eingaben: Db, Jahreszahlen. Keine Fehler."""
    r = {}
    for y in jahre:
        r.update({x["datum"]: x["name"] or EIGENER_FREIER_TAG for x in db.eigene_feiertage(y)})
        r.update(freie_tage(y))
    return r


def runden(x: float, stellen: int = 0) -> float:
    """Kaufmännisch runden (halbe Werte nach oben), anders als round, das auf die gerade Zahl rundet (6,5 → 6).
    Eingaben: Zahl ab 0, Nachkommastellen. Rückgabe: gerundete Zahl. Keine Fehler bei endlichen Zahlen."""
    f = 10 ** stellen
    return int(round(x * f, 9) + 0.5) / f          # round(…, 9) glättet Gleitkomma-Reste wie 1,15 × 10 = 11,4999…


def _kontext(db, jahr):
    """Holt die Daten eines Jahres: Tage, eigene freie Tage (Menge), Abschnitte (Teilzeit, Elternzeit) und die Jahreseinstellung."""
    ein = db.jahr_einstellung(jahr)
    return db.tage(jahr), db.eigene_frei_tage(jahr), db.abschnitte(jahr), ein


VOR_BEGINN = "vor Beginn der Erfassung"                     # Hinweis an Tagen und Monaten vor „Erfassung gültig ab“ (R6)
VOR_BEGINN_AB = VOR_BEGINN + " (ab {datum})"                # Zeile im Monatsexport eines Monats, der vor „ab“ endet


def _ab(db):
    """„Erfassung gültig ab“ (R6) oder None ohne Startwerte: Einträge und Tage davor zählen nirgends."""
    sw = db.startwerte_lesen()
    return sw.ab if sw else None


def _vor_beginn(d: date, ab) -> bool:
    """True, wenn der Tag (oder das letzte Datum eines Zeitraums) vor „ab“ liegt."""
    return ab is not None and d < ab


def _monat_summe(db, j: int, m: int, tage, eigene, abschnitte) -> dict:
    """Summe eines Monats ab „ab“ (ohne Startwerte: die gelten nur für das ganze Jahr)."""
    return summe(tage, eigene, abschnitte, date(j, m, 1), date(j, m, calendar.monthrange(j, m)[1]), ab=_ab(db))


def jahr_summe(db, j: int) -> dict:
    """Zählregel Jahressumme mit Startwerten (R6): summe des Jahres j ab „ab“, im Jahr von „ab“ mit dem Stand bis zum Vortag (Start-HO, -Büro,
    -Urlaub, -Gleittage, -Kranktage, -Kind krank). Eine Stelle für Jahr, HO-Rest, Urlaub, Krank, Übersicht, Übertrag und Zu tun.
    Eingaben: Db, Jahr. Rückgabe: Ergebnis von regeln.summe (mit start und krank_start). Keine Fehler."""
    tage, eigene, abschnitte, _ = _kontext(db, j)
    return summe(tage, eigene, abschnitte, date(j, 1, 1), date(j, 12, 31), ab=_ab(db), start=db.startwerte_jahr(j))


def angespart_genommen(db, ohne: date | None = None) -> dict:
    """Zählregel Konto angesparter Urlaub: genommene Tage je Herkunftsjahr {Herkunftsjahr: Anzahl}, gezählt wie in summe nur an Werktagen
    (ein später frei gewordener Tag kostet nichts); Einträge vor „ab“ zählen auch für die Konten nicht (R6). Eine Zählung für Bericht, Server und Zu tun.
    Eingaben: Db, ohne = ein Tag, der nicht mitzählt (der Tag, der gerade neu gespeichert wird). Keine Fehler."""
    ab = _ab(db)
    tage = [t for t in db.tage_alle() if t.art == "angespart" and t.datum != ohne and not _vor_beginn(t.datum, ab)]
    eigene = {y: db.eigene_frei_tage(y) for y in {t.datum.year for t in tage}}
    return dict(Counter(t.konto for t in tage if regeln.ist_werktag(t.datum, eigene[t.datum.year])))


def _fmt(s: dict, zeitformat: str = "hhmm") -> dict:
    """Minuten und Anteile in Anzeigetexte umwandeln (Dauern im Zeitformat, zeit.fmt_dauer). „ist“ ist das Ist neben dem Soll (mit Auffüllung
    bei „Krank im Dienst“), „ist_quote“ die Basis der Quote (HO + Büro), „aufgefuellt“ die aufgefüllte Zeit."""
    dauer = partial(fmt_dauer, zeitformat=zeitformat)
    return {
        "ho": dauer(s["ho_min"]), "dst": dauer(s["dst_min"]), "ist": dauer(s["ist_soll_min"]), "ist_quote": dauer(s["ist_min"]),
        "aufgefuellt": dauer(s["aufgefuellt_min"]), "quote": fmt_prozent(s["quote"]),
        "soll": dauer(s["soll_min"]), "grenze80": dauer(s["grenze_min"]), "rest": dauer(s["ho_rest"]),
        "ueberschritten": dauer(s["ueberschritten"]),
    }


def _zahlen(s: dict) -> dict:
    """Summe ohne die Liste der Elternzeit-Tage (nur die Zahlen für die Antwort)."""
    return {k: v for k, v in s.items() if k != "elternzeit_liste"}


def monat(db, jahr: int, m: int, zeitformat: str = "hhmm") -> dict:
    """Auswertung eines Monats: eine Zeile je Tag, Summen, Anzeigetexte (Dauern im Zeitformat „hhmm“ oder „dezimal“), Prognose für Monat und Jahr. Mit Startwerten (R6): erfassung_ab,
    vor_beginn (Monat endet vor ab) und vor_beginn_text („vor Beginn der Erfassung (ab TT.MM.JJJJ)“ für die Exporte, sonst leer)."""
    tage, eigene, abschnitte, _ = _kontext(db, jahr)
    namen = tag_namen(db, (jahr,))
    letzter = date(jahr, m, calendar.monthrange(jahr, m)[1])
    im = {t.datum: t for t in tage}
    ab = _ab(db)
    zeilen = []
    for tag in range(1, letzter.day + 1):
        d = date(jahr, m, tag)
        zeilen.append(_zeile(d, im.get(d), eigene, abschnitte, namen, ab, zeitformat))
    s = _monat_summe(db, jahr, m, tage, eigene, abschnitte)
    davor = _vor_beginn(letzter, ab)
    return {"jahr": jahr, "monat": m, "name": MONATE[m - 1], "tage": zeilen, "summe": _zahlen(s), "text": _fmt(s, zeitformat), "rot": s["quote_rot"],
            "erfassung_ab": ab.isoformat() if ab else "", "vor_beginn": davor, "vor_beginn_text": VOR_BEGINN_AB.format(datum=de(ab)) if davor else "",
            "jahr_prognose": prognose(db, jahr, zeitformat=zeitformat), "monat_prognose": prognose(db, jahr, m, zeitformat=zeitformat),
            "familientage_aktiv": familientage_aktiv(db, jahr)}


def _zeile(d: date, t, eigene, abschnitte, namen, ab=None, zeitformat: str = "hhmm") -> dict:
    """Eine Tageszeile für Monat und Woche: Datum, Feiertag, Soll, HO, Büro, Art, Notiz, Vermerk und geprueft (Dauern im Zeitformat),
    Kommen/Gehen/Pause (Uhrzeiten, immer hh:mm),
    dazu ist_min (HO + Büro), aufgefuellt (Text, leer bei 0) und aufgefuellt_min, ist_soll_min (Ist mit Auffüllung), soll_konto_min
    (Soll fürs Gleitzeit-Konto wie woche.soll_tag) und saldo_konto_min (Gleitzeit-Saldo wie woche.saldo_tag, an freien Tagen 0, weil die Arbeit
    dort zum Freizeitkonto zählt), damit die Oberfläche nur summiert und nicht selbst zählt oder filtert.
    Ein Tag vor ab (R6) zeigt seine Einträge, hat aber vor_beginn True, keine Auffüllung, kein Soll (auch nicht in soll, soll_zeit) und keinen Saldo fürs Konto."""
    a = regeln.abschnitt_fuer(d, abschnitte)
    vor = _vor_beginn(d, ab)
    soll = not vor and regeln.ist_soll_tag(d, eigene, abschnitte)
    ist = (t.ho + t.dst) if t else 0
    auf = regeln.aufgefuellt_min(d, t, eigene, abschnitte, ab)
    return {
        "datum": d.isoformat(), "tag": d.day, "wt": WT[d.weekday()],
        "feiertag": namen.get(d, "") or (f"Faschingsdienstag · Soll {format(konfig.fuer(d)['fasching_std'], 'g').replace('.', ',')} Std." if feiertage.ist_faschingsdienstag(d) and soll else ""),
        "frei": ist_frei(d, eigene), "wochenende": d.weekday() >= 5, "soll": soll, "abschnitt": a.art if a else "",
        "soll_zeit": fmt_dauer(regeln.tagessoll_min(d, abschnitte), zeitformat) if soll else "",
        "ho": fmt_dauer(t.ho, zeitformat) if t and t.ho else "", "dst": fmt_dauer(t.dst, zeitformat) if t and t.dst else "",
        "art": t.art if t else "", "notiz": t.notiz if t else "", "konto": t.konto if t else 0, "attest": t.attest if t else "", "freigabe": t.freigabe if t else 0,
        "vermerk": t.vermerk if t else "", "geprueft": t.geprueft if t else 0,
        "ist_min": ist, "aufgefuellt": fmt_dauer(auf, zeitformat) if auf else "", "aufgefuellt_min": auf, "ist_soll_min": ist + auf,
        "soll_konto_min": 0 if vor else wo.soll_tag(d, t, eigene, abschnitte), "saldo_konto_min": 0 if vor else wo.saldo_tag(d, t, eigene, abschnitte),
        "vor_beginn": vor,
        **({"kommen": fmt_hhmm(t.kommen), "gehen": fmt_hhmm(t.gehen), "pause": fmt_hhmm(t.pause)} if t and t.kommen >= 0
           else {"kommen": "", "gehen": "", "pause": ""}),
    }


def tag_min(s: dict, von, bis, eigene, abschnitte) -> int:
    """Übliches Tagessoll der Arbeitstage im Zeitraum (sonst 8:00): Länge eines „Tages“ für Umrechnungen."""
    laengen = Counter(regeln.tagessoll_min(d, abschnitte) for d in (von + timedelta(n) for n in range((bis - von).days + 1))
                      if regeln.ist_soll_tag(d, eigene, abschnitte))
    return (laengen.most_common(1)[0][0] if laengen else 0) or 480


RATE_SCHLUESSEL = {"jahr": "buero_pro_woche", "monat": "buero_pro_woche_monat"}   # gemerkte Annahme je Karte (Monat, Jahr)
ZEITRAUM_FEHLER = "Zeitraum: monat oder jahr"
RATE_OHNE_DATEN = 1.0                                       # noch kein Tag gearbeitet: „Automatisch“ rechnet 1 Büro-Tag pro Woche


def buero_rate(db, zeitraum="jahr"):
    """Büro-Tage pro Woche für die Prognose des Zeitraums („monat“ oder „jahr“): von Hand gesetzt (meta) oder None = automatisch."""
    w = db.meta_lesen(RATE_SCHLUESSEL[zeitraum], "")
    try:
        return max(0.0, min(float(regeln.BUERO_TAGE_MAX), float(w))) if str(w) != "" else None
    except ValueError:
        return None


@dataclass
class RestWoche:
    """Eine Kalenderwoche mit noch geplanten Soll-Tagen. rest: Tagessoll (Minuten) je Rest-Tag; n_rest: Arbeitstage je Woche je Rest-Tag;
    n: Arbeitstage je Woche für jeden Soll-Tag der Woche im Zeitraum ohne Abwesenheit (auch vergangene und schon gearbeitete);
    schon: Büro-Tage dieser Woche im Zeitraum, die schon eingetragen sind."""
    rest: list
    n_rest: list
    n: list
    schon: int

    def dst_tage(self, r) -> float:
        """Büro-Tage der Restzeit dieser Woche bei r Tagen je Woche: Ziel ist die Summe von min(1, r / n) über die Soll-Tage der Woche im Zeitraum
        (Wochen mit Feiertag, Urlaub oder am Rand des Zeitraums zählen so anteilig), ohne die schon eingetragenen, höchstens die Rest-Tage."""
        ziel = sum(min(1.0, r / n) for n in self.n)
        return min(len(self.rest), max(0.0, ziel - self.schon))

    def dst_min(self, r) -> float:
        """Büro-Minuten der Restzeit dieser Woche bei r Tagen je Woche (mit dem mittleren Tagessoll der Rest-Tage, ungerundet)."""
        return self.dst_tage(r) * sum(self.rest) / len(self.rest)


def _rest_wochen(tage, eigene, abschnitte, von, bis, heute) -> list:
    """Kalenderwochen (RestWoche) mit noch nicht gearbeiteten Soll-Tagen ab heute bis „bis“ (Teilzeit, Feiertage, Fasching beachtet);
    Urlaub, Krank und andere Abwesenheiten, „Krank im Dienst“ sowie Tage mit Zeiteintrag sind keine Rest-Tage (dieselben Tage wie geplant_min in summe)."""
    im = {t.datum: t for t in tage}
    je_woche = {}
    for d in regeln.tage_im_zeitraum(max(heute, von), bis):
        t = im.get(d)
        if regeln.ist_soll_tag(d, eigene, abschnitte) and not (t and (t.art in regeln.ABWESEND or t.art == regeln.KRANK_IM_DIENST or t.ho or t.dst)):
            je_woche.setdefault(d.isocalendar()[:2], []).append(d)
    return [_rest_woche(kw, rest, im, eigene, abschnitte, von, bis) for kw, rest in je_woche.items()]


def _rest_woche(kw, rest, im, eigene, abschnitte, von, bis) -> RestWoche:
    """Eine Woche der Restzeit: ihre Soll-Tage im Zeitraum ohne Abwesenheit (für das Wochenziel) und die schon eingetragenen Büro-Tage.
    Tage der Woche außerhalb von von bis (Nachbarmonat, Nachbarjahr) zählen nicht."""
    woche = [d for d in (date.fromisocalendar(*kw, n) for n in range(1, 8)) if von <= d <= bis and regeln.ist_soll_tag(d, eigene, abschnitte)]
    da = [d for d in woche if not (im.get(d) and im[d].art in regeln.ABWESEND)]
    schon = sum(1 for d in woche if im.get(d) and im[d].dst > 0)
    return RestWoche([regeln.tagessoll_min(d, abschnitte) for d in rest], [regeln.arbeitstage_je_woche(d, abschnitte) for d in rest],
                     [regeln.arbeitstage_je_woche(d, abschnitte) for d in da], schon)


def _ueblich(werte) -> int:
    """Der häufigste Wert, bei Gleichstand der größere (z. B. die übliche Zahl der Arbeitstage je Woche)."""
    zahl = Counter(werte)
    return max(zahl, key=lambda w: (zahl[w], w))


def hochrechnung(tage, eigene, abschnitte, von, bis, rate_hand=None, heute=None, ab=None, start=None, zeitformat="hhmm"):
    """Ausblick auf das Ende des Zeitraums von bis (Monat oder Jahr). Rückgabe None, wenn keine Soll-Zeit mehr geplant ist; keine Fehler.
    Eingaben: Tage, eigene freie Tage und Abschnitte, Zeitraum, rate_hand (0 bis BUERO_TAGE_MAX
    oder None = Automatisch), heute (Standard: heute; ab diesem Tag zählt die Restzeit), ab und start (R6): Tage vor ab zählen weder im Ist noch
    im Wochenziel, die Rest-Tage beginnen bei max(heute, von, ab); start (Startwerte, nur Jahresprognose im Jahr von ab) zählt in HO und Ist,
    nicht in den Anteil der Büro-Tage für Automatisch (der kommt nur aus erfassten Tagen).
    Eine Rechnung für die Kacheln 0–5, „Automatisch“ und „Bei diesem Tempo“ (R7, Entscheidung der Leitung 19.11.2026): je Kalenderwoche
    r Büro-Tage, je Soll-Tag der Woche im Zeitraum min(1, r / Arbeitstage je Woche laut Abschnitt), sodass kurze Wochen anteilig zählen;
    schon eingetragene Büro-Tage der Woche werden abgezogen, höchstens die Rest-Tage der Woche; Minuten mit dem Tagessoll der Rest-Tage,
    daher gilt immer gesamt = Ist + geplant. Automatisch ist dieselbe Rechnung mit rate_auto: bisheriger Anteil der Büro-Tage (Tag mit HO
    und Büro zählt als Büro-Tag) mal die übliche Zahl der Arbeitstage je Woche, auf eine Stelle gerundet, damit Text und Zahl zusammenpassen;
    ohne gearbeiteten Tag RATE_OHNE_DATEN und ohne_daten True. auto_quote, auto_rot und auto_buero_tage kommen immer mit, auch bei rate_hand.
    buero_reicht_nicht: auch mit Büro an allen Rest-Tagen (HO am Ende = bisherige HO-Zeit) bleibt die Quote über der Grenze, gleich bei
    jeder Zahl der Arbeitstage je Woche. Quote minutengenau gegen die Grenze des Profils (regeln.ueber_grenze, genau auf der Grenze nicht rot).
    Dauern als Text im Zeitformat („hhmm“ oder „dezimal“); Antwort-Form wie bisher (test_altstand), darum keine neuen *_min-Felder."""
    dauer = partial(fmt_dauer, zeitformat=zeitformat)
    heute = heute or date.today()
    s = summe(tage, eigene, abschnitte, von, bis, stichtag=heute, ab=ab, start=start)
    g, h, ist = s["geplant_min"], s["ho_min"], s["ist_min"]
    if g <= 0:
        return None
    anfang = max(von, ab) if ab else von
    gesamt = ist + g
    gr = regeln.ho_grenze(min(bis, heute))
    grenze = regeln.grenze_min(gesamt, gr)
    tag = tag_min(s, anfang, bis, eigene, abschnitte)
    wochen = _rest_wochen(tage, eigene, abschnitte, anfang, bis, heute)
    gearbeitet = s["ho_tage"] + s["dst_tage"]
    rate_auto = runden(s["dst_tage"] / gearbeitet * _ueblich(n for w in wochen for n in w.n_rest), 1) if gearbeitet else RATE_OHNE_DATEN

    def variante(r):
        """Bei r Büro-Tagen je Woche: (HO-Minuten am Ende, Büro-Minuten und -Tage der Restzeit)."""
        dst = min(g, int(round(sum(w.dst_min(r) for w in wochen))))
        return h + g - dst, dst, sum(w.dst_tage(r) for w in wochen)

    ho_ende, buero_min, buero_tage = variante(rate_auto if rate_hand is None else rate_hand)
    ho_auto, _, auto_tage = variante(rate_auto)
    reserve = grenze - ho_ende                              # >0: so viel HO-Zeit bleibt unter der Grenze, <0: so viel zu viel
    noetig = min(g, max(0, h + g - grenze))                 # Büro-Zeit, die noch kommen muss; mehr als die geplante Zeit geht nicht
    noetig_tage = -(-noetig // tag)
    varianten = []
    for r in range(regeln.BUERO_TAGE_MAX + 1):
        ho_r = variante(r)[0]
        varianten.append({"rate": r, "quote": fmt_prozent(ho_r / gesamt), "rot": regeln.ueber_grenze(ho_r, gesamt, gr)})
    ist_monat = von.month == bis.month
    return {"jahr": von.year, "monat": von.month if ist_monat else None, "zeitraum": "monat" if ist_monat else "jahr",
            "rate": rate_auto if rate_hand is None else rate_hand, "rate_auto": rate_auto, "rate_hand": rate_hand is not None,
            "restwochen": len(wochen), "rest_tage": sum(len(w.rest) for w in wochen), "buero_tage": int(runden(buero_tage)), "buero": dauer(buero_min),
            "quote_ende": fmt_prozent(ho_ende / gesamt),
            "auto_quote": fmt_prozent(ho_auto / gesamt), "auto_rot": regeln.ueber_grenze(ho_auto, gesamt, gr), "auto_buero_tage": int(runden(auto_tage)),
            "ohne_daten": not gearbeitet, "buero_reicht_nicht": regeln.ueber_grenze(h, gesamt, gr),
            "status": "ueber" if reserve < 0 else ("knapp" if reserve < tag else "sicher"),
            "reserve": dauer(abs(reserve)), "reserve_tage": abs(reserve) // tag, "reserve_min": reserve,
            "noetig": dauer(noetig), "noetig_tage": noetig_tage, "noetig_je_woche": runden(noetig_tage / len(wochen), 1),
            "tag_laenge": dauer(tag), "geplant": dauer(g), "gesamt": dauer(gesamt), "grenze80": dauer(grenze), "varianten": varianten}


def prognose(db, j: int, m=None, heute=None, zeitformat: str = "hhmm"):
    """Prognose zum Monatsende (m gesetzt) oder Jahresende (m None) mit der gemerkten Annahme der Karte; ab „ab“, im Jahr die Startwerte (R6);
    Dauern im Zeitformat („hhmm“ oder „dezimal“)."""
    tage = db.tage(j)
    eigene = eigene_frei(db, (j,))
    von, bis = (date(j, m, 1), date(j, m, calendar.monthrange(j, m)[1])) if m else (date(j, 1, 1), date(j, 12, 31))
    return hochrechnung(tage, eigene, db.abschnitte(), von, bis, buero_rate(db, "monat" if m else "jahr"), heute,
                        ab=_ab(db), start=None if m else db.startwerte_jahr(j), zeitformat=zeitformat)


def jahr(db, j: int, zeitformat: str = "hhmm") -> dict:
    """Auswertung eines Jahres: je Monat und gesamt die Summen (Texte im Zeitformat „hhmm“ oder „dezimal“), dazu Urlaubsstand und Jahresprognose."""
    tage, eigene, abschnitte, ein = _kontext(db, j)
    ab = _ab(db)
    monate = []
    for m in range(1, 13):
        s = _monat_summe(db, j, m, tage, eigene, abschnitte)
        monate.append({"monat": m, "name": MONATE[m - 1], "summe": _zahlen(s), "text": _fmt(s, zeitformat), "rot": s["quote_rot"],
                       "vor_beginn": _vor_beginn(date(j, m, calendar.monthrange(j, m)[1]), ab)})
    g = jahr_summe(db, j)
    return {"jahr": j, "monate": monate, "gesamt": _zahlen(g), "text": _fmt(g, zeitformat), "rot": g["quote_rot"], "urlaub": urlaub_stand(db, j), "jahr_prognose": prognose(db, j, zeitformat=zeitformat)}


def _in_tagen(s: dict, von, bis, eigene, abschnitte, zeitformat: str = "hhmm") -> dict:
    """„noch möglich“ und „überschritten“ zusätzlich als ganze Tage plus Reststunden (im Zeitformat); ein Tag = das übliche Tagessoll der Arbeitstage
    im Zeitraum (sonst 8:00)."""
    tag = tag_min(s, von, bis, eigene, abschnitte)
    return {"tag_laenge": fmt_dauer(tag, zeitformat), "rest_tage": s["ho_rest"] // tag, "rest_tage_std": fmt_dauer(s["ho_rest"] % tag, zeitformat),
            "ueber_tage": s["ueberschritten"] // tag, "ueber_tage_std": fmt_dauer(s["ueberschritten"] % tag, zeitformat)}


def horest(db, j: int, m: int, zeitformat: str = "hhmm") -> dict:
    """Rest der Homeoffice-Zeit für einen Monat und das Jahr: zwei Blöcke mit Soll, Ist, Grenze und Rest (Dauern im Zeitformat),
    dazu die Prognosen für Monat und Jahr."""
    tage, eigene, abschnitte, _ = _kontext(db, j)
    dauer = partial(fmt_dauer, zeitformat=zeitformat)

    def block(s, von, bis, titel):
        """Ein Block (Monat oder Jahr) mit Summen s und Resttexten für den Zeitraum von bis."""
        return {"titel": titel, "soll": dauer(s["soll_min"]), "ist": dauer(s["ist_min"]), "geplant": dauer(s["geplant_min"]),
                "gesamt": dauer(s["plan_min"]), "grenze80": dauer(s["grenze_min"]), "ho": dauer(s["ho_min"]),
                "rest": dauer(s["ho_rest"]), "ueberschritten": dauer(s["ueberschritten"]) if s["ueberschritten"] else "",
                "rest_min": s["ho_rest"], "ueberschritten_min": s["ueberschritten"], "quote": fmt_prozent(s["quote"]), "rot": s["quote_rot"],
                **_in_tagen(s, von, bis, eigene, abschnitte, zeitformat)}
    return {"jahr": j, "monat": m, "jahr_prognose": prognose(db, j, zeitformat=zeitformat), "monat_prognose": prognose(db, j, m, zeitformat=zeitformat),
            "monat_block": block(_monat_summe(db, j, m, tage, eigene, abschnitte), date(j, m, 1), date(j, m, calendar.monthrange(j, m)[1]), f"{MONATE[m - 1]} {j}"),
            "jahr_block": block(jahr_summe(db, j), date(j, 1, 1), date(j, 12, 31), f"Jahr {j}")}


def _uebertrag(db, j: int):
    """Resturlaub aus dem Vorjahr: (Wert, automatisch berechneter Wert, von Hand festgelegt?).
    Automatisch = Rest des Vorjahres (Anspruch + dessen Übertrag - nach der Frist weggefallener Übertrag (_frist) - genommen), nie unter 0; ab dem ersten Jahr mit Einträgen gerechnet,
    mit Startwerten ab dem Jahr von „ab“ (R6: davor zählt nichts, dort zählt der Start-Urlaub als genommen).
    Die Reste der Vorjahre sind je Datenstand gemerkt: sonst rechnet jede Abfrage alle Jahre ab dem ersten neu durch."""
    alle = db.tage_alle()
    sw = db.startwerte_lesen()
    erstes = sw.ab.year if sw else (alle[0].datum.year if alle else j)
    hand = db.jahr_einstellung(j)["uebertrag"]
    if j <= erstes:
        return (0.0 if hand is None else hand), 0.0, hand is not None
    with db.lock, _UEBERTRAG_SCHLOSS:                     # Reihenfolge wie woche._summe: erst die Datenbank, dann der Merker (keine Verklemmung)
        m = db.__dict__.get("_reste")
        if m is None or m["gen"] != db.gen or m["rev"] != konfig.regelstand_nr():
            # Startwerte kommen über den Sync auch ohne „geändert ab“: ändern sie sich, gilt kein gemerkter Rest mehr
            # „Resturlaub behalten“ ist eine Einstellung ohne Tagesbezug (geaendert_seit meldet sie nicht): ändert sie sich, alles neu
            behalten = db.meta_mit(RESTURLAUB_BEHALTEN.format(""))
            weiter = m and m["rev"] == konfig.regelstand_nr() and m["erstes"] == erstes and m["startwerte"] == sw and m["behalten"] == behalten
            seit = db.geaendert_seit(m["gen"]) if weiter else ALLES
            gueltig = {y: r for y, r in m["rest"].items() if y < seit.year} if seit.year > erstes else {}     # Reste der Jahre vor der Änderung bleiben
            naechstes = erstes + len(gueltig)
            m = db.__dict__["_reste"] = {"gen": db.gen, "rev": konfig.regelstand_nr(), "erstes": erstes, "startwerte": sw, "behalten": behalten,
                                         "rest": gueltig, "eingang": gueltig[naechstes - 1] if gueltig else 0.0, "naechstes": naechstes}
        while m["naechstes"] < j:                        # Rest am Ende jedes Jahres bis zum Vorjahr von j
            y = m["naechstes"]
            ein = db.jahr_einstellung(y)
            eingang = m["eingang"] if ein["uebertrag"] is None else ein["uebertrag"]
            genommen = jahr_summe(db, y)["urlaub"]
            m["rest"][y] = m["eingang"] = max(0.0, ein["anspruch"] + zusatzurlaub(db, y) + eingang - _frist(db, y, eingang)["offen"] - genommen)
            m["naechstes"] = y + 1
        auto = m["rest"][j - 1]
    return (auto if hand is None else hand), auto, hand is not None


def zusatzurlaub(db, j: int) -> int:
    """Zusatzurlaub des Jahres j in Tagen (ur.zusatzurlaub mit den Abschnitten): zählt zum Jahresanspruch, nicht zum gespeicherten Erholungsurlaub."""
    return ur.zusatzurlaub(j, db.abschnitte())


def zusatz_im_uebertrag(db, j: int, uebertrag: float) -> float:
    """Anteil Zusatzurlaub am Übertrag „uebertrag“ aus j − 1 ins Jahr j (ur.zusatz_im_rest). Für die Frist: dieser Teil wird nicht
    angespart (ur.frist_offen_teilen). Keine Fehler."""
    return ur.zusatz_im_rest(uebertrag, db.jahr_einstellung(j - 1)["anspruch"], zusatzurlaub(db, j - 1))

def resturlaub_behalten(db, j: int) -> bool:
    """„Resturlaub behalten“ für das Urlaubsjahr j (Angestellte): der Übertrag aus j − 1 hat dann keine Frist."""
    return db.meta_lesen(RESTURLAUB_BEHALTEN.format(j), "0") == "1"


def _dienst(j: int) -> str:
    """Dienstverhältnis im Urlaubsjahr j (Regel dienstverhaeltnis am 01.01.)."""
    return konfig.fuer(date(j, 1, 1))["dienstverhaeltnis"]


def _behalten_moeglich(j: int) -> bool:
    """„Resturlaub behalten“ gibt es nur, wo der Übertrag ins Jahr j eine Frist mit Verfall „voraussichtlich“ hat (Angestellte und andere)."""
    return j - 1 >= ur.FRIST_AB_HERKUNFT and _dienst(j) == ur.DIENST_ANGESTELLT


def _frist_regel(db, j: int):
    """Frist für den Übertrag ins Urlaubsjahr j: (Frist, ansparen?, sicher?) oder None (Herkunft vor ur.FRIST_AB_HERKUNFT oder
    „Resturlaub behalten“). Beamte Bayern: bis 30.06., Ansparen, wenn das Modul „angespart“ zur Frist an ist, Verfall sicher.
    Eigene Frist: Tag aus resturlaub_frist, Ansparen wie Beamte Bayern nur mit resturlaub_ansparen, Verfall sicher (beide Regeln am 01.01. wie das Dienstverhältnis).
    Angestellte und andere: bis 31.03., ohne Ansparen, Verfall nur voraussichtlich (der Arbeitgeber muss vorher hingewiesen haben)."""
    if j - 1 < ur.FRIST_AB_HERKUNFT:
        return None
    w = konfig.fuer(date(j, 1, 1))
    dienst = w["dienstverhaeltnis"]
    if dienst == ur.DIENST_ANGESTELLT and resturlaub_behalten(db, j):
        return None
    if dienst == ur.DIENST_EIGEN:
        f, ansparen = date(j, *map(int, w["resturlaub_frist"].split("-"))), w["resturlaub_ansparen"]
    else:
        f, ansparen = ur.frist(j, dienst == ur.DIENST_BEAMTE_BY), dienst == ur.DIENST_BEAMTE_BY
    return f, ansparen and "angespart" not in konfig.fuer(f)["module_aus"], dienst != ur.DIENST_ANGESTELLT


KEINE_FRIST = {"frist": None, "offen": 0.0, "angespart": 0.0, "verfallen": 0.0, "sicher": False, "ansparen": False}


def _frist(db, j: int, uebertrag: float) -> dict:
    """Zählregel Resturlaub-Frist (ur.frist_verfall) für den Übertrag „uebertrag“ ins Jahr j: {frist (date oder None), offen (nach der Frist
    aus dem Jahr weggefallen), angespart, verfallen, sicher, ansparen}. Urlaub bis zur Frist zählt ab „ab“; die Start-Urlaubstage (R6) zählen
    für die Person günstig vor der Frist. Ein Konto von Hand des Vorjahres zählt auf den Höchstwert. Angespart wird nur der Teil aus Erholungsurlaub
    (ur.frist_offen_teilen), Zusatzurlaub im Übertrag verfällt. Ohne Frist: KEINE_FRIST. Keine Fehler."""
    regel = _frist_regel(db, j)
    if regel is None:
        return KEINE_FRIST
    f, ansparen, sicher = regel
    tage, eigene, abschnitte, _ = _kontext(db, j)
    bis_frist = summe(tage, eigene, abschnitte, date(j, 1, 1), f, ab=_ab(db), start=db.startwerte_jahr(j))["urlaub"]
    hand = next((k.tage for k in db.konten() if k.herkunft == j - 1), 0)
    erholung, _ = ur.frist_offen_teilen(uebertrag, zusatz_im_uebertrag(db, j, uebertrag), bis_frist)
    # Angespart wird nur Erholungsurlaub (Höchstgrenze: Hälfte des Erholungsurlaubs ohne Zusatz); ein Rest an Zusatzurlaub verfällt an der Frist
    _, angespart, _ = ur.frist_verfall(erholung, 0, db.jahr_einstellung(j - 1)["anspruch"], hand, ansparen)
    offen = max(0.0, float(uebertrag - bis_frist))
    verfallen = offen - angespart
    return {"frist": f, "offen": offen, "angespart": angespart, "verfallen": verfallen, "sicher": sicher, "ansparen": ansparen}


def frist_stand(db, j: int) -> dict:
    """Frist des geltenden Übertrags ins Jahr j (wie _frist); für Konten und Zu tun."""
    return _frist(db, j, _uebertrag(db, j)[0])


def konten(db, bis_jahr: int, heute: date | None = None) -> list:
    """Konten angesparten Urlaubs (ur.Konto): die gespeicherten (von Hand) und für die Herkunftsjahre ab ur.FRIST_AB_HERKUNFT bis bis_jahr − 1
    der automatisch angesparte Zuschlag (_frist), buchbar ab dem Tag nach der Frist. Mit heute nur Zuschläge, deren Frist vor heute liegt
    (Anzeige: das Konto entsteht erst am Tag nach der Frist); ohne heute auch künftige (Buchen und Planen prüfen zuschlag_ab).
    Abgeleitet, nie gespeichert: zwei Geräte und alte Sicherungen zählen nichts doppelt. Nach Herkunftsjahr sortiert. Keine Fehler."""
    alle = {k.herkunft: k for k in db.konten()}
    for y in range(ur.FRIST_AB_HERKUNFT, bis_jahr):
        fr = frist_stand(db, y + 1)
        if fr["angespart"] and (heute is None or heute > fr["frist"]):
            hand = alle[y].tage if y in alle else 0
            alle[y] = ur.Konto(y, hand + fr["angespart"], fr["angespart"], fr["frist"] + timedelta(days=1))
    return [alle[y] for y in sorted(alle)]


def familientage_aktiv(db, j: int) -> bool:
    """Familientage (10 zusätzliche Tage gegen 10 %) sind je Jahr abschaltbar und standardmäßig aus."""
    return str(db.meta_lesen(f"familientage_{j}", "0")) == "1"


def urlaub_stand(db, j: int) -> dict:
    """Stand des Urlaubs eines Jahres: Anspruch (inkl. Zusatzurlaub; erholung = gespeicherter Erholungsurlaub, zusatzurlaub = davon Zusatz), Übertrag, genommen, Rest (nach der Frist ohne den weggefallenen Übertrag; heute = date.today()), Frist des Übertrags
    (frist ISO oder "", frist_vorbei, frist_offen, frist_angespart, frist_verfallen, frist_sicher, frist_ansparen, resturlaub_behalten, behalten_moeglich; Regeln dienstverhaeltnis, resturlaub_frist, resturlaub_ansparen am 01.01.), Gleittage, Familientage, angesparte Konten und Monatsverlauf,
    dazu die Zähler Sonderurlaub und Kind krank mit Jahreslimit, Rest und Dienstverhältnis des Jahres (R5, N5; beide ziehen nichts vom Urlaub ab). Mit Startwerten (R6) zählen
    Start-Urlaub, -Gleittage und -Kind krank im Jahr von ab mit (Felder *_start); im Verlauf zieht der Monat von ab den Start-Urlaub ab."""
    tage, eigene, abschnitte, ein = _kontext(db, j)
    uebertrag, uebertrag_auto, uebertrag_hand = _uebertrag(db, j)
    s = jahr_summe(db, j)
    sw, ab = db.startwerte_jahr(j), _ab(db)
    heute = date.today()                                    # erst zur Laufzeit: die Frist ist ein Stichtag (vorher zählt der Übertrag ganz)
    alle_konten = konten(db, j, heute)
    genommen = angespart_genommen(db)
    verf = ur.angespart_verfuegbar(alle_konten, j, genommen)
    liste = [{"herkunft": k.herkunft, "tage": k.tage, "genommen": genommen.get(k.herkunft, 0), "rest": k.tage - genommen.get(k.herkunft, 0),
              "nutzbar": k.herkunft in verf, "automatisch": k.zuschlag, "von_hand": k.tage - k.zuschlag,
              "automatisch_ab": k.zuschlag_ab.isoformat() if k.zuschlag_ab else ""} for k in alle_konten]
    fr = _frist(db, j, uebertrag)
    vorbei = bool(fr["frist"]) and heute > fr["frist"]
    weg = fr["offen"] if vorbei else 0                      # erst nach der Frist sinkt der Rest wirklich
    # Monatsweise Stand des Erholungsurlaubs (wie Blatt „Urlaub“ der Excel-Datei); nach der Frist fällt im Monat der Frist der offene Übertrag weg
    zusatz = zusatzurlaub(db, j)
    anspruch = ein["anspruch"] + zusatz                  # Jahresanspruch inkl. Zusatzurlaub; ein["anspruch"] bleibt der Erholungsurlaub (Eingabe)
    rest, verlauf = anspruch + uebertrag, []
    for m in range(1, 13):
        sm = _monat_summe(db, j, m, tage, eigene, abschnitte)
        start = sw.urlaub if sw and sw.ab.month == m else 0
        rest -= sm["urlaub"] + start + (weg if vorbei and fr["frist"].month == m else 0)
        verlauf.append({"monat": MONATE[m - 1], "genommen": sm["urlaub"], "angespart": sm["angespart"], "gleittage": sm["gleittage"], "rest_nach": rest,
                        "start": start, "vor_beginn": _vor_beginn(date(j, m, calendar.monthrange(j, m)[1]), ab)})
    return {"jahr": j, "anspruch": anspruch, "erholung": ein["anspruch"], "zusatzurlaub": zusatz,
            "genommen": s["urlaub"], "uebertrag": uebertrag, "uebertrag_auto": uebertrag_auto, "uebertrag_hand": uebertrag_hand,
            "rest": ur.erholung_rest(anspruch + uebertrag - weg, s["urlaub"]),
            "frist": fr["frist"].isoformat() if fr["frist"] else "", "frist_vorbei": vorbei, "frist_offen": fr["offen"], "frist_angespart": fr["angespart"],
            "frist_verfallen": fr["verfallen"], "frist_sicher": fr["sicher"], "frist_ansparen": fr["ansparen"],
            "resturlaub_behalten": resturlaub_behalten(db, j), "behalten_moeglich": _behalten_moeglich(j),
            "gleittage": s["gleittage"], "gleittage_max": regeln.gleittage_max(j), "gleittage_rest": max(0, regeln.gleittage_max(j) - s["gleittage"]),
            "familientage_aktiv": familientage_aktiv(db, j), "familientage": s["familientage"], "familientage_max": regeln.familientage_max(j),
            "familientage_rest": max(0, regeln.familientage_max(j) - s["familientage"]),
            "sonderurlaub": s["sonderurlaub"], "kind_krank": s["kind_krank"], "kind_krank_max": regeln.kind_krank_max(j), "kind_krank_dienst": konfig.fuer_jahr(j)["kind_krank_dienst"], **{k: konfig.fuer(date(j, 1, 1))[k] for k in ("dienstverhaeltnis", *konfig.RESTURLAUB_FRIST_EIGEN)},
            "kind_krank_rest": max(0, regeln.kind_krank_max(j) - s["kind_krank"]),
            "urlaub_start": sw.urlaub if sw else 0, "gleittage_start": sw.gleittage if sw else 0, "kind_krank_start": sw.kind_krank if sw else 0,
            "angespart_genommen_jahr": s["angespart"], "konten": liste,
            "naechstes_konto": ur.naechstes_konto(verf), "verlauf": verlauf, "eigene_frei": [d.isoformat() for d in sorted(ein["eigene_frei"])]}


BRUECKE_RAND = timedelta(days=14)                          # so weit über das Jahr hinaus zählen freie Tage einer Brücke (Jahreswechsel)
BRUECKE_TEXT = "Mit {n} Urlaubstag{e} am {tage} hast du {frei} Tage frei ({von} bis {bis}{anlass})"


def _wt_tag(d: date) -> str:
    """Tag als „Fr 15.05.“."""
    return f"{WT[d.weekday()]} {d:%d.%m.}"


def brueckentage(db, j: int, heute: date = None) -> list:
    """Brückentage-Vorschlag der Seite Urlaub (ur.brueckentage) für das Jahr j: Urlaubstage nur im Jahr j, ab heute (Vorgabe date.today()),
    nur an Tagen ohne Eintrag; frei ist, wer am Tag kein Soll hat (regeln.ist_soll_tag: Feiertage, 24./31.12., eigene freie Tage, Teilzeit und Elternzeit).
    Leer, wenn das Modul Urlaub aus ist. Rückgabe: [{"urlaub": [JJJJ-MM-TT], "von", "bis", "tage", "frei", "anlass", "text"}]. Keine Fehler."""
    if "urlaub" in (konfig.CFG.get("module_aus") or []):
        return []
    heute = heute or date.today()
    jahre = (j - 1, j, j + 1)
    eigene, abschnitte = eigene_frei(db, jahre), db.abschnitte()
    # Anlass ist nur ein benannter Tag, der sonst ein Arbeitstag wäre (Feiertag am Wochenende oder am freien Teilzeit-Tag bringt nichts)
    namen = {d: n for d, n in tag_namen(db, jahre).items() if regeln.ist_planmaessiger_arbeitstag(d, abschnitte)}
    belegt = {t.datum for y in jahre for t in db.tage(y)}
    start, ende = date(j, 1, 1) - BRUECKE_RAND, date(j, 12, 31) + BRUECKE_RAND
    tage = [start + timedelta(days=i) for i in range((ende - start).days + 1)]
    vorschlaege = ur.brueckentage(tage, partial(_bruecke_arbeitet, eigene=eigene, abschnitte=abschnitte), namen,
                                  lambda d: d.year == j and d >= heute and d not in belegt)
    return [_bruecke(url, von, bis, namen) for url, von, bis in vorschlaege]


def _bruecke_arbeitet(d: date, eigene, abschnitte):
    """Zustand eines Tags für ur.brueckentage: True = Soll-Tag, False = frei, None = im Abschnitt ohne Stunden (Elternzeit, zählt nicht als gewonnen)."""
    a = regeln.abschnitt_fuer(d, abschnitte)
    if a is not None and a.wochenstunden <= 0:
        return None
    return regeln.ist_soll_tag(d, eigene, abschnitte)


def _bruecke(url: list, von: date, bis: date, namen: dict) -> dict:
    """Ein Vorschlag als Antwort mit Satz für die Karte; anlass = die Namen der freien Tage im Zeitraum."""
    anlass = ", ".join(dict.fromkeys(namen[d] for d in sorted(namen) if von <= d <= bis))
    frei = (bis - von).days + 1
    text = BRUECKE_TEXT.format(n=len(url), e="en" if len(url) > 1 else "", tage=" und ".join(map(_wt_tag, url)), frei=frei,
                               von=_wt_tag(von), bis=_wt_tag(bis), anlass=f", {anlass}" if anlass else "")
    return {"urlaub": [d.isoformat() for d in url], "von": von.isoformat(), "bis": bis.isoformat(), "tage": len(url), "frei": frei, "anlass": anlass, "text": text}


ATTEST_AB_TAG = 4                                           # ab diesem Kranktag einer Phase ist ein Attest nötig
ATTEST_FEHLT = f"Attest fehlt (ab Tag {ATTEST_AB_TAG})"
KRANK_STATUS = ("attest", "ohne", "fehlt", "dienst", "frei")  # Status einer Krankphase; die Oberfläche braucht für jeden einen Text


def krank(db, j: int, heute: date = None) -> dict:
    """Kranktage eines Jahres als Liste und in Phasen (Tage in Folge), mit Hinweis „Attest fehlt“ ab dem 4. Tag ohne Attest.
    Mit Startwerten (R6): Kranktage = Startwert (krank_start) + gezählte Tage; Einträge vor ab bleiben in der Liste (zaehlt False, vor_beginn,
    Hinweis VOR_BEGINN), bilden aber keine Phase und zählen nicht in ohne_attest (der Startwert auch nicht: er hat keine einzelnen Tage).
    Phasen werden wie in _zeitraeume über den Jahreswechsel verfolgt (Einträge aus j − 1 bis j + 1), damit ab dem 4. Tag einer Phase vom
    Dezember das Attest auch im Januar fehlt; gezeigt werden Phasen mit einem Tag im Jahr j, im Jahr gekappt; Liste und Kennzahlen bleiben beim Jahr j.
    heute (Vorgabe date.today()) entscheidet, ob eine Phase noch läuft (_laeuft_noch)."""
    jahre = (j - 1, j, j + 1)
    tage = [t for y in jahre for t in db.tage(y)]
    eigene, abschnitte = eigene_frei(db, jahre), db.abschnitte()
    s = jahr_summe(db, j)
    ab = _ab(db)
    liste = {}
    for t in tage:
        if t.art in regeln.KRANK or t.art == regeln.KRANK_IM_DIENST:
            vor = _vor_beginn(t.datum, ab)
            liste[t.datum] = {"datum": de(t.datum), "iso": t.datum.isoformat(), "wt": WT[t.datum.weekday()], "art": ARTEN[t.art],
                              "zaehlt": not vor and regeln.zaehlt_als_krank(t.datum, t.art, eigene, abschnitte), "vor_beginn": vor, "notiz": t.notiz,
                              "attest": de(date.fromisoformat(t.attest)) if t.attest else "", **({"hinweis": VOR_BEGINN} if vor else {})}
    # Phasen trennen wie die Zeiträume der Übersicht (regeln.unterbricht_krank); „Krank im Dienst“ gehört zur Phase
    trenner = partial(regeln.unterbricht_krank, eigene=eigene, abschnitte=abschnitte)
    gruppen = regeln.zeitraeume_bilden(sorted(d for d in liste if not _vor_beginn(d, ab)), trenner)
    heute = heute or date.today()
    phasen = [_krank_phase([liste[d] for d in g], j, _laeuft_noch(g[-1], heute, trenner)) for g in gruppen if any(d.year == j for d in g)]
    liste = [e for d, e in sorted(liste.items()) if d.year == j]
    fehlt_n = sum(1 for e in liste if e.get("hinweis") == ATTEST_FEHLT)
    return {"jahr": j, "kranktage": s["krank"], "krank_start": s["krank_start"], "attest": s["krank_attest"], "im_dienst": s["krank_dienst"],
            "attest_fehlt": fehlt_n, "liste": liste, "phasen": list(reversed(phasen)), "ohne_attest": s["krank"] - s["krank_start"] - s["krank_attest"]}


def _laeuft_noch(bis: date, heute: date, trenner) -> bool:
    """True, wenn eine Krankphase mit letztem Tag bis am Tag heute noch läuft: Von bis (ausschließlich) bis heute (einschließlich) liegt
    kein Tag, der Phasen trennt (regeln.unterbricht_krank). Wochenenden, Feiertage und freie Tage der Teilzeit verlängern sie also. Keine Fehler."""
    return not any(trenner(bis + timedelta(days=n)) for n in range(1, (heute - bis).days + 1))


def _krank_phase(phase: list, jahr: int = None, laeuft: bool = True) -> dict:
    """Eine Krankphase (Einträge der Liste in Folge) mit Status und Tagen. Ohne Attest sind bis zu 3 Kranktage in Folge erlaubt; ab dem 4. gezählten Tag
    ohne Attest bekommt der Eintrag den Hinweis „Attest fehlt“, nur solange die Phase noch läuft (laeuft; vergangene: ein nötiges Attest war da).
    Eingaben: Einträge der Krank-Liste (mit zaehlt, attest, art, notiz). Rückgabe: Angaben der Phase (Von, Bis, gezählte Tage, Status aus
    KRANK_STATUS: attest, ohne oder fehlt mit gezählten Tagen; ohne gezählten Tag dienst, wenn „Krank im Dienst“ dabei ist, sonst frei).
    Mit jahr: Attest und Status aus der ganzen Phase (auch über den Jahreswechsel), Von, Bis, Tage und Liste nur aus den Einträgen dieses Jahres
    (gekappt wie die Zeiträume der Übersicht, damit die Summe der Phasen die Kranktage des Jahres ist). Setzt „hinweis“ in den Einträgen. Keine Fehler."""
    zaehl = [e for e in phase if e["zaehlt"]]
    attest = next((e["attest"] for e in phase if e["attest"]), "")
    fehlt = laeuft and len(zaehl) > ATTEST_AB_TAG - 1 and not attest
    if fehlt:
        for e in zaehl[ATTEST_AB_TAG - 1:]:
            e["hinweis"] = ATTEST_FEHLT
    dienst = ARTEN[regeln.KRANK_IM_DIENST]
    ohne_tag = "dienst" if any(e["art"] == dienst for e in phase) else "frei"
    status = ohne_tag if not zaehl else ("attest" if attest else ("fehlt" if fehlt else "ohne"))
    phase = [e for e in phase if jahr is None or e["iso"][:4] == str(jahr)]
    noten = []
    for e in phase:
        if e["notiz"] and e["notiz"] not in noten:
            noten.append(e["notiz"])
    return {"von": phase[0]["iso"], "bis": phase[-1]["iso"], "von_text": phase[0]["datum"], "bis_text": phase[-1]["datum"], "tage": sum(e["zaehlt"] for e in phase),
            "im_dienst": sum(1 for e in phase if e["art"] == dienst), "attest": attest, "status": status, "notiz": " · ".join(noten),
            "tage_liste": [{"wt": e["wt"], "datum": e["datum"][:6], "zaehlt": e["zaehlt"], "dienst": e["art"] == dienst} for e in phase]}


def steuer(db, j: int, zeitformat: str = "hhmm") -> dict:
    """Zahlen für die Homeoffice-Übersicht eines Jahres: Tage je Art, HO- und Büro-Stunden, Quote, Zeiträume für Krank und Elternzeit.
    Mit Startwerten im Jahr von ab (R6): Zahlen mit dem Stand bis zum Vortag, start (Wörterbuch: ab und die Zählwerte regeln.START_FELDER) und
    stand_bis (TT.MM.JJJJ, sonst leer); Zeiträume nur aus Tagen ab ab. Stunden im Zeitformat (Minuten in jahr_summe)."""
    s = jahr_summe(db, j)
    ab = _ab(db)
    start = s["start"] and {k: s["start"][k] for k in ("ab",) + regeln.START_FELDER}      # ohne Gleitzeit- und Freizeitkonto: die Übersicht kann an Dritte gehen
    return {"jahr": j, "start": start, "stand_bis": de(ab - timedelta(days=1)) if start else "", "urlaub": s["urlaub"], "angespart": s["angespart"], "gleittage": s["gleittage"], "krank": s["krank"], "krank_attest": s["krank_attest"],
            "krank_dienst": s["krank_dienst"], "familientage": s["familientage"], "sonderurlaub": s["sonderurlaub"], "kind_krank": s["kind_krank"], "ho_tage": s["ho_tage"], "dst_tage": s["dst_tage"], "elternzeit_tage": s["elternzeit_tage"],
            "ho_stunden": fmt_dauer(s["ho_min"], zeitformat), "dst_stunden": fmt_dauer(s["dst_min"], zeitformat), "quote": fmt_prozent(s["quote"]),
            **_zeitraeume(db, j)}


def _zeitraeume(db, j: int) -> dict:
    """Elternzeit und Kranktage des Jahres als Zeiträume (Von–Bis, Anzahl Tage), über die Jahresgrenze verfolgt, im Jahr gekappt und gekennzeichnet.
    „Krank im Dienst“ zählt nicht als Krank und trennt (es ist ein Arbeitstag). Nur Tage ab „ab“ bilden Zeiträume (R6)."""
    # shortcut: nur die Nachbarjahre werden geladen; eine Lücke ohne Arbeitstag über mehr als ein Jahr gibt es praktisch nicht
    jahre = (j - 1, j, j + 1)
    im = {t.datum: t for y in jahre for t in db.tage(y)}
    eigene = eigene_frei(db, jahre)
    abschnitte = db.abschnitte()
    ab = _ab(db)
    alle = regeln.tage_im_zeitraum(max(date(j - 1, 1, 1), ab or date.min), date(j + 1, 12, 31))
    eltern = [d for d in alle if regeln.zaehlt_als_elternzeit(d, getattr(im.get(d), "art", ""), eigene, abschnitte)]
    krank = [d for d in sorted(im) if not _vor_beginn(d, ab) and regeln.zaehlt_als_krank(d, im[d].art, eigene, abschnitte)]
    werktag = partial(regeln.ist_werktag, eigene=eigene)
    trenner = partial(regeln.unterbricht_krank, eigene=eigene, abschnitte=abschnitte)
    return {"elternzeit_zeitraeume": [z for z, _ in _im_jahr(regeln.zeitraeume_bilden(eltern, werktag), j)],
            "krank_zeitraeume": [{**z, **_attest(im, tage)} for z, tage in _im_jahr(regeln.zeitraeume_bilden(krank, trenner), j)]}


ZEITRAUM_VORHER = "begann vor {jahr}"                       # Hinweis an einem Zeitraum über die Jahresgrenze
ZEITRAUM_WEITER = "geht {jahr} weiter"


def _im_jahr(gruppen, j: int):
    """Je Zeitraum aus gezählten Tagen, der ins Jahr j fällt: (Angaben, Tage im Jahr). Von und Bis sind der erste und letzte gezählte Tag im Jahr;
    ein Zeitraum über die Jahresgrenze wird aufs Jahr gekappt und gekennzeichnet.
    Eingaben: Zeiträume aus regeln.zeitraeume_bilden, Jahr. Rückgabe: Paare (Angaben mit von, bis, tage, ab_vorjahr, ins_folgejahr, hinweis; Tage im Jahr).
    Zeiträume ohne Tag im Jahr fallen weg. Keine Fehler."""
    for g in gruppen:
        tage = [d for d in g if d.year == j]
        if not tage:
            continue
        vor, nach = g[0].year < j, g[-1].year > j
        hinweis = ", ".join(x for x in (ZEITRAUM_VORHER.format(jahr=j) if vor else "", ZEITRAUM_WEITER.format(jahr=j + 1) if nach else "") if x)
        yield {"von": de(tage[0]), "bis": de(tage[-1]), "tage": len(tage), "ab_vorjahr": vor, "ins_folgejahr": nach, "hinweis": hinweis}, tage


ATTEST_MIT, ATTEST_OHNE = "mit Attest", "ohne Attest"       # Attest-Text eines Krank-Zeitraums (in allen Exporten)
ATTEST_TEILWEISE = "teilweise mit Attest ({mit} von {alle} Tagen)"


def _attest(im, tage) -> dict:
    """Attest-Angaben eines Krank-Zeitraums: mit, ohne oder teilweise (n von m Tagen) und die Abgabe-Daten.
    Eingaben: Einträge nach Datum, gezählte Kranktage des Zeitraums (alle in im). Rückgabe: attest_tage, attest_text, attest_datum (TT.MM.JJJJ, mit Komma). Keine Fehler."""
    mit = [d for d in tage if im[d].art == regeln.KRANK_ATTEST or im[d].attest]
    daten = sorted({im[d].attest for d in tage if im[d].attest})
    text = ATTEST_MIT if mit and len(mit) == len(tage) else (ATTEST_TEILWEISE.format(mit=len(mit), alle=len(tage)) if mit else ATTEST_OHNE)
    return {"attest_tage": len(mit), "attest_text": text, "attest_datum": ", ".join(de(date.fromisoformat(x)) for x in daten)}


_ZEILEN = [("Urlaubstage (Erholungsurlaub)", "urlaub"), ("Angesparter Urlaub (Tage)", "angespart"), ("Gleittage", "gleittage"),
           ("Kranktage (ohne „Krank im Dienst“)", "krank"), ("davon mit Attest", "krank_attest"),
           ("Tage im Homeoffice (nur HO, ohne Büro)", "ho_tage"), ("Tage im Büro (auch mit HO am selben Tag)", "dst_tage"),
           ("Tage in Elternzeit", "elternzeit_tage"), ("Krank im Dienst (kein Kranktag, Fehlzeit aufgefüllt)", "krank_dienst"),
           ("Sonderurlaub (Tage)", "sonderurlaub"), ("Kind krank (Tage)", "kind_krank")]
STAND_BIS = "Stand bis {datum} (Startwerte)"                # Block der Startwerte in der Übersicht (R8, nur im Jahr von „ab“)
KRANK_VOR_BEGINN = "davon " + VOR_BEGINN


def uebersicht_zeilen(s: dict, zeitformat: str = "hhmm") -> list:
    """Zeilen der Homeoffice-Übersicht [Angabe, Wert] für CSV, Excel und Dokumente (R8), Tage als Zahl: die Zählungen, „davon vor Beginn der
    Erfassung“ unter den Kranktagen, Stunden und Quote, mit Startwerten am Ende der Block „Stand bis …“. Texte fest im Code (keine Eingaben).
    zeitformat: wie bei steuer (die Stunden der Startwerte liegen in s nur als Minuten vor). Fehler: ValueError bei unbekanntem Zeitformat."""
    z = []
    for text, k in _ZEILEN:
        z.append([text, s[k]])
        if k == "krank" and s["start"] and s["start"]["krank"]:     # 0 vor Beginn: keine Zeile (Fehler 23.11.2026)
            z.append([KRANK_VOR_BEGINN, s["start"]["krank"]])
    z += [["HO-Stunden", s["ho_stunden"]], ["Büro-Stunden", s["dst_stunden"]], ["HO-Quote", s["quote"]]]
    return z + _start_zeilen(s, zeitformat)


def _start_zeilen(s: dict, zeitformat: str) -> list:
    """Block „Stand bis TT.MM.JJJJ (Startwerte)“ der Übersicht, Stunden im Zeitformat; Kind krank nur mit eingeschaltetem Modul; leer ohne Startwerte im Jahr."""
    st = s["start"]
    if not st:
        return []
    z = [[STAND_BIS.format(datum=s["stand_bis"]), ""], ["HO-Stunden", fmt_dauer(st["ho_min"], zeitformat)], ["Büro-Stunden", fmt_dauer(st["dst_min"], zeitformat)],
         ["Urlaubstage", st["urlaub"]], ["Gleittage", st["gleittage"]], ["Kranktage", st["krank"]]]
    if regeln.KIND_KRANK not in (konfig.CFG.get("module_aus") or []):
        z.append(["Kind krank (Tage)", st["kind_krank"]])
    return z


UEBERSICHT = "Homeoffice-Übersicht"                          # Titel der Jahresübersicht (informativ, kein Steuer-Nachweis)
UEBERSICHT_DATEI = "Homeoffice-Uebersicht"                   # derselbe Titel im Dateinamen (nur ASCII)


ELTERNZEIT_TITEL, KRANK_TITEL = "Elternzeit", "Kranktage"
ELTERNZEIT_KOPF = ["Von", "Bis", "Tage", "Hinweis"]
KRANK_KOPF = ["Von", "Bis", "Tage", "Attest", "Attest abgegeben am", "Hinweis"]


def elternzeit_zeilen(s: dict) -> list:
    """Zeilen der Elternzeit-Zeiträume für Tabellen (alle Exporte); Tage als Zahl."""
    return [[e["von"], e["bis"], e["tage"], e["hinweis"]] for e in s["elternzeit_zeitraeume"]]


def krank_zeilen(s: dict) -> list:
    """Zeilen der Krank-Zeiträume für Tabellen (alle Exporte); Tage als Zahl."""
    return [[k["von"], k["bis"], k["tage"], k["attest_text"], k["attest_datum"], k["hinweis"]] for k in s["krank_zeitraeume"]]


def zeitraum_tabellen(s: dict) -> list:
    """Die Tabellen Elternzeit und Kranktage als (Titel, Kopf, Zeilen), gleich für CSV, PDF, Word, ODT, ODS, Markdown und Text."""
    return [(ELTERNZEIT_TITEL, ELTERNZEIT_KOPF, elternzeit_zeilen(s)), (KRANK_TITEL, KRANK_KOPF, krank_zeilen(s))]


def steuer_csv(s: dict, zeitformat: str = "hhmm") -> str:
    """Homeoffice-Übersicht als CSV-Text (Semikolon, mit BOM und Vermerk); zeitformat wie bei uebersicht_zeilen."""
    z = [f"{UEBERSICHT} {s['jahr']};Anzahl"]
    z += [f"{t};{w}" for t, w in uebersicht_zeilen(s, zeitformat)]
    for titel, kopf, zeilen in zeitraum_tabellen(s):
        z += ["", titel, ";".join(kopf)] + [";".join(map(str, zeile)) for zeile in zeilen]
    z += ["", VERMERK]
    return "\ufeff" + "\r\n".join(z) + "\r\n"


def woche(db, j: int, kw: int, zeitformat: str = "hhmm", jetzt: datetime = None) -> dict:
    """Eine ISO-Kalenderwoche (Mo–So) mit Tageswerten, Wochensaldo und Gleitzeit-Konto (Dauern und Salden im Zeitformat „hhmm“ oder „dezimal“). ist_min: HO + Büro an Arbeitstagen bis heute (ohne
    Arbeit an freien Tagen, die zählt zum Freizeitkonto); ist_soll_min das Ist mit Auffüllung bei „Krank im Dienst“; Text „ist“ und Saldo
    rechnen mit ist_soll_min. Künftige Tage zählen nur mit ihren
    gearbeiteten Minuten, weil ihr Soll im Saldo noch fehlt (sonst ergäbe die Auffüllung ein Plus ohne Arbeit). wochenziel: woche.wochenziel_balken
    (Ist gegen Soll der ganzen Woche, Marke Soll bis heute); tagesziel: der heutige Tag der laufenden Woche (_tagesziel, sonst TAGESZIEL_LEER);
    kappung: Text der Kappung, wenn ein Stichtag bis heute in der Woche liegt (sonst ""). jetzt (Vorgabe: Uhrzeit des Rechners) setzen nur Tests."""
    try:
        montag = date.fromisocalendar(j, kw, 1)
    except ValueError:
        raise konfig.Meldung("Ungültige Kalenderwoche")
    sonntag = montag + timedelta(days=6)
    heute_ = jetzt.date() if jetzt else date.today()
    abschnitte = db.abschnitte()
    ab = _ab(db)
    jahre = sorted({montag.year, sonntag.year})
    tage, eigene, namen = {}, eigene_frei(db, jahre), tag_namen(db, jahre)
    for y in jahre:
        for t in db.tage(y):
            tage[t.datum] = t
    zeilen, ist_soll_s, ist_s, soll_s, soll_woche, soll_konto, fz_s = [], 0, 0, 0, 0, 0, 0
    soll_bis_heute, heute_zeile = 0, None                    # für das Wochenziel: Montag bis einschließlich heute
    for n in range(7):
        d = montag + timedelta(days=n)
        t = tage.get(d)
        z = _zeile(d, t, eigene, abschnitte, namen, ab, zeitformat)
        ist, ist_soll = z["ist_min"], z["ist_soll_min"]
        soll = wo.soll_tag(d, t, eigene, abschnitte)
        fz = 0 if z["vor_beginn"] else wo.freizeit_tag(d, t, eigene, abschnitte)      # vor „ab“ (R6) auch nicht im Freizeitkonto
        if d == heute_:
            heute_zeile = (z, ist_frei(d, eigene) and not z["vor_beginn"])   # z wird unten noch ergänzt; Arbeit an freien Tagen geht ins Freizeitkonto
        if z["vor_beginn"] or ist_frei(d, eigene):                # ohne Soll und Saldo: Tag vor „ab“ (bleibt sichtbar); Arbeit an Wochenende/Feiertag geht aufs Freizeitkonto statt in die Gleitzeit
            z.update({"monat": d.month, "jahr": d.year, "ist": fmt_dauer(ist, zeitformat) if ist else "", "soll_min": 0, "arbeit_min": 0, "saldo": "", "saldo_min": 0, "zukunft": d > heute_,
                      "freizeit": wo.fmt_saldo(fz, zeitformat) if fz else "", "freizeit_min": fz})
            zeilen.append(z)
            fz_s += fz if d <= heute_ else 0
            continue
        z.update({"freizeit": wo.fmt_saldo(fz, zeitformat) if fz else "", "freizeit_min": fz})
        fz_s += fz if d <= heute_ else 0
        arbeit = 0 if t is not None and t.art == "gleittag" else soll      # am Gleittag bleibt das Soll fürs Konto stehen, gearbeitet wird nicht
        z.update({"monat": d.month, "jahr": d.year, "ist": fmt_dauer(ist_soll, zeitformat) if ist_soll else "", "soll_min": soll, "arbeit_min": arbeit,
                  "saldo": wo.fmt_saldo(ist_soll - soll, zeitformat) if (ist_soll or soll) else "", "saldo_min": ist_soll - soll, "zukunft": d > heute_})
        zeilen.append(z)
        if d <= heute_:
            soll_bis_heute += arbeit
        soll_woche += arbeit                                      # zu arbeitende Zeit der ganzen Woche (ohne Urlaub, Krank, Gleittage); „soll“ zählt für den Saldo nur bis heute
        soll_konto += soll                                        # Soll der ganzen Woche wie im Konto (mit Gleittag)
        if d <= heute_ or ist:
            ist_s += ist
            ist_soll_s += ist_soll if d <= heute_ else ist
            soll_s += soll if d <= heute_ else 0
    ende = min(sonntag, heute_)
    vor, nach = montag - timedelta(days=7), montag + timedelta(days=7)
    return {"jahr": j, "kw": kw, "von": montag.isoformat(), "bis": sonntag.isoformat(), "tage": zeilen,
            "ist": fmt_dauer(ist_soll_s, zeitformat), "ist_min": ist_s, "ist_soll_min": ist_soll_s, "aufgefuellt_min": ist_soll_s - ist_s, "soll": fmt_dauer(soll_s, zeitformat), "soll_woche": fmt_dauer(soll_woche, zeitformat), "soll_woche_min": soll_woche,
            "saldo_woche_min": ist_soll_s - soll_konto,   # Ist minus Soll der ganzen Woche wie im Konto (negativ: es fehlt noch Zeit)
            "saldo": wo.fmt_saldo(ist_soll_s - soll_s, zeitformat), "saldo_min": ist_soll_s - soll_s,
            "konto": wo.fmt_saldo(wo.konto(db, ende), zeitformat), "konto_min": wo.konto(db, ende), "konto_anfang": wo.fmt_saldo(wo.konto(db, montag - timedelta(days=1)), zeitformat),
            "freizeit_woche": wo.fmt_saldo(fz_s, zeitformat), "freizeit_woche_min": fz_s, "freizeit_konto": wo.fmt_saldo(wo.freizeit_konto(db, ende), zeitformat), "freizeit_konto_min": wo.freizeit_konto(db, ende),
            "wochenziel": wo.wochenziel_balken(soll_woche, ist_soll_s, soll_bis_heute, zeitformat),
            "tagesziel": _tagesziel(db, *heute_zeile, jetzt, zeitformat) if heute_zeile else dict(TAGESZIEL_LEER),
            "kappung": " · ".join(wo.kappung_text(k, zeitformat) for k in wo.kappungen(db, ende) if montag <= k["datum"] and k["verfallen_min"]),
            "familientage_aktiv": familientage_aktiv(db, j), "heute_in_woche": montag <= heute_ <= sonntag, "vor": list(vor.isocalendar()[:2]), "nach": list(nach.isocalendar()[:2])}


TAGESZIEL_LEER = {"satz": "", "gehen": "", "saldo_heute": "", "saldo_heute_min": 0, "soll_tag": "", "soll_tag_min": 0, "freizeit": False}


def _tagesziel(db, z: dict, frei: bool, jetzt, zeitformat: str) -> dict:
    """Feld „tagesziel“ von woche für den heutigen Tag (Zeile z der Woche, frei: Wochenende, Feiertag oder eigener freier Tag): Satz und Gehen-Zeit
    von woche.tagesziel_satz (nur mit Tagessoll), Saldo des Tages ohne die laufende Uhr (die Oberfläche rechnet sie live dazu), Tagessoll und
    freizeit (an einem freien Tag gearbeitet oder die Uhr läuft dort seit heute: zählt zum Freizeitkonto). Keine Fehler."""
    beginn, lauf = _uhr_heute(db, jetzt, date.fromisoformat(z["datum"]))
    soll = z["arbeit_min"]
    ziel = wo.tagesziel_satz(soll - z["ist_soll_min"], z["ist_min"], beginn, lauf, date.fromisoformat(z["datum"]), zeitformat) if soll > 0 else TAGESZIEL_LEER
    return {"satz": ziel["satz"], "gehen": ziel["gehen"], "saldo_heute": z["saldo"], "saldo_heute_min": z["saldo_min"],
            "soll_tag": fmt_dauer(soll, zeitformat), "soll_tag_min": soll, "freizeit": frei and (z["freizeit_min"] > 0 or beginn is not None)}


def _uhr_heute(db, jetzt, heute_: date) -> tuple:
    """(Beginn in Minuten ab Mitternacht, Minuten bis jetzt) der Stempeluhr, wenn sie heute gestartet wurde; sonst (None, 0), auch wenn sie seit
    einem früheren Tag läuft (sie bucht auf jenen Tag). jetzt (None: Uhrzeit des Rechners) setzen nur Tests."""
    uhr = db.stempel_lesen()
    if not uhr:
        return None, 0
    beginn = uhr["start"].replace(tzinfo=None)              # Wanduhrzeit wie die Stempeluhr bei einem jetzt ohne Versatz
    if beginn.date() != heute_:
        return None, 0
    jetzt = jetzt or datetime.combine(heute_, datetime.now().time())
    return beginn.hour * 60 + beginn.minute, max(0, int((jetzt - beginn).total_seconds()) // 60)


def gleitzeit(db, zeitformat: str = "hhmm") -> dict:
    """Stand des Gleitzeit-Kontos und des Freizeitkontos heute, jeweils mit Startwert (Texte als Saldo im Zeitformat);
    kappung: Hinweis auf die letzte Kappung (kappung_hinweis) oder None."""
    k = wo.konto(db, date.today())
    f = wo.freizeit_konto(db, date.today())
    saldo = partial(wo.fmt_saldo, zeitformat=zeitformat)
    return {"konto": saldo(k), "konto_min": k, "start": saldo(wo.startsaldo(db)), "start_min": wo.startsaldo(db),
            "freizeit": saldo(f), "freizeit_min": f, "freizeit_start": saldo(wo.freizeit_start(db)), "freizeit_start_min": wo.freizeit_start(db),
            "kappung": kappung_hinweis(db, date.today(), zeitformat)}


SALDO_SCHRITTE = ("tag", "woche")
SALDO_TAGE_MAX = 400                                       # so viele Tage höchstens je Abfrage der Saldo-Punkte (reicht für ein Jahr Wochen)
SALDO_SCHRITT_FEHLER = "Schritt: tag oder woche"
SALDO_REIHENFOLGE_FEHLER = "„von“ liegt nach „bis“"
SALDO_LAENGE_FEHLER = f"Höchstens {SALDO_TAGE_MAX} Tage"


def saldo_punkte(db, von: date, bis: date, schritt: str = "tag", heute: date = None) -> dict:
    """Punkte der kleinen Saldo-Verläufe der Übersicht (GET /api/gleitzeit/saldo, Entscheidung des Entwicklers vom 24.11.2026), ohne laufende Uhr
    (die Oberfläche rechnet sie live dazu). schritt „tag“: je Tag mit Soll von „von“ bis min(bis, heute) ab dem Beginn des Kontos der Beitrag zum
    Gleitzeit-Konto (woche.saldo_tag; ein Gleittag zählt mit −Tagessoll), kw None. „woche“: je ISO-Woche, die den Zeitraum berührt, der Saldo wie
    bericht.woche (bis heute), datum = Montag, kw gesetzt, auch über Jahresgrenzen. Rückgabe: {"punkte": [{datum, kw, saldo_min, ist_min, soll_min}]}.
    Fehler: konfig.Meldung bei unbekanntem Schritt, von nach bis oder mehr als SALDO_TAGE_MAX Tagen (Daten 1970–2200 prüft die Route)."""
    if schritt not in SALDO_SCHRITTE:
        raise konfig.Meldung(SALDO_SCHRITT_FEHLER)
    if von > bis:
        raise konfig.Meldung(SALDO_REIHENFOLGE_FEHLER)
    if (bis - von).days + 1 > SALDO_TAGE_MAX:
        raise konfig.Meldung(SALDO_LAENGE_FEHLER)
    heute = heute or date.today()
    beginn = wo._beginn(db, db.tage_alle())
    if beginn is None:
        return {"punkte": []}
    von, bis = max(von, beginn), min(bis, heute)
    return {"punkte": _saldo_tage(db, von, bis) if schritt == "tag" else _saldo_wochen(db, von, bis, heute)}


def _saldo_tage(db, von: date, bis: date) -> list:
    """Beitrag jedes Tages mit Soll zum Gleitzeit-Konto von „von“ bis „bis“ (beide schon auf Beginn und heute begrenzt)."""
    tage, abschnitte = {t.datum: t for t in db.tage_alle()}, db.abschnitte()
    eigene = eigene_frei(db, range(von.year, bis.year + 1))
    punkte = []
    for d in regeln.tage_im_zeitraum(von, bis):
        soll = wo.soll_tag(d, tage.get(d), eigene, abschnitte)
        if soll > 0:
            s = wo.saldo_tag(d, tage.get(d), eigene, abschnitte)
            punkte.append({"datum": d.isoformat(), "kw": None, "saldo_min": s, "ist_min": s + soll, "soll_min": soll})
    return punkte


def _saldo_wochen(db, von: date, bis: date, heute: date) -> list:
    """Saldo jeder ISO-Woche, die von „von“ bis „bis“ berührt, wie bericht.woche zum Zeitpunkt heute (Soll bis heute)."""
    punkte, montag = [], von - timedelta(days=von.weekday())
    jetzt = datetime.combine(heute, datetime.min.time())
    while montag <= bis:
        j, kw = montag.isocalendar()[:2]
        w = woche(db, j, kw, jetzt=jetzt)
        punkte.append({"datum": montag.isoformat(), "kw": kw, "saldo_min": w["saldo_min"], "ist_min": w["ist_soll_min"], "soll_min": w["ist_soll_min"] - w["saldo_min"]})
        montag += timedelta(days=7)
    return punkte


KAPPUNG_HINWEIS_TAGE = 365                                 # so lange nach dem Stichtag steht „gekappt am …“ an der Gleitzeit


def kappung_hinweis(db, heute: date, zeitformat: str = "hhmm"):
    """Letzte Kappung mit verfallenen Minuten am Stichtag oder bis KAPPUNG_HINWEIS_TAGE danach: {datum, verfallen_min, text}; sonst None."""
    ks = [k for k in wo.kappungen(db, heute) if k["verfallen_min"] and (heute - k["datum"]).days < KAPPUNG_HINWEIS_TAGE]
    if not ks:
        return None
    k = ks[-1]
    return {"datum": k["datum"].isoformat(), "verfallen_min": k["verfallen_min"], "text": wo.kappung_text(k, zeitformat)}


def kappung_jahr(db, jahr: int, zeitformat: str = "hhmm") -> dict:
    """Kappung im Jahr für die Einstellungen (GET /api/kappung/<J>): Stichtag, ob dort gekappt wird, Grenze und genehmigte Übernahme.
    Stichtag und an kommen aus woche.kappungstage (Regel am Stichtag selbst, wie gerechnet wird); ohne Kappung im Jahr der Stichtag der Jahresregel."""
    tage = wo.kappungstage(date(jahr, 1, 1), date(jahr, 12, 31))
    stichtag = tage[-1] if tage else wo.stichtag_im_jahr(jahr, konfig.fuer_jahr(jahr)["kappung_stichtag"])
    u = db.kappung_uebernahme(jahr)
    return {"jahr": jahr, "stichtag": stichtag.isoformat(), "an": bool(tage), "grenze_min": konfig.fuer(stichtag)["kappung_grenze_min"],
            "uebernahme_min": u, "uebernahme": fmt_dauer(u, zeitformat)}


# Meldung, wenn ein vorbelegtes Konto über der Grenze liegt: Die Person hat den Wert nicht eingegeben, also Stand und Weg nennen
VORTAG_FEHLER = {"gleitzeit_min": "Gleitzeit-Konto am Vortag: {stand}. Bitte einen Stand bis ±{grenze} eintragen.",
                 "freizeit_min": "Freizeitkonto am Vortag: {stand}. Bitte zuerst dessen Stand auf höchstens ±{grenze} setzen."}
UEBERTRAG_UEBERNOMMEN = "Übertrag {jahr}: {tage} Tage von Hand übernommen"


def startwerte_stand(db, ab: date = None, heute: date = None) -> dict:
    """Startwerte für die Karte „Erfassung gültig ab“ (R6, GET /api/startwerte): die neun Felder wie gespeichert (ohne Startwerte ab "" und 0),
    dazu ho, dst (hh:mm), gleitzeit (±hh:mm) und stand_bis (TT.MM.JJJJ des Vortags von ab, sonst leer). Mit ab: Vorbelegung für dieses Datum,
    gleitzeit_min wie woche.konten_am_vortag (Konto am Ende von ab − 1; beim Vorverlegen von ab so, dass der Stand bleibt). Schreibt nichts.
    Fehler: KonfigFehler (ein ValueError), wenn ab nach heute liegt (Vorgabe: heute)."""
    sw = db.startwerte_lesen()
    werte = sw.werte() if sw else {"ab": "", **{f: 0 for f in konfig.STARTWERTE_NAMEN}}
    if ab is not None:
        if ab > (heute or date.today()):
            raise konfig.KonfigFehler(konfig.STARTWERTE_ZUKUNFT)
        werte.update(ab=ab.isoformat(), gleitzeit_min=wo.konten_am_vortag(db, ab)["gleitzeit_min"])
    beginn = date.fromisoformat(werte["ab"]) if werte["ab"] else None
    return {**werte, "ho": fmt_hhmm(werte["ho_min"]), "dst": fmt_hhmm(werte["dst_min"]), "gleitzeit": wo.fmt_saldo(werte["gleitzeit_min"]),
            "stand_bis": de(beginn - timedelta(days=1)) if beginn else ""}


def startwerte_speichern(db, werte: dict, heute: date) -> list:
    """Startwerte setzen, ändern oder löschen ohne stille Sprünge (R6, PUT /api/startwerte). Rechnen und Schreiben laufen unter db.lock (RLock),
    damit kein anderer Schreibzugriff dazwischenkommt; die Merker in woche und _uebertrag nehmen das Schloss in derselben Reihenfolge.
    Eingabe werte: ab ("" löscht) und ho_min, dst_min, urlaub, gleittage, krank, kind_krank als ganze Zahlen, gleitzeit_min optional.
    Setzen/Ändern: Gleitzeit ohne Angabe = Konto am Ende von ab − 1 mit den jetzt geltenden Einstellungen, Freizeitkonto eingefroren auf seinen
    Stand am Ende von ab − 1 (woche.konten_am_vortag: auch beim Vorverlegen von ab bleibt der Stand beider Konten); ein automatischer
    Urlaubsübertrag > 0 ins Jahr von ab ohne Wert von Hand wird als Wert von Hand festgeschrieben.
    Löschen: Startstände so, dass beide Konten heute denselben Stand zeigen; ohne Startwerte geschieht nichts. Db.startwerte_setzen sichert vorher
    und prüft gegen heute. Rückgabe: Hinweise für die Antwort (z. B. der festgeschriebene Übertrag).
    Fehler: KonfigFehler (ValueError) mit Feld und Grenze, bei einem vorbelegten Konto über ±999:59 mit dessen Stand; nichts geschrieben."""
    with db.lock:
        return _startwerte_speichern(db, werte, heute)


def _startwerte_speichern(db, werte: dict, heute: date) -> list:
    """startwerte_speichern ohne Schloss (siehe dort)."""
    if not werte.get("ab"):
        if db.startwerte_lesen() is not None:                    # sonst gäbe es eine Kopie und zwei Sätze für den Sync ohne jede Änderung
            db.startwerte_setzen(None, konten=wo.konten_ohne_startwerte(db, heute))
        return []
    eingabe = {f: werte.get(f) for f in ("ab",) + konfig.STARTWERTE_ZEITEN + konfig.STARTWERTE_TAGE}
    hand = werte.get("gleitzeit_min")
    ab = konfig.startwerte_pruefen({**eingabe, "gleitzeit_min": 0 if hand is None else hand, "freizeit_min": 0}).ab
    konten = _konten_vorbelegt(db, ab, hand)
    auto = _uebertrag(db, ab.year)[1]
    uebertrag = (ab.year, auto) if db.jahr_einstellung(ab.year)["uebertrag"] is None and auto > 0 else None
    db.startwerte_setzen({**eingabe, **konten}, heute=heute, uebertrag=uebertrag)
    return [UEBERTRAG_UEBERNOMMEN.format(jahr=ab.year, tage=f"{auto:g}".replace(".", ","))] if uebertrag else []


def _konten_vorbelegt(db, ab: date, hand) -> dict:
    """Konten der Startwerte beim Setzen und Ändern: die Vorbelegung (woche.konten_am_vortag), Gleitzeit mit dem Wert der Person (hand), wenn sie
    einen schickt. Rückgabe: {gleitzeit_min, freizeit_min}. Fehler: KonfigFehler mit dem Stand, wenn ein vorbelegter Wert über ±999:59 liegt."""
    konten = wo.konten_am_vortag(db, ab)
    if hand is not None:
        konten["gleitzeit_min"] = hand                           # schon von konfig.startwerte_pruefen gegen die Grenze geprüft
    for feld, meldung in VORTAG_FEHLER.items():
        if abs(konten[feld]) > konfig.STARTWERTE_KONTO_MAX:
            raise konfig.KonfigFehler(meldung.format(stand=wo.fmt_saldo(konten[feld]), grenze=fmt_hhmm(konfig.STARTWERTE_KONTO_MAX)))
    return konten


def heute(db, d: date) -> dict:
    """Für die Abend-Erinnerung: ist heute ein Arbeitstag, für den noch nichts eingetragen ist?"""
    abschnitte = db.abschnitte()
    eigene = db.eigene_frei_tage(d.year)
    t = next((x for x in db.tage(d.year) if x.datum == d), None)
    soll = regeln.ist_soll_tag(d, eigene, abschnitte)
    eingetragen = bool(t and (t.ho or t.dst or t.art))
    laeuft = db.stempel_lesen() is not None
    return {"datum": d.isoformat(), "soll_tag": soll, "eingetragen": eingetragen, "stempel_laeuft": laeuft,
            "erinnern": bool(soll and not eingetragen and not laeuft)}
