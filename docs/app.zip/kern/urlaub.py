# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Urlaubskonten: Erholungsurlaub (Regel „Urlaubstage pro Jahr“, ab Werk ERHOLUNG_VORGABE) und angesparter Urlaub (Konto je Herkunftsjahr)."""
import calendar
from dataclasses import dataclass
from datetime import date, timedelta

from daten import konfig
from daten.konfig import Meldung
from kern import regeln

ERHOLUNG_VORGABE = 30   # Urlaubstage je Jahr, wenn weder das Jahr noch die Regeln einen Wert haben
ANSPAR_MAX = 15      # Tage je Herkunftsjahr
ANSPAR_JAHRE = 3     # nutzbar im Herkunftsjahr plus drei Folgejahre
ANSPAR_ANTEIL = 0.5  # automatisch angespart wird höchstens die Hälfte des Jahresanspruchs des Herkunftsjahres
FRIST_AB_HERKUNFT = 2025          # erstes Urlaubsjahr, dessen Rest eine Frist hat (erste Frist 2026); ältere Überträge bleiben wie gespeichert
FRIST_BEAMTE_BY = (6, 30)         # Beamte Bayern: Resturlaub bis 30.06., danach automatisch angespart
DIENST_BEAMTE_BY = "beamte_by"    # Dienstverhältnis (Regel dienstverhaeltnis) mit Frist 30.06. und Ansparen
DIENST_ANGESTELLT = "angestellt"  # Frist 31.03., Verfall voraussichtlich, „Resturlaub behalten“ je Jahr
DIENST_EIGEN = "eigen"            # Frist und Ansparen aus den Regeln resturlaub_frist und resturlaub_ansparen, Verfall sicher
FRIST_SONST = (3, 31)             # sonst bis 31.03. (§ 7 Abs. 3 BUrlG), danach verfällt er voraussichtlich


@dataclass
class Konto:
    """Angesparter Urlaub eines Herkunftsjahres (Tage). zuschlag: davon automatisch angespart (Frist), erst ab zuschlag_ab buchbar."""
    herkunft: int
    tage: float
    zuschlag: float = 0.0
    zuschlag_ab: date | None = None


def erholung_rest(anspruch: float, genommen: float) -> float:
    """Resturlaub in Tagen: Anspruch minus genommene Tage (kann negativ sein)."""
    return anspruch - genommen


# ---- Zusatzurlaub (Auftrag vom 23.11.2026; Regel zusatzurlaub_art/zusatzurlaub_tage, konfig.ZUSATZURLAUB_ARTEN)
ZUSATZ_SCHWER_TAGE = 5     # § 208 Abs. 1 SGB IX: Arbeitstage Zusatzurlaub bei einer Woche mit ZUSATZ_SCHWER_WOCHE Arbeitstagen, sonst anteilig
ZUSATZ_SCHWER_WOCHE = 5
MONATE = 12                # § 208 Abs. 2 SGB IX: beginnt oder endet die Schwerbehinderung im Jahr, 1/12 je vollem Monat (aufgerundet)


def zusatz_schwer(arbeitstage_je_monat: list) -> int:
    """Zusatzurlaub nach § 208 SGB IX in Tagen. Eingabe: Arbeitstage je Woche für jeden vollen Monat des Jahres mit Schwerbehinderung
    (höchstens 12 Einträge). Es zählt die günstigste Woche des Jahres (meiste Arbeitstage), damit ein Wechsel oder eine Elternzeit (0 Tage)
    den gezwölftelten Zusatzurlaub nicht noch einmal kürzt (§ 208 Abs. 2 S. 3). Je Monat 1/12 von ZUSATZ_SCHWER_TAGE · n / ZUSATZ_SCHWER_WOCHE;
    jeder Bruchteil wird zugunsten der Person auf einen ganzen Tag aufgerundet (Entscheidung 23.11.2026: 4,17 → 5, 0,42 → 1).
    Gerechnet mit ganzen Zahlen, damit 5,0 nicht auf 6 kippt. Keine Fehler."""
    if not arbeitstage_je_monat:
        return 0
    zaehler = ZUSATZ_SCHWER_TAGE * max(arbeitstage_je_monat) * len(arbeitstage_je_monat)
    return -(-zaehler // (ZUSATZ_SCHWER_WOCHE * MONATE))


def _schwer_monate(jahr: int, abschnitte) -> list:
    """Arbeitstage je Woche (regeln.arbeitstage_je_woche, mit Teilzeit-Abschnitten) für jeden Monat des Jahres, in dem die Regel am ersten
    und letzten Tag „schwerbehinderung“ ist (voller Monat); ändert sich die Woche im Monat, zählt die größere Zahl (günstiger). Ohne eine
    Version mit Schwerbehinderung sofort leer (der häufige Fall bleibt schnell)."""
    if all(v["werte"].get("zusatzurlaub_art") != konfig.ZUSATZ_SCHWER for v in konfig.VERSIONEN):
        return []
    r = []
    for m in range(1, MONATE + 1):
        rand = (date(jahr, m, 1), date(jahr, m, calendar.monthrange(jahr, m)[1]))
        if all(konfig.fuer(d)["zusatzurlaub_art"] == konfig.ZUSATZ_SCHWER for d in rand):
            tage = (rand[0] + timedelta(days=i) for i in range((rand[1] - rand[0]).days + 1))
            r.append(max(regeln.arbeitstage_je_woche(d, abschnitte) for d in tage))
    return r


def _eigen_tage(jahr: int) -> int:
    """Eigener Wert des Jahres: der höchste zusatzurlaub_tage aller Tage mit Art „eigen“, für das ganze Jahr, ohne Zwölftel
    (Entscheidung 23.11.2026). Geprüft werden der 01.01. und jeder Tag, an dem im Jahr eine Regel-Version beginnt. Keine Fehler."""
    tage = [date(jahr, 1, 1)] + [date.fromisoformat(v["ab"]) for v in konfig.VERSIONEN if v["ab"][:4] == str(jahr)]
    return max((r["zusatzurlaub_tage"] for r in map(konfig.fuer, tage) if r["zusatzurlaub_art"] == konfig.ZUSATZ_EIGEN), default=0)


def zusatzurlaub(jahr: int, abschnitte) -> int:
    """Zusatzurlaub des Jahres in Tagen (erhöht den Jahresanspruch): Schwerbehinderung nach zusatz_schwer für die vollen Monate mit der Regel,
    dazu der eigene Wert (_eigen_tage) für das ganze Jahr. Art „keiner“: 0. Keine Fehler."""
    return _eigen_tage(jahr) + zusatz_schwer(_schwer_monate(jahr, abschnitte))


def zusatz_im_rest(rest: float, erholung: float, zusatz: float) -> float:
    """Anteil Zusatzurlaub am Rest eines Jahres. Verbraucht wird erst der Übertrag, dann der Zusatzurlaub, dann der Erholungsurlaub;
    übrig bleibt also zuerst Erholungsurlaub. Eingaben in Tagen (Rest = Anspruch inkl. Zusatz + Übertrag − genommen). Keine Fehler."""
    return min(zusatz, max(0.0, rest - erholung))


def frist_offen_teilen(uebertrag: float, zusatz_im_uebertrag: float, genommen_bis_frist: float) -> tuple:
    """Teilt den an der Frist offenen Übertrag: (aus Erholungsurlaub, aus Zusatzurlaub). Bis zur Frist genommener Urlaub verbraucht zuerst
    den Zusatzurlaub im Übertrag. Nur der Teil aus Erholungsurlaub darf angespart werden, der Zusatzurlaub verfällt an der Frist. Keine Fehler."""
    offen = max(0.0, float(uebertrag - genommen_bis_frist))
    zusatz = min(offen, max(0.0, zusatz_im_uebertrag - genommen_bis_frist))
    return offen - zusatz, float(zusatz)


def pruefe_konto(herkunft: int, tage: float) -> None:
    """Prüft die Tage eines Kontos (0 bis 15); sonst Meldung. Die Herkunft wird hier nicht geprüft."""
    if tage < 0 or tage > ANSPAR_MAX:
        raise Meldung(f"Angesparter Urlaub: 0 bis {ANSPAR_MAX} Tage je Jahr")


def angespart_verfuegbar(konten, jahr: int, genommen_je_konto: dict) -> dict:
    """Rest je Herkunftsjahr, nur Konten, die im Jahr noch nutzbar sind."""
    r = {}
    for k in konten:
        if 0 <= jahr - k.herkunft <= ANSPAR_JAHRE:
            rest = k.tage - genommen_je_konto.get(k.herkunft, 0)
            if rest > 0:
                r[k.herkunft] = rest
    return r


def buchbar(konten, tag: date, genommen_je_konto: dict) -> dict:
    """Konten, von denen sich am Tag ein ganzer Tag buchen lässt: im Jahr nutzbar (angespart_verfuegbar) und mindestens 1 Tag Rest;
    der automatisch angesparte Zuschlag zählt erst ab zuschlag_ab. Rückgabe: {Herkunftsjahr: Rest}. Keine Fehler."""
    verf = angespart_verfuegbar(konten, tag.year, genommen_je_konto)
    r = {}
    for k in konten:
        rest = verf.get(k.herkunft, 0) - (k.zuschlag if k.zuschlag_ab and tag < k.zuschlag_ab else 0)
        if rest >= 1:
            r[k.herkunft] = rest
    return r


def erst_ab(konten, tag: date, genommen_je_konto: dict):
    """Das älteste Konto, das am Tag nur wegen des noch nicht buchbaren Zuschlags (zuschlag_ab) keinen ganzen Tag hergibt, sonst None.
    Für eine klare Fehlermeldung beim Buchen. Keine Fehler."""
    verf = angespart_verfuegbar(konten, tag.year, genommen_je_konto)
    return next((k for k in konten if k.zuschlag_ab and tag < k.zuschlag_ab and verf.get(k.herkunft, 0) >= 1), None)


def frist(jahr: int, beamte_by: bool) -> date:
    """Letzter Tag, an dem der Resturlaub des Vorjahres im Urlaubsjahr „jahr“ nutzbar ist."""
    return date(jahr, *(FRIST_BEAMTE_BY if beamte_by else FRIST_SONST))


def frist_verfall(uebertrag: float, genommen_bis_frist: float, anspruch_vorjahr: float, konto_hand: float, ansparen: bool) -> tuple:
    """Zählregel Resturlaub-Frist: Urlaub bis zur Frist verbraucht zuerst den Übertrag. Was davon übrig ist („offen“), wird angespart
    (nur mit „ansparen“, höchstens die Hälfte des Vorjahresanspruchs und ANSPAR_MAX, ein Konto von Hand zählt darauf) oder verfällt.
    Rückgabe: (offen, angespart, verfallen) in Tagen. Die Grenze zählt in ganzen Tagen (abgerundet wie beim Ansparen von Hand), und das Konto
    (von Hand plus angespart) bleibt ganz, sonst entstünde ein halber Tag, der sich nie buchen lässt; ein halber Tag verfällt. Keine Fehler."""
    offen = max(0.0, float(uebertrag - genommen_bis_frist))            # immer float: gleiche Form der Antwort
    grenze = int(min(ANSPAR_MAX, anspruch_vorjahr * ANSPAR_ANTEIL)) if ansparen else 0
    roh = max(0.0, min(offen, grenze - konto_hand))
    angespart = max(0.0, float(int(konto_hand + roh) - konto_hand)) if roh else 0.0   # int rundet ab, beide Werte sind nie negativ
    return offen, angespart, offen - angespart


def verfaellt_am(herkunft: int) -> date:
    """Letzter Tag, an dem angesparter Urlaub des Herkunftsjahres nutzbar ist (Herkunftsjahr plus ANSPAR_JAHRE, bis 31.12.)."""
    return date(herkunft + ANSPAR_JAHRE, 12, 31)


def naechstes_konto(verfuegbar: dict):
    """Ältestes Konto mit Rest (wie im Buchungssystem)."""
    return min(verfuegbar) if verfuegbar else None


BRUECKE_URLAUB_MAX = 2   # höchstens so viele Urlaubstage je Brückentage-Vorschlag
BRUECKE_ANZAHL = 8       # höchstens so viele Vorschläge


def brueckentage(tage, arbeitet, namen: dict, buchbar) -> list:
    """Brückentage-Vorschläge: höchstens BRUECKE_URLAUB_MAX Arbeitstage am Stück zwischen zwei freien Blöcken, von denen einer einen benannten
    freien Tag (Feiertag, 24./31.12., eigener freier Tag an einem sonst zu arbeitenden Tag) enthält. Eingaben: fortlaufende Tage (die Ränder
    dürfen ins Nachbarjahr reichen, damit Brücken über den Jahreswechsel ganz zählen), arbeitet(Tag) -> True (Arbeitstag), False (frei) oder
    None (zählt nicht, z. B. Elternzeit ohne Stunden: trennt Blöcke, damit solche Tage nie als gewonnen gelten), namen {Tag: Name},
    buchbar(Tag) -> bool (Urlaub dort möglich). Rückgabe: höchstens BRUECKE_ANZAHL (Urlaubstage, erster freier Tag, letzter freier Tag),
    nach freien Tagen je Urlaubstag absteigend, dann nach mehr freien Tagen, dann nach Datum. Keine Fehler."""
    bloecke = []
    for d in tage:
        a = arbeitet(d)
        if bloecke and bloecke[-1][0] == a:
            bloecke[-1][1].append(d)
        else:
            bloecke.append((a, [d]))
    r = []
    for (a_vor, vor), (a_url, url), (a_nach, nach) in zip(bloecke, bloecke[1:], bloecke[2:]):
        if ((a_vor, a_url, a_nach) == (False, True, False) and len(url) <= BRUECKE_URLAUB_MAX and all(map(buchbar, url))
                and any(d in namen for d in vor + nach)):
            r.append((url, vor[0], nach[-1]))
    r.sort(key=lambda x: (-((x[2] - x[1]).days + 1) / len(x[0]), -(x[2] - x[1]).days, x[0][0]))
    return r[:BRUECKE_ANZAHL]
