# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Urlaubskonten: Erholungsurlaub (Regel „Urlaubstage pro Jahr“, ab Werk ERHOLUNG_VORGABE) und angesparter Urlaub (Konto je Herkunftsjahr)."""
from dataclasses import dataclass
from datetime import date

from daten.konfig import Meldung

ERHOLUNG_VORGABE = 30   # Urlaubstage je Jahr, wenn weder das Jahr noch die Regeln einen Wert haben
ANSPAR_MAX = 15      # Tage je Herkunftsjahr
ANSPAR_JAHRE = 3     # nutzbar im Herkunftsjahr plus drei Folgejahre


@dataclass
class Konto:
    """Angesparter Urlaub eines Herkunftsjahres (Tage)."""
    herkunft: int
    tage: float


def erholung_rest(anspruch: float, genommen: float) -> float:
    """Resturlaub in Tagen: Anspruch minus genommene Tage (kann negativ sein)."""
    return anspruch - genommen


def pruefe_konto(herkunft: int, tage: float) -> None:
    """Prüft die Tage eines Kontos (0 bis 15); sonst Meldung. Die Herkunft wird hier nicht geprüft."""
    if tage < 0 or tage > ANSPAR_MAX:
        raise Meldung(f"Angesparter Urlaub: 0 bis {ANSPAR_MAX} Tage je Jahr")


def angespart_verfuegbar(konten, jahr: int, genommen_je_konto: dict) -> dict:
    """Rest je Herkunftsjahr, nur Konten, die im Jahr noch nutzbar sind."""
    r = {}
    for k in konten:
        if 0 <= jahr - k.herkunft <= ANSPAR_JAHRE:
            rest = k.tage - genommen_je_konto.get(k.herkunft, 0)
            if rest > 0:
                r[k.herkunft] = rest
    return r


def buchbar(konten, jahr: int, genommen_je_konto: dict) -> dict:
    """Konten, von denen sich im Jahr ein ganzer Tag buchen lässt: nutzbar (angespart_verfuegbar) und mindestens 1 Tag Rest.
    Eingaben wie angespart_verfuegbar. Rückgabe: {Herkunftsjahr: Rest}. Keine Fehler."""
    return {k: v for k, v in angespart_verfuegbar(konten, jahr, genommen_je_konto).items() if v >= 1}


def verfaellt_am(herkunft: int) -> date:
    """Letzter Tag, an dem angesparter Urlaub des Herkunftsjahres nutzbar ist (Herkunftsjahr plus ANSPAR_JAHRE, bis 31.12.)."""
    return date(herkunft + ANSPAR_JAHRE, 12, 31)


def naechstes_konto(verfuegbar: dict):
    """Ältestes Konto mit Rest (wie im Buchungssystem)."""
    return min(verfuegbar) if verfuegbar else None
