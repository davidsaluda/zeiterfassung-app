# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Urlaubskonten: Erholungsurlaub (Regel „Urlaubstage pro Jahr“, ab Werk ERHOLUNG_VORGABE) und angesparter Urlaub (Konto je Herkunftsjahr)."""
from dataclasses import dataclass
from datetime import date

from daten.konfig import Meldung

ERHOLUNG_VORGABE = 30   # Urlaubstage je Jahr, wenn weder das Jahr noch die Regeln einen Wert haben
ANSPAR_MAX = 15      # Tage je Herkunftsjahr
ANSPAR_JAHRE = 3     # nutzbar im Herkunftsjahr plus drei Folgejahre


@dataclass
class Konto:
    """Angesparter Urlaub eines Herkunftsjahres (Tage)."""
    herkunft: int
    tage: float


def erholung_rest(anspruch: float, genommen: float) -> float:
    """Resturlaub in Tagen: Anspruch minus genommene Tage (kann negativ sein)."""
    return anspruch - genommen


def pruefe_konto(herkunft: int, tage: float) -> None:
    """Prüft die Tage eines Kontos (0 bis 15); sonst Meldung. Die Herkunft wird hier nicht geprüft."""
    if tage < 0 or tage > ANSPAR_MAX:
        raise Meldung(f"Angesparter Urlaub: 0 bis {ANSPAR_MAX} Tage je Jahr")


def angespart_verfuegbar(konten, jahr: int, genommen_je_konto: dict) -> dict:
    """Rest je Herkunftsjahr, nur Konten, die im Jahr noch nutzbar sind."""
    r = {}
    for k in konten:
        if 0 <= jahr - k.herkunft <= ANSPAR_JAHRE:
            rest = k.tage - genommen_je_konto.get(k.herkunft, 0)
            if rest > 0:
                r[k.herkunft] = rest
    return r


def buchbar(konten, jahr: int, genommen_je_konto: dict) -> dict:
    """Konten, von denen sich im Jahr ein ganzer Tag buchen lässt: nutzbar (angespart_verfuegbar) und mindestens 1 Tag Rest.
    Eingaben wie angespart_verfuegbar. Rückgabe: {Herkunftsjahr: Rest}. Keine Fehler."""
    return {k: v for k, v in angespart_verfuegbar(konten, jahr, genommen_je_konto).items() if v >= 1}


def verfaellt_am(herkunft: int) -> date:
    """Letzter Tag, an dem angesparter Urlaub des Herkunftsjahres nutzbar ist (Herkunftsjahr plus ANSPAR_JAHRE, bis 31.12.)."""
    return date(herkunft + ANSPAR_JAHRE, 12, 31)


def naechstes_konto(verfuegbar: dict):
    """Ältestes Konto mit Rest (wie im Buchungssystem)."""
    return min(verfuegbar) if verfuegbar else None


BRUECKE_URLAUB_MAX = 2   # höchstens so viele Urlaubstage je Brückentage-Vorschlag
BRUECKE_ANZAHL = 8       # höchstens so viele Vorschläge


def brueckentage(tage, arbeitet, namen: dict, buchbar) -> list:
    """Brückentage-Vorschläge: höchstens BRUECKE_URLAUB_MAX Arbeitstage am Stück zwischen zwei freien Blöcken, von denen einer einen benannten
    freien Tag (Feiertag, 24./31.12., eigener freier Tag an einem sonst zu arbeitenden Tag) enthält. Eingaben: fortlaufende Tage (die Ränder
    dürfen ins Nachbarjahr reichen, damit Brücken über den Jahreswechsel ganz zählen), arbeitet(Tag) -> True (Arbeitstag), False (frei) oder
    None (zählt nicht, z. B. Elternzeit ohne Stunden: trennt Blöcke, damit solche Tage nie als gewonnen gelten), namen {Tag: Name},
    buchbar(Tag) -> bool (Urlaub dort möglich). Rückgabe: höchstens BRUECKE_ANZAHL (Urlaubstage, erster freier Tag, letzter freier Tag),
    nach freien Tagen je Urlaubstag absteigend, dann nach mehr freien Tagen, dann nach Datum. Keine Fehler."""
    bloecke = []
    for d in tage:
        a = arbeitet(d)
        if bloecke and bloecke[-1][0] == a:
            bloecke[-1][1].append(d)
        else:
            bloecke.append((a, [d]))
    r = []
    for (a_vor, vor), (a_url, url), (a_nach, nach) in zip(bloecke, bloecke[1:], bloecke[2:]):
        if ((a_vor, a_url, a_nach) == (False, True, False) and len(url) <= BRUECKE_URLAUB_MAX and all(map(buchbar, url))
                and any(d in namen for d in vor + nach)):
            r.append((url, vor[0], nach[-1]))
    r.sort(key=lambda x: (-((x[2] - x[1]).days + 1) / len(x[0]), -(x[2] - x[1]).days, x[0][0]))
    return r[:BRUECKE_ANZAHL]
