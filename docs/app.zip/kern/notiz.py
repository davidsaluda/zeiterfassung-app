# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Anmerkungen, die nur wiederholen, was der Tag schon zeigt (Art, Monat, Datum), werden nicht gespeichert."""
import re

MONATE = {"januar", "februar", "märz", "maerz", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "dezember"}
WOERTER = {
    "urlaub": {"urlaub", "erholungsurlaub"},
    "angespart": {"angespart", "angesparter", "urlaub"},
    "gleittag": {"gleittag", "gleittage", "gleitzeit"},
    "krank": {"krank", "krankheit", "krankmeldung", "attest"},
    "krank_attest": {"krank", "krankheit", "krankmeldung", "attest"},
    "krank_dienst": {"krank", "im", "dienst"},
    "elternzeit": {"elternzeit"},
    "familientag": {"familientag", "familientage", "familie"},
    "sonderurlaub_tag": {"sonderurlaub"},
    "kind_krank": {"kind", "krank", "kinderkrank", "kinderkrankentag", "kinderkrankentage"},
    "freizeit": {"freizeit", "freizeitausgleich", "fza"},
}
WOERTER["krank_attest"] |= {"mit"}
# Wörter der sichtbaren Vermerke (konfig.VERMERKE: „Dienstreise/Außentermin“, „Fortbildung“); der Tag zeigt sie schon an
VERMERK_WOERTER = {"dienstreise": {"dienstreise", "außentermin", "aussentermin"}, "fortbildung": {"fortbildung"}}


def ueberfluessig(art: str, notiz: str, vermerk: str = "") -> bool:
    """True, wenn die Anmerkung nur aus Wörtern der Art oder des Vermerks, Monatsnamen, Datumsangaben und „bis“ besteht
    (z. B. „Urlaub Oktober“, „Gleittage“, „21.05.2019 - 24.05.2019“, beim Vermerk Dienstreise „Außentermin“)."""
    erlaubt = WOERTER.get(art, set()) | VERMERK_WOERTER.get(vermerk, set())
    if not erlaubt or not notiz.strip():
        return False
    for t in re.split(r"[\s,;:/\-–]+", notiz.lower()):
        if not t or t == "bis" or re.fullmatch(r"[\d.]+", t) or t in MONATE or t in erlaubt:
            continue
        return False
    return True
