# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Daten prüfen: sucht im ganzen Datenbestand nach Auffälligkeiten und liefert verständliche Hinweise mit Sprung zum Tag.
Nur lesend (über die Lese-Funktionen von Db, regeln, feiertage und bericht), ändert nie etwas, keine Verbindung nach außen.
Gedacht für Einträge, die die Eingabe heute verhindert, die aber über Synchronisierung, Import oder alte Sicherungen in der Datenbank stehen."""
from datetime import date

from kern import bericht
from kern import feiertage
from kern import regeln
from kern.zeit import fmt_hhmm

FUNDE_MAX = 500                                             # mehr zeigt die Liste nicht, der Rest steht als Zahl in „mehr“
GEHEN_VOR_KOMMEN, DOPPELT, FEIERTAG, URLAUB = "gehen-vor-kommen", "doppelt", "zeit-an-feiertag", "urlaub-ueber-anspruch"
FEHLER, HINWEIS = "fehler", "hinweis"
SCHWERE = {GEHEN_VOR_KOMMEN: FEHLER, DOPPELT: FEHLER, FEIERTAG: HINWEIS, URLAUB: FEHLER}   # Arbeit am Feiertag kann gewollt sein
ZIEL_TAG = "#/tag/{}"
ZIEL_URLAUB = "#/urlaub"
ZIEL_SYNC = "#/sync"
GANZER_TAG = regeln.ABWESEND                                # ganztägige Arten; „Krank im Dienst“ gehört nicht dazu
NICHT_AM_FEIERTAG = ("urlaub", "angespart", "gleittag")     # zählen an freien Tagen nicht (regeln.summe)
EIGENER_FREIER_TAG = "eigener freier Tag"
TEXT_HALB = "nur Kommen oder nur Gehen eingetragen"
TEXT_GEHEN = "Gehen ({gehen}) liegt nicht nach Kommen ({kommen})"
TEXT_KOMMEN = "Kommen liegt nicht zwischen 00:00 und 23:59"
TEXT_GEHEN_MAX = "Gehen liegt nach " + fmt_hhmm(regeln.GEHEN_MAX_MIN)
TEXT_PAUSE = f"Pause liegt nicht zwischen 0 und {regeln.PAUSE_HAND_MAX_MIN // 60} Stunden"
TEXT_PAUSE_LANG = "Die Pause ist länger als die Zeit von Kommen bis Gehen"
MINUTEN_TAG = 1440
TEXT_DOPPELT = "{art} und {zeit} Stunden Arbeitszeit am selben Tag"
TEXT_KONFLIKT = "zwei Fassungen nach dem Synchronisieren"
TEXT_FEIERTAG_ZEIT = "{zeit} Stunden Arbeitszeit"
TEXT_FEIERTAG_ART = "{art} zählt an freien Tagen nicht"
TEXT_JAHR = "{jahr}: {tage} mehr eingetragen als Anspruch und Übertrag."
TEXT_KONTO = "Angesparter Urlaub aus {herkunft}: {tage} mehr genommen als angespart."


def pruefen(db) -> dict:
    """Ergebnis für GET /api/pruefen: {"funde": höchstens FUNDE_MAX Funde nach Datum, "tage": Anzahl Tage der Datenbank, "mehr": weggelassene Funde}."""
    alle = funde(db)
    return {"funde": alle[:FUNDE_MAX], "tage": len(db.tage_alle()), "mehr": max(0, len(alle) - FUNDE_MAX)}


def funde(db) -> list:
    """Alle Funde nach Datum sortiert; je Fund {"id", "datum" (JJJJ-MM-TT), "text", "ziel", "schwere" (fehler|hinweis)}."""
    tage = db.tage_alle()
    jahre = sorted({t.datum.year for t in tage})
    frei = {j: _freie_tage(db, j) for j in jahre}
    r = []
    for t in tage:
        r += _gehen_vor_kommen(t) + _doppelt(t) + _feiertag(t, frei[t.datum.year])
    r += _konflikte(db) + _urlaub(db, jahre, tage)
    return sorted(r, key=lambda f: f["datum"])


def _fund(kennung: str, d: date, text: str, ziel: str = "") -> dict:
    """Ein Fund; ohne Ziel springt er zum Tag."""
    return {"id": kennung, "datum": d.isoformat(), "text": text, "ziel": ziel or ZIEL_TAG.format(d.isoformat()), "schwere": SCHWERE[kennung]}


def _am_tag(kennung: str, d: date, text: str, ziel: str = "", name: str = "") -> list:
    """Ein Fund mit Datum (und Namen des Feiertags) vor dem Text, als Liste."""
    kopf = f"{bericht.de(d)} ({name})" if name else bericht.de(d)
    return [_fund(kennung, d, f"{kopf}: {text}.", ziel)]


def _arbeitszeit(t) -> int:
    """Arbeitszeit des Tages in Minuten (Homeoffice und Büro)."""
    return t.ho + t.dst


def _gehen_vor_kommen(t) -> list:
    """Halbe oder unmögliche Uhrzeiten (Grenzen wie regeln.arbeitszeit), je Fall ein eigener Text.
    Gehen nach Mitternacht (bis 48:00) ist erlaubt."""
    text = _uhrzeit_fehler(t.kommen, t.gehen, t.pause)
    return _am_tag(GEHEN_VOR_KOMMEN, t.datum, text) if text else []


def _uhrzeit_fehler(kommen: int, gehen: int, pause: int) -> str:
    """Text zur ersten unmöglichen Angabe, leer wenn alles möglich ist oder der Tag keine Uhrzeit hat."""
    if kommen == gehen == regeln.OHNE_UHRZEIT:
        return ""
    if regeln.OHNE_UHRZEIT in (kommen, gehen):
        return TEXT_HALB
    if gehen <= kommen:
        return TEXT_GEHEN.format(gehen=fmt_hhmm(gehen), kommen=fmt_hhmm(kommen))
    try:
        regeln.arbeitszeit(kommen, gehen, pause)             # die Grenzen gelten nur dort; hier nur der passende Text
        return ""
    except ValueError:
        pass
    if not 0 <= kommen < MINUTEN_TAG:
        return TEXT_KOMMEN
    if gehen > regeln.GEHEN_MAX_MIN:
        return TEXT_GEHEN_MAX
    return TEXT_PAUSE if not 0 <= pause <= regeln.PAUSE_HAND_MAX_MIN else TEXT_PAUSE_LANG


def _doppelt(t) -> list:
    """Ganztägige Art (Urlaub, Krank …) und Arbeitszeit am selben Tag."""
    if t.art not in GANZER_TAG or not _arbeitszeit(t):
        return []
    return _am_tag(DOPPELT, t.datum, TEXT_DOPPELT.format(art=regeln.ARTEN[t.art], zeit=fmt_hhmm(_arbeitszeit(t))))


def _konflikte(db) -> list:
    """Offene Konflikte der Synchronisierung an Tagen (zwei Fassungen desselben Tages)."""
    return [f for art, schluessel in db.konflikte() if art == "tag"
            for f in _am_tag(DOPPELT, date.fromisoformat(schluessel), TEXT_KONFLIKT, ZIEL_SYNC)]


def _freie_tage(db, jahr: int) -> dict:
    """Freie Tage des Jahres: {Datum: Name}. Gesetzliche Feiertage immer; Heiligabend, Silvester und eigene freie Tage
    nur an Werktagen, denn sie geben nur einen Werktag frei (am Wochenende ist Arbeit dort gewollte Wochenendarbeit)."""
    frei = dict.fromkeys(db.jahr_einstellung(jahr)["eigene_frei"], EIGENER_FREIER_TAG)
    frei.update(feiertage.freie_tage(jahr))
    gesetzlich = feiertage.feiertage(jahr)
    return {d: name for d, name in frei.items() if d in gesetzlich or d.weekday() < 5}


def _feiertag(t, frei: dict) -> list:
    """Arbeitszeit, Urlaub oder Gleittag an einem freien Tag aus _freie_tage; ein gewöhnliches Wochenende ist gewollt und zählt nicht."""
    name = frei.get(t.datum)
    if not name:
        return []
    if _arbeitszeit(t):
        return _am_tag(FEIERTAG, t.datum, TEXT_FEIERTAG_ZEIT.format(zeit=fmt_hhmm(_arbeitszeit(t))), name=name)
    if t.art in NICHT_AM_FEIERTAG:
        return _am_tag(FEIERTAG, t.datum, TEXT_FEIERTAG_ART.format(art=regeln.ARTEN[t.art]), name=name)
    return []


def _anzahl(n: float, einzahl: str, mehrzahl: str) -> str:
    """Anzahl mit Komma und passendem Wort („1 Tag“, „2 Tage“, „0,5 Tage“)."""
    return f"{n:g}".replace(".", ",") + " " + (einzahl if n == 1 else mehrzahl)


def _urlaub(db, jahre: list, tage: list) -> list:
    """Urlaub über Anspruch und Übertrag je Jahr (bericht.urlaub_stand) und überzogene angesparte Konten (einmal, sie gelten für alle Jahre).
    Datum des Funds: der letzte Urlaubstag des Jahres bzw. der letzte Tag aus dem Konto."""
    r = []
    for j in jahre:
        rest = bericht.urlaub_stand(db, j)["rest"]
        if rest < 0:
            d = max((t.datum for t in tage if t.datum.year == j and t.art == "urlaub"), default=date(j, 12, 31))
            r.append(_fund(URLAUB, d, TEXT_JAHR.format(jahr=j, tage=_anzahl(-rest, "Urlaubstag", "Urlaubstage")), ZIEL_URLAUB))
    konten = bericht.urlaub_stand(db, jahre[-1])["konten"] if jahre else []
    for k in konten:
        if k["rest"] < 0:
            d = max(t.datum for t in tage if t.art == "angespart" and t.konto == k["herkunft"])
            r.append(_fund(URLAUB, d, TEXT_KONTO.format(herkunft=k["herkunft"], tage=_anzahl(-k["rest"], "Tag", "Tage")), ZIEL_URLAUB))
    return r
