# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Zeitformate: Eingabe und Anzeige hh:mm, gespeichert als ganze Minuten."""
import re

from daten.konfig import Meldung

_RE = re.compile(r"^(\d{1,2}):([0-5]\d)$")
# Dauer „8:30“ oder „8,5“/„8.5“ (höchstens 2 Nachkommastellen); per Muster statt float(), damit „1e9“, „NaN“ und „inf“ nicht durchgehen
_DAUER = re.compile(r"(\d{1,4})(?::([0-5]\d)|[,.](\d{1,2}))?", re.ASCII)
DAUER_FEHLER = "Ungültige Dauer (erlaubt zum Beispiel 8:30 oder 8,5)"
ZEITFORMAT_FEHLER = "Zeitformat: hhmm oder dezimal"
MINUS = "−"                    # echtes Minuszeichen wie woche.fmt_saldo


def parse_hhmm(text, max_std=23):
    """'7:45' -> 465; leer -> None; ungültig -> Meldung. max_std 47: Gehen nach Mitternacht („26:00“)."""
    if text is None:
        return None
    t = str(text).strip()
    if t == "":
        return None
    m = _RE.match(t)
    if not m or int(m.group(1)) > max_std:
        raise Meldung(f"Ungültige Zeit „{t}“ (erlaubt: 00:00 bis 23:59, Format hh:mm)")
    return int(m.group(1)) * 60 + int(m.group(2))


def dauer_lesen(text) -> int:
    """Eine Dauer in beiden Schreibweisen lesen (Stunden je Tag, Startwerte): „8:30“, „8,5“ und „8.5“ ergeben 510, „6“ ergibt 360.
    Eingabe: Text (bis 4 Stellen Stunden, damit Startwerte eines ganzen Jahres passen; Minuten 00–59 oder bis 2 Nachkommastellen). Rückgabe: ganze Minuten ab 0, Nachkommastellen
    gerundet (round(h × 60)). Fehler: Meldung mit DAUER_FEHLER bei leerem oder ungültigem Text; Grenzen (z. B. höchstens 10 Stunden)
    prüft der Aufrufer."""
    m = _DAUER.fullmatch(str(text).strip()) if text is not None else None
    if not m:
        raise Meldung(DAUER_FEHLER)
    stunden, minuten, anteil = m.groups()
    return int(stunden) * 60 + int(minuten or 0) + round(int((anteil or "").ljust(2, "0")) * 60 / 100)


def fmt_hhmm(minuten) -> str:
    """Minuten als hh:mm (465 ergibt 07:45; ab 100 Stunden dreistellig)."""
    minuten = int(minuten)
    return f"{minuten // 60:02d}:{minuten % 60:02d}"


def fmt_dauer(minuten, zeitformat="hhmm") -> str:
    """Eine Dauer als Text im Zeitformat der Regel `zeitformat` (funktionen.md 0.8): „hhmm“ wie fmt_hhmm (450 ergibt 07:30), „dezimal“ als Stunden
    mit Komma, kaufmännisch auf zwei Stellen (450 ergibt 7,50, 440 ergibt 7,33). Eingabe: ganze Minuten, auch negativ (Saldo, mit „−“ davor),
    Summen also immer erst in Minuten bilden und dann einmal formatieren. Fehler: ValueError mit ZEITFORMAT_FEHLER bei einem anderen Format."""
    minuten = int(minuten)
    betrag = abs(minuten)
    if zeitformat == "hhmm":
        text = fmt_hhmm(betrag)
    elif zeitformat == "dezimal":
        hundertstel = (betrag * 10 + 3) // 6        # Minuten / 60 × 100 + 0,5 abgerundet: ganzzahlig, also exakt kaufmännisch (round() rundet auf gerade)
        text = f"{hundertstel // 100},{hundertstel % 100:02d}"
    else:
        raise ValueError(ZEITFORMAT_FEHLER)
    return MINUS + text if minuten < 0 else text


def fmt_prozent(anteil) -> str:
    """Anteil (0 bis 1) als Prozent mit zwei Stellen und Komma (0.8 ergibt 80,00 %); None ergibt „–“."""
    if anteil is None:
        return "–"
    return f"{anteil * 100:.2f}".replace(".", ",") + " %"


def fmt_zahl(n) -> str:
    """Zahl für die Anzeige: ganze Zahl ohne „,0“, sonst mit Dezimalkomma (1,5)."""
    return str(int(n)) if float(n).is_integer() else str(n).replace(".", ",")


def fmt_tage(n) -> str:
    """Zahl mit „Tag“ (genau 1) oder „Tage“, halbe Tage mit Komma (1,5 Tage)."""
    return f"{fmt_zahl(n)} {'Tag' if n == 1 else 'Tage'}"
