# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Suche nach Tagen (Auftrag A6, 25.11.2026): filtert gespeicherte Tage nach Text in der Anmerkung, Art, Ort und Zeitraum.
Rechnet nichts Neues: Gesamtzeit ist HO + Büro des Tages wie überall. Die Eingaben prüft die Route (routen_zeiten, GET /api/suche)."""
from kern.regeln import WT
from kern.zeit import fmt_dauer

ARBEITSTAG = "arbeitstag"                  # Name der Art "" (gewöhnlicher Arbeitstag) in der Art-Liste der Anfrage
ORTE = ("ho", "dst")
TEXT_MAX = 100                             # Zeichen des Suchtexts
TREFFER_MAX = 500                          # Zeilen je Antwort; die Zahl aller Treffer steht daneben
AUSSCHNITT_LAENGE, AUSSCHNITT_VOR = 90, 30  # Zeichen des Notiz-Ausschnitts und davon vor dem Treffer
AUSLASSUNG = "…"


def _art_schluessel(art: str) -> str:
    """Art eines Tages als Name in der Art-Liste: "" heißt ARBEITSTAG."""
    return art or ARBEITSTAG


def _ort_passt(tag, ort: str) -> bool:
    """Ort „ho“: nur Homeoffice; „dst“: Büro, auch mit HO am selben Tag (Zählregel: HO und Büro an einem Tag zählt als Büro-Tag); leer: jeder Tag."""
    if ort == "ho":
        return tag.ho > 0 and not tag.dst
    if ort == "dst":
        return tag.dst > 0
    return True


def _passt(tag, text: str, arten, ort: str, von, bis) -> bool:
    """Erfüllt der Tag alle Kriterien? text schon klein (casefold), arten leer = jede Art."""
    return (von <= tag.datum <= bis and (not arten or _art_schluessel(tag.art) in arten) and _ort_passt(tag, ort)
            and text in tag.notiz.casefold())


def ausschnitt(notiz: str, text: str) -> str:
    """Teil der Anmerkung um die erste Fundstelle (höchstens AUSSCHNITT_LAENGE Zeichen, gekürzte Enden mit AUSLASSUNG); kurze Anmerkung ganz."""
    if len(notiz) <= AUSSCHNITT_LAENGE:
        return notiz
    anfang = max(0, min(notiz.casefold().find(text) - AUSSCHNITT_VOR, len(notiz) - AUSSCHNITT_LAENGE)) if text else 0
    ende = anfang + AUSSCHNITT_LAENGE
    return (AUSLASSUNG if anfang else "") + notiz[anfang:ende].strip() + (AUSLASSUNG if ende < len(notiz) else "")


def _dauer(minuten: int, zeitformat: str) -> str:
    """Dauer als Text, 0 Minuten leer (ein Urlaubstag zeigt keine „00:00“)."""
    return fmt_dauer(minuten, zeitformat) if minuten else ""


def _zeile(tag, text: str, zeitformat: str) -> dict:
    """Eine Ergebniszeile: Datum, Art, Orte, Gesamtzeit und Notiz-Ausschnitt."""
    return {"datum": tag.datum.isoformat(), "datum_text": f"{WT[tag.datum.weekday()]} {tag.datum:%d.%m.%Y}", "art": tag.art,
            "ho": _dauer(tag.ho, zeitformat), "dst": _dauer(tag.dst, zeitformat), "gesamt": _dauer(tag.ho + tag.dst, zeitformat),
            "notiz": ausschnitt(tag.notiz, text)}


def suchen(tage, *, text: str, arten, ort: str, von, bis, zeitformat: str) -> dict:
    """Tage, die alle Kriterien erfüllen, neueste zuerst. Eingaben: tage (regeln.Tag), text (Teil der Anmerkung, ohne Groß/klein), arten (Namen wie in
    ARTEN, gewöhnlicher Tag als ARBEITSTAG; leer = alle), ort ("", "ho", "dst"), von/bis (date, beide eingeschlossen), zeitformat der Regeln.
    Rückgabe: {treffer: höchstens TREFFER_MAX Zeilen, anzahl: alle Treffer, mehr: True, wenn Zeilen fehlen}."""
    klein = text.casefold()
    passende = [t for t in tage if _passt(t, klein, arten, ort, von, bis)]
    passende.sort(key=lambda t: t.datum, reverse=True)
    return {"treffer": [_zeile(t, klein, zeitformat) for t in passende[:TREFFER_MAX]], "anzahl": len(passende), "mehr": len(passende) > TREFFER_MAX}
