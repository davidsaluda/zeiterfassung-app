# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Karte „Zu tun“ der Übersicht (Auftrag 18.11.2026): sammelt, was die Person erledigen sollte, aus dem Rechenkern
und dem Stand von Sicherung und Synchronisierung. Gleich in allen Fassungen; gerechnet wird nur mit vorhandenen Funktionen (Krank, Urlaub, Quote, Saldo).
Ein Eintrag: {"id", "stufe" (rot, gelb, info), "text", "knopf", "ziel" ("#/<seite>")}, bei tage-fehlen mit mehreren Tagen dazu "fehlend" (ISO-Daten). Abgeschaltete Module erzeugen keine Einträge."""
from datetime import date, datetime, timedelta

from kern import bericht
from daten import konfig
from kern import regeln
from daten import sicherung
from daten import update
import urheber
from kern import urlaub as ur
from kern import woche as wo
from kern.zeit import fmt_dauer, fmt_tage as _tage, fmt_zahl as _zahl

STUFEN = ("rot", "gelb", "info")                 # Reihenfolge in der Karte
UPDATE_PLATTFORMEN = ("desktop", "android")       # nur dort führt der Knopf zur Release-Seite; sonst lädt die Web-App neu bzw. aktualisiert die Verwaltung
SYNC_ALT_TAGE = 7
LUECKE_TAGE = 31                                  # so weit zurück sucht „Arbeitstage ohne Eintrag“
STEMPEL_OFFEN = timedelta(hours=10)
WOCHENTAGE = ("Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag")
ZIEL_TAG = "#/tag/{}/bearbeiten"                  # öffnet den Tag zum Bearbeiten (oberflaeche-uebergaben 1.5, entschieden: „/bearbeiten“)
VERFALL_TAGE = 90                                 # so lange vor dem Verfall meldet Zu tun (gelb, ab FRIST_ROT_TAGE rot): Zeit genug, die Tage zu planen
VERFALL_TEXT = "{rest} angesparter Urlaub aus {herkunft} {verb} am {bis} ({wann})."
VERMERK_KURZ = {"dienstreise": "Dienstreise", "fortbildung": "Fortbildung"}   # kurz im Satz „Dienstreise am 12.11.“ (konfig.VERMERKE ist lang)
VERMERK_SONST = "Vermerk"
JAHRESWECHSEL_MONAT = 1
PLAN_VORLAUF_MONAT = 11                           # ab diesem Monat planen Urlaub, Sondertage und Einstellungen auch das Folgejahr (wie grundlage.js)
URLAUB_PLANEN_MONAT = 12                          # in diesem Monat erinnert Zu tun an die Planung des Folgejahres
URLAUB_PLANEN = "Urlaub {jahr} planen"
ANSPAREN_SCHRITT, AUS_SCHRITT = "ansparen", "aus"
KONTO_SCHON_DA = "Für {jahr} ist schon ein Konto angelegt."
SCHON_ANGESPART = "Für {jahr} ist das Ansparen schon erledigt."
ANSPAREN_GRENZE = "Ansparen: ganze Tage von 0 bis {max}"
ANSPAREN_AUTOMATISCH = "Für {jahr} gibt es kein Ansparen von Hand mehr: Der Resturlaub hat eine Frist (siehe Urlaub)."
FRIST_WARNEN_TAGE = 42                            # so lange vor der Frist des Resturlaubs meldet Zu tun (gelb)
FRIST_ROT_TAGE = 14                               # ab hier rot (auch wenn alles angespart würde: der Resturlaub ist dann weg)
NACH_FRIST_TAGE = 42                              # so lange zeigt Zu tun nach der Frist mindestens, was angespart wurde und was verfallen ist
FRIST_TEXT = "Resturlaub {vorjahr}: noch {offen} bis {frist} {danach}"         # frist endet mit Punkt (TT.MM.)
DANACH_ANSPAREN = "Danach werden {angespart} angespart, {verfallen} verfallen."
DANACH_ALLES_ANGESPART = "Danach werden sie angespart."
DANACH_VERFALL = "Danach verfallen sie."
DANACH_VORAUSSICHTLICH = "Danach verfallen sie voraussichtlich."
NACH_ANGESPART = "{angespart} aus {vorjahr} angespart, {verfallen} verfallen."
NACH_ALLES_ANGESPART = "{angespart} aus {vorjahr} angespart."
NACH_VERFALLEN = "{verfallen} aus {vorjahr} verfallen."
NACH_VORAUSSICHTLICH = "{verfallen} aus {vorjahr} verfallen voraussichtlich (nur, wenn dein Arbeitgeber vorher auf den Verfall hingewiesen hat)."
ANMELDUNG_UNBEKANNT = "Das Synchronisieren mit dem Server braucht eine neue Anmeldung."
SYNC_FEHLER = "Das letzte Synchronisieren ist fehlgeschlagen."
STEMPEL_MITTERNACHT = "Die Stempeluhr endet jetzt spätestens um 23:59. Einstellen unter Arbeitszeit."


class AnsparFehler(konfig.Meldung):
    """Falsche Eingabe beim Ansparen (Text ist für die Person bestimmt und darf an den Browser)."""


def _eintrag(id_: str, stufe: str, text: str, knopf: str, ziel: str) -> dict:
    """Ein Eintrag der Karte in der festen Form."""
    return {"id": id_, "stufe": stufe, "text": text, "knopf": knopf, "ziel": ziel}


def _tagen(n) -> str:
    """Zahl mit „Tag“ oder „Tagen“ (Dativ: „vor 48 Tagen“)."""
    return f"{_zahl(n)} {'Tag' if n == 1 else 'Tagen'}"


def _datum(text):
    """Datum aus einem ISO-Text (Datum oder Zeitpunkt); None, wenn leer oder unlesbar."""
    try:
        return date.fromisoformat(str(text)[:10])
    except ValueError:
        return None


def _de(d: date) -> str:
    """Datum als TT.MM.JJJJ."""
    return d.strftime("%d.%m.%Y")


def eintraege(db, heute: date, stand: dict) -> list:
    """Alle Einträge der Karte, rot vor gelb vor info. heute: date oder datetime (mit Uhrzeit gilt für die Stempeluhr die 10-Stunden-Grenze).
    stand: Stand von Synchronisierung und Sicherung (wie GET /api/abgleich, dazu plattform, letzte_sicherung, admin); fehlende Schlüssel melden nichts.
    Modul „zutun“ aus: leere Liste."""
    aus = set(konfig.fuer(_tag(heute))["module_aus"])
    if "zutun" in aus:
        return []
    an = aus.isdisjoint
    r = []
    if an({"sicherung"}):
        r += _sicherung(db, _tag(heute), stand)
    if an({"abgleich"}) and not stand.get("modul_aus"):
        r += _sync(_tag(heute), stand)
    vergessen = vergessener_tag(db, _tag(heute)) if an({"stempel"}) else None
    if an({"monat"}):
        r += _luecken(db, _tag(heute), vergessen)
    if an({"stempel"}):
        r += _stempel(db, heute) + _vergessen(vergessen, _tag(heute)) + _stempel_mitternacht(db, _tag(heute))
    if an({"krank"}):
        r += _attest(db, _tag(heute))
    if an({"urlaub", "angespart"}):
        r += _verfall(db, _tag(heute)) + _uebertrag_pruefen(db, _tag(heute))
    if an({"urlaub"}):
        r += _resturlaub(db, _tag(heute))
    if an({"urlaub", "planung"}):
        r += _urlaub_planen(_tag(heute))
    r += _vermerk(db, _tag(heute))
    r += _quote(db, _tag(heute), an({"horest"}))
    if an({"horest"}):
        r += _quote_monat(db, _tag(heute))
    if an({"gleitzeit"}):
        r += _saldo(db, _tag(heute)) + _kappung(db, _tag(heute))
    r += _admin(stand.get("admin")) + _update(stand)
    return sorted(r, key=lambda e: STUFEN.index(e["stufe"]))


def _stempel_mitternacht(db, heute: date) -> list:
    """stempel-mitternacht (info, einmal nach dem Update; „Nicht mehr zeigen“ blendet ihn aus): Die Stempeluhr endet seit der Regel stempel_mitternacht
    (Entscheidung des Entwicklers vom 24.11.2026, ab Werk aus) spätestens um 23:59. Nur, solange die Regel aus ist und schon eine Uhr über
    Mitternacht lief (Gehen nach 24:00): Nur dann ändert sich für die Person etwas, neue Nutzer sehen ihn nicht."""
    if konfig.fuer(heute).get(konfig.MITTERNACHT_REGEL) or not any(t.gehen > regeln.TAG_MIN for t in db.tage_alle()):
        return []
    return [_eintrag("stempel-mitternacht", "info", STEMPEL_MITTERNACHT, "Einstellen", "#/einstellungen/arbeitszeit")]


def planungsjahre(heute) -> list:
    """Jahre, die Urlaub, Sondertage und Einstellungen am Tag heute (date oder datetime) zum Planen anbieten: [J], ab PLAN_VORLAUF_MONAT [J, J + 1].
    Gleich in der Oberfläche (grundlage.js planungsjahre)."""
    j = heute.year
    return [j, j + 1] if heute.month >= PLAN_VORLAUF_MONAT else [j]


def _urlaub_planen(heute: date) -> list:
    """urlaub-planen-<J+1> (info, „Nicht mehr zeigen“ hakt ab; die Kennung trägt das Jahr, damit es im nächsten Dezember wiederkommt):
    im URLAUB_PLANEN_MONAT die Erinnerung, den Urlaub des Folgejahres zu planen."""
    if heute.month != URLAUB_PLANEN_MONAT:
        return []
    folgejahr = planungsjahre(heute)[-1]
    return [_eintrag(f"urlaub-planen-{folgejahr}", "info", URLAUB_PLANEN.format(jahr=folgejahr), "Zur Planung", "#/urlaub/planung")]


def _tag(heute) -> date:
    """Nur das Datum, auch wenn ein Zeitpunkt übergeben wurde."""
    return heute.date() if isinstance(heute, datetime) else heute


def sicherung_grenze(heute: date) -> int:
    """Gelb-Grenze: nach so vielen Tagen ohne Sicherung kommt der Hinweis (Regel zutun_sicherung_tage, bei 0 die Vorgabe)."""
    return konfig.sicherung_tage(konfig.fuer(heute))


def _sicherung_eintrag(kennung: str, alter: int, text: str, heute: date) -> list:
    """Eintrag zur Sicherung: gelb ab der Gelb-Grenze, rot ab der Rot-Grenze; darunter nichts. alter: Tage seit der letzten Sicherung bzw. dem ersten Eintrag."""
    werte = konfig.fuer(heute)
    if alter < konfig.sicherung_tage(werte):
        return []
    stufe = "rot" if alter >= konfig.sicherung_rot_tage(werte) else "gelb"
    return [_eintrag(kennung, stufe, text, "Jetzt sichern", "#/sicherung")]


def _sicherung(db, heute: date, stand: dict) -> list:
    """sicherung-nie (erster Eintrag mindestens Gelb-Grenze Tage alt, nie gesichert) oder sicherung-alt (letzte Sicherung zu alt), gelb, ab der Rot-Grenze rot.
    Nichts ohne Angabe im Stand und mit eingerichteter Synchronisierung (dann warnen abgleich-fehler und abgleich-alt)."""
    if "letzte_sicherung" not in stand or _sync_eingerichtet(stand):
        return []
    letzte = stand["letzte_sicherung"]
    if not letzte:
        alle = db.tage_alle()
        if not alle:
            return []
        return _sicherung_eintrag("sicherung-nie", (heute - alle[0].datum).days, "Deine Daten sind noch nie gesichert.", heute)
    d = _datum(letzte)
    if d is None:
        return []
    alter = (heute - d).days
    return _sicherung_eintrag("sicherung-alt", alter, f"Letzte Sicherung am {_de(d)}, vor {_tagen(alter)}.", heute)


def _sync_eingerichtet(stand: dict) -> bool:
    """Ist eine Synchronisierung eingerichtet (Ordner, Server oder GitHub)? Die eigene Ablage des Servers (Art „lokal“) gibt es immer; sie zählt erst,
    wenn die Person die Synchronisierung begonnen hat (Passwort gesetzt oder schon synchronisiert), sonst mahnte die Karte jeden ohne Synchronisierung."""
    ziel = stand.get("ziel") or {}
    begonnen = ziel.get("art") != "lokal" or stand.get("passwort") or stand.get("letzter")
    return bool((ziel.get("eingerichtet") and begonnen) or stand.get("github"))


def _sync(heute: date, stand: dict) -> list:
    """Passwort fehlt, Anmeldung am Server nötig, letzte Synchronisierung fehlgeschlagen, offene Konflikte, lange keine Synchronisierung."""
    if not _sync_eingerichtet(stand):
        return []
    r = []
    if stand.get("passwort") is False:
        r.append(_eintrag("abgleich-passwort", "rot", "Zum Synchronisieren fehlt das Passwort.", "Passwort eingeben", "#/sync"))
    grund = (stand.get("server_anmeldung") or {}).get("fehler")
    if grund:
        r.append(_eintrag("abgleich-anmeldung", "rot", sicherung.ANMELDE_TEXTE.get(grund, ANMELDUNG_UNBEKANNT), "Anmelden", "#/sync"))
    letzter = stand.get("letzter") or {}
    if letzter and not letzter.get("ok"):
        r.append(_eintrag("abgleich-fehler", "rot", SYNC_FEHLER, "Ansehen", "#/sync"))     # der Fehlertext steht auf der Seite Synchronisieren
    n = len(stand.get("konflikte") or [])
    if n:
        r.append(_eintrag("abgleich-konflikte", "rot", f"{'Ein Konflikt' if n == 1 else f'{n} Konflikte'} nach dem Synchronisieren.", "Entscheiden", "#/sync"))
    zuletzt = _datum(letzter.get("zeit")) if letzter.get("ok") else None
    if zuletzt and (heute - zuletzt).days >= SYNC_ALT_TAGE:
        r.append(_eintrag("abgleich-alt", "gelb", f"Seit {_tagen((heute - zuletzt).days)} nicht synchronisiert (zuletzt am {_de(zuletzt)}).", "Synchronisieren", "#/sync"))
    return r


def fehlende_tage(db, heute: date) -> list:
    """Arbeitstage (Regeln, Feiertage, eigene freie Tage, Abschnitte) seit dem ersten Eintrag und nicht vor „Erfassung gültig ab“ (R6),
    höchstens LUECKE_TAGE zurück, bis gestern, an denen nichts eingetragen ist. Urlaub, Krank und jede andere Art zählen als eingetragen, eine Anmerkung allein nicht."""
    alle = db.tage_alle()
    if not alle:
        return []
    eingetragen = {t.datum for t in alle if t.ho or t.dst or t.art}
    abschnitte, eigene = db.abschnitte(), {}
    sw = db.startwerte_lesen()
    von = max(alle[0].datum, heute - timedelta(days=LUECKE_TAGE), sw.ab if sw else date.min)
    r = []
    for d in regeln.tage_im_zeitraum(von, heute - timedelta(days=1)):
        if d.year not in eigene:
            eigene[d.year] = set(db.jahr_einstellung(d.year)["eigene_frei"])
        if d not in eingetragen and regeln.ist_soll_tag(d, eigene[d.year], abschnitte):
            r.append(d)
    return r


def _luecken(db, heute: date, vergessen=None) -> list:
    """tage-fehlen: Arbeitstage ohne Eintrag, ohne den Tag, den stempel-vergessen schon meldet; der Knopf öffnet den ersten.
    Bei mehreren Tagen dazu „fehlend“ (ISO-Daten, ältester zuerst), damit die Karte je Tag einen Sprung zum Nachtragen zeigt."""
    fehlen = [d for d in fehlende_tage(db, heute) if d != vergessen]
    if not fehlen:
        return []
    n, erster = len(fehlen), fehlen[0]
    text = f"{n} {'Arbeitstag' if n == 1 else 'Arbeitstage'} ohne Eintrag (seit {erster:%d.%m.})"
    e = _eintrag("tage-fehlen", "gelb", text, "Nachtragen", ZIEL_TAG.format(erster.isoformat()))
    if n > 1:
        e["fehlend"] = [d.isoformat() for d in fehlen]
    return [e]


def _stempel(db, heute) -> list:
    """stempel-offen: Die Stempeluhr läuft seit einem Tag vor heute oder (mit Uhrzeit) seit über 10 Stunden. Wer über Mitternacht arbeitet,
    sieht den Hinweis ab 00:00 (Vorgabe „läuft seit gestern oder über 10 Stunden“)."""
    s = db.stempel_lesen()
    if not s:
        return []
    start = s["start"]
    offen = start.date() < _tag(heute) or (isinstance(heute, datetime) and heute - start > STEMPEL_OFFEN)
    if not offen:
        return []
    return [_eintrag("stempel-offen", "rot", f"Die Stempeluhr läuft seit {start:%d.%m.}, {start:%H:%M} Uhr: Gehen nachtragen.", "Gehen nachtragen",
                     "#/start/stempel")]


def vergessener_tag(db, heute: date):
    """Der letzte Soll-Tag vor heute, wenn dort nichts eingetragen ist (fehlende_tage: ab erstem Eintrag und „Erfassung gültig ab“) und keine
    Stempeluhr läuft, die an oder vor ihm begann; sonst None."""
    fehlen = fehlende_tage(db, heute)
    if not fehlen or _soll_tag_davor(db, heute) != fehlen[-1]:
        return None
    s = db.stempel_lesen()
    return None if s and s["start"].date() <= fehlen[-1] else fehlen[-1]


def _soll_tag_davor(db, heute: date):
    """Der letzte Soll-Tag vor heute (Regeln, Feiertage, eigene freie Tage, Abschnitte), höchstens LUECKE_TAGE zurück; sonst None."""
    abschnitte = db.abschnitte()
    for n in range(1, LUECKE_TAGE + 1):
        d = heute - timedelta(days=n)
        if regeln.ist_soll_tag(d, set(db.jahr_einstellung(d.year)["eigene_frei"]), abschnitte):
            return d
    return None


def _vergessen(tag, heute: date) -> list:
    """stempel-vergessen: Am Tag „tag“ (vergessener_tag) ist nichts eingetragen; gestern mit kurzem Wochentag, sonst mit vollem."""
    if tag is None:
        return []
    if tag == heute - timedelta(days=1):
        wann = f"Gestern ({regeln.WT[tag.weekday()]}, {tag:%d.%m.})"
    else:
        wann = f"Am {WOCHENTAGE[tag.weekday()]}, {tag:%d.%m.}"
    return [_eintrag("stempel-vergessen", "gelb", f"{wann} ist nichts eingetragen. Stempeluhr vergessen?", "Nachtragen", ZIEL_TAG.format(tag.isoformat()))]


def _attest(db, heute: date) -> list:
    """attest-fehlt: dieselbe Zahl wie auf der Seite Krank (bericht.krank), für dieses Jahr und das Vorjahr zusammen.
    Das Vorjahr zählt mit, weil eine Dezember-Phase über den Jahreswechsel laufen kann; jedes Jahr zählt nur seine eigenen Einträge
    und nur in laufenden Phasen, daher nichts doppelt."""
    n = sum(bericht.krank(db, j, heute)["attest_fehlt"] for j in (heute.year - 1, heute.year))
    if not n:
        return []
    return [_eintrag("attest-fehlt", "rot", f"{_tage(n)} krank ohne Attest, länger als 3 Tage: Attest fehlt.", "Attest eintragen", "#/krank")]


def _verfall(db, heute: date) -> list:
    """urlaub-verfaellt-<Herkunftsjahr>: angesparter Urlaub mit Rest, der in höchstens VERFALL_TAGE Tagen verfällt (ältestes Konto zuerst),
    gelb, ab FRIST_ROT_TAGE rot. Das Jahr in der Kennung sorgt dafür, dass „Nicht mehr zeigen“ nicht auch das Konto des nächsten Jahres abhakt."""
    r = []
    for herkunft, rest in sorted(ur.angespart_verfuegbar(bericht.konten(db, heute.year, heute), heute.year, bericht.angespart_genommen(db)).items()):
        bis = ur.verfaellt_am(herkunft)
        noch = (bis - heute).days
        if noch <= VERFALL_TAGE:
            text = VERFALL_TEXT.format(rest=_tage(rest), herkunft=herkunft, verb="verfällt" if rest == 1 else "verfallen", bis=_de(bis),
                                       wann=f"in {_tagen(noch)}" if noch else "heute")
            r.append(_eintrag(f"urlaub-verfaellt-{herkunft}", "rot" if noch <= FRIST_ROT_TAGE else "gelb", text, "Urlaub planen", "#/urlaub/planung"))
    return r[:1]


def _danach(fr: dict) -> str:
    """Satz, was nach der Frist mit dem offenen Resturlaub geschieht (ansparen, verfallen oder voraussichtlich verfallen)."""
    if not fr["sicher"]:
        return DANACH_VORAUSSICHTLICH
    if not fr["angespart"]:
        return DANACH_VERFALL
    return DANACH_ANSPAREN.format(angespart=_zahl(fr["angespart"]), verfallen=_zahl(fr["verfallen"])) if fr["verfallen"] else DANACH_ALLES_ANGESPART


def _nach_frist(fr: dict, vorjahr: int) -> str:
    """Satz nach der Frist: wie viel angespart wurde und wie viel verfallen ist (bei Angestellten voraussichtlich)."""
    angespart, verfallen = _tage(fr["angespart"]), _tage(fr["verfallen"])
    if not fr["sicher"]:
        return NACH_VORAUSSICHTLICH.format(verfallen=verfallen, vorjahr=vorjahr)
    if not fr["angespart"]:
        return NACH_VERFALLEN.format(verfallen=verfallen, vorjahr=vorjahr)
    if not fr["verfallen"]:
        return NACH_ALLES_ANGESPART.format(angespart=angespart, vorjahr=vorjahr)
    return NACH_ANGESPART.format(angespart=angespart, verfallen=_zahl(fr["verfallen"]), vorjahr=vorjahr)


def _resturlaub(db, heute: date) -> list:
    """resturlaub-frist-<Vorjahr>: offener Resturlaub des Vorjahres in höchstens FRIST_WARNEN_TAGE Tagen vor der Frist (bericht.frist_stand), gelb,
    ab FRIST_ROT_TAGE rot. resturlaub-<Vorjahr>: nach der Frist einmal, was angespart wurde und was verfallen ist
    (info, „Nicht mehr zeigen“ hakt ab; beide Kennungen tragen das Jahr, damit das Abhaken nicht für das nächste Jahr gilt).
    Eine eigene Frist kann am Jahresrand liegen: im Dezember zählt auch die Frist des nächsten Jahres (etwa 15.01.), im Januar und Februar
    die des Vorjahres (etwa 31.12.)."""
    jahre = [heute.year]
    if (heute - date(heute.year - 1, 12, 31)).days <= NACH_FRIST_TAGE:
        jahre.insert(0, heute.year - 1)
    if (date(heute.year + 1, 1, 1) - heute).days <= FRIST_WARNEN_TAGE:
        jahre.append(heute.year + 1)
    return [e for j in jahre for e in _resturlaub_jahr(db, heute, j)]


def _resturlaub_jahr(db, heute: date, j: int) -> list:
    """Eintrag zur Frist des Übertrags ins Jahr j (Rest des Jahres j − 1) am Tag heute: Warnung davor, Hinweis danach bis Jahresende,
    mindestens NACH_FRIST_TAGE lang (sonst sähe man ihn bei Frist 31.12. nie); sonst keiner."""
    fr = bericht.frist_stand(db, j)
    if not fr["frist"] or not fr["offen"]:
        return []
    vorjahr, noch = j - 1, (fr["frist"] - heute).days
    if noch < 0:
        if heute > max(date(j, 12, 31), fr["frist"] + timedelta(days=NACH_FRIST_TAGE)):
            return []
        return [_eintrag(f"resturlaub-{vorjahr}", "info", _nach_frist(fr, vorjahr), "Ansehen", "#/urlaub")]
    if noch > FRIST_WARNEN_TAGE:
        return []
    stufe = "rot" if noch <= FRIST_ROT_TAGE else "gelb"
    text = FRIST_TEXT.format(vorjahr=vorjahr, offen=_tage(fr["offen"]), frist=f"{fr['frist']:%d.%m.}", danach=_danach(fr))
    return [_eintrag(f"resturlaub-frist-{vorjahr}", stufe, text, "Urlaub planen", "#/urlaub/planung")]


def _quote(db, heute: date, horest_an: bool) -> list:
    """quote-grenze: nur im Homeoffice-Modus mit Grenze. Rot, wenn die Quote des Jahres (bericht.jahr_summe, mit Startwerten) schon an der Grenze ist,
    gelb, wenn die Jahres-Prognose darüber liegt."""
    regel = konfig.fuer(heute)
    if regel["ho_modus"] != "grenze":
        return []
    ziel = "#/horest" if horest_an else "#/jahr"
    j = heute.year
    if bericht.jahr_summe(db, j)["quote_rot"]:
        return [_eintrag("quote-grenze", "rot", f"Homeoffice {j} über {regel['ho_grenze']} %.", "Ansehen", ziel)]
    p = bericht.prognose(db, j, heute=heute)
    if p and p["status"] == "ueber":
        return [_eintrag("quote-grenze", "gelb", f"Prognose {j} über {regel['ho_grenze']} % Homeoffice ({p['quote_ende']}).", "Ansehen", ziel)]
    return []


def _quote_monat(db, heute: date) -> list:
    """quote-monat: Die Prognose des laufenden Monats liegt über der Grenze und das Jahr ist nicht sicher (die Quote gilt fürs Jahr, funktionen.md 2a).
    Gelb mit den nötigen Büro-Tagen; rot, wenn auch nur noch Büro nicht reicht (die nötige Zeit ist auf die geplante begrenzt, deshalb zählt
    buero_reicht_nicht). Bei genau der Grenze kein Hinweis: Status „ueber“ gilt erst darüber."""
    regel = konfig.fuer(heute)
    if regel["ho_modus"] != "grenze":
        return []
    pm = bericht.prognose(db, heute.year, heute.month, heute)
    if not pm or pm["status"] != "ueber" or pm["noetig_tage"] <= 0:
        return []
    pj = bericht.prognose(db, heute.year, heute=heute)
    if pj and pj["status"] == "sicher":
        return []
    monat, n, grenze = bericht.MONATE[heute.month - 1], pm["noetig_tage"], regel["ho_grenze"]
    if pm["buero_reicht_nicht"] or n > pm["rest_tage"]:
        return [_eintrag("quote-monat", "rot", f"Homeoffice im {monat} bleibt über {grenze} %, auch wenn du nur noch im Büro arbeitest.", "Ansehen", "#/horest")]
    text = f"Homeoffice im {monat} droht über {grenze} % zu kommen: noch {n} Büro-{'Tag' if n == 1 else 'Tage'} in diesem Monat nötig."
    return [_eintrag("quote-monat", "gelb", text, "Ansehen", "#/horest")]


KAPPUNG_VORLAUF_TAGE = 28                        # „Zu tun“ warnt ab 4 Wochen vor dem Stichtag (gelb), ab 7 Tagen rot
KAPPUNG_ROT_TAGE = 7
KAPPUNG_WARNUNG = "Gleitzeit {stand}, am {datum:%d.%m.} verfallen {verfallen}"
KAPPUNG_KNOPF = "Übernahme eintragen"
KAPPUNG_ZIEL = "#/einstellungen/arbeitszeit/{}"           # mit dem Jahr des Stichtags: die Übernahme gilt je Jahr


def _kappung(db, heute: date) -> list:
    """gleitzeit-kappung: am nächsten Stichtag mit Kappung (woche.kappungstage) in höchstens KAPPUNG_VORLAUF_TAGE Tagen liegt das Plus über
    Grenze plus genehmigter Übernahme. Stand: Konto heute, am Stichtag selbst vor der Kappung. Gelb, ab KAPPUNG_ROT_TAGE Tagen rot."""
    tage = wo.kappungstage(heute, heute + timedelta(days=KAPPUNG_VORLAUF_TAGE))
    if not tage:
        return []
    stichtag = tage[0]
    stand = wo.konto(db, heute) + sum(k["verfallen_min"] for k in wo.kappungen(db, heute) if k["datum"] == heute)
    grenze = konfig.fuer(stichtag)["kappung_grenze_min"] + db.kappung_uebernahme(stichtag.year)
    if stand <= grenze:
        return []
    zf = konfig.fuer(heute)["zeitformat"]
    stufe = "rot" if (stichtag - heute).days <= KAPPUNG_ROT_TAGE else "gelb"
    text = KAPPUNG_WARNUNG.format(stand=fmt_dauer(stand, zf), datum=stichtag, verfallen=fmt_dauer(stand - grenze, zf))
    return [_eintrag("gleitzeit-kappung", stufe, text, KAPPUNG_KNOPF, KAPPUNG_ZIEL.format(stichtag.year))]


def _saldo(db, heute: date) -> list:
    """saldo-grenze: Gleitzeit-Konto (Stand heute, wie die Übersicht) über zutun_saldo_grenze Stunden im Plus oder über zutun_saldo_minus
    Stunden im Minus. Grenze 0 heißt kein Hinweis in dieser Richtung (Entscheidung vom 23.11.2026)."""
    k, regel = wo.konto(db, heute), konfig.fuer(heute)
    plus, minus = wo.saldo_grenzen(regel)
    grenze = plus if k > 0 else minus
    if not grenze or abs(k) <= grenze:
        return []
    zf = regel["zeitformat"]
    return [_eintrag("saldo-grenze", "gelb", f"Gleitzeit-Konto {wo.fmt_saldo(k, zf)} Stunden, mehr als {fmt_dauer(grenze, zf)} Stunden {'im Plus' if k > 0 else 'im Minus'}.",
                     "Woche ansehen", "#/woche")]


def _admin(admin) -> list:
    """Hinweise für die Verwaltung (nur, wenn der Server sie übergibt): Konten ohne Passwort, Einträge im Papierkorb."""
    if not isinstance(admin, dict):
        return []
    r = []
    n = admin.get("passwort_offen") or 0
    if n:
        r.append(_eintrag("admin-passwort-offen", "info", f"{n} {'Konto wartet' if n == 1 else 'Konten warten'} auf ein Passwort.", "Verwalten", "#/einstellungen/geraete"))
    n = admin.get("papierkorb") or 0
    if n:
        r.append(_eintrag("admin-papierkorb", "info", f"{n} {'Eintrag liegt' if n == 1 else 'Einträge liegen'} im Papierkorb.", "Verwalten", "#/einstellungen/geraete"))
    return r


def _neuere_version(wert):
    """Der Wert, wenn er eine gültige Versionsnummer (JJJJMMTT.HHMM) über der eigenen ist, sonst None. Prüft selbst, weil die Nummer
    eines anderen Geräts aus einer fremden Datei kommt."""
    return wert if isinstance(wert, str) and update.VERSION_FORM.fullmatch(wert) and wert > urheber.VERSION else None


def _update(stand: dict) -> list:
    """update-da (GitHub meldet eine neuere Version, stand["update_neueste"]) und update-anderes-geraet (ein Gerät im Sync nutzt eine neuere,
    stand["sync_app_neueste"]). Knopf zur Release-Seite nur in der Windows- und der Android-App, sonst zur Hilfe. "version": die neue Nummer
    (geprüft), daraus verlinkt die Oberfläche „Was ist neu?“ im Wiki."""
    r = []
    neu = _neuere_version(stand.get("update_neueste"))
    if neu:
        r.append({**_eintrag("update-da", "info", f"Version {neu} ist erschienen. Du hast {urheber.VERSION}.", "Zum Download", update.RELEASE_SEITE), "version": neu})
    neu = _neuere_version(stand.get("sync_app_neueste"))
    if neu:
        ziel = update.RELEASE_SEITE if stand.get("plattform") in UPDATE_PLATTFORMEN else "#/hilfe"
        r.append({**_eintrag("update-anderes-geraet", "info", f"Ein anderes Gerät nutzt schon Version {neu}. Bitte auch hier aktualisieren.", "Aktualisieren", ziel),
                  "version": neu})
    return r


def _vermerk(db, heute: date) -> list:
    """vermerk-pruefen (funktionen.md 5): Tage bis heute im laufenden und vorigen Jahr, nicht vor „Erfassung gültig ab“, mit Vermerk und ohne
    „Zeiten geprüft“. Ein Eintrag; der Knopf öffnet den ersten Tag. Künftige Tage melden nichts."""
    sw = db.startwerte_lesen()
    von = max(date(heute.year - 1, 1, 1), sw.ab if sw else date.min)
    offen = [t for t in db.tage_alle() if von <= t.datum <= heute and t.vermerk and not t.geprueft]
    if not offen:
        return []
    erster = offen[0]
    if len(offen) == 1:
        text = f"{VERMERK_KURZ.get(erster.vermerk, VERMERK_SONST)} am {erster.datum:%d.%m.}: Zeiten prüfen."
    else:
        text = f"{len(offen)} Tage mit Dienstreise oder Fortbildung: Zeiten prüfen (erster am {erster.datum:%d.%m.})."
    return [_eintrag("vermerk-pruefen", "gelb", text, "Prüfen", ZIEL_TAG.format(erster.datum.isoformat()))]


def _uebertrag_pruefen(db, heute: date) -> list:
    """uebertrag-pruefen (funktionen.md 4): Nach dem Ansparen steht der Übertrag von Hand und folgt späteren Änderungen am Vorjahr nicht mehr.
    Gelb, solange der Merker „ansparen“ gesetzt ist, ein Konto des Vorjahres besteht, der Übertrag nicht max(0, automatisch − Konto) ist und sich
    der automatische Übertrag seit dem Ansparen geändert hat (eine bewusste Änderung von Hand meldet nichts; ohne gemerkten Wert wie früher).
    Gilt das ganze Jahr, nicht nur im Januar."""
    vorjahr = heute.year - 1
    konto = next((k for k in db.konten() if k.herkunft == vorjahr), None)
    if konto is None or ANSPAREN_SCHRITT not in db.jahreswechsel_erledigt(vorjahr):
        return []
    stand = bericht.urlaub_stand(db, heute.year)
    soll = max(0, stand["uebertrag_auto"] - konto.tage)
    if not stand["uebertrag_hand"] or stand["uebertrag"] == soll or db.ansparen_auto(vorjahr) == stand["uebertrag_auto"]:
        return []
    text = f"Resturlaub aus {vorjahr} hat sich geändert: Übertrag jetzt {_zahl(soll)} statt {_tage(stand['uebertrag'])}?"
    return [_eintrag("uebertrag-pruefen", "gelb", text, "Ansehen", "#/urlaub")]


def _schritt(id_: str, text: str, erledigt, knopf: str, ziel: str) -> dict:
    """Ein Schritt der Jahreswechsel-Karte in der festen Form."""
    return {"id": id_, "text": text, "erledigt": bool(erledigt), "knopf": knopf, "ziel": ziel}


def _anspar_grenze(auto: float) -> int:
    """Höchstzahl, die das Ansparen annimmt: ganze Tage bis ur.ANSPAR_MAX und bis zum automatischen Übertrag „auto“ (Rest des Vorjahres)."""
    return int(min(ur.ANSPAR_MAX, auto))


def _vorjahr_vor_beginn(db, vorjahr: int) -> bool:
    """True, wenn das ganze Vorjahr vor „Erfassung gültig ab“ liegt (R6): Dann zählt sein Urlaub nicht und es gibt nichts anzusparen."""
    sw = db.startwerte_lesen()
    return bool(sw) and sw.ab.year > vorjahr


def _ansparen_erledigt(db, heute: date, rest: float, merker: set) -> bool:
    """Ansparen gilt als erledigt ohne Rest, mit Merker („Nicht ansparen“), mit Konto des Vorjahres oder mit Übertrag des Jahres von Hand."""
    vorjahr = heute.year - 1
    return (rest <= 0 or ANSPAREN_SCHRITT in merker or any(k.herkunft == vorjahr for k in db.konten())
            or db.jahr_einstellung(heute.year)["uebertrag"] is not None)


def jahreswechsel(db, heute: date, stand: dict):
    """Karte „Jahreswechsel“ (funktionen.md 4, GET /api/jahreswechsel): vom 1. bis 31. Januar, wenn das Vorjahr Einträge hat, die Karte nicht
    ausgeblendet ist und mindestens ein Schritt offen ist; sonst None. Schritte je eingeschaltetem Modul: ansparen, gleitzeit, steuer, sicherung.
    stand: wie bei eintraege (eine Sicherung ab dem 1. Januar erledigt den Schritt Sicherung).
    Rückgabe {jahr: Vorjahr, schritte: [{id, text, erledigt, knopf, ziel}], rest_urlaub}."""
    vorjahr = heute.year - 1
    merker = db.jahreswechsel_erledigt(vorjahr)
    if heute.month != JAHRESWECHSEL_MONAT or AUS_SCHRITT in merker or not db.tage(vorjahr):
        return None
    regel = konfig.fuer(heute)
    an = set(regel["module_aus"]).isdisjoint
    rest = bericht.urlaub_stand(db, heute.year)["uebertrag_auto"]       # derselbe Wert wie beim Ansparen (jahreswechsel_ansparen)
    schritte = []
    if an({"urlaub", "angespart"}) and not _vorjahr_vor_beginn(db, vorjahr) and vorjahr < ur.FRIST_AB_HERKUNFT:     # danach: Frist statt Ansparen von Hand
        schritte.append(_schritt(ANSPAREN_SCHRITT, f"Resturlaub {vorjahr}: {_tage(rest)}. Wie viele davon ansparen? (höchstens {_anspar_grenze(rest)})",
                                 _ansparen_erledigt(db, heute, rest, merker), "Ansparen", "#/urlaub"))
    if an({"gleitzeit"}):
        k = wo.konto(db, date(vorjahr, 12, 31))
        schritte.append(_schritt("gleitzeit", f"Gleitzeit-Konto am 31.12.{vorjahr}: {wo.fmt_saldo(k, regel['zeitformat'])} Stunden. Es läuft im neuen Jahr weiter.",
                                 "gleitzeit" in merker, "Stimmt", "#/einstellungen/person"))
    if an({"nachweis"}) and regel["ho_modus"] != "kein":
        schritte.append(_schritt("steuer", f"Homeoffice-Übersicht {vorjahr} für die Steuer herunterladen", "steuer" in merker, "Herunterladen",
                                 f"api/steuer/{vorjahr}.pdf"))
    if an({"sicherung"}):
        gesichert = _datum(stand.get("letzte_sicherung"))
        schritte.append(_schritt("sicherung", "Sicherung anlegen", "sicherung" in merker or (gesichert and gesichert.year >= heute.year),
                                 "Jetzt sichern", "#/sicherung"))
    if all(s["erledigt"] for s in schritte):
        return None
    return {"jahr": vorjahr, "schritte": schritte, "rest_urlaub": rest}


def jahreswechsel_ansparen(db, heute: date, tage) -> dict:
    """„Ansparen“ (POST /api/jahreswechsel/ansparen): legt das Konto des Vorjahres mit „tage“ an und setzt den Übertrag des Jahres von Hand auf
    automatisch − tage, sonst zählten die Tage doppelt (als Konto und als Rest). Eingabe: ganze Zahl 0 bis min(ANSPAR_MAX, Rest); 0 hakt nur ab.
    Nur für Vorjahre vor ur.FRIST_AB_HERKUNFT; danach gilt die Frist des Resturlaubs (bericht._frist).
    Rückgabe {ok, konto, uebertrag}. Fehler: AnsparFehler (ein ValueError) bei Vorjahr ab ur.FRIST_AB_HERKUNFT, anderer Zahl, schon angelegtem Konto oder schon erledigtem Schritt."""
    vorjahr = heute.year - 1
    if vorjahr >= ur.FRIST_AB_HERKUNFT:
        raise AnsparFehler(ANSPAREN_AUTOMATISCH.format(jahr=vorjahr))
    with db.lock:
        auto = bericht.urlaub_stand(db, heute.year)["uebertrag_auto"]
        grenze = _anspar_grenze(auto)
        if isinstance(tage, bool) or not isinstance(tage, int) or not 0 <= tage <= grenze:
            raise AnsparFehler(ANSPAREN_GRENZE.format(max=grenze))
        if any(k.herkunft == vorjahr for k in db.konten()):
            raise AnsparFehler(KONTO_SCHON_DA.format(jahr=vorjahr))
        if ANSPAREN_SCHRITT in db.jahreswechsel_erledigt(vorjahr):
            raise AnsparFehler(SCHON_ANGESPART.format(jahr=vorjahr))
        db.jahreswechsel_ansparen(vorjahr, tage, auto - tage, auto)
    return {"ok": True, "konto": tage, "uebertrag": auto - tage}
