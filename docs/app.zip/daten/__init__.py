# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Paket daten (Teamplan B6): Module der Schicht daten; Importe als `from daten import <modul>`."""
