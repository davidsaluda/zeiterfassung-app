# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""SQLite-Speicher für die Zeiterfassung-App. Eine Verbindung je Aufruf, alle Zugriffe unter einem Schloss.

Für die Synchronisierung zwischen Geräten merkt sich die Tabelle „stand“ zu jedem Tag und jeder Einstellung, wann und auf welchem Gerät sie zuletzt
geändert wurde, dazu die Fassung (je Gerät ein Zähler). Gelöschtes bleibt dort als Markierung stehen. Die Regeln des Zusammenführens stehen in sync.py."""
import contextlib
import json
import os
import re
import shutil
import sqlite3
import tempfile
import threading
from datetime import date, datetime, timezone

from kern.regeln import ABSCHNITT_ARTEN, ARTEN, JAHR_MAX, JAHR_MIN, NOTIZ_MAX, STEUERZEICHEN, URLAUB_MAX, WOCHENSTUNDEN_MAX, WT, Tag, Abschnitt, gleittage_max, ist_werktag, kind_krank_max, notiz_bereinigen, tageszeit_gueltig, uhrzeiten_gueltig, zahl_gueltig
from daten import konfig
from daten.sicherung import MAX_KLAR
from kern.urlaub import Konto, ERHOLUNG_VORGABE

SCHEMA = """
CREATE TABLE IF NOT EXISTS tag (datum TEXT PRIMARY KEY, ho INTEGER NOT NULL DEFAULT 0, dst INTEGER NOT NULL DEFAULT 0,
                                art TEXT NOT NULL DEFAULT '', notiz TEXT NOT NULL DEFAULT '', konto INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS jahr (jahr INTEGER PRIMARY KEY, anspruch REAL NOT NULL, eigene_frei TEXT NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS abschnitt (id INTEGER PRIMARY KEY AUTOINCREMENT, von TEXT NOT NULL, bis TEXT NOT NULL,
                                      wochenstunden REAL NOT NULL, art TEXT NOT NULL, arbeitstage TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS konto (herkunft INTEGER PRIMARY KEY, tage REAL NOT NULL);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stempel (id INTEGER PRIMARY KEY CHECK (id = 1), art TEXT NOT NULL, start TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS stand (art TEXT NOT NULL, schluessel TEXT NOT NULL, zeit TEXT NOT NULL, geraet TEXT NOT NULL, fassung TEXT NOT NULL,
                                  geloescht INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (art, schluessel));
CREATE TABLE IF NOT EXISTS konflikt (art TEXT NOT NULL, schluessel TEXT NOT NULL, fremd TEXT NOT NULL, PRIMARY KEY (art, schluessel));
"""
ALT = "alt"                                               # Fassung von Einträgen aus der Zeit vor dem Sync (auf allen Geräten gleich)
ZAEHLER_AB = "abgleich_zaehler_ab"                        # nur auf diesem Gerät (nicht in SYNC_META): höchster eigener Zähler vor dem letzten Wiederherstellen
ZAEHLER_AB_FORM = re.compile(r"[0-9]{1,9}")                # nur ASCII-Ziffern („²“ besteht isdigit(), aber nicht int())
ZAEHLER_AB_MAX = 10 ** 9 - 10 ** 6                         # höchste Untergrenze (= sync.FASSUNG_RAND): darüber gälte bald jede eigene Änderung beim Partner als ungültig
OHNE_GERAET = "unbekannt"
ABSCHNITTE = ("abschnitte", "alle")                       # die Abschnitte synchronisiert die App als ein Ganzes (ihre Nummern gelten nur je Gerät)
# Kopf des Monatsnachweises (funktionen.md 3): je Feld ein Meta-Schlüssel „nachweis_<Feld>“, Text ohne Steuerzeichen, höchstens NACHWEIS_MAX Zeichen
NACHWEIS_FELDER = {"name": "Name", "arbeitgeber": "Arbeitgeber", "personalnummer": "Personalnummer"}
NACHWEIS_VORSILBE = "nachweis_"
NACHWEIS_MAX = 80
NACHWEIS_META = re.compile(NACHWEIS_VORSILBE + "(?:" + "|".join(NACHWEIS_FELDER) + ")")
# Jahreswechsel-Helfer (funktionen.md 4): je abgehaktem Schritt „jahreswechsel_<Vorjahr>_<Schritt>“ = "1". Ein Schlüssel je Schritt, weil der Sync
# keine Listen zusammenführt: Zwei Geräte, die offline verschiedene Schritte abhaken, ergeben so keinen Konflikt.
ANSPAREN = "ansparen"                                         # Schritt, den Db.jahreswechsel_ansparen abhakt
JAHRESWECHSEL_SCHRITTE = (ANSPAREN, "gleitzeit", "steuer", "sicherung", "aus")
JAHRESWECHSEL_VORSILBE = "jahreswechsel_"
JAHRESWECHSEL_META = re.compile(JAHRESWECHSEL_VORSILBE + "[0-9]{4}_(?:" + "|".join(JAHRESWECHSEL_SCHRITTE) + ")")
ERLEDIGT = "1"
# automatischer Übertrag beim Ansparen „ansparen_auto_<Vorjahr>“, im Sync seit Format 5 (Geräte bis Format 4 lesen solche Dateien gar nicht);
# zutun meldet „uebertrag-pruefen“ nur, wenn der automatische Übertrag seitdem anders ist, nicht nach einer bewussten Änderung von Hand
ANSPAREN_AUTO = "ansparen_auto_{}"
ANSPAREN_AUTO_META = re.compile(re.escape(ANSPAREN_AUTO.format("")) + "[0-9]{4}")
# Geführte Einrichtung beim ersten Start (funktionen.md 6.1): nur dieses Gerät, deshalb nicht in SYNC_META; fehlt = offen
EINRICHTUNG = "einrichtung"
EINRICHTUNG_STAENDE = ("fertig", "uebersprungen")
# diese Einstellungen wandern mit; eigene Profile seit 18.11.2026 je Profil ein Satz „profil:<Name>“, damit Konflikte und Löschen nur dieses Profil treffen
SYNC_META = re.compile(r"buero_pro_woche(?:_monat)?|familientage_\d{4}|gleitzeit_start_min|freizeit_start_min|konfig|" + konfig.STARTWERTE + "|"
                           + NACHWEIS_META.pattern + "|" + JAHRESWECHSEL_META.pattern + "|" + ANSPAREN_AUTO_META.pattern + "|" + re.escape(konfig.PROFIL_VORSILBE) + f"(?:{konfig.PROFIL_NAME.pattern})")
PROFILE_ALT = "profile"                                   # alle eigenen Profile in einem Satz (nur die Fassung vom 18.11.2026): wird beim Start umgestellt
PROFILE_UNLESBAR = "profile_unlesbar"                     # ein unlesbarer Sammelsatz bleibt hier liegen (nur auf diesem Gerät)
STAND_ARTEN = ("tag", "jahr", "konto", "meta", "abschnitte")
TAG_FELDER = ("ho", "dst", "art", "notiz", "konto", "attest", "freigabe", "kommen", "gehen", "pause", "vermerk", "geprueft")   # Reihenfolge wie _tag_schreiben
UHR_SPALTEN = (("kommen", "INTEGER NOT NULL DEFAULT -1"), ("gehen", "INTEGER NOT NULL DEFAULT -1"), ("pause", "INTEGER NOT NULL DEFAULT 0"))
ABSCHNITT_FELDER = ("von", "bis", "wochenstunden", "art", "arbeitstage", "tagesminuten")
# Spalten seit Phase 2 (R4, funktionen.md 0.1), im Sync seit Format 5. Ältere Datenbanken bekommen sie in _schema.
VERMERK_SPALTEN = (("vermerk", "TEXT NOT NULL DEFAULT ''"), ("geprueft", "INTEGER NOT NULL DEFAULT 0"))
TAGESMINUTEN_SPALTE = ("tagesminuten", "TEXT NOT NULL DEFAULT ''")
LEERER_TAG = {"ho": 0, "dst": 0, "art": "", "notiz": ""}      # so geschrieben, wird ein Tag gelöscht
# Startstände der Konten (R6): mit „Erfassung gültig ab“ im JSON der Startwerte, sonst im eigenen Meta-Schlüssel wie bisher
KONTEN = {"gleitzeit": ("gleitzeit_min", "gleitzeit_start_min"), "freizeit": ("freizeit_min", "freizeit_start_min")}


WEG1_MELDUNG = "{} Abschnitte ohne Arbeitstage rechnen jetzt mit den Arbeitstagen der Regeln"     # Protokoll des Dienstes beim Umstellen (R4)
ALLES, KEIN_TAG = date.min, date.max                      # Grenzfälle für „geändert ab“
AENDERUNGEN_MERKEN = 500
# eine Schema-Umstellung zur Zeit im ganzen Prozess: Jedes Db hat ein eigenes Schloss, und zwei Db derselben Datei (etwa gleichzeitige
# erste Demo-Anfragen) fügten sonst dieselbe Spalte zweimal an („duplicate column name“), denn SQLite schreibt ALTER TABLE sofort fest
_SCHEMA_SCHLOSS = threading.Lock()


class Db:
    """Datenbank der App (SQLite): Tage, Urlaubsjahre, Konten, Abschnitte, Stempeluhr, Einstellungen und das Änderungsprotokoll für die Synchronisierung."""
    def __init__(self, pfad: str, geraet: str = OHNE_GERAET):
        """Öffnet die Datenbank unter „pfad“ (legt Ordner und Datei an) und stellt das Schema her. geraet: Kennung dieses Geräts im Änderungsprotokoll."""
        self.pfad = pfad
        self.geraet = geraet                               # Kennung dieses Geräts für das Änderungsprotokoll
        self.uhr = lambda: datetime.now(timezone.utc)      # Änderungszeit in Weltzeit (Geräte in verschiedenen Zeitzonen bleiben vergleichbar)
        self.lock = threading.RLock()
        self.gen = 0                                       # zählt Schreibzugriffe (Schlüssel für alle Zwischenspeicher)
        self._aenderungen = []                             # (gen, frühester betroffener Tag) der letzten Schreibzugriffe, siehe geaendert_seit
        self._cache = {}                                   # gelesene Daten bis zum nächsten Schreibzugriff
        self._aufnahme = None                              # {iso: (vorher, nachher)} während aufnahme() läuft, sonst None
        self._rueckgaengig = None                          # das gemerkte Rückgängig (rueckgaengig.py), nur im Speicher: nach Neustart nichts zurückzunehmen
        os.makedirs(os.path.dirname(os.path.abspath(pfad)), exist_ok=True)
        self._schema()

    def _schema(self, sichern: bool = True):
        """Tabellen anlegen und ältere Datenbanken auf den heutigen Stand bringen (auch nach dem Wiederherstellen einer alten Sicherung).
        sichern: Vor der Umstellung einer Datenbank mit Einträgen wird eine Kopie in den Ordner „sicherung“ gelegt."""
        with self.lock, _SCHEMA_SCHLOSS:                   # Prüfen und Umstellen gehören zusammen, siehe _SCHEMA_SCHLOSS
            with self._c() as c:
                tabellen = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                mit_tagen = "tag" in tabellen and c.execute("SELECT 1 FROM tag LIMIT 1").fetchone() is not None
                spalten = {r[1] for r in c.execute("PRAGMA table_info(tag)")} if "tag" in tabellen else set()
                # Anmerkungen mit Steuerzeichen (Zeilenumbrüche aus dem Import): Andere Geräte lehnen sie im Sync ab, deshalb einmal bereinigen
                # dazu zu lange Anmerkungen (alte Sicherung): gekürzt statt abgelehnt
                unsauber = [(r[0], notiz_bereinigen(r[1])[:NOTIZ_MAX]) for r in c.execute("SELECT datum, notiz FROM tag WHERE notiz != ''")
                            if STEUERZEICHEN.search(r[1]) or len(r[1]) > NOTIZ_MAX] if mit_tagen else []
                profile_alt = "meta" in tabellen and c.execute("SELECT 1 FROM meta WHERE k=?", (PROFILE_ALT,)).fetchone() is not None
                umstellen = sichern and ((mit_tagen and ("stand" not in tabellen or any(n not in spalten for n, _ in UHR_SPALTEN) or bool(unsauber))) or profile_alt)
                umstellen = umstellen or (sichern and ((mit_tagen and any(n not in spalten for n, _ in VERMERK_SPALTEN))
                                                       or _abschnitte_ohne_tagesminuten(c, tabellen) or ("jahr" in tabellen and bool(_frei_als_text(c)))))
            if umstellen:
                ordner = os.path.join(os.path.dirname(os.path.abspath(self.pfad)), "sicherung")
                os.makedirs(ordner, exist_ok=True)
                self._kopieren(self.pfad, os.path.join(ordner, f"vor-umstellung-{datetime.now():%Y-%m-%d_%H%M%S}.db"))
            with self._c() as c:
                c.executescript(SCHEMA)
                if "uebertrag" not in [r[1] for r in c.execute("PRAGMA table_info(jahr)")]:
                    c.execute("ALTER TABLE jahr ADD COLUMN uebertrag REAL")
                if "konto" not in [r[1] for r in c.execute("PRAGMA table_info(tag)")]:
                    c.execute("ALTER TABLE tag ADD COLUMN konto INTEGER NOT NULL DEFAULT 0")
                if "attest" not in [r[1] for r in c.execute("PRAGMA table_info(tag)")]:
                    c.execute("ALTER TABLE tag ADD COLUMN attest TEXT NOT NULL DEFAULT ''")
                if "freigabe" not in [r[1] for r in c.execute("PRAGMA table_info(tag)")]:
                    c.execute("ALTER TABLE tag ADD COLUMN freigabe INTEGER NOT NULL DEFAULT 0")
                vorhanden = [r[1] for r in c.execute("PRAGMA table_info(tag)")]
                for name, typ in UHR_SPALTEN:                    # Kommen, Gehen, Pause (seit 20261116): alte Tage bleiben „ohne Uhrzeit“
                    if name not in vorhanden:
                        c.execute(f"ALTER TABLE tag ADD COLUMN {name} {typ}")
                for name, typ in VERMERK_SPALTEN:                 # Vermerk und „geprüft“ am Tag (Phase 2): alte Tage ohne Vermerk
                    _spalte_ergaenzen(c, "tag", name, typ)
                weg1 = _abschnitte_weg1(c)                       # vor dem Anlegen der Spalte: so kommt die Meldung genau einmal
                if _spalte_ergaenzen(c, "abschnitt", *TAGESMINUTEN_SPALTE) and weg1:
                    print(WEG1_MELDUNG.format(weg1), flush=True)
                for jahr, alt, neu in _frei_als_text(c):         # ohne Protokoll (wie _profile_umstellen): zwei Geräte mit denselben alten Daten bleiben gleich
                    c.execute("UPDATE jahr SET eigene_frei=? WHERE jahr=? AND eigene_frei=?", (neu, jahr, alt))
                for datum, notiz in unsauber:                      # als Änderung dieses Geräts vermerkt: Die anderen Geräte übernehmen die bereinigte Fassung
                    c.execute("UPDATE tag SET notiz=? WHERE datum=?", (notiz, datum))
                    self._stempeln(c, "tag", datum, True)
                if profile_alt:
                    self._profile_umstellen(c)

    @staticmethod
    def _profile_umstellen(c) -> None:
        """Sammelsatz „profile“ (alle eigenen Profile in einem Satz) auf je Profil einen Satz „profil:<Name>“ umstellen.
        Die neuen Sätze tragen kein Protokoll (Fassung ALT): Zwei Geräte mit demselben alten Profil sind so gleich und kein Konflikt,
        verschiedene Profile werden vereint, und nur ein gleich benanntes Profil mit anderem Inhalt wird ein Konflikt.
        Ein unlesbarer Sammelsatz bleibt unter PROFILE_UNLESBAR erhalten (nur auf diesem Gerät)."""
        roh = c.execute("SELECT v FROM meta WHERE k=?", (PROFILE_ALT,)).fetchone()[0]
        try:
            profile = json.loads(roh)
            if not isinstance(profile, dict):
                raise ValueError("Profile")
        except (ValueError, RecursionError):                 # RecursionError: zu tief verschachtelt (sonst startet die App mit dieser Datei nie wieder)
            c.execute("INSERT OR REPLACE INTO meta (k,v) VALUES (?,?)", (PROFILE_UNLESBAR, roh))
            profile = {}
        for name, p in profile.items():
            if konfig.profil_name_gueltig(name) and isinstance(p, dict):
                c.execute("INSERT OR IGNORE INTO meta (k,v) VALUES (?,?)", (konfig.PROFIL_VORSILBE + name, konfig.profil_text(p)))
        c.execute("DELETE FROM meta WHERE k=?", (PROFILE_ALT,))
        c.execute("DELETE FROM stand WHERE art='meta' AND schluessel=?", (PROFILE_ALT,))
        c.execute("DELETE FROM konflikt WHERE art='meta' AND schluessel=?", (PROFILE_ALT,))

    def _c(self):
        """Neue Verbindung zur Datei als Kontext: Schloss halten, bei Erfolg speichern (commit), bei Fehler zurückrollen, am Ende schließen."""
        con = sqlite3.connect(self.pfad, timeout=10)
        con.row_factory = sqlite3.Row
        return _Ctx(con, self.lock)

    def _kopieren(self, von: str, nach: str) -> None:
        """Konsistente Kopie der Datenbank „von“ nach „nach“ mit dem SQLite-Backup."""
        with self.lock:
            a, b = sqlite3.connect(von), sqlite3.connect(nach)
            try:
                a.backup(b)
            finally:
                b.close()
                a.close()

    def _stempeln(self, c, art: str, schluessel: str, vorhanden: bool, geloescht: bool = False) -> None:
        """Änderung im Protokoll vermerken (in derselben Transaktion wie die Änderung). vorhanden: Den Eintrag gab es vorher schon."""
        r = c.execute("SELECT fassung FROM stand WHERE art=? AND schluessel=?", (art, schluessel)).fetchone()
        if r is None and geloescht and not vorhanden:
            return                                         # nichts da und nie etwas da gewesen: keine Löschmarke nötig
        fassung = self.fassung_weiter(json.loads(r["fassung"]) if r else ({ALT: 1} if vorhanden else {}), c)
        c.execute("INSERT OR REPLACE INTO stand (art,schluessel,zeit,geraet,fassung,geloescht) VALUES (?,?,?,?,?,?)",
                  (art, schluessel, self.uhr().isoformat(timespec="seconds"), self.geraet, json.dumps(fassung, sort_keys=True), int(geloescht)))

    def _zaehler_ab(self, c) -> int:
        """Untergrenze für den eigenen Zähler (Verbindung c): der höchste Zähler vor dem letzten Wiederherstellen, sonst 0."""
        r = c.execute("SELECT v FROM meta WHERE k=?", (ZAEHLER_AB,)).fetchone()
        return int(r[0]) if r and _zaehler_ab_gueltig(str(r[0])) else 0

    def fassung_weiter(self, fassung: dict, c=None) -> dict:
        """Die Fassung einer neuen Änderung auf diesem Gerät: der eigene Zähler eins über dem bisherigen und über der Untergrenze.
        Nach dem Einspielen einer älteren Sicherung kennen die anderen Geräte höhere Zähler dieses Geräts; ohne Untergrenze hielten sie
        eine neue Eingabe für alt und sie ginge bei der Synchronisierung still verloren. c: offene Verbindung (sonst eine eigene)."""
        if c is None:
            with self._c() as c:
                return self.fassung_weiter(fassung, c)
        return {**fassung, self.geraet: max(fassung.get(self.geraet, 0), self._zaehler_ab(c)) + 1}

    def _hoechster_zaehler(self) -> int:
        """Höchster Zähler dieses Geräts im Protokoll und in der Untergrenze (vor dem Ersetzen des Datenbestands)."""
        try:
            with self._c() as c:
                eigene = [json.loads(r[0]).get(self.geraet, 0) for r in c.execute("SELECT fassung FROM stand")]
                return max([self._zaehler_ab(c), *eigene])
        except (sqlite3.DatabaseError, ValueError, AttributeError):    # ein kaputter Stand darf das Wiederherstellen nicht verhindern
            return 0

    def _tag_schreiben(self, c, datum: date, ho, dst, art, notiz, konto=0, attest="", freigabe=0, kommen=-1, gehen=-1, pause=0, vermerk="", geprueft=0) -> None:
        """Tag in der Transaktion „c“ schreiben; ein ganz leerer Tag (keine Zeit, Art, Anmerkung und kein Vermerk) wird gelöscht. Vermerkt die Änderung im Protokoll
        und, während aufnahme() läuft, den Stand vor dem ersten und nach dem letzten Schreiben des Tages."""
        iso = datum.isoformat()
        auf = self._aufnahme
        vorher = _tag_zeile(c, iso) if auf is not None and iso not in auf else None
        vorhanden = c.execute("SELECT 1 FROM tag WHERE datum=?", (iso,)).fetchone() is not None
        leer = not ho and not dst and not art and not notiz and not vermerk
        if leer:
            c.execute("DELETE FROM tag WHERE datum=?", (iso,))
        else:
            c.execute("INSERT OR REPLACE INTO tag (datum,ho,dst,art,notiz,konto,attest,freigabe,kommen,gehen,pause,vermerk,geprueft) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (iso, ho or 0, dst or 0, art or "", notiz or "", konto or 0, attest or "", 1 if freigabe else 0, kommen, gehen, pause or 0,
                       vermerk or "", 1 if geprueft else 0))
        self._stempeln(c, "tag", iso, vorhanden, leer)
        if auf is not None:
            auf[iso] = (auf[iso][0] if iso in auf else vorher, _tag_zeile(c, iso))

    def _geaendert(self, ab: date = ALLES):
        """ab: frühester Tag, dessen Tageswerte sich geändert haben können (ALLES = unbekannt, KEIN_TAG = keine Tageswerte betroffen)."""
        with self.lock:
            self.gen += 1
            self._cache.clear()
            self._aenderungen.append((self.gen, ab))
            del self._aenderungen[:-AENDERUNGEN_MERKEN]

    def geaendert_seit(self, gen: int) -> date:
        """Frühester Tag, dessen Tageswerte sich seit dem Stand „gen“ geändert haben können. Laufende Summen bleiben bis zum Tag davor gültig.
        KEIN_TAG: nichts an Tageswerten geändert. ALLES: unbekannt (zu lange her oder eine Änderung ohne Tagesbezug)."""
        with self.lock:
            if gen == self.gen:
                return KEIN_TAG
            if not self._aenderungen or self._aenderungen[0][0] > gen + 1:
                return ALLES
            return min(ab for g, ab in self._aenderungen if g > gen)

    def _merken(self, schluessel, laden):
        """Ergebnis von „laden()“ unter dem Schlüssel merken, bis der nächste Schreibzugriff den Zwischenspeicher leert."""
        with self.lock:
            if schluessel not in self._cache:
                self._cache[schluessel] = laden()
            return self._cache[schluessel]

    # Tage
    def tag_setzen(self, datum: date, ho: int, dst: int, art: str, notiz: str, konto: int = 0, attest: str = "", freigabe: int = 0,
                   kommen: int = -1, gehen: int = -1, pause: int = 0, vermerk: str = "", geprueft: int = 0):
        """Einen Tag speichern (ho/dst in Minuten, Art, Anmerkung, Konto, Attest, Freigabe, Kommen/Gehen in Minuten ab Mitternacht, Pause,
        Vermerk aus konfig.VERMERKE oder "", geprueft 0/1); ein leerer Tag wird gelöscht. Wer einen Tag ändert, gibt Vermerk und geprueft mit, sonst fallen sie weg."""
        with self._c() as c:
            self._tag_schreiben(c, datum, ho, dst, art, notiz, konto, attest, freigabe, kommen, gehen, pause, vermerk, geprueft)
        self._geaendert(datum)

    def tage_setzen(self, zeilen):
        """Mehrere Tage in einer Transaktion schreiben (leere Tage werden gelöscht)."""
        with self._c() as c:
            for zeile in zeilen:                          # (datum, ho, dst, art, notiz, konto[, attest, freigabe, kommen, gehen, pause, vermerk, geprueft])
                self._tag_schreiben(c, *zeile)
        self._geaendert(min((z[0] for z in zeilen), default=KEIN_TAG))

    @contextlib.contextmanager
    def aufnahme(self):
        """Rekorder für Rückgängig (funktionen.md 1). Liefert {iso: (vorher, nachher)}: je Tag, den die Aktion schreibt, alle TAG_FELDER vor dem ersten
        und nach dem letzten Schreiben (None = kein Eintrag). Hält die ganze Zeit das Schloss, damit kein anderer Faden in die Aufnahme schreibt.
        Fasst nichts zusammen (eine Transaktion kommt aus tage_setzen). Schlägt die Aktion fehl, steht Zurückgerolltes trotzdem darin: dann nicht merken."""
        with self.lock:
            self._aufnahme = {}
            try:
                yield self._aufnahme
            finally:
                self._aufnahme = None

    def zuruecksetzen(self, aenderungen: dict, stempel: dict = None) -> int:
        """Rückgängig in einer Transaktion: jeden Tag aus „aenderungen“ ({iso: (vorher, nachher)} aus aufnahme) auf „vorher“ setzen und, falls gegeben,
        die Stempeluhr {art, start} wieder laufen lassen. Nur wenn jeder Tag noch genau „nachher“ ist und keine Uhr läuft, sonst InzwischenGeaendert
        und nichts geändert. Es ist eine neue Änderung (Fassung steigt, andere Geräte übernehmen sie). Rückgabe: Zahl der Tage."""
        with self._c() as c:
            if any(_tag_zeile(c, iso) != nachher for iso, (_, nachher) in aenderungen.items()):
                raise InzwischenGeaendert("Tag")
            if stempel and c.execute("SELECT 1 FROM stempel WHERE id=1").fetchone():
                raise InzwischenGeaendert("Stempeluhr")
            for iso, (vorher, _) in aenderungen.items():
                self._tag_schreiben(c, date.fromisoformat(iso), **(vorher or LEERER_TAG))
            if stempel:
                c.execute("INSERT INTO stempel (id,art,start) VALUES (1,?,?)", (stempel["art"], stempel["start"].isoformat(timespec="seconds")))
        self._geaendert(min((date.fromisoformat(iso) for iso in aenderungen), default=KEIN_TAG))
        return len(aenderungen)

    @staticmethod
    def _tag(r):
        """Zeile der Tabelle tag als Tag (mit vermerk und geprueft)."""
        return Tag(date.fromisoformat(r["datum"]), **{f: r[f] for f in TAG_FELDER})

    def tage(self, jahr: int):
        """Alle Tage des Jahres, nach Datum sortiert."""
        def laden():
            """Liest die Tage des Jahres aus der Datei."""
            with self._c() as c:
                return [self._tag(r) for r in c.execute("SELECT * FROM tag WHERE datum BETWEEN ? AND ? ORDER BY datum", (f"{jahr}-01-01", f"{jahr}-12-31"))]
        return list(self._merken(("tage", jahr), laden))

    def tage_alle(self):
        """Alle Tage der Datenbank, nach Datum sortiert."""
        def laden():
            """Liest alle Tage aus der Datei."""
            with self._c() as c:
                return [self._tag(r) for r in c.execute("SELECT * FROM tag ORDER BY datum")]
        return list(self._merken("tage_alle", laden))

    # Jahre
    def _jahr_lesen(self, jahr: int) -> dict:
        """Zeile des Jahres (gemerkt): anspruch (None = Regel), frei [{datum: date, name}] nach Datum, uebertrag. Ohne Zeile: nichts davon."""
        def laden():
            """Liest die Zeile des Jahres; ohne Zeile: kein Anspruch, keine freien Tage, kein Übertrag."""
            with self._c() as c:
                r = c.execute("SELECT * FROM jahr WHERE jahr=?", (jahr,)).fetchone()
            if not r:
                return {"anspruch": None, "frei": [], "uebertrag": None}
            frei = [{"datum": date.fromisoformat(x["datum"]), "name": x["name"]} for x in _frei_objekte(json.loads(r["eigene_frei"]))]
            return {"anspruch": r["anspruch"], "frei": frei, "uebertrag": r["uebertrag"]}
        return self._merken(("jahr", jahr), laden)

    def jahr_einstellung(self, jahr: int) -> dict:
        """Einstellung eines Jahres: anspruch (Urlaubstage; ohne eigenen Wert die Regel „urlaub_tage“), eigene_frei (Liste von Daten, ohne Namen)
        und uebertrag (Tage oder None = automatisch berechnet). Die Namen der eigenen freien Tage liefert eigene_feiertage."""
        e = self._jahr_lesen(jahr)
        anspruch = e["anspruch"] if e["anspruch"] is not None else float(konfig.fuer_jahr(jahr).get("urlaub_tage", ERHOLUNG_VORGABE))   # Jahr ohne eigenen Wert: Regel „Urlaubstage pro Jahr“
        return {"anspruch": anspruch, "eigene_frei": [x["datum"] for x in e["frei"]], "uebertrag": e["uebertrag"]}

    def eigene_feiertage(self, jahr: int) -> list:
        """Einmalige eigene freie Tage des Jahres mit Namen: [{"datum": date, "name": Text}] nach Datum ("" = ohne Namen, z. B. alte Daten)."""
        return [dict(x) for x in self._jahr_lesen(jahr)["frei"]]

    def eigene_frei_tage(self, jahr: int) -> set:
        """Die einmaligen eigenen freien Tage des Jahres als Menge von Daten (für Rechnungen, die nur „frei oder nicht“ brauchen)."""
        return {x["datum"] for x in self._jahr_lesen(jahr)["frei"]}

    def uebertrag_setzen(self, jahr: int, wert):
        """Resturlaub aus dem Vorjahr von Hand festlegen; None = wieder automatisch berechnen."""
        with self._c() as c:
            self._uebertrag_schreiben(c, jahr, wert)
        self._geaendert(date(jahr, 1, 1))

    def _uebertrag_schreiben(self, c, jahr: int, wert) -> None:
        """Übertrag des Jahres in der Transaktion „c“ schreiben (None = automatisch) und im Protokoll vermerken."""
        vorhanden = c.execute("SELECT 1 FROM jahr WHERE jahr=?", (jahr,)).fetchone() is not None
        c.execute("INSERT INTO jahr (jahr,anspruch,eigene_frei,uebertrag) VALUES (?,?,'[]',?) ON CONFLICT(jahr) DO UPDATE SET uebertrag=excluded.uebertrag",
                  (jahr, float(konfig.fuer_jahr(jahr).get("urlaub_tage", ERHOLUNG_VORGABE)), None if wert is None else float(wert)))
        self._stempeln(c, "jahr", str(jahr), vorhanden)

    def jahr_setzen(self, jahr: int, anspruch: float, eigene_frei, namen: dict = None):
        """Anspruch (Tage) und eigene freie Tage (Daten) des Jahres speichern; ein vorhandener Übertrag bleibt.
        namen: {Datum: Name} der eigenen freien Tage; None = die gespeicherten Namen bleibender Tage behalten (Aufrufer ohne Namen löschen sie nicht)."""
        if namen is None:
            namen = {x["datum"]: x["name"] for x in self._jahr_lesen(jahr)["frei"]}
        frei = [{"datum": d.isoformat(), "name": namen.get(d, "")} for d in sorted(set(eigene_frei))]
        with self._c() as c:
            vorhanden = c.execute("SELECT 1 FROM jahr WHERE jahr=?", (jahr,)).fetchone() is not None
            c.execute("INSERT INTO jahr (jahr,anspruch,eigene_frei) VALUES (?,?,?) ON CONFLICT(jahr) DO UPDATE SET anspruch=excluded.anspruch, eigene_frei=excluded.eigene_frei",
                      (jahr, float(anspruch), json.dumps(frei, ensure_ascii=False)))
            self._stempeln(c, "jahr", str(jahr), vorhanden)
        self._geaendert(date(jahr, 1, 1))

    # Abschnitte
    @staticmethod
    def _abschnitt(r):
        """Zeile der Tabelle abschnitt als Abschnitt (mit tagesminuten, Stunden je Tag wie „Mo:480,Di:360“, "" = keine)."""
        return Abschnitt(date.fromisoformat(r["von"]), date.fromisoformat(r["bis"]), r["wochenstunden"], r["art"], r["arbeitstage"], r["id"], tagesminuten=r["tagesminuten"])

    def abschnitte(self, jahr=None):
        """Abschnitte nach Beginn sortiert; mit „jahr“ nur die, die sich mit diesem Jahr überschneiden."""
        def laden():
            """Liest die Abschnitte aus der Datei."""
            with self._c() as c:
                if jahr is None:
                    rows = c.execute("SELECT * FROM abschnitt ORDER BY von")
                else:
                    rows = c.execute("SELECT * FROM abschnitt WHERE von<=? AND bis>=? ORDER BY von", (f"{jahr}-12-31", f"{jahr}-01-01"))
                return [self._abschnitt(r) for r in rows]
        return list(self._merken(("abschnitte", jahr), laden))

    def abschnitt_speichern(self, a: Abschnitt) -> int:
        """Abschnitt neu anlegen (id 0) oder ändern; gibt die Nummer (id) zurück. Die Abschnitte zählen in der Synchronisierung als ein Ganzes.
        Ohne Stunden je Tag (tagesminuten "") gilt Weg 1 oder 2. Fehler: ValueError, wenn die Stunden je Tag nicht zu den Arbeitstagen passen
        (konfig.tagesminuten_pruefen) oder ein Arbeitstag doppelt steht; dann ist nichts gespeichert."""
        konfig.tagesminuten_pruefen(a.tagesminuten, a.arbeitstage)
        konfig.arbeitstage_lesen(a.arbeitstage)            # KonfigFehler (ValueError) bei „Mo,Mo“: halbierte das Tagessoll (Wochenstunden geteilt durch die Zahl der Tage)
        with self._c() as c:
            self._stempeln(c, *ABSCHNITTE, c.execute("SELECT 1 FROM abschnitt LIMIT 1").fetchone() is not None)
            if a.id:
                c.execute("UPDATE abschnitt SET von=?,bis=?,wochenstunden=?,art=?,arbeitstage=?,tagesminuten=? WHERE id=?",
                          (a.von.isoformat(), a.bis.isoformat(), a.wochenstunden, a.art, a.arbeitstage, a.tagesminuten, a.id))
                aid = a.id
            else:
                aid = c.execute("INSERT INTO abschnitt (von,bis,wochenstunden,art,arbeitstage,tagesminuten) VALUES (?,?,?,?,?,?)",
                                (a.von.isoformat(), a.bis.isoformat(), a.wochenstunden, a.art, a.arbeitstage, a.tagesminuten)).lastrowid
        self._geaendert()
        return aid

    def abschnitt_loeschen(self, aid: int):
        """Löscht den Abschnitt mit der Nummer „aid“."""
        with self._c() as c:
            self._stempeln(c, *ABSCHNITTE, c.execute("SELECT 1 FROM abschnitt LIMIT 1").fetchone() is not None)
            c.execute("DELETE FROM abschnitt WHERE id=?", (aid,))
        self._geaendert()

    # Konten (angesparter Urlaub)
    def konten(self):
        """Alle Konten angesparten Urlaubs, nach Herkunftsjahr sortiert."""
        def laden():
            """Liest die Konten aus der Datei."""
            with self._c() as c:
                return [Konto(r["herkunft"], r["tage"]) for r in c.execute("SELECT * FROM konto ORDER BY herkunft")]
        return list(self._merken("konten", laden))

    def konto_setzen(self, herkunft: int, tage: float):
        """Tage des Kontos für ein Herkunftsjahr setzen; 0 Tage löscht das Konto."""
        with self._c() as c:
            self._konto_schreiben(c, herkunft, tage)
        self._geaendert()

    def _konto_schreiben(self, c, herkunft: int, tage: float) -> None:
        """Konto des Herkunftsjahrs in der Transaktion „c“ schreiben (0 Tage = löschen) und im Protokoll vermerken."""
        vorhanden = c.execute("SELECT 1 FROM konto WHERE herkunft=?", (herkunft,)).fetchone() is not None
        if tage:
            c.execute("INSERT OR REPLACE INTO konto (herkunft,tage) VALUES (?,?)", (herkunft, float(tage)))
        else:
            c.execute("DELETE FROM konto WHERE herkunft=?", (herkunft,))
        self._stempeln(c, "konto", str(herkunft), vorhanden, not tage)

    # Stempeluhr (eine laufende Zeit)
    def stempel_lesen(self):
        """Die laufende Zeit {art, start} oder None, wenn keine läuft."""
        with self._c() as c:
            r = c.execute("SELECT art, start FROM stempel WHERE id=1").fetchone()
        return {"art": r["art"], "start": datetime.fromisoformat(r["start"])} if r else None

    def stempel_setzen(self, art: str, start: datetime):
        """Startet die laufende Zeit (ersetzt eine vorhandene)."""
        with self._c() as c:
            c.execute("INSERT OR REPLACE INTO stempel (id,art,start) VALUES (1,?,?)", (art, start.isoformat(timespec="seconds")))
        self._geaendert(KEIN_TAG)

    def stempel_loeschen(self):
        """Beendet die laufende Zeit, ohne zu buchen."""
        with self._c() as c:
            c.execute("DELETE FROM stempel WHERE id=1")
        self._geaendert(KEIN_TAG)

    # Einstellungen (Zahl in Minuten usw.)
    def meta_lesen(self, k: str, standard=None):
        """Einstellung (Text) unter dem Schlüssel „k“; fehlt sie, kommt „standard“ zurück."""
        def laden():
            """Liest den Wert aus der Datei (None, wenn es ihn nicht gibt)."""
            with self._c() as c:
                r = c.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
            return r["v"] if r else None
        v = self._merken(("meta", k), laden)
        return standard if v is None else v

    def pruefen(self) -> None:
        """Liest direkt aus der Datei (ohne Zwischenspeicher): wirft einen sqlite3-Fehler, wenn die Datenbank nicht lesbar ist."""
        with self._c() as c:
            c.execute("SELECT COUNT(*) FROM meta").fetchone()

    def meta_setzen(self, k: str, v):
        """Einstellung speichern; nur die Schlüssel, die mit anderen Geräten synchronisiert werden, kommen ins Änderungsprotokoll."""
        with self._c() as c:
            self._meta_schreiben(c, k, str(v))
        self._geaendert(KEIN_TAG)                           # Startstände und Regeln lesen die Auswertungen bei jeder Abfrage neu

    def _meta_schreiben(self, c, k: str, v) -> None:
        """Einstellung in der Transaktion „c“ schreiben (Text) oder löschen (None). Synchronisierte Schlüssel kommen ins Protokoll, gelöschte mit Löschmarke."""
        vorhanden = c.execute("SELECT 1 FROM meta WHERE k=?", (k,)).fetchone() is not None
        if v is None:
            c.execute("DELETE FROM meta WHERE k=?", (k,))
        else:
            c.execute("INSERT OR REPLACE INTO meta (k,v) VALUES (?,?)", (k, v))
        if SYNC_META.fullmatch(k):
            self._stempeln(c, "meta", k, vorhanden, geloescht=v is None)

    def meta_mit(self, vorsilbe: str) -> dict:
        """Alle Einstellungen, deren Schlüssel mit „vorsilbe“ beginnt: {Schlüssel: Text}."""
        def laden():
            """Liest alle Einstellungen und behält die mit der Vorsilbe (in Python, damit _ und % keine Platzhalter sind)."""
            with self._c() as c:
                return {r["k"]: r["v"] for r in c.execute("SELECT k, v FROM meta") if r["k"].startswith(vorsilbe)}
        return dict(self._merken(("meta_mit", vorsilbe), laden))

    def meta_loeschen(self, k: str) -> None:
        """Einstellung löschen; bei synchronisierten Schlüsseln bleibt eine Löschmarke im Protokoll, damit die Löschung auf alle Geräte wandert."""
        with self._c() as c:
            self._meta_schreiben(c, k, None)
        self._geaendert(KEIN_TAG)

    # Kopf des Monatsnachweises, Jahreswechsel-Helfer und Einrichtung (funktionen.md 3, 4, 6)
    def nachweis_kopf(self) -> dict:
        """Kopf des Monatsnachweises: {"name", "arbeitgeber", "personalnummer"}, "" = leer. Beim Lesen erneut bereinigt und auf NACHWEIS_MAX
        Zeichen gekürzt, weil die Werte aus älteren Ständen in die Datei gekommen sein können."""
        return {f: notiz_bereinigen(self.meta_lesen(NACHWEIS_VORSILBE + f, ""))[:NACHWEIS_MAX] for f in NACHWEIS_FELDER}

    def nachweis_kopf_setzen(self, werte) -> dict:
        """Kopf des Monatsnachweises setzen. Eingabe: Wörterbuch mit einem Teil von name, arbeitgeber, personalnummer (Text; fehlende Felder
        bleiben, wie sie sind). Steuerzeichen werden zu Leerzeichen, Rand-Leerzeichen fallen weg (notiz_bereinigen). Nur geänderte Felder werden
        geschrieben (sonst entstünden unnötige Konflikte in der Synchronisierung), alle in einer Transaktion. Rückgabe: der ganze Kopf wie nachweis_kopf.
        Fehler: KonfigFehler bei unbekanntem Feld, anderem Typ als Text oder mehr als NACHWEIS_MAX Zeichen; dann ist nichts geschrieben."""
        neu = {NACHWEIS_VORSILBE + f: v for f, v in _nachweis_pruefen(werte).items()}
        geaendert = {k: v for k, v in neu.items() if self.meta_lesen(k, "") != v}
        if geaendert:
            with self._c() as c:
                for k, v in geaendert.items():
                    self._meta_schreiben(c, k, v)
            self._geaendert(KEIN_TAG)
        return self.nachweis_kopf()

    def jahreswechsel_erledigt(self, jahr: int) -> set:
        """Die Schritte des Jahreswechsels (JAHRESWECHSEL_SCHRITTE), die für das Vorjahr „jahr“ abgehakt sind. Nur der Wert "1" zählt."""
        vorsilbe = f"{JAHRESWECHSEL_VORSILBE}{jahr}_"
        return {k[len(vorsilbe):] for k, v in self.meta_mit(vorsilbe).items() if v == ERLEDIGT and k[len(vorsilbe):] in JAHRESWECHSEL_SCHRITTE}

    def jahreswechsel_abhaken(self, jahr: int, schritt: str) -> None:
        """Einen Schritt des Jahreswechsels für das Vorjahr „jahr“ als erledigt merken (wandert in der Synchronisierung mit). Schon abgehakt: nichts geschrieben.
        Fehler: KonfigFehler, wenn jahr keine ganze Zahl von 1970 bis 2200 oder schritt kein Wert aus JAHRESWECHSEL_SCHRITTE ist."""
        with self._c() as c:
            geschrieben = self._abhaken_schreiben(c, jahr, schritt)
        if geschrieben:
            self._geaendert(KEIN_TAG)

    def _abhaken_schreiben(self, c, jahr: int, schritt: str) -> bool:
        """Schritt des Jahreswechsels in der Transaktion „c“ abhaken. Rückgabe: True, wenn etwas geschrieben wurde (vorher nicht abgehakt).
        Fehler: KonfigFehler bei ungültigem Jahr oder Schritt (wie jahreswechsel_abhaken)."""
        if not _jahreszahl(jahr) or not isinstance(schritt, str) or schritt not in JAHRESWECHSEL_SCHRITTE:
            raise konfig.KonfigFehler("Jahreswechsel: unbekannter Schritt oder ungültiges Jahr")
        k = f"{JAHRESWECHSEL_VORSILBE}{jahr}_{schritt}"
        r = c.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        if r is not None and r["v"] == ERLEDIGT:
            return False
        self._meta_schreiben(c, k, ERLEDIGT)
        return True

    def jahreswechsel_ansparen(self, vorjahr: int, tage: int, uebertrag: float, auto: float) -> None:
        """„Ansparen“ in einer SQLite-Transaktion: Übertrag des Folgejahrs auf „uebertrag“, Konto „vorjahr“ mit „tage“, der automatische Übertrag
        „auto“ unter ANSPAREN_AUTO (wandert im Sync mit) und der Merker „ansparen“.
        Bricht ein Schritt ab, ist nichts geschrieben (sonst gingen angesparte Tage still verloren, die Karte zeigte aber „erledigt“). tage 0: nur abhaken.
        Die Grenzen (ganze Tage, höchstens ANSPAR_MAX und Rest) prüft der Aufrufer (zutun.jahreswechsel_ansparen). Fehler: KonfigFehler bei ungültigem Jahr."""
        with self._c() as c:
            if tage:
                self._uebertrag_schreiben(c, vorjahr + 1, uebertrag)
                self._konto_schreiben(c, vorjahr, tage)
                self._meta_schreiben(c, ANSPAREN_AUTO.format(vorjahr), format(auto, "g"))
            self._abhaken_schreiben(c, vorjahr, ANSPAREN)
        self._geaendert()

    def ansparen_auto(self, vorjahr: int):
        """Der automatische Übertrag, der beim Ansparen für „vorjahr“ galt (Zahl), oder None: nicht angespart, mit einer älteren Fassung oder unlesbar."""
        try:
            return float(self.meta_lesen(ANSPAREN_AUTO.format(vorjahr)))
        except (TypeError, ValueError):
            return None

    def einrichtung_stand(self) -> str:
        """Stand der Einrichtung beim ersten Start auf diesem Gerät: "fertig", "uebersprungen" oder "" (offen; auch bei einem unbekannten Wert)."""
        v = self.meta_lesen(EINRICHTUNG, "")
        return v if v in EINRICHTUNG_STAENDE else ""

    def einrichtung_setzen(self, stand) -> None:
        """Einrichtung als „fertig“ oder „uebersprungen“ merken (nur dieses Gerät). KonfigFehler bei jedem anderen Wert."""
        if not isinstance(stand, str) or stand not in EINRICHTUNG_STAENDE:
            raise konfig.KonfigFehler("Einrichtung: fertig oder übersprungen")
        self.meta_setzen(EINRICHTUNG, stand)

    # Startwerte „Erfassung gültig ab“ (R6)
    def startwerte_lesen(self):
        """Die gespeicherten Startwerte (konfig.Startwerte) oder None: ohne Schlüssel und bei unlesbarem Text (dann rechnet alles wie ohne)."""
        def laden():
            """Liest und prüft den Text des Meta-Schlüssels."""
            text = self.meta_lesen(konfig.STARTWERTE)
            try:
                return None if text is None else konfig.startwerte_lesen(text)
            except konfig.KonfigFehler:
                return None
        return self._merken(konfig.STARTWERTE, laden)

    def startwerte_jahr(self, jahr: int):
        """Die Startwerte, wenn sie im Jahr gelten (nur im Kalenderjahr von „ab“), sonst None. Für Jahressummen: Urlaub, Krank, HO, Büro usw."""
        sw = self.startwerte_lesen()
        return sw if sw and sw.gilt_im_jahr(jahr) else None

    def startwerte_setzen(self, werte, heute: date = None, uebertrag: tuple = None, konten: dict = None, sichern: bool = True) -> None:
        """Startwerte setzen oder ändern (werte: die neun Felder wie konfig.startwerte_pruefen) oder löschen (werte None).
        heute: bei einer Eingabe der Person das heutige Datum; dann zusätzlich: ab nicht nach heute, Urlaub + Gleittage + Krank + Kind krank höchstens
        die Werktage vor ab (regeln.ist_werktag mit den eigenen freien Tagen), Gleittage und Kind krank höchstens die Grenze des Jahres. Ohne heute
        (Synchronisierung, Rechnung) nur die Prüfung von konfig. uebertrag: (Jahr, Tage), als Übertrag von Hand festschreiben. konten: {gleitzeit_start_min,
        freizeit_start_min} in ganzen Minuten, z. B. beim Löschen der Stand der Konten ohne ab. Die Werte der Konten rechnet der Aufrufer (woche), db rechnet nicht.
        Vorher eine Kopie vor-startwerte-<Zeit>.db im Ordner „sicherung“ (sichern), dann alles in einer Transaktion. Fehler: KonfigFehler, nichts geschrieben."""
        sw = None if werte is None else konfig.startwerte_pruefen(werte)
        if sw and heute is not None:
            self._startwerte_plausibel(sw, heute)
        konten = _konten_pruefen(konten or {})
        if uebertrag is not None and not (_jahreszahl(uebertrag[0]) and zahl_gueltig(uebertrag[1], -URLAUB_MAX, URLAUB_MAX)):
            raise konfig.KonfigFehler("Übertrag: Jahr und Tage")
        if sichern:
            self._kopie("vor-startwerte")
        with self._c() as c:
            self._meta_schreiben(c, konfig.STARTWERTE, sw.text() if sw else None)
            for k, v in konten.items():
                self._meta_schreiben(c, k, str(v))
            if uebertrag is not None:
                self._uebertrag_schreiben(c, *uebertrag)
        self._geaendert()                                   # ALLES: „ab“ ändert, was in jeder gemerkten Summe zählt

    def _startwerte_plausibel(self, sw, heute: date) -> None:
        """Prüfung einer Eingabe gegen heute und die Regeln des Jahres von „ab“ (siehe startwerte_setzen). KonfigFehler mit der Grenze im Text."""
        if sw.ab > heute:
            raise konfig.KonfigFehler(konfig.STARTWERTE_ZUKUNFT)
        j = sw.ab.year
        eigene = self.eigene_frei_tage(j)
        werktage = sum(ist_werktag(date.fromordinal(n), eigene) for n in range(date(j, 1, 1).toordinal(), sw.ab.toordinal()))
        if sw.urlaub + sw.gleittage + sw.krank + sw.kind_krank > werktage:
            raise konfig.KonfigFehler(f"Urlaub, Gleittage, Kranktage und Kind krank zusammen höchstens {werktage} Tage (Werktage vor dem {sw.ab:%d.%m.%Y})")
        if sw.gleittage > gleittage_max(j):
            raise konfig.KonfigFehler(f"Gleittage: höchstens {gleittage_max(j)} im Jahr {j}")
        grenze = kind_krank_max(j)
        if sw.kind_krank > grenze:
            raise konfig.KonfigFehler(f"Kind krank: höchstens {grenze} Tage im Jahr {j}")

    def startkonto(self, feld: str) -> int:
        """Startstand eines Kontos („gleitzeit“ oder „freizeit“, KeyError sonst) in Minuten: mit Startwerten deren Wert, sonst der Meta-Schlüssel (fehlt: 0)."""
        im_json, schluessel = KONTEN[feld]
        sw = self.startwerte_lesen()
        return getattr(sw, im_json) if sw else int(self.meta_lesen(schluessel, 0))

    def startkonto_setzen(self, feld: str, wert: int) -> None:
        """Startstand eines Kontos setzen (für woche.stand_setzen): mit Startwerten im JSON (Grenze ±999:59, KonfigFehler), sonst im Meta-Schlüssel."""
        im_json, schluessel = KONTEN[feld]
        sw = self.startwerte_lesen()
        if sw:
            self.startwerte_setzen({**sw.werte(), im_json: wert}, sichern=False)
        else:
            self.meta_setzen(schluessel, wert)

    def _kopie(self, vorsilbe: str) -> str:
        """Kopie der Datenbank als <vorsilbe>-<Zeit>.db im Ordner „sicherung“ neben der Datei (nie eine vorhandene überschrieben). Gibt den Pfad zurück."""
        ordner = os.path.join(os.path.dirname(os.path.abspath(self.pfad)), "sicherung")
        os.makedirs(ordner, exist_ok=True)
        ziel = _neue_datei(ordner, f"{vorsilbe}-{datetime.now():%Y-%m-%d_%H%M%S}")
        self._kopieren(self.pfad, ziel)
        return ziel

    def ist_neu(self) -> bool:
        """Wirklich neue Datenbank: keine Tage, keine Abschnitte, keine gespeicherten Regeln und nichts im Änderungsprotokoll (auch keine Löschmarke)."""
        with self._c() as c:
            return not any(c.execute(sql).fetchone() for sql in ("SELECT 1 FROM tag LIMIT 1", "SELECT 1 FROM abschnitt LIMIT 1",
                                                                 "SELECT 1 FROM meta WHERE k='konfig'", "SELECT 1 FROM stand LIMIT 1"))

    def sicherung_bytes(self) -> bytes:
        """Konsistente Kopie der Datenbank (für den Download)."""
        with tempfile.TemporaryDirectory() as t:
            ziel = os.path.join(t, "k.db")
            self._kopieren(self.pfad, ziel)
            with open(ziel, "rb") as f:
                return f.read()

    def wiederherstellen(self, quelle: str, ordner: str) -> dict:
        """Den ganzen Datenbestand durch die Sicherung „quelle“ ersetzen. Vorher wird die Sicherung geprüft und der aktuelle Stand gesichert
        (Datei vor-wiederherstellung-…db im Sicherungsordner, wird nicht automatisch gelöscht)."""
        with tempfile.TemporaryDirectory() as t:              # geprüft und eingespielt wird dieselbe Kopie: die Quelle kann sich dazwischen nicht ändern
            kopie = os.path.join(t, "pruefung.db")
            _wegwerf_kopie(quelle, kopie)
            pruefe_sicherung(kopie)
            return self._einspielen(kopie, ordner)

    def _einspielen(self, quelle: str, ordner: str) -> dict:
        """Die geprüfte Datei „quelle“ als Datenbestand übernehmen (siehe wiederherstellen); der Stand davor kommt nach „ordner“."""
        os.makedirs(ordner, exist_ok=True)
        davor = _neue_datei(ordner, f"vor-wiederherstellung-{datetime.now():%Y-%m-%d_%H%M%S}")
        with self.lock:
            zaehler = self._hoechster_zaehler()
            self._kopieren(self.pfad, davor)
            self._kopieren(quelle, self.pfad)
            self._schema(sichern=False)                      # die eingespielte Datei ist selbst die Sicherung
            with self._c() as c:
                c.execute("INSERT OR REPLACE INTO meta (k,v) VALUES (?,?)", (ZAEHLER_AB, str(max(zaehler, self._zaehler_ab(c)))))
                c.execute("DELETE FROM stempel")             # eine laufende Uhr aus einer alten Sicherung wäre sinnlos
                c.execute("DELETE FROM konflikt")            # offene Konflikte gehören zum alten Stand; der nächste Sync findet sie neu
                n = c.execute("SELECT COUNT(*) FROM tag").fetchone()[0]
            self._geaendert()
        return {"tage": n, "davor": os.path.basename(davor)}

    # Sync: alle Einträge mit ihrem Stand lesen und schreiben (die Regeln des Zusammenführens stehen in sync.py)
    def saetze(self) -> dict:
        """{(art, schluessel): {"wert", "zeit", "geraet", "fassung", "geloescht"}} für Tage, Jahre, Konten, Einstellungen und die Abschnitte.
        Einträge ohne Vermerk im Protokoll (aus der Zeit vor der Synchronisierung) tragen die Fassung {ALT: 1} und keine Zeit."""
        with self._c() as c:
            werte = {("tag", r["datum"]): {f: r[f] for f in TAG_FELDER} for r in c.execute("SELECT * FROM tag")}
            for r in c.execute("SELECT * FROM jahr"):
                werte[("jahr", str(r["jahr"]))] = {"anspruch": r["anspruch"], "eigene_frei": _frei_objekte(json.loads(r["eigene_frei"])), "uebertrag": r["uebertrag"]}
            for r in c.execute("SELECT * FROM konto"):
                werte[("konto", str(r["herkunft"]))] = {"tage": r["tage"]}
            for r in c.execute("SELECT * FROM meta"):
                if SYNC_META.fullmatch(r["k"]):
                    werte[("meta", r["k"])] = {"v": r["v"]}
            staende = {(r["art"], r["schluessel"]): r for r in c.execute("SELECT * FROM stand")}
            liste = [{f: r[f] for f in ABSCHNITT_FELDER} for r in c.execute("SELECT * FROM abschnitt ORDER BY von, bis, id")]
            if liste or ABSCHNITTE in staende:
                werte[ABSCHNITTE] = {"liste": liste}
        saetze = {}
        for k in set(werte) | set(staende):
            s, wert = staende.get(k), werte.get(k)
            saetze[k] = {"wert": wert, "zeit": s["zeit"] if s else "", "geraet": s["geraet"] if s else "",
                         "fassung": json.loads(s["fassung"]) if s else {ALT: 1}, "geloescht": wert is None}
        return saetze

    def saetze_schreiben(self, saetze: dict) -> None:
        """Einträge samt Stand so übernehmen, wie sie sind (von der Synchronisierung geprüft), alle in einer Transaktion. wert None = gelöscht.
        Fehlende Felder seit Format 5 (Vermerk und geprüft am Tag, Namen der freien Tage, Stunden je Tag) gelten als leer: Offene Konflikte
        aus der Zeit davor tragen sie nicht, und wer sich für den Eintrag des anderen Geräts entscheidet, nimmt ihn ganz."""
        with self._c() as c:
            for (art, schluessel), s in saetze.items():
                w = s["wert"]
                if art == "tag":
                    c.execute("DELETE FROM tag WHERE datum=?", (schluessel,))
                    if w is not None:
                        neu = {"vermerk": "", "geprueft": 0, **w}
                        c.execute(f"INSERT INTO tag (datum,{','.join(TAG_FELDER)}) VALUES (?{',?' * len(TAG_FELDER)})", (schluessel, *(neu[f] for f in TAG_FELDER)))
                elif art == "jahr":
                    c.execute("DELETE FROM jahr WHERE jahr=?", (int(schluessel),))
                    if w is not None:
                        frei = _frei_objekte(w["eigene_frei"])
                        c.execute("INSERT INTO jahr (jahr,anspruch,eigene_frei,uebertrag) VALUES (?,?,?,?)", (int(schluessel), w["anspruch"], json.dumps(frei, ensure_ascii=False), w["uebertrag"]))
                elif art == "konto":
                    c.execute("DELETE FROM konto WHERE herkunft=?", (int(schluessel),))
                    if w is not None:
                        c.execute("INSERT INTO konto (herkunft,tage) VALUES (?,?)", (int(schluessel), w["tage"]))
                elif art == "meta":
                    c.execute("DELETE FROM meta WHERE k=?", (schluessel,))
                    if w is not None:
                        c.execute("INSERT INTO meta (k,v) VALUES (?,?)", (schluessel, w["v"]))
                elif (art, schluessel) == ABSCHNITTE:
                    c.execute("DELETE FROM abschnitt")
                    for a in (w or {"liste": []})["liste"]:
                        a = {"tagesminuten": "", **a}
                        c.execute(f"INSERT INTO abschnitt ({','.join(ABSCHNITT_FELDER)}) VALUES (?{',?' * (len(ABSCHNITT_FELDER) - 1)})", tuple(a[f] for f in ABSCHNITT_FELDER))
                else:
                    raise ValueError(f"unbekannte Art {art}")
                c.execute("INSERT OR REPLACE INTO stand (art,schluessel,zeit,geraet,fassung,geloescht) VALUES (?,?,?,?,?,?)",
                          (art, schluessel, s["zeit"], s["geraet"], json.dumps(s["fassung"], sort_keys=True), int(w is None)))
        if saetze:
            self._geaendert()

    def konflikte(self) -> dict:
        """Offene Konflikte: {(art, schluessel): Eintrag des anderen Geräts}. Der eigene Eintrag bleibt gültig, bis die Person entscheidet."""
        with self._c() as c:
            return {(r["art"], r["schluessel"]): json.loads(r["fremd"]) for r in c.execute("SELECT * FROM konflikt")}

    def konflikte_aendern(self, neu: dict, erledigt=()) -> None:
        """Offene Konflikte aktualisieren: die „erledigten“ (art, schluessel) löschen, die „neuen“ mit dem fremden Eintrag speichern."""
        with self._c() as c:
            for art, schluessel in erledigt:
                c.execute("DELETE FROM konflikt WHERE art=? AND schluessel=?", (art, schluessel))
            for (art, schluessel), fremd in neu.items():
                c.execute("INSERT OR REPLACE INTO konflikt (art,schluessel,fremd) VALUES (?,?,?)", (art, schluessel, json.dumps(fremd, ensure_ascii=False)))

    # Sicherung
    def sicherung(self, ordner: str, behalten: int = 7):
        """Tagessicherung zeiterfassung-JJJJ-MM-TT.db im Ordner anlegen und ältere löschen, sodass nur die jüngsten „behalten“ übrig bleiben. Gibt den Pfad zurück."""
        os.makedirs(ordner, exist_ok=True)
        ziel = os.path.join(ordner, f"zeiterfassung-{datetime.now():%Y-%m-%d}.db")
        self._kopieren(self.pfad, ziel)
        for f in nachtsicherungen(ordner)[:-behalten]:
            os.remove(os.path.join(ordner, f))
        return ziel


class InzwischenGeaendert(ValueError):
    """Rückgängig geht nicht: Ein betroffener Tag oder die Stempeluhr wurde nach der Aktion geändert (z. B. durch die Synchronisierung)."""


def _tag_zeile(c, iso: str):
    """Alle Spalten (TAG_FELDER) eines Tages in der Transaktion „c“ als Wörterbuch, None ohne Eintrag (direkt aus der Datei, ohne Zwischenspeicher)."""
    r = c.execute(f"SELECT {','.join(TAG_FELDER)} FROM tag WHERE datum=?", (iso,)).fetchone()
    return dict(r) if r else None


def _konten_pruefen(konten: dict) -> dict:
    """Startstände für startwerte_setzen: nur gleitzeit_start_min und freizeit_start_min, ganze Minuten. KonfigFehler sonst."""
    erlaubt = {schluessel for _, schluessel in KONTEN.values()}
    if not set(konten) <= erlaubt or any(isinstance(v, bool) or not isinstance(v, int) for v in konten.values()):
        raise konfig.KonfigFehler("Startstand der Konten: ganze Minuten")
    return konten


def _neue_datei(ordner: str, stamm: str) -> str:
    """Pfad <stamm>.db im Ordner, bei gleichem Namen <stamm>-2.db usw.: nie eine vorhandene Sicherung überschreiben."""
    pfad, nr = os.path.join(ordner, stamm + ".db"), 1
    while os.path.exists(pfad):
        nr += 1
        pfad = os.path.join(ordner, f"{stamm}-{nr}.db")
    return pfad


def _spalte_ergaenzen(c, tabelle: str, name: str, typ: str) -> bool:
    """Legt die Spalte an, wenn sie fehlt. Legt ein zweites Db-Objekt auf derselben Datei sie zur selben Zeit an,
    ist das kein Fehler (sonst bräche einer der beiden Starts mit „duplicate column name“ ab). Rückgabe: True, wenn dieser Aufruf sie angelegt hat."""
    if name in {r[1] for r in c.execute(f"PRAGMA table_info({tabelle})")}:
        return False
    try:
        c.execute(f"ALTER TABLE {tabelle} ADD COLUMN {name} {typ}")
    except sqlite3.OperationalError:
        if name not in {r[1] for r in c.execute(f"PRAGMA table_info({tabelle})")}:
            raise
        return False
    return True


def _abschnitte_weg1(c) -> int:
    """Zahl der Abschnitte mit Wochenstunden > 0 und ohne Arbeitstage: Früher Soll 0, seit R4 Weg 1 (Arbeitstage der Regeln)."""
    return c.execute("SELECT COUNT(*) FROM abschnitt WHERE wochenstunden > 0 AND arbeitstage = ''").fetchone()[0]


def _abschnitte_ohne_tagesminuten(c, tabellen: set) -> bool:
    """True, wenn es Abschnitte gibt und ihre Tabelle die Spalte tagesminuten noch nicht hat (dann vor der Umstellung sichern)."""
    return ("abschnitt" in tabellen and TAGESMINUTEN_SPALTE[0] not in {r[1] for r in c.execute("PRAGMA table_info(abschnitt)")}
            and c.execute("SELECT 1 FROM abschnitt LIMIT 1").fetchone() is not None)


def _frei_objekte(liste) -> list:
    """Eigene freie Tage als Objekte {"datum": "JJJJ-MM-TT", "name": Text} nach Datum; ein alter Eintrag (nur der Datumstext) bekommt den Namen ""."""
    return sorted(({"datum": x, "name": ""} if isinstance(x, str) else {"datum": x["datum"], "name": x["name"]} for x in liste), key=lambda x: x["datum"])


def _frei_als_text(c) -> list:
    """Jahre, deren eigene freie Tage noch als Datumstexte gespeichert sind (vor Phase 2): [(jahr, alter Text, neuer Text mit Objekten)].
    Unlesbares bleibt, wie es ist: Der Start darf daran nicht scheitern (eine solche Sicherung lehnt pruefe_sicherung ab)."""
    r = []
    for jahr, text in c.execute("SELECT jahr, eigene_frei FROM jahr"):
        try:
            liste = json.loads(text)
            if isinstance(liste, list) and any(isinstance(x, str) for x in liste):
                r.append((jahr, text, json.dumps(_frei_objekte(liste), ensure_ascii=False)))
        except (ValueError, TypeError, KeyError, RecursionError):
            continue
    return r


ERLAUBTE_TABELLEN = set(re.findall(r"CREATE TABLE IF NOT EXISTS (\w+)", SCHEMA)) | {"sqlite_sequence"}   # alle Stände haben nur Tabellen aus SCHEMA (ältere mit weniger Spalten)
SQLITE_KOPF = b"SQLite format 3\x00"
SICHERUNG_MAX = MAX_KLAR                                  # größte Sicherung (wie der größte entpackte Inhalt einer verschlüsselten Sicherung)
SICHERUNG_KEINE_DB = "Die Datei ist keine Datenbank-Sicherung dieser App (.db)"
SICHERUNG_FREMD = "Die Datei ist keine Sicherung dieser App"
SICHERUNG_BESCHAEDIGT = "Die Sicherung ist beschädigt"
SICHERUNG_UNLESBAR = "Die Sicherung ist beschädigt oder keine Datenbank"
SICHERUNG_ZU_GROSS = "Die Sicherung ist zu groß"


def _tag_gueltig(r: dict) -> bool:
    """Ein Tag aus einer Sicherung, wie ihn auch die Oberfläche speichern würde. Spalten, die alte Sicherungen noch nicht haben, dürfen fehlen;
    Länge und Zeichen der Notiz bleiben ungeprüft, damit keine alte Sicherung an einer Notiz scheitert."""
    konto, attest = r.get("konto", 0), r.get("attest", "")
    if r["art"] not in ARTEN or not tageszeit_gueltig(r["ho"], r["dst"], r["art"]) or not isinstance(r["notiz"], str):
        return False
    if isinstance(konto, bool) or not isinstance(konto, int) or not (konto == 0 or JAHR_MIN <= konto <= JAHR_MAX):
        return False
    if r.get("freigabe", 0) not in (0, 1) or not isinstance(attest, str):
        return False
    if not uhrzeiten_gueltig(r.get("kommen", -1), r.get("gehen", -1), r.get("pause", 0)):
        return False
    if r.get("vermerk", "") not in ("", *konfig.VERMERKE) or r.get("geprueft", 0) not in (0, 1):
        return False
    if attest:
        _datum(attest)
    return True


def _pruefe_tage(con) -> None:
    """Jeder Tag der Sicherung muss ein Datum und mögliche Werte tragen (sonst rechnet die App nach dem Wiederherstellen falsch oder gar nicht)."""
    spalten = [s[1] for s in con.execute("PRAGMA table_info(tag)")]
    for zeile in con.execute("SELECT * FROM tag"):
        r = dict(zip(spalten, zeile))
        try:
            d = _datum(r["datum"])                          # nur JJJJ-MM-TT von 1970 bis 2200: andere Schreibweisen stünden doppelt in der Liste
            gueltig = _tag_gueltig(r)
        except (TypeError, ValueError):
            raise konfig.Meldung("Die Sicherung enthält einen ungültigen Tag")
        if not gueltig:
            raise konfig.Meldung(f"Die Sicherung enthält einen ungültigen Tag ({d:%d.%m.%Y})")


STAND_GERAET = re.compile(r"[0-9a-z]{1,32}")             # Gerätekennung wie im Sync (sync.GERAET)
STAND_GERAETE_MAX, STAND_ZAEHLER_MAX = 64, 10 ** 9


STAND_ZEIT_MAX = 40


def _stand_schluessel(art, schluessel) -> bool:
    """Schlüssel wie in der Synchronisierung (sync.satz_pruefen): Datum, Jahr, bekannte Einstellung oder die Abschnitte als Ganzes.
    Dazu der alte Sammelsatz der Profile: Sicherungen vom 18.11.2026 bleiben lesbar, _schema stellt sie nach dem Wiederherstellen um."""
    if not isinstance(schluessel, str):
        return False
    if art == "tag":
        _datum(schluessel)
        return True
    if art in ("jahr", "konto"):
        return schluessel.isascii() and schluessel.isdigit() and str(int(schluessel)) == schluessel and JAHR_MIN <= int(schluessel) <= JAHR_MAX
    return bool(art == "meta" and (SYNC_META.fullmatch(schluessel) or schluessel == PROFILE_ALT)) or (art, schluessel) == ABSCHNITTE


def _stand_gueltig(art, schluessel, geraet, fassung, zeit="") -> bool:
    """Ein Eintrag des Änderungsprotokolls aus einer Sicherung, wie ihn auch die Synchronisierung annimmt (sync.satz_pruefen)."""
    try:
        f = json.loads(fassung)
        if not _stand_schluessel(art, schluessel) or not isinstance(zeit, str) or len(zeit) > STAND_ZEIT_MAX:
            return False
        if zeit:
            datetime.fromisoformat(zeit)
    except (ValueError, TypeError):
        return False
    if art not in STAND_ARTEN or not isinstance(geraet, str) or (geraet and not STAND_GERAET.fullmatch(geraet)):
        return False
    if not isinstance(f, dict) or not 0 < len(f) <= STAND_GERAETE_MAX:
        return False
    return all(STAND_GERAET.fullmatch(k) and isinstance(n, int) and not isinstance(n, bool) and 0 < n <= STAND_ZAEHLER_MAX for k, n in f.items())


def _datum(text) -> date:
    """Ein Datum aus einer Sicherung in der Schreibweise der App (JJJJ-MM-TT, 1970 bis 2200); ValueError oder TypeError sonst."""
    d = date.fromisoformat(text)
    if d.isoformat() != text or not JAHR_MIN <= d.year <= JAHR_MAX:
        raise ValueError("Datum")
    return d


def _jahreszahl(w) -> bool:
    """True bei einer ganzen Zahl zwischen 1970 und 2200."""
    return isinstance(w, int) and zahl_gueltig(w, JAHR_MIN, JAHR_MAX)


def _jahr_gueltig(r: dict) -> bool:
    """Prüft eine Zeile der Tabelle jahr aus einer Sicherung (Jahr, Anspruch, freie Tage, Übertrag)."""
    frei, uebertrag = json.loads(r["eigene_frei"]), r.get("uebertrag")     # die Spalte „uebertrag“ fehlt in alten Sicherungen
    return (_jahreszahl(r["jahr"]) and zahl_gueltig(r["anspruch"], 0, URLAUB_MAX) and isinstance(frei, list) and len(frei) <= 366
            and all(_frei_eintrag_gueltig(x) for x in frei) and (uebertrag is None or zahl_gueltig(uebertrag, -URLAUB_MAX, URLAUB_MAX)))


def _frei_eintrag_gueltig(x) -> bool:
    """Ein eigener freier Tag aus einer Sicherung: Datumstext (vor Phase 2) oder {datum, name} mit einem Namen bis konfig.FEIERTAG_NAME_MAX Zeichen
    ohne Steuerzeichen ("" bei umgestellten alten Daten). ValueError oder TypeError bei einem ungültigen Datum."""
    if isinstance(x, str):
        return bool(_datum(x))
    return (isinstance(x, dict) and set(x) == {"datum", "name"} and isinstance(x["name"], str) and len(x["name"]) <= konfig.FEIERTAG_NAME_MAX
            and not STEUERZEICHEN.search(x["name"]) and bool(_datum(x["datum"])))


def _konto_gueltig(r: dict) -> bool:
    """Prüft eine Zeile der Tabelle konto aus einer Sicherung (Herkunftsjahr, Tage)."""
    return _jahreszahl(r["herkunft"]) and zahl_gueltig(r["tage"], 0, URLAUB_MAX)


def _abschnitt_gueltig(r: dict) -> bool:
    """Prüft eine Zeile der Tabelle abschnitt aus einer Sicherung (Datumsfolge, Wochenstunden, Art, Arbeitstage, Stunden je Tag)."""
    tage = r["arbeitstage"]
    if not isinstance(tage, str):
        return False
    konfig.tagesminuten_pruefen(r.get("tagesminuten", ""), tage)   # ValueError; alte Sicherungen haben die Spalte nicht
    return (_datum(r["von"]) <= _datum(r["bis"]) and zahl_gueltig(r["wochenstunden"], 0, WOCHENSTUNDEN_MAX) and r["art"] in ABSCHNITT_ARTEN
            and isinstance(tage, str) and all(t in WT[:5] for t in tage.split(",") if t))


def _meta_gueltig(r: dict) -> bool:
    """Nur was die App beim Lesen nicht selbst abfängt: Text, die Startstände als ganze Minuten, die Startwerte (konfig.startwerte_lesen),
    eigene Profile (Name und Inhalt wie in der Synchronisierung), das Ein/Aus der Profile als JSON, Kopf des Monatsnachweises und Jahreswechsel-Merker
    (meta_eintrag_gueltig, sonst lehnten die anderen Geräte sie in der Synchronisierung ab). Unbekannte Einstellungen stören nicht.
    Zu tief Verschachteltes wirft RecursionError (= ungültig)."""
    k, v = r["k"], r["v"]
    if not isinstance(k, str) or not isinstance(v, str) or not meta_eintrag_gueltig(k, v):
        return False
    if k.endswith("_start_min"):
        int(v)
    elif k == konfig.STARTWERTE:
        konfig.startwerte_lesen(v)
    elif k.startswith(konfig.PROFIL_VORSILBE):
        if not SYNC_META.fullmatch(k) or not konfig.profil_name_gueltig(k[len(konfig.PROFIL_VORSILBE):]) or len(v) > konfig.PROFIL_DATEI_MAX:
            return False
        konfig.profil_lesen(v)
    elif k == konfig.SCHALTER:
        json.loads(v)
    elif k == ZAEHLER_AB:
        return _zaehler_ab_gueltig(v)
    return True


def meta_eintrag_gueltig(k: str, v) -> bool:
    """Eine Regel für Wiederherstellen und Synchronisierung. Kopf des Monatsnachweises: Text bis NACHWEIS_MAX Zeichen ohne Steuerzeichen.
    Jahreswechsel-Merker: genau "1". Gemerkter automatischer Übertrag: endliche Zahl in ±URLAUB_MAX.
    Andere Schlüssel: True (die prüfen _meta_gueltig bzw. die Synchronisierung selbst)."""
    if NACHWEIS_META.fullmatch(k):
        return isinstance(v, str) and len(v) <= NACHWEIS_MAX and not STEUERZEICHEN.search(v)
    if JAHRESWECHSEL_META.fullmatch(k):
        return v == ERLEDIGT
    if ANSPAREN_AUTO_META.fullmatch(k):
        try:
            return zahl_gueltig(float(v), -URLAUB_MAX, URLAUB_MAX)         # nan und inf bestehen float(), aber nicht die Grenzen
        except (TypeError, ValueError):
            return False
    return True


def _nachweis_pruefen(werte) -> dict:
    """Eingabe für den Kopf des Monatsnachweises prüfen und bereinigen (siehe Db.nachweis_kopf_setzen). Rückgabe: {Feld: Text}. KonfigFehler sonst."""
    if not isinstance(werte, dict) or not set(werte) <= set(NACHWEIS_FELDER):
        raise konfig.KonfigFehler("Monatsnachweis: nur Name, Arbeitgeber und Personalnummer")
    r = {}
    for f, v in werte.items():
        if not isinstance(v, str):
            raise konfig.KonfigFehler(f"{NACHWEIS_FELDER[f]}: Text erwartet")
        r[f] = notiz_bereinigen(v)
        if len(r[f]) > NACHWEIS_MAX:
            raise konfig.KonfigFehler(f"{NACHWEIS_FELDER[f]}: höchstens {NACHWEIS_MAX} Zeichen")
    return r


def _zaehler_ab_gueltig(v: str) -> bool:
    """True, wenn v eine Untergrenze für die eigene Synchronisierung-Zähler sein kann: ganze Zahl in ASCII-Ziffern bis ZAEHLER_AB_MAX."""
    return bool(ZAEHLER_AB_FORM.fullmatch(v)) and int(v) <= ZAEHLER_AB_MAX


ZEILEN_PRUEFEN = (("jahr", _jahr_gueltig, "ein ungültiges Urlaubsjahr"), ("konto", _konto_gueltig, "ein ungültiges Urlaubskonto"),
                  ("abschnitt", _abschnitt_gueltig, "einen ungültigen Abschnitt"), ("meta", _meta_gueltig, "eine ungültige Einstellung"))


def _pruefe_zeilen(con, tabellen: set) -> None:
    """Urlaubsjahre, Konten, Abschnitte und Einstellungen der Sicherung müssen lesbar sein (sonst rechnet die App nach dem Wiederherstellen nicht mehr).
    Tabellen, die alte Sicherungen noch nicht haben, dürfen fehlen."""
    for tabelle, gueltig, was in ZEILEN_PRUEFEN:
        if tabelle not in tabellen:
            continue
        spalten = [s[1] for s in con.execute(f"PRAGMA table_info({tabelle})")]
        for zeile in con.execute(f"SELECT * FROM {tabelle}"):
            try:
                in_ordnung = gueltig(dict(zip(spalten, zeile)))
            except (TypeError, ValueError, KeyError, RecursionError):
                in_ordnung = False
            if not in_ordnung:
                raise konfig.Meldung(f"Die Sicherung enthält {was}")


def _wegwerf_kopie(quelle: str, kopie: str) -> None:
    """Fremde Datei byteweise nach „kopie“ (ohne -wal/-journal daneben), nur wenn Größe und Kopf stimmen. konfig.Meldung sonst."""
    try:
        if os.path.getsize(quelle) > SICHERUNG_MAX:
            raise konfig.Meldung(SICHERUNG_ZU_GROSS)
        with open(quelle, "rb") as f:
            if f.read(len(SQLITE_KOPF)) != SQLITE_KOPF:
                raise konfig.Meldung(SICHERUNG_KEINE_DB)
        shutil.copyfile(quelle, kopie)
    except OSError:
        raise konfig.Meldung(SICHERUNG_UNLESBAR)


def _pruefe_aufbau(con) -> set:
    """Nur Tabellen und Indizes, die die App selbst anlegt: keine Trigger, Sichten, virtuellen oder fremden Tabellen. Rückgabe: Tabellennamen."""
    objekte = con.execute("SELECT type, name, sql FROM sqlite_master").fetchall()
    for typ, name, sql in objekte:
        virtuell = "virtual" in (sql or "").lower()           # auch „CREATE/**/VIRTUAL“: das eigene Schema enthält das Wort nie
        if typ not in ("table", "index") or virtuell or (typ == "table" and name not in ERLAUBTE_TABELLEN):
            raise konfig.Meldung(SICHERUNG_FREMD)
    return {n for t, n, _ in objekte if t == "table"}


def pruefe_sicherung(pfad: str) -> None:
    """Nur eine unbeschädigte Datenbank dieser App wird angenommen (konfig.Meldung sonst). pfad: Wegwerf-Kopie (sie wird geöffnet).
    Schutz vor Lücken in SQLite, die virtuelle Tabellen oder untergeschobenes SQL brauchen: trusted_schema aus, dann erst der Aufbau
    aus sqlite_master, und integrity_check erst danach (er ruft sonst die Module virtueller Tabellen auf)."""
    with open(pfad, "rb") as f:
        if f.read(len(SQLITE_KOPF)) != SQLITE_KOPF:
            raise konfig.Meldung(SICHERUNG_KEINE_DB)
    con = sqlite3.connect(pfad)
    try:
        con.execute("PRAGMA trusted_schema=OFF")
        tabellen = _pruefe_aufbau(con)
        if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise konfig.Meldung(SICHERUNG_BESCHAEDIGT)
        spalten = {r[1] for r in con.execute("PRAGMA table_info(tag)")}
        if not {"datum", "ho", "dst", "art", "notiz"} <= spalten or "meta" not in tabellen:
            raise konfig.Meldung(SICHERUNG_FREMD)
        _pruefe_tage(con)
        _pruefe_zeilen(con, tabellen)
        if "stand" in tabellen:                             # Änderungsprotokoll: dieselben Regeln wie im Sync, sonst lehnen die anderen Geräte die Datei ab
            for art, schluessel, geraet, fassung, zeit in con.execute("SELECT art, schluessel, geraet, fassung, zeit FROM stand"):
                if not _stand_gueltig(art, schluessel, geraet, fassung, zeit):
                    raise konfig.Meldung(SICHERUNG_FREMD)
    except sqlite3.DatabaseError:
        raise konfig.Meldung(SICHERUNG_UNLESBAR)
    finally:
        con.close()


def sicherung_liste(ordner: str) -> list:
    """Sicherungen im Ordner, neueste zuerst (für die Auswahl beim Wiederherstellen)."""
    try:
        namen = [f for f in os.listdir(ordner) if f.endswith(".db")]
    except OSError:
        return []
    r = []
    for f in namen:
        st = os.stat(os.path.join(ordner, f))
        r.append({"name": f, "zeit": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="minutes"), "bytes": st.st_size})
    return sorted(r, key=lambda x: x["zeit"], reverse=True)


NACHTSICHERUNG = re.compile(r"(?:zeiterfassung|homeoffice)-(\d{4}-\d{2}-\d{2})\.db")      # „homeoffice-“: Name der App bis 15.11.2026


def nachtsicherungen(ordner: str) -> list:
    """Die Tagessicherungen im Ordner, älteste zuerst. Andere Dateien dort (von Hand abgelegte Kopien, Stände vor einem Wiederherstellen)
    zählen nicht: Sie dürfen weder die jüngste Sicherung verdecken noch beim Aufräumen gelöscht werden."""
    return sorted((f for f in os.listdir(ordner) if NACHTSICHERUNG.fullmatch(f)), key=lambda f: NACHTSICHERUNG.fullmatch(f)[1])


def sicherung_stand(ordner: str):
    """Name und Zeit der jüngsten Sicherung im Ordner (None, wenn es keine gibt)."""
    try:
        alt = nachtsicherungen(ordner)
    except OSError:
        return None
    if not alt:
        return None
    st = os.stat(os.path.join(ordner, alt[-1]))
    return {"datei": alt[-1], "zeit": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="minutes"), "anzahl": len(alt), "bytes": st.st_size}


class _Ctx:
    """Kontext für eine Datenbankverbindung: hält das Schloss, speichert oder rollt zurück und schließt die Verbindung."""
    def __init__(self, con, lock):
        """Merkt sich Verbindung und Schloss."""
        self.con, self.lock = con, lock

    def __enter__(self):
        """Nimmt das Schloss und gibt die Verbindung heraus."""
        self.lock.acquire()
        return self.con

    def __exit__(self, typ, wert, tb):
        """Speichert (kein Fehler) oder rollt zurück, schließt die Verbindung und gibt das Schloss frei. Fehler werden nicht verschluckt."""
        try:
            if typ is None:
                self.con.commit()
            else:
                self.con.rollback()
        finally:
            self.con.close()
            self.lock.release()
        return False
