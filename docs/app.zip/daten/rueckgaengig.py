# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Rückgängig nach Speichern, Löschen, Planen, Kommen und Gehen (funktionen.md 1): eine Stufe je Datenbank-Objekt, nur im Speicher des Dienstes.

Ablauf: Die Route schreibt unter db.aufnahme(), merkt das Ergebnis mit merken() und gibt {"id", "text"} an die Oberfläche. anwenden() setzt alle
betroffenen Tage in einer Transaktion zurück (db.zuruecksetzen). Solange offen() gilt, wartet die Synchronisierung, damit kein Stand hinausgeht,
der Sekunden später zurückgenommen wird. Nach Neustart, Demo-Wechsel oder auf einem anderen Gerät gibt es nichts zurückzunehmen (410)."""
import re
import secrets
from datetime import datetime, timedelta, timezone

from daten.db import InzwischenGeaendert

GRENZE = timedelta(seconds=60)                               # so lange nimmt der Dienst Rückgängig an (die Leiste schließt nach spätestens 55 s)
KENNUNG = re.compile(r"[0-9a-f]{16}")
ABGELAUFEN = "Rückgängig ist abgelaufen."
GEAENDERT = "Rückgängig geht nicht mehr: Ein Tag wurde inzwischen geändert (z. B. durch die Synchronisierung)."
UNGUELTIG = "Rückgängig: ungültige Kennung"


class RueckgaengigFehler(Exception):
    """Rückgängig geht nicht. status: 400 (Kennung ungültig), 409 (inzwischen geändert), 410 (abgelaufen oder unbekannt); der Text geht an die Person."""
    def __init__(self, text: str, status: int):
        """Merkt sich Meldetext und HTTP-Status."""
        super().__init__(text)
        self.status = status


def _jetzt() -> datetime:
    """Jetzt in Weltzeit (Vorgabe für alle Funktionen hier; Tests geben die Zeit selbst vor)."""
    return datetime.now(timezone.utc)


def merken(db, text: str, aenderungen: dict, stempel: dict = None, jetzt: datetime = None, stempel_neu: dict = None):
    """Merkt das Rückgängig der eben ausgeführten Aktion und ersetzt ein älteres (nur eine Stufe).
    Eingaben: Meldetext für die Leiste, {iso: (vorher, nachher)} aus db.aufnahme(), beim Gehen die alte Stempeluhr {art, start},
    beim Kommen die eben gestartete (stempel_neu, Rückgängig hält sie wieder an).
    Rückgabe: {"id": 16 Hex-Zeichen, "text"} für die Antwort der Route, None wenn die Aktion nichts geändert hat."""
    verwerfen(db)
    if not aenderungen and not stempel and not stempel_neu:
        return None
    kennung = secrets.token_hex(8)
    db._rueckgaengig = {"id": kennung, "aenderungen": dict(aenderungen), "stempel": stempel, "stempel_neu": stempel_neu, "bis": (jetzt or _jetzt()) + GRENZE}
    return {"id": kennung, "text": text}


def _gemerkt(db, jetzt: datetime = None):
    """Das gemerkte Rückgängig, solange es gilt (sonst None)."""
    m = db._rueckgaengig
    return m if m and (jetzt or _jetzt()) <= m["bis"] else None


def offen(db, jetzt: datetime = None) -> bool:
    """True, solange ein Rückgängig angenommen wird (bis ende(), verwerfen() oder GRENZE). Solange wartet die Synchronisierung."""
    return _gemerkt(db, jetzt) is not None


def anwenden(db, kennung, jetzt: datetime = None) -> dict:
    """Nimmt die gemerkte Aktion zurück. Eingabe: Kennung aus merken(). Rückgabe: {"ok": True, "tage": Zahl}.
    Fehler: RueckgaengigFehler mit 400 (Kennung nicht 16 Hex-Zeichen), 410 (abgelaufen, schon verbraucht, fremde Kennung),
    409 (ein Tag oder die Stempeluhr wurde inzwischen geändert; dann ist nichts geändert)."""
    if not isinstance(kennung, str) or not KENNUNG.fullmatch(kennung):
        raise RueckgaengigFehler(UNGUELTIG, 400)
    with db.lock:
        m = _gemerkt(db, jetzt)
        if not m or not secrets.compare_digest(m["id"], kennung):
            raise RueckgaengigFehler(ABGELAUFEN, 410)
        try:
            tage = db.zuruecksetzen(m["aenderungen"], m["stempel"], m["stempel_neu"])
        except InzwischenGeaendert:
            raise RueckgaengigFehler(GEAENDERT, 409)
        verwerfen(db)
    return {"ok": True, "tage": tage}


def ende(db, kennung) -> None:
    """Die Oberfläche hat die Leiste geschlossen (POST /api/rueckgaengig/ende): Rückgängig mit dieser Kennung verfällt, die Synchronisierung muss nicht warten."""
    m = db._rueckgaengig
    if m and isinstance(kennung, str) and KENNUNG.fullmatch(kennung) and secrets.compare_digest(m["id"], kennung):
        verwerfen(db)


def verwerfen(db) -> None:
    """Vergisst das gemerkte Rückgängig (neue Aktion, „Jetzt synchronisieren“)."""
    db._rueckgaengig = None
