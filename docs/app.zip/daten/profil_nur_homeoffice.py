# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Mitgeliefertes Profil „Nur Homeoffice“ (seit 18.11.2026, Auftrag). Aufbau wie profil_buero_homeoffice.py:
Fehlt diese Datei, fehlt nur dieses Profil. Seit 19.11.2026 ab Werk ausgeschaltet (keine Vorlage beim ersten Start, funktionen.md 6.1);
Datenbanken mit dieser Wahl rechnen weiter, einschalten unter Einstellungen."""

NAME = "Nur Homeoffice"                                      # Anzeigename; steht nur hier
BESCHREIBUNG = "Nur Homeoffice, ohne Büro-Tage."
# Eingebaute Regeln, nur ohne Büro-Tage. Der HO-Spielraum ist aus (ohne Grenze kein Spielraum), Gleittage und Freizeitkonto sind in diesem Profil aus. Grün mit Kontrast AA auf Weiß und hellem Grund.
PROFIL = {"name": NAME, "beschreibung": BESCHREIBUNG, "aktiv": False, "voreinstellung": False, "akzent": "#2e7d4f", "farbe": "hell",
          "werte": {"ho_modus": "nur", "module_aus": ["horest", "gleittage", "freizeit"]}}
