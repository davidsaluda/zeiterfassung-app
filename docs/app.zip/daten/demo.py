# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Demo-Modus: eigene, getrennte Datenbank mit Beispieldaten (zum Ausprobieren, solange die echte noch leer ist).
Die Beispieltage liegen immer relativ zu heute, damit Monat, Woche und Planung lebendig aussehen.
Dauerregel seit 18.11.2026 (Auftrag): Jede Demo wird zufällig aus den geltenden Regeln (Profil) gebaut: Homeoffice-Modus,
HO-Grenze, Arbeitstage, Wochenstunden, Urlaubstage, Limits, abgeschaltete Module, eigene Feiertage. Nie ein festes Muster.
Sie setzt „Erfassung gültig ab“ auf den ersten Demo-Tag (R6) und legt keine Abschnitte an (Profile kennen keine, R4).
Nur die Design-Prüfung setzt HO_DEMO_SAMEN, damit ihre Bilder von Lauf zu Lauf gleich bleiben."""
import json
import os
import random
from datetime import date, timedelta

from daten import konfig
from kern import regeln
from kern import urlaub as ur
from kern.feiertage import freie_tage

WOCHENTAGE = ("Mo", "Di", "Mi", "Do", "Fr")
UEBERTRAG_DEMO = (3, 12)                  # Resturlaub aus dem Vorjahr (Tage), wenn die Beispieltage erst im Jahr beginnen: zeigt die Frist
ZEITRAUM_TAGE = 75                       # so weit reichen die Beispieltage zurück
SCHWANKUNG_MIN = 30                      # Arbeitszeit je Tag: Soll plus/minus bis zu 30 Minuten, in 6-Minuten-Schritten
SCHWANKUNG_UNTEN_MIN = 18                # nach unten weniger als nach oben: wer Gleitzeit hat, baut eher etwas auf
HO_ANTEIL = 0.55                         # Wahrscheinlichkeit für einen Homeoffice-Tag (mit oder ohne Grenze)
GEMISCHT_ANTEIL = 0.1                    # Tag mit Homeoffice und Büro
GRENZE_ABSTAND = 5                       # mit Grenze: die Monatsquote bleibt mindestens 5 Prozentpunkte darunter
WOCHENENDE_MIN = (240, 300, 360)
SELTEN_ANTEIL = 0.5                      # Wahrscheinlichkeit für je einen Tag Sonderurlaub, Kind krank und Krank im Dienst (R3, R5)
KRANK_IM_DIENST_PROZENT = (50, 75)       # gearbeitet an einem Tag „Krank im Dienst“: Anteil am Tagessoll, abgerundet auf 6 Minuten
VERMERK_ANTEIL = 0.1                     # Anteil der Arbeitstage mit Vermerk (Dienstreise oder Fortbildung), ohne Wirkung auf die Rechnung
# Erfundene Personendaten, damit Monatsnachweis und Exporte in der Demo vollständig aussehen; stehen nur in der Demo-Datenbank
NACHWEIS_KOPF = {"name": "Max Mustermann", "arbeitgeber": "Musterfirma", "personalnummer": "12345", "ort": "Musterstadt"}
START_TAGE_MAX = {"urlaub": 5, "gleittage": 2, "krank": 3, "kind_krank": 2}   # Startwerte (R6): höchstens so viele Tage je Feld vor „ab“
START_MODULE = {"urlaub": ("urlaub",), "gleittage": ("urlaub", "gleittage"), "krank": ("krank",), "kind_krank": ("kind_krank",)}
LIMIT_FELD = {"urlaub": "urlaub", "gleittag": "gleittage", regeln.KIND_KRANK: "kind_krank"}   # Art mit Jahreslimit: ihr Feld in den Startwerten
GLEITZEIT_START_MIN = (1200, 1500, 1800) # Startstand des Gleitzeit-Kontos: 20, 25 oder 30 Stunden (Gleittage, der offene Tag heute und die Schwankungen bleiben im Plus)
REGEL_FELDER = ("ho_modus", "ho_grenze", "arbeitstage", "wochenstunden", "urlaub_tage", "gleittage_max", "module_aus",
                "bundesland", "heiligabend_frei", "silvester_frei", "himmelfahrt_frei", "feiertage_eigen", "feiertage_aus",
                "kind_krank_max", "kind_krank_dienst", "dienstverhaeltnis", "fasching_std",
                "gleitzeit_kappung", "kappung_stichtag", "kappung_grenze_min", "kappung_ab_jahr", "resturlaub_frist", "resturlaub_ansparen")   # ändert sich eins davon, passt die Demo nicht mehr (Limits, freie Tage, Tagessoll am Faschingsdienstag, Kappung, Frist des Resturlaubs)


def _fingerabdruck() -> str:
    """Die geltenden Regeln der Demo-Felder als Text; ändert sich einer, passt die Demo nicht mehr."""
    r = konfig.fuer(date.today())
    return json.dumps({k: r.get(k) for k in REGEL_FELDER}, sort_keys=True)


def passt(db) -> bool:
    """Wurde die Demo mit den heute geltenden Regeln befüllt?"""
    return db.meta_lesen("demo_regeln") == _fingerabdruck()


def zuruecksetzen(db, heute: date = None, samen=None):
    """Demo-Datenbank leeren und neu (zufällig) befüllen."""
    with db._c() as c:
        for t in ("tag", "jahr", "abschnitt", "konto", "meta", "stempel"):
            c.execute(f"DELETE FROM {t}")
    db._geaendert()                                       # sonst bleiben alte Werte im Zwischenspeicher, falls das Befüllen abbricht
    befuellen(db, heute or date.today(), samen)


def _jahreslimit(db, art: str, jahr: int) -> float:
    """Höchstzahl an Tagen dieser Art im Jahr: Urlaubsanspruch (mit Zusatzurlaub, wenn das Profil ihn hat), Gleittage- bzw. Kind-krank-Limit laut Regeln."""
    if art == "urlaub":
        return db.jahr_einstellung(jahr)["anspruch"] + ur.zusatzurlaub(jahr, db.abschnitte())
    return regeln.gleittage_max(jahr) if art == "gleittag" else regeln.kind_krank_max(jahr)


def _startwerte(db, zufall, r: dict, ab: date, arbeitstag, tagessoll: int) -> dict:
    """Startwerte (R6) ohne ab und Konten: der Stand vom 01.01. bis ab − 1, passend zum Profil.
    Tage zufällig bis START_TAGE_MAX, nur mit Modul, zusammen höchstens die Arbeitstage davor, je Feld höchstens das Jahreslimit.
    HO und Büro: die übrigen Arbeitstage × Tagessoll, nach Homeoffice-Modus geteilt (mit Grenze mindestens GRENZE_ABSTAND darunter).
    ab am 01.01. ergibt nur Nullen (kein Tag davor)."""
    aus = set(r["module_aus"])
    tage = sum(arbeitstag(date.fromordinal(n)) for n in range(date(ab.year, 1, 1).toordinal(), ab.toordinal()))
    limits = {"urlaub": _jahreslimit(db, "urlaub", ab.year), "gleittage": _jahreslimit(db, "gleittag", ab.year),
              "krank": tage, "kind_krank": _jahreslimit(db, regeln.KIND_KRANK, ab.year)}
    werte = {}
    for feld, hoechstens in START_TAGE_MAX.items():
        an = not aus.intersection(START_MODULE[feld])
        werte[feld] = zufall.randint(0, int(min(hoechstens, limits[feld], tage))) if an else 0
        tage -= werte[feld]
    minuten = tage * tagessoll
    anteil = zufall.uniform(HO_ANTEIL / 2, HO_ANTEIL)
    if r["ho_modus"] == "grenze":
        anteil = min(anteil, max(0, float(r["ho_grenze"]) - GRENZE_ABSTAND) / 100)
    ho = {"kein": 0, "nur": minuten}.get(r["ho_modus"], int(minuten * anteil))
    return {**werte, "ho_min": ho, "dst_min": minuten - ho}


def befuellen(db, heute: date, samen=None):
    """Beispieltage nach den Regeln, die an `heute` gelten. samen: fester Zufall (Tests, Design-Prüfung), sonst jedes Mal anders."""
    zufall = random.Random(samen if samen is not None else os.environ.get("HO_DEMO_SAMEN"))
    r = konfig.fuer(heute)
    aus = set(r["module_aus"])
    arbeitstage = {WOCHENTAGE.index(x) for x in r["arbeitstage"].split(",")}
    soll = round(r["wochenstunden"] * 60 / len(arbeitstage))
    obergrenze = max(regeln.MAX_TAG_MIN, min(soll, regeln.TAG_MIN))   # über 10 Stunden nur, wenn schon das Tagessoll darüber liegt (dann mit Freigabe)
    modus, grenze = r["ho_modus"], float(r["ho_grenze"])
    monat_ho, monat_alle = {}, {}
    zeilen = {}                                      # Datum: Zeile für db.tage_setzen; alles in einer Transaktion, ein späterer Eintrag ersetzt einen früheren

    def feiertag(d: date) -> bool:
        """Feiertag oder laut Regeln freier Tag (24.12./31.12.), auch an einem Samstag."""
        return d in freie_tage(d.year)

    def werktag(d: date) -> bool:
        """Ist das Datum ein Arbeitstag nach den Regeln (gewählter Wochentag, kein Feiertag)?"""
        return d.weekday() in arbeitstage and not feiertag(d)

    def limit(art: str, jahr: int) -> float:
        """Jahreslimit der Art, im Jahr von „ab“ abzüglich der Tage aus den Startwerten (sie zählen dort mit)."""
        return _jahreslimit(db, art, jahr) - (start[LIMIT_FELD[art]] if jahr == ab.year else 0)

    def frei_setzen(d: date, art: str, notiz: str = "") -> bool:
        """Trägt einen ganzen Tag dieser Art ein; Urlaub, Gleittage und Kind krank nur, solange das Limit des Jahres nicht erreicht ist. Rückgabe: eingetragen?"""
        if art in LIMIT_FELD and sum(1 for x, z in zeilen.items() if x.year == d.year and z[3] == art and x != d) >= limit(art, d.year):
            return False
        zeilen[d] = (d, 0, 0, art, notiz)
        return True

    def aufteilen(d: date, minuten: int) -> tuple:
        """(HO, Büro) für einen Arbeitstag, passend zum Homeoffice-Modus."""
        if modus == "kein":
            return 0, minuten
        if modus == "nur":
            return minuten, 0
        if zufall.random() < GEMISCHT_ANTEIL:
            ho = minuten // 2
        else:
            ho = minuten if zufall.random() < HO_ANTEIL else 0
        m = (d.year, d.month)
        if modus == "grenze" and (monat_ho.get(m, 0) + ho) * 100 > (grenze - GRENZE_ABSTAND) * (monat_alle.get(m, 0) + minuten):
            ho = 0                                        # Monatsquote bliebe sonst nicht sicher unter der Grenze
        monat_ho[m] = monat_ho.get(m, 0) + ho
        monat_alle[m] = monat_alle.get(m, 0) + minuten
        return ho, minuten - ho

    def arbeit(d: date, minuten: int, notiz: str = "", art: str = ""):
        """Trägt einen Arbeitstag (art leer oder Krank im Dienst) mit der Aufteilung HO/Büro ein, höchstens bis zur Obergrenze, darüber mit Freigabe.
        Ein normaler Arbeitstag bekommt manchmal einen Vermerk."""
        minuten = min(minuten, obergrenze)
        ho, dst = aufteilen(d, minuten)
        vermerk = zufall.choice(sorted(konfig.VERMERKE)) if not art and zufall.random() < VERMERK_ANTEIL else ""
        zeilen[d] = (d, ho, dst, art, notiz, 0, "", int(minuten > regeln.MAX_TAG_MIN), -1, -1, 0, vermerk)

    def nach_vorn(d: date) -> date:
        """Das nächste Datum ab d (einschließlich), das ein Arbeitstag ist."""
        while not werktag(d):
            d += timedelta(days=1)
        return d

    db.jahr_setzen(heute.year, float(r["urlaub_tage"]), [])
    ab = heute - timedelta(days=ZEITRAUM_TAGE)               # „Erfassung gültig ab“ = erster Demo-Tag
    start = (_startwerte(db, zufall, r, ab, werktag, min(soll, obergrenze)) if ab.year == heute.year
             else dict.fromkeys(("ho_min", "dst_min", *START_TAGE_MAX), 0))   # ab im Vorjahr: der Stand davor bleibt leer
    tage = [ab + timedelta(days=n) for n in range((heute - ab).days)]
    werktage = [d for d in tage if werktag(d)]
    besondere = {}
    if "urlaub" not in aus and len(werktage) > 25:
        i = zufall.randrange(5, len(werktage) - 15)
        besondere.update({d: "urlaub" for d in werktage[i:i + zufall.randint(3, 5)]})   # ein Urlaub am Stück
    if "krank" not in aus:
        offen = [d for d in werktage if d not in besondere]   # nicht im Urlaub, sonst fiele die Krankphase ganz weg
        i = zufall.randrange(0, max(1, len(offen) - 3))
        besondere.update({d: "krank" for d in offen[i:i + zufall.randint(1, 3)]})
    frei = [d for d in werktage[:-1] if d not in besondere]
    for art, an in (("gleittag", "urlaub" not in aus and "gleittage" not in aus), ("freizeit", "freizeit" not in aus),
                    (regeln.SONDERURLAUB, "sonderurlaub" not in aus and zufall.random() < SELTEN_ANTEIL),
                    (regeln.KIND_KRANK, "kind_krank" not in aus and zufall.random() < SELTEN_ANTEIL),
                    (regeln.KRANK_IM_DIENST, "krank" not in aus and zufall.random() < SELTEN_ANTEIL)):
        if an and frei:
            d = zufall.choice(frei)
            frei.remove(d)
            besondere[d] = art
    for d in werktage:
        art = besondere.get(d)
        if art == regeln.KRANK_IM_DIENST:              # angefangen, dann krank: die fehlende Zeit füllt die App auf (Saldo 0)
            arbeit(d, regeln.tagessoll_min(d, []) * zufall.randint(*KRANK_IM_DIENST_PROZENT) // 100 // 6 * 6, art=art)   # Tagessoll mit Faschingsdienstag
        elif not (art and frei_setzen(d, art, "Ausgleich für Wochenendarbeit" if art == "freizeit" else "")):   # über dem Limit: ein normaler Arbeitstag
            arbeit(d, soll + zufall.randrange(-SCHWANKUNG_UNTEN_MIN, SCHWANKUNG_MIN + 1, 6))
    if "freizeit" not in aus:                        # Wochenendarbeit: kommt aufs Freizeitkonto, nicht in die Gleitzeit
        samstage = [d for d in tage if d.weekday() == 5]
        gewaehlt = zufall.sample(samstage, min(len(samstage), zufall.randint(1, 2)))
        ersatz = [d for d in samstage if not feiertag(d) and d not in gewaehlt]
        # Feiertag am Samstag: zufällig ein anderer Samstag. Gezogen wird aus allen, damit derselbe Samen ohne Feiertag dieselben Tage ergibt (Bilder der Design-Prüfung).
        gewaehlt = [ersatz.pop(zufall.randrange(len(ersatz))) if feiertag(d) else d for d in gewaehlt]
        minuten = [zufall.choice(WOCHENENDE_MIN) for _ in gewaehlt]
        # Soll des Ausgleichstags selbst: Die Rest-Minuten der Woche bekommen die ersten Arbeitstage (regeln.tagessoll_min), nicht jeder Tag gleich viel
        ausgleich = sum(regeln.tagessoll_min(d, db.abschnitte()) for d, a in besondere.items() if a == "freizeit")
        if minuten and sum(minuten) < ausgleich:
            minuten[-1] += ausgleich - sum(minuten)   # der Freizeitausgleich (ein ganzer Tag) braucht Guthaben, sonst stünde das Freizeitkonto im Minus
        for d, m in zip(gewaehlt, minuten):
            arbeit(d, m, "Bereitschaft")
    if "urlaub" not in aus:                          # geplant: ein Gleittag in den nächsten Wochen, ein Urlaub in gut einem Monat
        if "gleittage" not in aus:
            d = nach_vorn(heute + timedelta(days=zufall.randint(7, 21)))
            frei_setzen(d, "gleittag")
        d = nach_vorn(heute + timedelta(days=zufall.randint(28, 45)))
        for n in range(zufall.randint(3, 7)):
            if werktag(d + timedelta(days=n)):
                frei_setzen(d + timedelta(days=n), "urlaub")
    db.tage_setzen(list(zeilen.values()))
    db.startwerte_setzen({**start, "ab": ab.isoformat(), "gleitzeit_min": zufall.choice(GLEITZEIT_START_MIN), "freizeit_min": 0},
                         heute=heute, sichern=False)   # mit heute: dieselbe Plausibilitätsprüfung wie bei einer Eingabe
    if "urlaub" not in aus and ab.year == heute.year:  # zuletzt gezogen: der Zufall davor bleibt (Bilder der Design-Prüfung)
        db.uebertrag_setzen(heute.year, zufall.randint(*UEBERTRAG_DEMO))   # beginnt ab im Vorjahr, rechnet die App den Übertrag selbst
    if "monatsnachweis" not in aus:
        db.nachweis_kopf_setzen(NACHWEIS_KOPF)
    db.meta_setzen("demo_regeln", _fingerabdruck())
