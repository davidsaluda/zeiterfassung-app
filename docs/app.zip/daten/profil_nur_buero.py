# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Mitgeliefertes Profil „Nur Büro“ (seit 18.11.2026, Auftrag; vorher ein privates Profil im Datenordner).
Aufbau wie profil_buero_homeoffice.py: Fehlt diese Datei, fehlt nur dieses Profil. Seit 19.11.2026 ab Werk ausgeschaltet (keine Vorlage beim
ersten Start, funktionen.md 6.1); Datenbanken mit dieser Wahl rechnen weiter, einschalten unter Einstellungen."""

NAME = "Nur Büro"                                            # Anzeigename; steht nur hier
BESCHREIBUNG = "Ohne Homeoffice, weniger Seiten."
# 40,5 Stunden, 28 Urlaubstage, kein Homeoffice, Faschingsdienstag normal, Mariä Himmelfahrt frei, 24.12. und 31.12. Arbeitstage;
# ausgeblendet ist, was ohne Homeoffice und ohne Gleit-, Familien- und Freizeittage niemand braucht.
PROFIL = {"name": NAME, "beschreibung": BESCHREIBUNG, "aktiv": False, "voreinstellung": False, "akzent": "#00a4a4", "farbe": "hell",
          "werte": {"wochenstunden": 40.5, "urlaub_tage": 28, "ho_modus": "kein", "fasching_std": None, "himmelfahrt_frei": True,
                    "heiligabend_frei": False, "silvester_frei": False,
                    "module_aus": ["horest", "gleittage", "familientage", "angespart", "freizeit", "nachweis", "ex_office", "ex_text", "ex_daten"]}}
