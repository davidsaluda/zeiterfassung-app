# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""AES-256-GCM und die Schlüsselableitung PBKDF2-HMAC-SHA-256 für die verschlüsselte Sicherung und die Synchronisierung (sicherung.py).

Python bringt kein AES in der Standardbibliothek mit, aber fast jede Python-Fassung enthält die Bibliothek OpenSSL (hashlib rechnet damit).
Dieses Modul ruft deren geprüfte AES-Umsetzung direkt auf (ctypes), statt selbst eine Verschlüsselung zu bauen. Es entsteht keine Verbindung:
OpenSSL rechnet hier nur, das Netz-Modul ssl wird nicht eingebunden.

Pyodide 314 (die Web-App) bringt kein OpenSSL mehr mit. Nur wo OpenSSL fehlt, rechnet dieses Modul mit pycryptodome (Ausnahme seit 22.11.2026,
das Paket liefert der Bau der Web-App mit); die Ergebnisse sind bitgleich (Test test_groesse_web). Fehlt beides, meldet verfuegbar() False
und sicherung.py sagt das mit einem klaren Text."""
import ctypes
import ctypes.util
import glob
import hashlib
import os

SCHLUESSEL = 32                                            # AES-256
EINMAL = 12                                                # Einmalwert, wie für GCM empfohlen (96 Bit)
MARKE = 16                                                 # Prüfmarke (128 Bit)
_IVLEN_SETZEN, _MARKE_LESEN, _MARKE_SETZEN = 0x9, 0x10, 0x11   # EVP_CTRL_AEAD_SET_IVLEN, _GET_TAG, _SET_TAG
_FUNKTIONEN = ("EVP_CIPHER_CTX_new", "EVP_CIPHER_CTX_free", "EVP_aes_256_gcm", "EVP_CIPHER_CTX_ctrl", "EVP_EncryptInit_ex", "EVP_EncryptUpdate",
               "EVP_EncryptFinal_ex", "EVP_DecryptInit_ex", "EVP_DecryptUpdate", "EVP_DecryptFinal_ex")


class Ungueltig(ValueError):
    """Die Prüfmarke passt nicht: falscher Schlüssel oder veränderte Daten."""


class Fehlt(RuntimeError):
    """Auf diesem Gerät fehlt AES oder PBKDF2 (weder OpenSSL noch pycryptodome)."""


def _kandidaten():
    """Wo OpenSSL liegen kann: neben dem Modul, mit dem hashlib rechnet (Windows, gepackte Desktop-App), oder als dessen Abhängigkeit (Server im Container, Android)."""
    try:
        import _hashlib
        pfad = getattr(_hashlib, "__file__", "") or ""
    except ImportError:
        pfad = ""
    if pfad and os.name == "nt":
        yield from sorted(glob.glob(os.path.join(os.path.dirname(pfad), "libcrypto*.dll")), reverse=True)
    elif pfad:
        yield pfad
    name = ctypes.util.find_library("crypto")
    if name:
        yield name
    if os.name != "nt":
        yield None                                         # das laufende Programm selbst (OpenSSL fest eingebaut)


def _laden():
    """Sucht eine OpenSSL-Bibliothek mit allen nötigen Funktionen und richtet sie ein. Gibt sie zurück oder None."""
    for kandidat in _kandidaten():
        try:
            lib = ctypes.CDLL(kandidat)
            if all(hasattr(lib, f) for f in _FUNKTIONEN):
                return _einrichten(lib)
        except OSError:
            continue
    return None


def _einrichten(lib):
    """Legt für die genutzten OpenSSL-Funktionen Rückgabe- und Argumenttypen fest (ctypes). Gibt die Bibliothek zurück."""
    zeiger, zahl, zahl_zeiger = ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_int)
    lib.EVP_CIPHER_CTX_new.restype, lib.EVP_CIPHER_CTX_new.argtypes = zeiger, []
    lib.EVP_CIPHER_CTX_free.restype, lib.EVP_CIPHER_CTX_free.argtypes = None, [zeiger]
    lib.EVP_aes_256_gcm.restype, lib.EVP_aes_256_gcm.argtypes = zeiger, []
    lib.EVP_CIPHER_CTX_ctrl.restype, lib.EVP_CIPHER_CTX_ctrl.argtypes = zahl, [zeiger, zahl, zahl, ctypes.c_char_p]
    for name in ("EVP_EncryptInit_ex", "EVP_DecryptInit_ex"):
        f = getattr(lib, name)
        f.restype, f.argtypes = zahl, [zeiger, zeiger, zeiger, ctypes.c_char_p, ctypes.c_char_p]
    for name in ("EVP_EncryptUpdate", "EVP_DecryptUpdate"):
        f = getattr(lib, name)
        f.restype, f.argtypes = zahl, [zeiger, ctypes.c_char_p, zahl_zeiger, ctypes.c_char_p, zahl]
    for name in ("EVP_EncryptFinal_ex", "EVP_DecryptFinal_ex"):
        f = getattr(lib, name)
        f.restype, f.argtypes = zahl, [zeiger, ctypes.c_char_p, zahl_zeiger]
    return lib


def _pycryptodome():
    """-> (AES, PBKDF2, SHA256) aus pycryptodome oder None, wenn es fehlt (überall außer in der Web-App)."""
    try:
        from Crypto.Cipher import AES
        from Crypto.Hash import SHA256
        from Crypto.Protocol.KDF import PBKDF2
    except ImportError:
        return None
    return AES, PBKDF2, SHA256


_lib = _laden()
_crypto = _pycryptodome() if _lib is None or not hasattr(hashlib, "pbkdf2_hmac") else None   # nur als Ersatz, wo OpenSSL fehlt
STUECK = 1 << 30                                           # OpenSSL nimmt die Länge als int entgegen


def verfuegbar() -> bool:
    """Ist AES auf diesem Gerät nutzbar (OpenSSL oder pycryptodome gefunden)?"""
    return _lib is not None or _crypto is not None


def ableiten(geheim: bytes, salz: bytes, runden: int, laenge: int) -> bytes:
    """PBKDF2-HMAC-SHA-256 (RFC 8018): laenge Byte aus geheim und salz. Rechnet mit hashlib (OpenSSL), sonst mit pycryptodome; beide liefern dieselben Bytes.
    Fehlt: weder das eine noch das andere da."""
    pbkdf2 = getattr(hashlib, "pbkdf2_hmac", None)
    if pbkdf2 is not None:
        return pbkdf2("sha256", geheim, salz, runden, laenge)
    if _crypto is None:
        raise Fehlt("PBKDF2 ist auf diesem Gerät nicht verfügbar")
    _, kdf, sha256 = _crypto
    return kdf(geheim, salz, dkLen=laenge, count=runden, hmac_hash_module=sha256)   # ohne hmac_hash_module rechnete es mit SHA-1


def _pruefen(schluessel: bytes, einmal: bytes) -> None:
    """Prüft, dass AES da ist und Schlüssel (32 Byte) und Einmalwert (12 Byte) die richtige Länge haben; sonst Fehlt bzw. ValueError."""
    if not verfuegbar():
        raise Fehlt("AES ist auf diesem Gerät nicht verfügbar")
    if len(schluessel) != SCHLUESSEL or len(einmal) != EINMAL:
        raise ValueError("Schlüssel braucht 32 Byte, der Einmalwert 12 Byte")


def _lauf(start, weiter, schluessel: bytes, einmal: bytes, daten: bytes, kopf: bytes, ctx) -> bytes:
    """Gemeinsamer Teil von Ver- und Entschlüsseln: einrichten, den Kopf nur prüfen lassen (er bleibt lesbar), die Daten umrechnen."""
    n = ctypes.c_int(0)
    ok = start(ctx, _lib.EVP_aes_256_gcm(), None, None, None) == 1
    ok = ok and _lib.EVP_CIPHER_CTX_ctrl(ctx, _IVLEN_SETZEN, EINMAL, None) == 1
    ok = ok and start(ctx, None, None, schluessel, einmal) == 1
    ok = ok and (not kopf or weiter(ctx, None, ctypes.byref(n), kopf, len(kopf)) == 1)
    teile = []
    for i in range(0, len(daten), STUECK):
        teil = daten[i:i + STUECK]
        aus = ctypes.create_string_buffer(len(teil) + 16)
        ok = ok and weiter(ctx, aus, ctypes.byref(n), teil, len(teil)) == 1
        teile.append(aus.raw[:n.value])
    if not ok:
        raise RuntimeError("AES-Aufruf fehlgeschlagen")
    return b"".join(teile)


def _gcm(schluessel: bytes, einmal: bytes, kopf: bytes):
    """Ein AES-256-GCM-Objekt von pycryptodome, der Kopf ist schon zur Prüfung übergeben (nur wo OpenSSL fehlt)."""
    zelle = _crypto[0].new(schluessel, _crypto[0].MODE_GCM, nonce=einmal, mac_len=MARKE)
    zelle.update(kopf)
    return zelle


def verschluesseln(schluessel: bytes, einmal: bytes, klar: bytes, kopf: bytes = b"") -> bytes:
    """-> Geheimtext + 16 Byte Prüfmarke. Der Kopf wird nicht verschlüsselt, aber mit geprüft."""
    _pruefen(schluessel, einmal)
    if _lib is None:
        geheim, marke = _gcm(schluessel, einmal, kopf).encrypt_and_digest(klar)
        return geheim + marke
    ctx = _lib.EVP_CIPHER_CTX_new()
    try:
        geheim = _lauf(_lib.EVP_EncryptInit_ex, _lib.EVP_EncryptUpdate, schluessel, einmal, klar, kopf, ctx)
        n, rest, marke = ctypes.c_int(0), ctypes.create_string_buffer(16), ctypes.create_string_buffer(MARKE)
        if _lib.EVP_EncryptFinal_ex(ctx, rest, ctypes.byref(n)) != 1 or _lib.EVP_CIPHER_CTX_ctrl(ctx, _MARKE_LESEN, MARKE, marke) != 1:
            raise RuntimeError("AES-Aufruf fehlgeschlagen")
        return geheim + rest.raw[:n.value] + marke.raw
    finally:
        _lib.EVP_CIPHER_CTX_free(ctx)


def entschluesseln(schluessel: bytes, einmal: bytes, geheim_mit_marke: bytes, kopf: bytes = b"") -> bytes:
    """-> Klartext. Ungueltig, wenn Schlüssel, Kopf oder Daten nicht zur Prüfmarke passen; dann wird nichts herausgegeben."""
    _pruefen(schluessel, einmal)
    if len(geheim_mit_marke) < MARKE:
        raise Ungueltig("zu kurz")
    geheim, marke = geheim_mit_marke[:-MARKE], geheim_mit_marke[-MARKE:]
    if _lib is None:
        try:
            return _gcm(schluessel, einmal, kopf).decrypt_and_verify(geheim, marke)
        except ValueError:                                 # pycryptodome meldet eine falsche Marke so; den Klartext gibt es dann nicht heraus
            raise Ungueltig("Prüfmarke passt nicht") from None
    ctx = _lib.EVP_CIPHER_CTX_new()
    try:
        klar = _lauf(_lib.EVP_DecryptInit_ex, _lib.EVP_DecryptUpdate, schluessel, einmal, geheim, kopf, ctx)
        n, rest = ctypes.c_int(0), ctypes.create_string_buffer(16)
        if _lib.EVP_CIPHER_CTX_ctrl(ctx, _MARKE_SETZEN, MARKE, marke) != 1:
            raise RuntimeError("AES-Aufruf fehlgeschlagen")
        if _lib.EVP_DecryptFinal_ex(ctx, rest, ctypes.byref(n)) != 1:
            raise Ungueltig("Prüfmarke passt nicht")
        return klar + rest.raw[:n.value]
    finally:
        _lib.EVP_CIPHER_CTX_free(ctx)


def selbsttest() -> bool:
    """Rechnet einen bekannten Prüfwert nach (GCM-Beschreibung von McGrew und Viega, Testfall 13). So zeigt jede Fassung der App, ob ihr AES richtig rechnet."""
    try:
        marke = bytes.fromhex("530f8afbc74536b9a963b4f1c4cb738b")
        return verschluesseln(bytes(SCHLUESSEL), bytes(EINMAL), b"") == marke and entschluesseln(bytes(SCHLUESSEL), bytes(EINMAL), marke) == b""
    except (RuntimeError, ValueError):
        return False
