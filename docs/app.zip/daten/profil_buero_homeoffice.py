# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Mitgeliefertes Profil „Büro + Homeoffice“ (eine Datei je Profil, seit 18.11.2026, Auftrag „Profile auslagern“).
Fehlt diese Datei, fehlt nur dieses Profil. konfig.mitgeliefert() prüft den Inhalt wie jede andere Eingabe.

Felder: name (1 bis 40 Zeichen), aktiv (ob das Profil zuerst zur Auswahl steht), voreinstellung (seine Regeln und Darstellung gelten, bis die Person
beim ersten Start wählt), akzent (#rrggbb oder ""), farbe ("hell", "dunkel", "auto" oder ""), werte (nur die Regeln, die von konfig.STANDARD abweichen)."""

NAME = "Büro + Homeoffice"                                      # Anzeigename; steht nur hier (Tests und Oberfläche lesen ihn aus dem Profil)
BESCHREIBUNG = ("Mit Homeoffice-Grenze 80 %, Bayern: Faschingsdienstag 4 Stunden, Heiligabend und Silvester frei, "   # ein Satz für die Wahl beim ersten Start
                "Gleit- und Familientage.")
# Dieselben Regeln wie die eingebauten der App, helle Darstellung in Blau.
PROFIL = {"name": NAME, "beschreibung": BESCHREIBUNG, "aktiv": True, "voreinstellung": True, "akzent": "#2c5a93", "farbe": "hell", "werte": {}}
