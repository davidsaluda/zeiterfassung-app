# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Einstellbare Regeln mit Gültigkeit ab einem Datum (gespeichert in der Tabelle meta unter "konfig").
Jede Version gilt ab ihrem Datum bis zur nächsten. Eine Änderung gilt standardmäßig erst ab heute (Vergangenheit bleibt unverändert);
auf Wunsch ab einem Datum oder rückwirkend für alle Zeiträume. Die Voreinstellungen entsprechen dem bisherigen Verhalten.
Keine Abhängigkeiten, damit feiertage und regeln sie lesen können."""
import contextlib
import itertools
import json
import os
import re
import threading
from dataclasses import asdict, dataclass
from datetime import date

BUNDESLAENDER = {"BW": "Baden-Württemberg", "BY": "Bayern", "BE": "Berlin", "BB": "Brandenburg", "HB": "Bremen", "HH": "Hamburg", "HE": "Hessen",
                 "MV": "Mecklenburg-Vorpommern", "NI": "Niedersachsen", "NW": "Nordrhein-Westfalen", "RP": "Rheinland-Pfalz", "SL": "Saarland",
                 "SN": "Sachsen", "ST": "Sachsen-Anhalt", "SH": "Schleswig-Holstein", "TH": "Thüringen"}
# Tage „Kind krank“ je Kind und Elternteil (Entscheidung N5, 19.11.2026: Vorgabe nach Gesetz, Jahr und Dienstverhältnis, Werte änderbar; keine Rechtsauskunft).
# Stand 19.11.2026. Gesetzlich versichert, § 45 SGB V (gesetze-im-internet.de/sgb_5/__45.html, BMG-FAQ Kinderkrankengeld): Abs. 2 Grundregel 10,
# Abs. 2a befristet 15 (2024 bis 2026); für 2027 keine Verlängerung beschlossen. Beamte in Bayern, § 10 Abs. 3 UrlMV (gesetze-bayern.de/Content/Document/BayUrlMV-10):
# bezahlte Dienstbefreiung bis 80 % davon (12 bzw. 8), der Rest ist Sonderurlaub nach § 13 UrlMV. Neue Jahre nur mit Quelle eintragen, nicht aus dem Gedächtnis.
KIND_KRANK_GESETZ_GRUND = 10                                 # alte feste Vorgabe der Regel kind_krank_max (Grundregel § 45 Abs. 2 SGB V)
KIND_KRANK_VORGABE = {"gesetzlich": ({2024: 15, 2025: 15, 2026: 15}, KIND_KRANK_GESETZ_GRUND), "beamte_by": ({2024: 12, 2025: 12, 2026: 12}, 8)}   # Dienst: (Jahr -> Tage, sonst)
KIND_KRANK_DIENSTE = {"gesetzlich": "Gesetzlich (§ 45 SGB V)", "beamte_by": "Beamte Bayern (UrlMV)", "eigen": "Eigener Wert"}
KIND_KRANK_EIGEN = "eigen"                                   # Regel kind_krank_dienst: dann gilt kind_krank_max
# Zusatzurlaub (Auftrag vom 23.11.2026): erhöht den Jahresanspruch. „schwerbehinderung“ rechnet kern.urlaub.zusatzurlaub (zusatz_schwer) nach § 208 SGB IX,
# „eigen“ nimmt zusatzurlaub_tage (0 bis 30) je Jahr
ZUSATZURLAUB_ARTEN = {"keiner": "Keiner", "schwerbehinderung": "Schwerbehinderung", "eigen": "Eigener Wert"}
ZUSATZ_KEINER, ZUSATZ_SCHWER, ZUSATZ_EIGEN = "keiner", "schwerbehinderung", "eigen"
# Dienstverhältnis für die Frist des Resturlaubs (urlaub.DIENST_BEAMTE_BY): eigene Regel, unabhängig von Kind krank (Prüfbefund 23.11.2026)
DIENSTVERHAELTNISSE = {"angestellt": "Angestellte und andere", "beamte_by": "Beamte Bayern", "eigen": "Eigene Frist"}
# „Eigene Frist“ (Entscheidung 23.11.2026, andere Beamte): Frist des Resturlaubs als MM-TT im Folgejahr (nie 02-29, die Frist gibt es jedes Jahr),
# ansparen danach wie Beamte Bayern (nur mit Modul „angespart“) oder Verfall; beide Regeln wirken nur bei „eigen“ (kern.bericht._frist_regel)
RESTURLAUB_FRIST_EIGEN = {"resturlaub_frist": "03-31", "resturlaub_ansparen": False}
STANDARD = {"bundesland": "BY", "heiligabend_frei": True, "silvester_frei": True, "fasching_std": 4.0,
            "gleittage_max": 20, "familientage_max": 10, "ho_grenze": 80, "wochenstunden": 40.0, "arbeitstage": "Mo,Di,Mi,Do,Fr",
            "pausen": [[360, 30]], "ho_modus": "grenze", "module_aus": [],
            "urlaub_tage": 30, "himmelfahrt_frei": False,
            "zutun_sicherung_tage": 0, "zutun_saldo_grenze": 40, "zutun_saldo_minus": 40,
            "kind_krank_max": KIND_KRANK_GESETZ_GRUND, "kind_krank_dienst": "gesetzlich", "dienstverhaeltnis": "angestellt", "zusatzurlaub_art": ZUSATZ_KEINER, "zusatzurlaub_tage": 0,
            "feiertage_eigen": [], "feiertage_aus": [], "zeitformat": "hhmm"}  # zutun_sicherung_tage: Gelb-Grenze der Sicherungs-Erinnerung, 0 = SICHERUNG_TAGE (bleibt 0, damit gespeicherte und synchronisierte Dateien gleich bleiben; die Oberfläche bekommt die wirksame Zahl aus uebersicht); zutun_saldo_grenze, zutun_saldo_minus: 0 = kein Hinweis in dieser Richtung (seit 23.11.2026, siehe SALDO_NULL_AUS); urlaub_tage: Jahresanspruch für Jahre ohne eigenen Wert; himmelfahrt_frei: 15.8. in Bayern (überwiegend katholische Gemeinden)
# Kennung der Regeln seit „Hinweis ab Plus/Minus 0 = kein Hinweis“ (Entscheidung vom 23.11.2026). Vorher hieß Minus 0 „wie Plus“; Regeln ohne die
# Kennung (Datenbank, Sync-Datei, Sicherung, Profil einer älteren Fassung) stellt _saldo_minus_alt beim Lesen um, damit sich nichts unbemerkt ändert.
SALDO_NULL_AUS = "zutun_saldo_null_aus"
# Regeln, die es nicht mehr gibt (Vorlagen für Anmerkungen bis 26.11.2026): pruefen überspringt sie still, damit eine noch offene Seite alter Version
# oder eine alte Datei keinen Fehler auslöst; gespeichert reicht sie speichern unverändert weiter (UNBEKANNT), Geräte alter Version behalten sie so
REGELN_ENTFALLEN = ("notiz_vorlagen",)
STANDARD[SALDO_NULL_AUS] = True
# Kappung der Gleitzeit (Auftrag vom 23.11.2026): Mit Ablauf des Stichtags (MM-TT) verfällt ein Plus über der Grenze (Minuten), gerechnet in woche.
# „dienst“: an bei den Dienstverhältnissen in KAPPUNG_DIENSTE (Regel dienstverhaeltnis), sonst aus. Erste Kappung ab Werk 2027: Die Regel kam am
# 23.11.2026, der Stichtag 2026 war schon vorbei, und ein Konto darf nicht rückwirkend kleiner werden; ein früheres Jahr stellt die Person selbst ein.
KAPPUNG_MODI = {"dienst": "nach Dienstverhältnis", "an": "an", "aus": "aus"}
KAPPUNG_DIENSTE = ("beamte_by",)
KAPPUNG_EINFUEHRUNG = 2027
STANDARD.update(RESTURLAUB_FRIST_EIGEN)
STANDARD.update({"gleitzeit_kappung": "dienst", "kappung_stichtag": "09-30", "kappung_grenze_min": 3000, "kappung_ab_jahr": KAPPUNG_EINFUEHRUNG})
# Stempeluhr über Mitternacht (Entscheidung des Entwicklers vom 24.11.2026): ab Werk aus, dann endet die Uhr spätestens um 23:59 am Tag des Beginns (daten.stempel)
MITTERNACHT_REGEL = "stempel_mitternacht"
STANDARD[MITTERNACHT_REGEL] = False
# Pausenregel: [Zeit von Kommen bis Gehen länger als, Pause insgesamt] in Minuten, Stufen aufsteigend
PAUSEN_STUFEN_MAX = 4
# Kappzeit (Auftrag vom 25.11.2026, kern.regeln.tag_rechnen): Zeit außerhalb der Regelarbeitszeit [Beginn, Ende] (Minuten ab Mitternacht, Ende
# einschließlich) verfällt; Arbeitszeit netto über der Tagesgrenze ohne „Über 10 Stunden freigegeben“ auch. Beides ab Werk an.
REGELZEIT_VORGABE = [6 * 60, 20 * 60]
TAGESGRENZE_VORGABE = 10 * 60
STANDARD.update({"regelzeit_an": True, "regelzeit": REGELZEIT_VORGABE, "tagesgrenze_an": True, "tagesgrenze_min": TAGESGRENZE_VORGABE})
REGELZEIT_FEHLER = "Regelarbeitszeit: Beginn und Ende als hh:mm, Beginn vor dem Ende, Ende höchstens 24:00"
BEGINN = "0001-01-01"                                        # Gültig-ab der ersten Version (immer vorhanden)
WERKTAGE = ["Mo", "Di", "Mi", "Do", "Fr"]
WOCHENSTUNDEN_MAX = 60                                       # Obergrenze überall (Regeln, Abschnitte, Sicherung, Sync)
HO_MODI = {"grenze": "mit Grenze", "ohne": "ohne Grenze", "kein": "kein Homeoffice", "nur": "nur Homeoffice"}   # ohne/kein/nur: keine Quote-Warnungen
# Module (Wunsch vom 17.11.2026): abgeschaltete Teile zeigt die Oberfläche nirgends mehr. Gerechnet wird unverändert, vorhandene Einträge bleiben.
MODULE = {"monat": "Monat", "horest": "Spielraum (nur mit HO-Grenze)", "jahr": "Jahr", "urlaub": "Urlaub", "darstellung": "Darstellung", "hilfe": "Hilfe",
          "gleittage": "Gleittage", "familientage": "Familientage", "angespart": "Angesparter Urlaub", "freizeit": "Freizeitkonto und Freizeitausgleich",
          "krank": "Krankmeldungen", "sonderurlaub": "Sonderurlaub", "kind_krank": "Kind krank", "planung": "Urlaubsplanung",
          "stempel": "Stempeluhr", "gleitzeit": "Gleitzeit-Konto", "woche": "Woche", "nachweis": "Homeoffice-Übersicht", "monatsnachweis": "Monatsnachweis",
          "export": "Export", "ex_pdf": "Export: PDF", "ex_office": "Export: Excel und Word (Monatsnachweis)", "ex_daten": "Export: CSV",
          "ex_kalender": "Export: Kalender", "sicherung": "Sicherung", "abgleich": "Synchronisieren", "github": "Synchronisieren über GitHub", "koppeln": "Geräte koppeln", "zutun": "Zu tun"}
# Module, die es nicht mehr gibt (25.11.2026: Markdown und Text entfallen): in alten Listen (Sicherung, Synchronisierung, ältere Oberfläche) still übergehen
MODULE_ENTFALLEN = ("ex_text",)
MODULE_OHNE_SCHALTER = ("darstellung",)                      # bleibt gültig (alte Sicherungen, Sync), ist aber immer an: „Aussehen“ steht in den Einstellungen
GRENZEN = {"urlaub_tage": (0, 60), "gleittage_max": (0, 60), "familientage_max": (0, 30), "ho_grenze": (1, 100),
           "zutun_sicherung_tage": (0, 365), "zutun_saldo_grenze": (0, 999), "kind_krank_max": (0, 70), "zutun_saldo_minus": (0, 999),
           "zusatzurlaub_tage": (0, 30)}   # ganze Zahlen: kleinster und größter Wert
GRENZEN.update({"kappung_grenze_min": (0, 59_999), "kappung_ab_jahr": (1970, 2200), "tagesgrenze_min": (1, 1440)})   # Grenze höchstens 999:59 wie die Konten der Startwerte
# Sichtbare Namen der Regeln für Fehlertexte (wie auf der Seite „Einstellungen“): Die Meldung geht an die Person, der interne Schlüssel sagt ihr nichts
EINSTELLUNG_NAMEN = {"urlaub_tage": "Urlaubstage pro Jahr", "gleittage_max": "Gleittage pro Jahr", "familientage_max": "Familientage pro Jahr",
                     "ho_grenze": "HO-Grenze (% der Gesamtzeit)", "zutun_sicherung_tage": "Erinnerung an Sicherung nach … Tagen", "zutun_saldo_grenze": "Hinweis ab Plus (Stunden)",
                     "zutun_saldo_minus": "Hinweis ab Minus (Stunden)", "kind_krank_max": "Kind krank (Tage pro Jahr)", "zusatzurlaub_tage": "Zusatzurlaub (Tage pro Jahr)", "heiligabend_frei": "24.12. (Heiligabend) ist frei",
                     "silvester_frei": "31.12. (Silvester) ist frei", "himmelfahrt_frei": "15.8. (Mariä Himmelfahrt) ist Feiertag", "resturlaub_ansparen": "Rest nach der Frist ansparen", "fasching_std": "Faschingsdienstag", "wochenstunden": "Wochenstunden"}
EINSTELLUNG_NAMEN.update({"kappung_grenze_min": "Grenze (Stunden)", "kappung_ab_jahr": "Erste Kappung im Jahr", "stempel_mitternacht": "Stempeluhr über Mitternacht erlauben",
                         "regelzeit_an": "Regelarbeitszeit", "tagesgrenze_an": "Tagesgrenze", "tagesgrenze_min": "Tagesgrenze (Stunden netto)"})
GRENZEN_TEXT = {"kappung_grenze_min": "0 und 999:59", "tagesgrenze_min": "0:01 und 24:00"}             # Grenzen, die die Oberfläche anders schreibt als gespeichert (Minuten als Stunden)
SICHERUNG_TAGE = 14                                          # Erinnerung an die Sicherung (gelb) nach so vielen Tagen, wenn zutun_sicherung_tage 0 ist (alle Fassungen); 
SICHERUNG_ROT_TAGE = 30                                      # ab so vielen Tagen (mindestens, sonst das Doppelte der Gelb-Grenze) ist die Erinnerung rot
SICHERUNG_ROT_FAKTOR = 2
# Schreibweise aller Dauern in Anzeigen und Exporten (funktionen.md 0.8); gerechnet wird immer in Minuten
ZEITFORMATE = {"hhmm": "7:30", "dezimal": "7,50"}
FASCHING_MAX_STD = 12                                        # Faschingsdienstag: höchstens so viele Stunden
# Namen aller Feiertage, die feiertage.py berechnet (alle Länder, dazu der Bayern-Schalter): nur diese lassen sich abwählen (feiertage_aus).
# Als Liste hier, weil konfig feiertage nicht importieren darf; tests/test_daten_kern.py hält beide gleich.
FEIERTAG_NAMEN = ("Neujahr", "Heilige Drei Könige", "Frauentag", "Karfreitag", "Ostermontag", "Tag der Arbeit", "Christi Himmelfahrt", "Pfingstmontag",
                  "Fronleichnam", "Mariä Himmelfahrt", "Weltkindertag", "Tag der Dt. Einheit", "Reformationstag", "Allerheiligen", "Buß- und Bettag",
                  "1. Weihnachtstag", "2. Weihnachtstag")
FEIERTAGE_EIGEN_MAX = 20                                     # jährliche eigene Feiertage
FEIERTAG_NAME_MAX = 40                                       # Zeichen im Namen eines eigenen Feiertags (jährlich und einmalig)
FEIERTAG_TAG = re.compile(r"(\d\d)-(\d\d)")                  # MM-TT eines jährlichen Feiertags
SCHALTJAHR = 2024                                            # Prüfjahr für MM-TT: so ist der 29.02. gültig (gilt dann nur in Schaltjahren)
# Steuerzeichen und Nicht-Zeichen (wie regeln.STEUERZEICHEN für Notizen): hier, weil konfig nichts importiert und Namen eigener Feiertage prüft;
# dazu die Bidi-Zeichen: Sie drehen die Leserichtung um, ein Text in Export oder Nachweis sähe dann anders aus, als er ist
STEUERZEICHEN = re.compile("[\x00-\x1f\x7f\u200e\u200f\u202a-\u202e\u2066-\u2069\ud800-\udfff\ufffe\uffff]")
# Unsichtbare Formatzeichen (weiches Trennzeichen, Nullbreite-Leerzeichen, Wortverbinder, BOM) stecken oft in Text, der von einer Webseite kopiert wurde.
# Sie werden still entfernt statt abgelehnt, damit eingefügter Text einfach funktioniert; die PDF-Schrift zeichnete U+00AD sonst als sichtbaren Bindestrich
UNSICHTBAR = re.compile("[\u00ad\u200b\u2060\ufeff]")
STEUERZEICHEN_XML = re.compile(f"(?![\t\n\r]){STEUERZEICHEN.pattern}")   # f\u00fcr Exporte und Dokumente: wie oben, nur Tab und Zeilenumbruch sind in XML erlaubt
# Stunden je Tag eines Abschnitts (Spalte abschnitt.tagesminuten, Weg 3): „Mo:480,Di:360“, Minuten je Werktag
TAGESMINUTEN = re.compile(r"(Mo|Di|Mi|Do|Fr):(0|[1-9]\d{0,2})")
TAGESMINUTEN_MAX = 600                                       # höchstens 10 Stunden an einem Tag
TAGESMINUTEN_TEXT_MAX = 60                                   # längster Text („Mo:600,Di:600,Mi:600,Do:600,Fr:600“ braucht 34 Zeichen)
# Startwerte „Erfassung gültig ab“ (R6): Stand des Jahres bis zum Vortag von „ab“, ein JSON-Text im Meta-Schlüssel STARTWERTE (wandert im Sync mit)
STARTWERTE = "startwerte"
STARTWERTE_ZUKUNFT = "Erfassung gültig ab: nicht in der Zukunft"   # Fehlertext für db und bericht
STARTWERTE_TEXT_MAX = 300                                    # längster Text (neun Felder); längere Texte werden gar nicht erst gelesen
STARTWERTE_JAHRE = (1970, 2200)                              # wie regeln.JAHR_MIN/JAHR_MAX (konfig importiert regeln nicht)
STARTWERTE_KONTO_MAX = 59_999                                # Betrag von Gleitzeit- und Freizeitkonto: höchstens 999:59
STARTWERTE_NAMEN = {"ho_min": "HO-Zeit", "dst_min": "Büro-Zeit", "urlaub": "Urlaub", "gleittage": "Gleittage", "krank": "Kranktage",
                    "kind_krank": "Kind krank", "gleitzeit_min": "Gleitzeit-Saldo", "freizeit_min": "Freizeitkonto"}
STARTWERTE_TAGE = ("urlaub", "gleittage", "krank", "kind_krank")      # ganze Tage, zusammen höchstens die Werktage vor „ab“
STARTWERTE_ZEITEN = ("ho_min", "dst_min")                    # Minuten, zusammen höchstens die Kalendertage vor „ab“ × 24 Stunden
STARTWERTE_KONTEN = ("gleitzeit_min", "freizeit_min")        # Stand am Ende des Vortags von „ab“, ± STARTWERTE_KONTO_MAX
TAG_MINUTEN = 24 * 60
_REVS = itertools.count(1)                                   # über alle Regelstände eindeutig: Zwischenspeicher mit rev im Schlüssel (feiertage) mischen nie zwei Stände


class _Stand:
    """Ein Regelstand: Versionen, heutige Werte und Zwischenspeicher. Der Prozess hat einen; „App prüfen“ rechnet mit einem eigenen (eigener_stand)."""

    def __init__(self):
        """Stand mit den eingebauten Regeln (STANDARD)."""
        self.versionen = [{"ab": BEGINN, "werte": dict(STANDARD)}]   # nach "ab" sortiert
        self.cfg = dict(STANDARD)                                     # Werte, die heute gelten (für die Oberfläche)
        self.unbekannt = {}                                           # je Gültig-ab: gespeicherte Werte, die diese Version nicht kennt; speichern reicht sie unverändert weiter
        self.rev = next(_REVS)                                        # zählt Änderungen (Cache-Schlüssel)
        self.gemerkt = {}                                             # Regeln je Tag; bei jeder Änderung der Versionen durch ein neues, leeres Verzeichnis ersetzt


class _Eigener(threading.local):
    """Der eigene Regelstand dieses Threads (None: es gelten die Regeln des Prozesses). Je Thread statt globalem Tausch:
    Ein anderer Thread (jede Anfrage) sieht ihn nie."""
    stand = None                                             # Vorgabe als Klassenwert: das Lesen ohne eigenen Stand bleibt schnell (heißer Pfad fuer, ist_frei)


_PROZESS = _Stand()
_EIGENER = _Eigener()
_STAND_NAMEN = {"VERSIONEN": "versionen", "CFG": "cfg", "UNBEKANNT": "unbekannt", "rev": "rev"}


def _stand() -> _Stand:
    """Der Regelstand, der hier gilt: der eigene von eigener_stand, sonst der des Prozesses."""
    return _EIGENER.stand or _PROZESS


def regelstand_nr() -> int:
    """Zähler des geltenden Regelstands (wie konfig.rev), für Zwischenspeicher-Schlüssel auf heißen Pfaden: ändert sich mit jeder Regeländerung,
    über alle Stände eindeutig. Schneller als konfig.rev, das über das Modul-__getattr__ geht."""
    return (_EIGENER.stand or _PROZESS).rev


def __getattr__(name):
    """konfig.VERSIONEN, konfig.CFG, konfig.UNBEKANNT und konfig.rev lesen den geltenden Regelstand (_stand). Fehler: AttributeError bei anderen Namen."""
    if name in _STAND_NAMEN:
        return getattr(_stand(), _STAND_NAMEN[name])
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


@contextlib.contextmanager
def eigener_stand():
    """Für „App prüfen“: Im Block gelten in diesem Thread eigene Regeln mit den Voreinstellungen; der Prozess und andere Threads behalten ihre."""
    vorher, _EIGENER.stand = _EIGENER.stand, _Stand()
    try:
        yield
    finally:
        _EIGENER.stand = vorher


URLAUB_SEITE = "Abwesenheit → Urlaub"                         # Weg zur Urlaub-Seite in Meldungen (aufbau.md 7), gleich mit und ohne Modul „Gleittage“


def urlaub_seite() -> str:
    """Weg zur Urlaub-Seite für Hinweise und Fehlertexte (Bereich Abwesenheit, Reiter Urlaub; aufbau.md 7)."""
    return URLAUB_SEITE

class Meldung(ValueError):
    """Bewusst geworfener Eingabefehler, dessen Text für die Person lesbar ist und so an den Browser darf (keine Pfade, keine Technik).
    Grundlage aller eigenen Fehlerklassen. Jeder andere ValueError gilt als intern: Die Routen geben dann nur UNGUELTIGE_EINGABE weiter."""


UNGUELTIGE_EINGABE = "Ungültige Eingabe"                    # für jeden ValueError, der keine Meldung ist: sein Text kann Interna enthalten


class KonfigFehler(Meldung):
    """Ungültige Einstellung; die Meldung ist für die Person lesbar."""


ARBEITSTAGE_DOPPELT = "Arbeitstage: jeder Tag höchstens einmal"


def arbeitstage_lesen(text, doppelte_entfernen: bool = False) -> list:
    """Gemeinsame Prüfung der Arbeitstage für Einstellungen, Abschnitte und Synchronisierung: „Fr, Mo“ -> ["Fr", "Mo"] (Reihenfolge bleibt,
    Leerstellen und leere Teile fallen weg). Ob die Kürzel gültig sind, prüft jede Stelle selbst (eigene Meldung).
    Ein doppelter Tag ergibt KonfigFehler(ARBEITSTAGE_DOPPELT), mit doppelte_entfernen=True wird er still entfernt (Synchronisierung alter Bestände)."""
    tage = [t.strip() for t in str(text).split(",") if t.strip()]
    if len(set(tage)) != len(tage):
        if not doppelte_entfernen:
            raise KonfigFehler(ARBEITSTAGE_DOPPELT)
        tage = list(dict.fromkeys(tage))
    return tage


def _iso(d) -> str:
    """Datum als Text JJJJ-MM-TT (ein Text bleibt, wie er ist)."""
    return d if isinstance(d, str) else d.isoformat()


def fuer(d) -> dict:
    """Die Regeln, die am Tag d gelten."""
    stand = _EIGENER.stand or _PROZESS                       # wie _stand(), ohne Funktionsaufruf: heißester Pfad des Rechenkerns
    merker = stand.gemerkt                                   # das Verzeichnis dieses Stands: ein Ergebnis von vor einer Änderung landet nie im neuen
    w = merker.get(d)
    if w is None:
        s = _iso(d)
        w = stand.versionen[0]["werte"]
        for v in stand.versionen:
            if v["ab"] <= s:
                w = v["werte"]
            else:
                break
        if len(merker) > 20000:
            merker.clear()
        merker[d] = w
    return w


def fuer_jahr(jahr: int) -> dict:
    """Regeln für Jahresgrenzen (Gleit-/Familientage): im laufenden Jahr die heutigen, in vergangenen die vom Jahresende, in künftigen die vom Jahresanfang."""
    heute = date.today()
    ref = date(jahr, 12, 31) if jahr < heute.year else (date(jahr, 1, 1) if jahr > heute.year else heute)
    return fuer(ref)


def _neu_berechnen():
    """Nach jeder Änderung der Versionen: Zwischenspeicher leeren, heutige Werte neu setzen, Zähler `rev` erhöhen."""
    stand = _stand()
    stand.gemerkt = {}
    stand.cfg.clear()
    stand.cfg.update(fuer(date.today()))
    stand.rev = next(_REVS)


def pruefen(d: dict, gespeichert: bool = False) -> dict:
    """Prüft die übergebenen Felder und liefert die bereinigten Werte (nur bekannte Felder).
    gespeichert: Werte aus der Datenbank oder von der Synchronisierung. Eine Einstellung, die erst eine neuere Version kennt, wird dann übersprungen,
    statt alle Regeln zu verwerfen (sonst fielen auf älteren Geräten Wochenstunden, Bundesland usw. still auf die Voreinstellung zurück)."""
    r = {}
    for k, v in d.items():
        if k in REGELN_ENTFALLEN:
            continue
        if k not in STANDARD:
            if gespeichert:
                continue
            raise KonfigFehler(f"Unbekannte Einstellung: {k}")
        if k == "bundesland":
            if not isinstance(v, str) or v not in BUNDESLAENDER:
                raise KonfigFehler("Bundesland unbekannt")
        elif k == "module_aus":
            v = [m for m in v if m not in MODULE_ENTFALLEN] if isinstance(v, list) else v
            if not isinstance(v, list) or any(not isinstance(m, str) or m not in MODULE for m in v):     # eine Liste als Eintrag: Fehlertext statt TypeError
                if not gespeichert:
                    raise KonfigFehler("Module: unbekannter Name")
                v = [m for m in v if isinstance(m, str) and m in MODULE] if isinstance(v, list) else []   # ein Modul einer neueren Version: überspringen
            v = [m for m in MODULE if m in v]
        elif k == "ho_modus":
            if not isinstance(v, str) or v not in HO_MODI:      # eine Liste aus einer Datei: Fehlertext statt TypeError
                raise KonfigFehler("Homeoffice: mit Grenze, ohne Grenze, kein Homeoffice oder nur Homeoffice")
        elif k == SALDO_NULL_AUS:
            if v is not True:                                # nur die Kennung selbst; aus einer Datei sonst überspringen, dann gilt die Umstellung
                if gespeichert:
                    continue
                raise KonfigFehler("Hinweis-Grenzen: Kennung ungültig")
        elif k in ("heiligabend_frei", "silvester_frei", "himmelfahrt_frei", "resturlaub_ansparen", "stempel_mitternacht", "regelzeit_an", "tagesgrenze_an"):
            if not isinstance(v, bool):
                if gespeichert and k in ("resturlaub_ansparen", "stempel_mitternacht", "regelzeit_an", "tagesgrenze_an"):
                    continue
                raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: ja oder nein")
        elif k == "resturlaub_frist":
            if not isinstance(v, str) or not _monatstag_gueltig(v) or v == "02-29":
                if gespeichert:
                    continue
                raise KonfigFehler("Frist für den Resturlaub: Tag und Monat (TT.MM.), nicht der 29.02.")
        elif k == "arbeitstage":
            tage = arbeitstage_lesen(v)
            if not tage or any(t not in WERKTAGE for t in tage):
                raise KonfigFehler("Arbeitstage: Montag bis Freitag, mindestens einer")
            v = ",".join(t for t in WERKTAGE if t in tage)
        elif k == "zeitformat":
            if not isinstance(v, str) or v not in ZEITFORMATE:
                if gespeichert:                              # ein Format einer neueren Version: überspringen, es gilt die Vorgabe
                    continue
                raise KonfigFehler("Zeitformat: Stunden und Minuten oder Dezimalzahl")
        elif k == "kind_krank_dienst":
            if not isinstance(v, str) or v not in KIND_KRANK_DIENSTE:
                if gespeichert:                              # ein Dienstverhältnis einer neueren Version: überspringen, es gilt die Vorgabe
                    continue
                raise KonfigFehler("Kind krank: Dienstverhältnis " + ", ".join(KIND_KRANK_DIENSTE.values()))
        elif k == "zusatzurlaub_art":
            if not isinstance(v, str) or v not in ZUSATZURLAUB_ARTEN:
                if gespeichert:                              # eine Art einer neueren Version: überspringen, es gilt die Vorgabe
                    continue
                raise KonfigFehler("Zusatzurlaub: " + ", ".join(ZUSATZURLAUB_ARTEN.values()))
        elif k == "dienstverhaeltnis":
            if not isinstance(v, str) or v not in DIENSTVERHAELTNISSE:
                if gespeichert:                              # ein Dienstverhältnis einer neueren Version: überspringen, es gilt die Vorgabe
                    continue
                raise KonfigFehler("Dienstverhältnis unbekannt")
        elif k == "gleitzeit_kappung":
            if isinstance(v, bool):                          # Schalter an/aus (true/false) gilt wie „an“/„aus“; gespeichert wird immer der Text
                v = "an" if v else "aus"
            if not isinstance(v, str) or v not in KAPPUNG_MODI:
                if gespeichert:                              # ein Wert einer neueren Version: überspringen, es gilt die Vorgabe
                    continue
                raise KonfigFehler("Kappung der Gleitzeit: " + ", ".join(KAPPUNG_MODI.values()))
        elif k == "kappung_stichtag":
            if not isinstance(v, str) or not _monatstag_gueltig(v):
                if gespeichert:
                    continue
                raise KonfigFehler("Kappung der Gleitzeit: Stichtag als Tag und Monat")
        elif k == "pausen":
            v = _pausen(v)
        elif k == "regelzeit":
            try:
                v = _regelzeit(v)
            except KonfigFehler:
                if gespeichert:
                    continue
                raise
        elif k == "feiertage_eigen":
            v = _feiertage_eigen(v)
        elif k == "feiertage_aus":
            v = _feiertage_aus(v, gespeichert)
        elif k in ("fasching_std", "wochenstunden"):
            if k == "fasching_std" and v in (None, "", 0):
                v = None
            else:
                try:
                    v = round(float(str(v).replace(",", ".")), 2)
                except ValueError:
                    raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: Zahl")
                if k == "fasching_std" and not 0 < v <= FASCHING_MAX_STD:
                    raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: zwischen 0 und {FASCHING_MAX_STD} Stunden")
                if k == "wochenstunden" and not 1 <= v <= WOCHENSTUNDEN_MAX:
                    raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: zwischen 1 und {WOCHENSTUNDEN_MAX}")
        else:
            try:
                v = int(v)
            except (TypeError, ValueError, OverflowError):     # OverflowError: unendlich (1e400 aus einer Datei)
                raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: ganze Zahl")
            von, bis = GRENZEN[k]
            if not von <= v <= bis:
                raise KonfigFehler(f"{EINSTELLUNG_NAMEN[k]}: zwischen {GRENZEN_TEXT.get(k, f'{von} und {bis}')}")
        r[k] = v
    return r


def kind_krank_gesetz(jahr: int) -> int:
    """Tage „Kind krank“ je Kind und Elternteil, die § 45 SGB V für das Jahr vorsieht (gesetzlich Versicherte)."""
    return kind_krank_vorgabe(jahr, "gesetzlich")


def kind_krank_vorgabe(jahr: int, dienst: str) -> int:
    """Vorgabe „Kind krank“ (Tage im Jahr) für ein Dienstverhältnis aus KIND_KRANK_VORGABE: der Wert des Jahres, sonst der Wert außerhalb der Tabelle.
    KeyError bei einem Dienst ohne Tabelle (auch „eigen“)."""
    jahre, sonst = KIND_KRANK_VORGABE[dienst]
    return jahre.get(jahr, sonst)


def kind_krank_vorgaben(jahr: int) -> dict:
    """Tage „Kind krank“ im Jahr je Dienstverhältnis mit Vorgabe (ohne „eigen“), z. B. {"gesetzlich": 15, "beamte_by": 12}: Die Oberfläche zeigt
    damit beim Wechsel der Vorgabe die Zahl, bevor gespeichert ist."""
    return {dienst: kind_krank_vorgabe(jahr, dienst) for dienst in KIND_KRANK_VORGABE}


def kind_krank_grenze(werte: dict, jahr: int) -> int:
    """Jahreslimit „Kind krank“ (R5, N5). Eingaben: Regeln, die für das Jahr gelten, und das Jahr. Rückgabe: bei kind_krank_dienst „eigen“ die Regel
    kind_krank_max, sonst die Vorgabe nach Gesetz und Jahr (kind_krank_vorgabe)."""
    dienst = werte.get("kind_krank_dienst", KIND_KRANK_EIGEN)
    return werte["kind_krank_max"] if dienst == KIND_KRANK_EIGEN else kind_krank_vorgabe(jahr, dienst)


def kappung_an(werte: dict) -> bool:
    """Kappung der Gleitzeit an? Eingabe: Regeln eines Tages. Rückgabe: „an“ True, „aus“ False, „dienst“ True genau bei einem Dienstverhältnis
    aus KAPPUNG_DIENSTE (Regel dienstverhaeltnis, wie die Frist des Resturlaubs)."""
    modus = werte.get("gleitzeit_kappung", "aus")
    return modus == "an" or (modus == "dienst" and werte.get("dienstverhaeltnis") in KAPPUNG_DIENSTE)


def _eigener_kind_krank_wert(neu: dict, bisher: dict) -> dict:
    """Wer nur die Zahl kind_krank_max ändert, wählt den eigenen Wert: kind_krank_dienst wird dann „eigen“. Ein unveränderter Wert (die Seite
    „Einstellungen“ schickt alle Felder) bleibt. Wer ein Dienstverhältnis wählt, setzt kind_krank_max auf KIND_KRANK_GESETZ_GRUND zurück: So heißt eine
    andere Zahl beim Laden immer „eigen“, auch wenn ein Gerät vor N5 (ohne kind_krank_dienst) nur die Zahl ändert (_aufgefuellt)."""
    if neu.get("kind_krank_dienst", KIND_KRANK_EIGEN) != KIND_KRANK_EIGEN:
        return {**neu, "kind_krank_max": KIND_KRANK_GESETZ_GRUND}
    if "kind_krank_max" in neu and "kind_krank_dienst" not in neu and neu["kind_krank_max"] != bisher.get("kind_krank_max"):
        return {**neu, "kind_krank_dienst": KIND_KRANK_EIGEN}
    return neu


def _aufgefuellt(werte: dict) -> dict:
    """Gespeicherte Werte mit den eingebauten (STANDARD) auffüllen. Ein Limit gleich der alten Vorgabe folgt dem gewählten Dienstverhältnis (ohne Wahl,
    Regeln vor N5: dem Gesetz), ein anderes hat die Person selbst eingetragen und bleibt ihr eigener Wert, auch wenn ein Gerät vor N5 die Wahl
    „gesetzlich“ unverändert weitergereicht hat (sonst änderte es sich still). Die Wahl eines Dienstes setzt die Zahl zurück (_eigener_kind_krank_wert).
    Regeln ohne „dienstverhaeltnis“ (älter als die eigene Regel) übernehmen „Beamte Bayern“ aus der Wahl bei Kind krank, sonst gilt „angestellt“."""
    r = {**STANDARD, **werte}
    if "dienstverhaeltnis" not in werte and werte.get("kind_krank_dienst") == "beamte_by":
        r["dienstverhaeltnis"] = "beamte_by"
    if r["kind_krank_max"] != KIND_KRANK_GESETZ_GRUND:
        r["kind_krank_dienst"] = KIND_KRANK_EIGEN
    return _saldo_minus_alt(werte, r)


def _saldo_minus_alt(werte: dict, r: dict) -> dict:
    """Umstellung „0 = kein Hinweis“ (23.11.2026): Gelesene Werte ohne SALDO_NULL_AUS stammen von einer älteren Fassung, dort hieß Minus 0 oder
    fehlend „wie Plus“. Eingabe: die gelesenen Werte und dieselben aufgefüllt (r, mit der Kennung aus STANDARD). Rückgabe: r, bei alten Werten mit
    Minus gleich Plus. Nicht in pruefen: Sonst sähe _unbekannte die gespeicherte 0 als fremden Wert und speichern schriebe sie zurück."""
    if SALDO_NULL_AUS not in werte and not werte.get("zutun_saldo_minus"):
        r["zutun_saldo_minus"] = r["zutun_saldo_grenze"]
    return r


def sicherung_tage(werte: dict) -> int:
    """Gelb-Grenze: nach so vielen Tagen ohne Sicherung erinnert die App (Karte „Zu tun“). Eingabe: Regeln eines Tages (z. B. CFG).
    Rückgabe: die Regel zutun_sicherung_tage, bei 0 SICHERUNG_TAGE (gleich auf allen Fassungen)."""
    return werte["zutun_sicherung_tage"] or SICHERUNG_TAGE


def sicherung_rot_tage(werte: dict) -> int:
    """Rot-Grenze der Sicherungs-Erinnerung: das Größere aus SICHERUNG_ROT_TAGE und dem Doppelten der Gelb-Grenze (14 gibt 30, 20 gibt 40)."""
    return max(SICHERUNG_ROT_TAGE, SICHERUNG_ROT_FAKTOR * sicherung_tage(werte))


def tagesminuten_lesen(text) -> dict:
    """Stunden je Tag eines Abschnitts lesen. Eingabe: Text wie „Mo:480,Di:360,Mi:240“ (Minuten je Werktag, jeder Tag höchstens einmal).
    Rückgabe: {"Mo": 480, …} in der Reihenfolge des Texts; "" ergibt {}. 0 Minuten sind erlaubt (aus Synchronisierung oder Sicherung: kein Arbeitstag).
    Fehler: KonfigFehler bei anderem Typ, anderem Format, Sa/So, doppeltem Tag oder mehr als TAGESMINUTEN_MAX Minuten."""
    if not isinstance(text, str):
        raise KonfigFehler("Stunden je Tag: Text erwartet")
    r = {}
    for teil in text.split(",") if text else ():
        m = TAGESMINUTEN.fullmatch(teil)
        if not m or m[1] in r or int(m[2]) > TAGESMINUTEN_MAX:
            raise KonfigFehler(f"Stunden je Tag: Format Mo:480,Di:360 (Minuten je Tag, höchstens {TAGESMINUTEN_MAX})")
        r[m[1]] = int(m[2])
    return r


def tagesminuten_pruefen(text, arbeitstage: str) -> dict:
    """Stunden je Tag eines Abschnitts zusammen mit seinen Arbeitstagen prüfen: eine Regel für Speichern, Sicherung und Synchronisierung, damit kein Gerät
    einen Abschnitt hält, den die anderen in der Synchronisierung ablehnen. Eingaben: Text wie bei tagesminuten_lesen, arbeitstage wie „Mo,Di,Mi“.
    Rückgabe: wie tagesminuten_lesen ("" ergibt {}: Weg 1 oder 2). Fehler: KonfigFehler bei Text über TAGESMINUTEN_TEXT_MAX Zeichen, falschem Format
    oder anderen Tagen als den Arbeitstagen (Weg 3 speichert arbeitstage = Tage mit Minuten). Die Woche bleibt so bei höchstens 5 × 600 Minuten."""
    if isinstance(text, str) and len(text) > TAGESMINUTEN_TEXT_MAX:
        raise KonfigFehler(f"Stunden je Tag: höchstens {TAGESMINUTEN_TEXT_MAX} Zeichen")
    minuten = tagesminuten_lesen(text)
    if minuten and set(minuten) != {t for t in arbeitstage.split(",") if t}:
        raise KonfigFehler("Stunden je Tag: genau für die Arbeitstage des Abschnitts")
    return minuten


@dataclass(frozen=True)
class Startwerte:
    """Startwerte „Erfassung gültig ab“ (R6): ab (erster gezählter Tag) und der Stand des Jahres bis ab − 1 (Minuten bzw. ganze Tage)."""
    ab: date
    ho_min: int
    dst_min: int
    urlaub: int
    gleittage: int
    krank: int
    kind_krank: int
    gleitzeit_min: int
    freizeit_min: int

    def gilt_im_jahr(self, jahr: int) -> bool:
        """Die Werte des Stands gelten nur im Kalenderjahr von „ab“ (der Gleitzeit-Saldo läuft als Konto weiter, das rechnet woche)."""
        return self.ab.year == jahr

    def werte(self) -> dict:
        """Die neun Felder als Wörterbuch, ab als Text JJJJ-MM-TT (Form von startwerte_pruefen)."""
        return {**asdict(self), "ab": self.ab.isoformat()}

    def text(self) -> str:
        """Der gespeicherte JSON-Text: Schlüssel sortiert, ohne Leerzeichen (gleiche Werte ergeben auf jedem Gerät denselben Text)."""
        return json.dumps(self.werte(), sort_keys=True, separators=(",", ":"))


def startwerte_pruefen(werte) -> Startwerte:
    """Prüft Startwerte ohne Bezug zu heute und zu den Regeln (so auch in der Synchronisierung und beim Wiederherstellen).
    Eingabe: Wörterbuch mit genau den neun Feldern; ab als Text JJJJ-MM-TT von 1970 bis 2200, sonst ganze Zahlen ab 0, Konten ± 999:59.
    Aus „ab“ folgen die Grenzen: HO + Büro höchstens Kalendertage vor ab × 24 Stunden, die Tage zusammen höchstens die Kalendertage vor ab
    (die genauere Grenze mit Werktagen prüft db.Db.startwerte_setzen), am 01.01. alles 0 außer den Konten. Rückgabe: Startwerte. Fehler: KonfigFehler."""
    felder = ("ab",) + tuple(STARTWERTE_NAMEN)
    if not isinstance(werte, dict) or set(werte) != set(felder):
        raise KonfigFehler("Startwerte: genau die Felder " + ", ".join(felder))
    ab = _startwerte_datum(werte["ab"])
    for feld, name in STARTWERTE_NAMEN.items():
        x = werte[feld]
        if isinstance(x, bool) or not isinstance(x, int):
            raise KonfigFehler(f"{name}: ganze Zahl")
        grenze = STARTWERTE_KONTO_MAX if feld in STARTWERTE_KONTEN else None
        if (grenze is None and x < 0) or (grenze is not None and abs(x) > grenze):
            raise KonfigFehler(f"{name}: höchstens ±999:59" if grenze else f"{name}: nicht negativ")
    tage_davor = (ab - date(ab.year, 1, 1)).days
    if tage_davor == 0 and any(werte[f] for f in STARTWERTE_ZEITEN + STARTWERTE_TAGE):
        raise KonfigFehler("Erfassung gültig ab 01.01.: Es gibt keinen Tag davor, nur der Gleitzeit-Saldo ist erlaubt")
    if sum(werte[f] for f in STARTWERTE_ZEITEN) > tage_davor * TAG_MINUTEN:
        raise KonfigFehler(f"HO und Büro zusammen höchstens {tage_davor * TAG_MINUTEN // 60} Stunden ({tage_davor} Tage vor dem {ab:%d.%m.%Y} × {TAG_MINUTEN // 60})")
    if sum(werte[f] for f in STARTWERTE_TAGE) > tage_davor:
        raise KonfigFehler(f"Urlaub, Gleittage, Kranktage und Kind krank zusammen höchstens {tage_davor} Tage")
    return Startwerte(ab, *(werte[f] for f in STARTWERTE_NAMEN))


def _startwerte_datum(text) -> date:
    """„ab“ der Startwerte: Text JJJJ-MM-TT von 1970 bis 2200, sonst KonfigFehler."""
    try:
        d = date.fromisoformat(text)
        if d.isoformat() != text or not STARTWERTE_JAHRE[0] <= d.year <= STARTWERTE_JAHRE[1]:
            raise ValueError
    except (TypeError, ValueError):
        raise KonfigFehler("Erfassung gültig ab: Datum JJJJ-MM-TT von 1970 bis 2200")
    return d


def startwerte_lesen(text) -> Startwerte:
    """Den gespeicherten Text der Startwerte lesen (Datenbank, Synchronisierung, Sicherung). Eingabe: JSON-Text bis STARTWERTE_TEXT_MAX Zeichen.
    Rückgabe: Startwerte. Fehler: KonfigFehler bei anderem Typ, zu langem Text, unlesbarem JSON oder Werten außerhalb der Grenzen (startwerte_pruefen)."""
    if not isinstance(text, str) or len(text) > STARTWERTE_TEXT_MAX:
        raise KonfigFehler(f"Startwerte: Text bis {STARTWERTE_TEXT_MAX} Zeichen")
    try:
        werte = json.loads(text)
    except (ValueError, RecursionError):
        raise KonfigFehler("Startwerte: nicht lesbar")
    return startwerte_pruefen(werte)


def _feiertage_eigen(v) -> list:
    """Jährliche eigene Feiertage [[MM-TT, Name], …] prüfen: höchstens FEIERTAGE_EIGEN_MAX, Tag im Schaltjahr gültig, kein Tag doppelt,
    Name 1 bis FEIERTAG_NAME_MAX Zeichen ohne Steuerzeichen (Leerzeichen am Rand entfernt). Rückgabe nach Tag sortiert, sonst KonfigFehler."""
    if not isinstance(v, list) or len(v) > FEIERTAGE_EIGEN_MAX:
        raise KonfigFehler(f"Eigene Feiertage: Liste mit höchstens {FEIERTAGE_EIGEN_MAX} Tagen")
    r = {}
    for e in v:
        if not isinstance(e, (list, tuple)) or len(e) != 2 or not isinstance(e[0], str) or not isinstance(e[1], str):
            raise KonfigFehler("Eigene Feiertage: je Tag (MM-TT) und Name")
        tag, name = e[0], e[1].strip()
        if not _monatstag_gueltig(tag):
            raise KonfigFehler(f"Eigene Feiertage: {tag} ist kein Tag (MM-TT)")
        if not 0 < len(name) <= FEIERTAG_NAME_MAX or STEUERZEICHEN.search(name):
            raise KonfigFehler(f"Eigene Feiertage: Name mit 1 bis {FEIERTAG_NAME_MAX} Zeichen, ohne Steuerzeichen")
        if tag in r:
            raise KonfigFehler(f"Eigene Feiertage: {tag} steht doppelt")
        r[tag] = name
    return [[t, r[t]] for t in sorted(r)]


def _monatstag_gueltig(tag: str) -> bool:
    """True, wenn „MM-TT“ ein Tag im Schaltjahr ist (der 29.02. also auch)."""
    m = FEIERTAG_TAG.fullmatch(tag)
    if not m:
        return False
    try:
        date(SCHALTJAHR, int(m[1]), int(m[2]))
    except ValueError:
        return False
    return True


def _feiertage_aus(v, gespeichert: bool) -> list:
    """Abgewählte berechnete Feiertage (Namen aus FEIERTAG_NAMEN, ohne Doppel) prüfen, Rückgabe in der Reihenfolge von FEIERTAG_NAMEN.
    gespeichert: unbekannte Namen (neuere Version) überspringen statt KonfigFehler."""
    if not isinstance(v, list) or any(not isinstance(n, str) for n in v):
        raise KonfigFehler("Abgewählte Feiertage: Liste von Namen")
    if len(set(v)) != len(v) or (not gespeichert and any(n not in FEIERTAG_NAMEN for n in v)):
        raise KonfigFehler("Abgewählte Feiertage: unbekannter oder doppelter Name")
    return [n for n in FEIERTAG_NAMEN if n in v]


def _minuten(x, was) -> int:
    """Pausenwert als ganze Minuten: eine Zahl bleibt, „hh:mm“ wird umgerechnet, sonst KonfigFehler (was = Name des Feldes für die Meldung)."""
    if isinstance(x, int) and not isinstance(x, bool):
        return x
    m = re.fullmatch(r"\s*(\d{1,2}):([0-5]\d)\s*", str(x or ""))
    if not m:
        raise KonfigFehler(f"Pausenregel: {was} als hh:mm")
    return int(m[1]) * 60 + int(m[2])


def _pausen(v) -> list:
    """Stufen [[ab, pause], …] (Minuten oder „hh:mm“): ab 1 Minute bis 24 Stunden, Pause 0 bis 2 Stunden, beides aufsteigend. Leere Liste: keine Pause."""
    if not isinstance(v, list) or len(v) > PAUSEN_STUFEN_MAX:
        raise KonfigFehler(f"Pausenregel: höchstens {PAUSEN_STUFEN_MAX} Stufen")
    r = []
    for st in v:
        if not isinstance(st, (list, tuple)) or len(st) != 2:
            raise KonfigFehler("Pausenregel: je Stufe Arbeitszeit und Pause")
        ab, p = _minuten(st[0], "Arbeitszeit"), _minuten(st[1], "Pause")
        if not (0 < ab <= 1440 and 0 < p <= 120):
            raise KonfigFehler("Pausenregel: Arbeitszeit bis 24:00, Pause 00:01 bis 02:00")
        if r and (ab <= r[-1][0] or p <= r[-1][1]):
            raise KonfigFehler("Pausenregel: jede Stufe mit längerer Arbeitszeit und längerer Pause als die vorige")
        r.append([ab, p])
    return r


def _regelzeit(v) -> list:
    """Regelarbeitszeit [Beginn, Ende] (Minuten oder „hh:mm“): 0 <= Beginn < Ende <= 24:00. Fehler: KonfigFehler(REGELZEIT_FEHLER)."""
    try:
        beginn, ende = (_minuten(x, "Uhrzeit") for x in v) if isinstance(v, list) and len(v) == 2 else (None, None)
    except KonfigFehler:
        beginn = ende = None
    if beginn is None or not 0 <= beginn < ende <= 1440:
        raise KonfigFehler(REGELZEIT_FEHLER)
    return [beginn, ende]


def _datum(s) -> str:
    """Prüft ein Datum und gibt es als JJJJ-MM-TT zurück, sonst KonfigFehler."""
    try:
        return date.fromisoformat(str(s)).isoformat()
    except ValueError:
        raise KonfigFehler("Datum im Format JJJJ-MM-TT")


def aendern(werte: dict, modus: str = "ab_heute", ab=None) -> None:
    """modus: ab_heute (Standard, nur künftig) | ab_datum (mit ab) | ab_datum_folgend (mit ab; die Werte gelten zusätzlich in jeder späteren Version,
    z. B. eigene Feiertage „ab 2027“, die eine spätere Version für Wochenstunden sonst wieder aufhöbe) | rueckwirkend (ersetzt alle Versionen) | ueberall."""
    neu, stand = pruefen(werte), _stand()
    neu = _eigener_kind_krank_wert(neu, fuer(_datum(ab) if modus in ("ab_datum", "ab_datum_folgend") else date.today()))
    if modus == "ueberall":                                  # Einstellung ohne Zeitbezug (Module): in jede Version, die Gültigkeiten bleiben
        for v in stand.versionen:
            stand.unbekannt[v["ab"]] = _ohne(stand.unbekannt.get(v["ab"], {}), neu, v["werte"])
            v["werte"].update(neu)
    elif modus == "rueckwirkend":
        u = _ohne(_unbekannt_am(date.today().isoformat()), neu, fuer(date.today()))
        stand.versionen[:] = [{"ab": BEGINN, "werte": {**fuer(date.today()), **neu}}]
        stand.unbekannt.clear()
        stand.unbekannt[BEGINN] = u
    elif modus in ("ab_heute", "ab_datum", "ab_datum_folgend"):
        tag = date.today().isoformat() if modus == "ab_heute" else _datum(ab)
        if tag <= BEGINN:
            raise KonfigFehler("Datum zu früh")
        basis = {**fuer(tag), **neu}
        stand.unbekannt[tag] = _ohne(_unbekannt_am(tag), neu, fuer(tag))
        stand.versionen[:] = [v for v in stand.versionen if v["ab"] != tag] + [{"ab": tag, "werte": basis}]
        stand.versionen.sort(key=lambda v: v["ab"])
        if modus == "ab_datum_folgend":
            for v in stand.versionen:
                if v["ab"] > tag:
                    stand.unbekannt[v["ab"]] = _ohne(stand.unbekannt.get(v["ab"], {}), neu, v["werte"])   # wie bei „ueberall“: sonst überdeckt ein weitergereichter Wert die Änderung beim Speichern
                    v["werte"].update(neu)
    else:
        raise KonfigFehler("Modus: ab_heute, ab_datum, ab_datum_folgend, rueckwirkend oder ueberall")
    _neu_berechnen()


def _unbekannt_am(tag: str) -> dict:
    """Die weitergereichten Werte (UNBEKANNT) der Version, die am Tag gilt."""
    stand = _stand()
    return stand.unbekannt.get(max(v["ab"] for v in stand.versionen if v["ab"] <= tag), {})


def _ohne(u: dict, neu: dict, bisher: dict) -> dict:
    """Weitergereichte Werte ohne die Felder, die die Person gerade selbst ändert: Ihr Wert weicht vom bisher gezeigten ab, dann gilt er.
    Die Seite „Einstellungen“ schickt alle Felder mit, auch die unveränderten."""
    return {k: w for k, w in u.items() if k not in neu or neu[k] == bisher.get(k)}


def loeschen(ab) -> None:
    """Löscht die Version, die ab dem Datum gilt. Die Grundversion (0001-01-01) und unbekannte Versionen lösen KonfigFehler aus."""
    tag = _datum(ab)
    if tag == BEGINN:
        raise KonfigFehler("Die Grundversion lässt sich nicht löschen")
    stand = _stand()
    if not any(v["ab"] == tag for v in stand.versionen):
        raise KonfigFehler("Version nicht gefunden")
    stand.versionen[:] = [v for v in stand.versionen if v["ab"] != tag]
    stand.unbekannt.pop(tag, None)
    _neu_berechnen()


def setzen(werte: dict) -> dict:
    """Für Tests und Skripte: rückwirkend für alle Zeiträume setzen (nur im Speicher)."""
    aendern(werte, "rueckwirkend")
    return dict(_stand().cfg)


def zuruecksetzen():
    """Setzt alle Regeln auf die eingebauten (STANDARD) zurück (nur im Speicher)."""
    stand = _stand()
    stand.versionen[:] = [{"ab": BEGINN, "werte": dict(STANDARD)}]
    stand.unbekannt.clear()
    _neu_berechnen()


def _neu_anlegen(db) -> None:
    """Erster Start mit einer wirklich neuen Datenbank: Regeln des Voreinstellungs-Profils. Weichen sie von den eingebauten ab, werden sie gespeichert,
    damit sie gelten, auch wenn das Profil später fehlt, und mit der Synchronisierung wandern. Gleiche Regeln bleiben ungespeichert: so übernimmt ein neues Gerät
    die Regeln der anderen bei der ersten Synchronisierung ohne Konflikt."""
    _stand().versionen[:] = [{"ab": BEGINN, "werte": grundwerte(db)}]
    _neu_berechnen()
    if _stand().cfg != STANDARD:
        speichern(db)


def _gespeicherte_werte(werte: dict) -> dict:
    """Werte einer gespeicherten oder synchronisierten Regel-Version wie pruefen(werte, True), aber je Feld: Ein Wert, den erst eine neuere Version
    kennt (etwa ein neuer Homeoffice-Modus), lässt nur dieses Feld auf der Voreinstellung. Sonst fielen alle Regeln still zurück und überschrieben
    beim nächsten Speichern die Regeln auf allen Geräten. Eigene Profile prüft profil_lesen weiter streng."""
    r = {}
    for k, v in werte.items():
        try:
            r.update(pruefen({k: v}, True))
        except (ValueError, TypeError):                      # KonfigFehler ist ein ValueError
            pass
    return r


def _unbekannte(werte: dict) -> dict:
    """Die Werte einer gespeicherten Version, die diese Version verwirft oder bereinigt (Feld, Wert oder Modul einer neueren Version).
    speichern schreibt sie unverändert zurück, bis die Person das Feld hier selbst ändert. Sonst überschriebe ein älteres Gerät beim nächsten
    Speichern die neue Regel auf allen Geräten, ohne Konflikt und ohne Hinweis."""
    gelesen = _gespeicherte_werte(werte)
    return {k: v for k, v in werte.items() if k not in gelesen or gelesen[k] != v}


def laden(db):
    """Beim Start: gespeicherte Versionen übernehmen (fehlerhafte Einträge ignorieren, dann gelten die eingebauten Regeln).
    Altes Format (nur ein Werte-Objekt) gilt als Grundversion. Die Regeln des Voreinstellungs-Profils gelten nur für eine neue Datenbank (_neu_anlegen):
    Eine bestehende ohne gespeicherte Regeln hat immer mit den eingebauten gerechnet und darf nicht rückwirkend andere bekommen."""
    zuruecksetzen()
    _schalter_aufraeumen(db)
    roh = db.meta_lesen("konfig")
    if not roh:
        if db.ist_neu():
            _neu_anlegen(db)
        return
    try:
        d = json.loads(roh)
        if isinstance(d, dict) and "versionen" in d:
            vs = [{"ab": _datum(v["ab"]), "werte": _aufgefuellt(_gespeicherte_werte(v["werte"]))} for v in d["versionen"]]
            if not any(v["ab"] == BEGINN for v in vs):
                vs.insert(0, {"ab": BEGINN, "werte": dict(STANDARD)})
            vs.sort(key=lambda v: v["ab"])
            stand = _stand()
            stand.versionen[:] = vs
            stand.unbekannt.update({_datum(v["ab"]): _unbekannte(v["werte"]) for v in d["versionen"]})
        elif isinstance(d, dict):
            stand = _stand()
            stand.versionen[:] = [{"ab": BEGINN, "werte": _aufgefuellt(_gespeicherte_werte(d))}]
            stand.unbekannt[BEGINN] = _unbekannte(d)
    except (ValueError, KeyError, TypeError, AttributeError):  # AttributeError: Werte einer Version kein Wörterbuch
        zuruecksetzen()
        return
    _neu_berechnen()


def speichern(db):
    """Schreibt alle Versionen als JSON in die Datenbank (Tabelle meta, Schlüssel „konfig“), mit den weitergereichten Werten (UNBEKANNT)."""
    stand = _stand()
    db.meta_setzen("konfig", json.dumps({"versionen": [{**v, "werte": {**v["werte"], **stand.unbekannt.get(v["ab"], {})}} for v in stand.versionen]}, ensure_ascii=False))


# ---- Profile: Vorbelegungen für „Einstellungen“ (ein Satz Regeln, dazu wahlweise eine Akzentfarbe). Mitgelieferte Profile je in einer eigenen
# Datei profil_*.py, weitere als JSON im Datenordner, eigene in der Datenbank (seit 18.11.2026, Auftrag; Voreinstellung bis zur Wahl beim ersten Start: profil_buero_homeoffice).
FARBEN = ("hell", "dunkel", "auto")                          # Darstellung, die ein Profil mitbringen kann ("" = lässt sie, wie sie ist)
PROFILE_MAX = 20
BESCHREIBUNG_MAX = 200                                        # ein Satz zu einem festen Profil (Frage beim ersten Start)
# Ohne Anker, weil db.SYNC_META das Muster einbettet: grobe Zeichenklasse ohne Steuer-, Format- und Trennzeichen; vollständig prüft profil_name_gueltig.
PROFIL_NAME = re.compile(r"[^\x00-\x1f\x7f-\x9f<>&\"'/\\\xad؜᠎\u200b-‏ -‮\u2060-⁯\ufeff￹-￻]{1,40}")
PROFIL_NAME_FEHLER = "Name des Profils: 1 bis 40 Zeichen, ohne Leerzeichen am Rand, ohne < > & / \\ und Anführungszeichen, nicht nur Punkte"
AKZENT = re.compile(r"#[0-9a-f]{6}")
PROFIL_DATEI_FORMAT = 1                                       # Kennung in exportierten Profil-Dateien („zeiterfassung_profil“)
PROFIL_VORSILBE = "profil:"                                   # Meta-Schlüssel eines eigenen Profils: „profil:<Name>“, je Profil ein Satz im Sync
SCHALTER = "profile_aktiv"                                    # Meta-Schlüssel: Ein/Aus je Profil auf diesem Gerät (bewusst nicht im Sync)


def profil_name_gueltig(name) -> bool:
    """Prüft einen Profilnamen: 1 bis 40 druckbare Zeichen (str.isprintable schließt Steuer-, Format-, Trenn- und Bidi-Zeichen aus),
    keine Leerzeichen am Rand, nicht nur Punkte und PROFIL_NAME (ohne < > & / \\ und Anführungszeichen).
    Der Name wird Teil eines Meta-Schlüssels und steht in der Oberfläche, in Dateien und in der Synchronisierung."""
    return (isinstance(name, str) and name.isprintable() and name == name.strip() and name.strip(".") != ""
            and PROFIL_NAME.fullmatch(name) is not None)


def mitgeliefert(profil) -> tuple:
    """Prüft ein Profil aus einer Datei profil_*.py. Rückgabe (Name, Profil) mit allen Regeln, oder None, wenn etwas nicht stimmt
    (dann fehlt nur dieses Profil, die App läuft weiter). Feste Profile setzen jede Regel, auch die Module."""
    try:
        name, werte = profil["name"], profil["werte"]
        akzent, farbe = profil.get("akzent", ""), profil.get("farbe", "")
        aktiv, vor, text = profil.get("aktiv", True), profil.get("voreinstellung", False), profil.get("beschreibung", "")
        if (not profil_name_gueltig(name) or not isinstance(werte, dict) or not isinstance(text, str) or len(text) > BESCHREIBUNG_MAX
                or (akzent and not AKZENT.fullmatch(str(akzent))) or farbe not in ("", *FARBEN) or not isinstance(aktiv, bool) or not isinstance(vor, bool)):
            return None
        gelesen = pruefen(werte)
        return name, {"werte": _saldo_minus_alt(gelesen, {**STANDARD, **gelesen}), "akzent": akzent, "farbe": farbe, "aktiv": aktiv, "voreinstellung": vor, "beschreibung": text}
    except (KonfigFehler, KeyError, TypeError, AttributeError):
        return None


# Mitgelieferte Profile als Python-Datei (feste Liste statt Ordnersuche: so nehmen alle Bauwege, Web-App-Paket, PyInstaller und Android, sie sicher mit).
# Ein neues öffentliches Profil: Datei profil_<name>.py nach dem Muster von profil_buero_homeoffice.py anlegen und hier eintragen.
# Private Profile gehören nicht hierher, sondern als JSON in den Ordner „profile“ im Datenordner (profile_aus_ordner).
try:
    from daten import profil_nur_zeiterfassung
except ImportError:                                          # Datei fehlt: Profil fehlt
    profil_nur_zeiterfassung = None
try:
    from daten import profil_mit_grenze
except ImportError:
    profil_mit_grenze = None
try:
    from daten import profil_buero_homeoffice
except ImportError:
    profil_buero_homeoffice = None
try:
    from daten import profil_nur_buero
except ImportError:
    profil_nur_buero = None
try:
    from daten import profil_nur_homeoffice
except ImportError:
    profil_nur_homeoffice = None
# Reihenfolge = Reihenfolge der Vorlagen beim ersten Start (funktionen.md 6.1); „Nur Büro“ und „Nur Homeoffice“ sind ab Werk ausgeschaltet
MITGELIEFERT = tuple(m for m in (profil_nur_zeiterfassung, profil_mit_grenze, profil_buero_homeoffice, profil_nur_buero, profil_nur_homeoffice) if m)
PROFILE_FEST = dict(p for p in (mitgeliefert(getattr(m, "PROFIL", None)) for m in MITGELIEFERT) if p)
PROFIL_WAHL = "profil_wahl"                                   # Meta-Schlüssel: beim ersten Start gewähltes Profil (je Gerät, nicht im Sync)
WAHL_FEHLER = "Bitte eines der mitgelieferten Profile wählen"
WAHL_SCHON = "Das Profil ist schon gewählt. Ändern geht unter Einstellungen → Module und Profile."
PROFIL_ORDNER = "profile"                                     # Unterordner im Datenordner: weitere Profile als JSON, je Datei eins
PROFIL_DATEI_MAX = 64 * 1024


def profile_aus_ordner(ordner: str) -> list:
    """Lädt weitere feste Profile aus <ordner>/*.json (nach Dateinamen), z. B. private Profile, die nicht im Code stehen dürfen.
    Jede Datei wird wie ein mitgeliefertes Profil geprüft; eine kaputte, zu große oder doppelte Datei wird übersprungen.
    Rückgabe: die Namen der neu geladenen Profile. Fehlt der Ordner, passiert nichts."""
    try:
        namen = sorted(n for n in os.listdir(ordner) if n.lower().endswith(".json"))
    except OSError:
        return []
    geladen = []
    for n in namen:
        pfad = os.path.join(ordner, n)
        try:
            if os.path.getsize(pfad) > PROFIL_DATEI_MAX:
                continue
            with open(pfad, encoding="utf-8") as f:
                p = mitgeliefert(json.load(f))
        except (OSError, ValueError):                         # unlesbar oder kein JSON
            continue
        if p and p[0] not in PROFILE_FEST:
            PROFILE_FEST[p[0]] = p[1]
            geladen.append(p[0])
    return geladen


def voreinstellung(db=None) -> str:
    """Name des Voreinstellungs-Profils: mit db das dort beim ersten Start gewählte (gewaehlt), sonst das zuletzt geladene mit „voreinstellung“.
    Profile aus dem Datenordner kommen nach denen im Code und gehen deshalb vor (z. B. das Profil des Arbeitgebers einer Person). "" = keines."""
    return (gewaehlt(db) if db is not None else "") or next((n for n, p in reversed(PROFILE_FEST.items()) if p["voreinstellung"]), "")


def gewaehlt(db) -> str:
    """Das beim ersten Start gewählte feste Profil dieser Datenbank, "" = noch keins gewählt (oder seine Datei fehlt inzwischen)."""
    n = db.meta_lesen(PROFIL_WAHL) or ""
    return n if n in PROFILE_FEST else ""


def profil_waehlen(db, name) -> None:
    """Antwort auf „Wie arbeitest du?“: Regeln des festen Profils übernehmen (ohne Einträge für alle Tage, sonst ab heute), speichern und
    das Profil für diese Datenbank als Voreinstellung merken. KonfigFehler, wenn name kein festes Profil ist oder schon eins gewählt wurde
    (später ändert „Anwenden“ die Regeln ab heute, nie rückwirkend über diese Wahl)."""
    if gewaehlt(db):
        raise KonfigFehler(WAHL_SCHON)
    if not isinstance(name, str) or name not in PROFILE_FEST:
        raise KonfigFehler(WAHL_FEHLER)
    leer = not db.tage_alle()
    aendern(PROFILE_FEST[name]["werte"], "rueckwirkend" if leer else "ab_heute")
    # wie _neu_anlegen: eingebaute Regeln einer leeren Datenbank bleiben ungespeichert, so tritt ein neues Gerät dem Sync ohne Konflikt bei
    if not leer or db.meta_lesen("konfig") or _stand().cfg != STANDARD:
        speichern(db)
    db.meta_setzen(PROFIL_WAHL, name)


def grundwerte(db=None) -> dict:
    """Regeln einer neuen Datenbank bzw. „Voreinstellung laden“: die des Voreinstellungs-Profils, ohne eines die eingebauten (STANDARD)."""
    n = voreinstellung(db)
    return dict(PROFILE_FEST[n]["werte"]) if n else dict(STANDARD)


def profil_text(p: dict) -> str:
    """Ein eigenes Profil als gespeicherter Text. Immer gleich geschrieben (sortiert), damit gleicher Inhalt auf zwei Geräten nie ein Konflikt ist."""
    return json.dumps({"werte": p.get("werte"), "akzent": p.get("akzent") or "", "farbe": p.get("farbe") or ""}, sort_keys=True, ensure_ascii=False)


def profil_lesen(text) -> dict:
    """Gespeicherten Text eines eigenen Profils prüfen -> {werte, akzent, farbe}. Regeln einer neueren Version werden übersprungen.
    ValueError (auch KonfigFehler), wenn das Profil nicht passt."""
    p = json.loads(text)
    if not isinstance(p, dict) or not isinstance(p.get("werte"), dict):
        raise ValueError("Profil")
    akzent, farbe = p.get("akzent") or "", p.get("farbe") or ""
    if (akzent and not AKZENT.fullmatch(str(akzent))) or farbe not in ("", *FARBEN):
        raise ValueError("Profil")
    return {"werte": _aufgefuellt(pruefen(p["werte"], True)), "akzent": akzent, "farbe": farbe}


def _eigene_profile(db) -> dict:
    """Die eigenen Profile aus der Datenbank, jedes einzeln geprüft: ein kaputtes fehlt nur selbst, sein Eintrag bleibt unverändert stehen."""
    r = {}
    for k, text in db.meta_mit(PROFIL_VORSILBE).items():
        name = k[len(PROFIL_VORSILBE):]
        try:
            if profil_name_gueltig(name):
                r[name] = profil_lesen(text)
        except (ValueError, TypeError, RecursionError):      # RecursionError: zu tief verschachtelt
            continue
    return r


def _schalter(db) -> dict:
    """Ein/Aus je Profil auf diesem Gerät: {Name: bool}; ein kaputter Eintrag zählt wie keiner."""
    try:
        d = json.loads(db.meta_lesen(SCHALTER) or "{}")
        return {n: a for n, a in d.items() if isinstance(a, bool)} if isinstance(d, dict) else {}
    except (ValueError, RecursionError):
        return {}


def _schalter_aufraeumen(db) -> None:
    """Verwirft das Ein/Aus von Profilen, die es weder fest noch eigen gibt (z. B. ein umbenanntes mitgeliefertes Profil aus einer alten Sicherung).
    Es geht nur der Name verloren; Regeln und eigene Profile bleiben, wie sie sind."""
    s = _schalter(db)
    if all(n in PROFILE_FEST for n in s):                     # der übliche Fall: ohne die eigenen Profile zu lesen
        return
    eigene = _eigene_profile(db)
    bekannt = {n: a for n, a in s.items() if n in PROFILE_FEST or n in eigene}
    if bekannt != s:
        db.meta_setzen(SCHALTER, json.dumps(bekannt, ensure_ascii=False))


def profile(db) -> list:
    """Feste Profile zuerst, dann die eigenen nach Namen; jedes mit „aktiv“ (Schalter dieses Geräts, sonst die Vorgabe der Datei)."""
    s, vor = _schalter(db), voreinstellung(db)
    fest = [{"name": n, "fest": True, **p, "werte": p["werte"], "aktiv": s.get(n, p["aktiv"]), "voreinstellung": n == vor} for n, p in PROFILE_FEST.items()]
    # Ein eigenes Profil mit dem Namen eines festen bleibt gespeichert (es kann von einem Gerät ohne dieses feste Profil stammen), wird hier aber nicht gezeigt.
    eigen = [{"name": n, "fest": False, **p, "werte": p["werte"], "aktiv": s.get(n, True), "voreinstellung": False}
             for n, p in sorted(_eigene_profile(db).items(), key=lambda x: x[0].lower()) if n not in PROFILE_FEST]
    return fest + eigen


def profil_schalten(db, name, aktiv) -> None:
    """Schaltet ein Profil auf diesem Gerät ein oder aus. KonfigFehler bei unbekanntem Namen oder wenn aktiv kein Ja/Nein ist."""
    if not isinstance(aktiv, bool):
        raise KonfigFehler("Ein oder aus erwartet")
    if not isinstance(name, str) or (name not in PROFILE_FEST and name not in _eigene_profile(db)):
        raise KonfigFehler("Dieses Profil gibt es nicht")
    s = _schalter(db)
    s[name] = aktiv
    db.meta_setzen(SCHALTER, json.dumps(s, ensure_ascii=False))


def _eigenes_ablegen(db, name, werte: dict, akzent, farbe) -> None:
    """Legt ein eigenes Profil ab (neu oder überschreiben) nach Prüfung von Name, Farbe, Darstellung und Anzahl."""
    name = name.strip() if isinstance(name, str) else ""
    if not profil_name_gueltig(name):
        raise KonfigFehler(PROFIL_NAME_FEHLER)
    if name in PROFILE_FEST:
        raise KonfigFehler(f"„{name}“ ist ein festes Profil. Bitte einen anderen Namen wählen.")
    akzent = akzent.lower() if isinstance(akzent, str) else ""
    if akzent and not AKZENT.fullmatch(akzent):
        raise KonfigFehler("Farbe: Hex-Wert wie #1a73e8 erwartet")
    if farbe not in ("", *FARBEN):
        raise KonfigFehler("Darstellung: hell, dunkel oder auto erwartet")
    eigene = _eigene_profile(db)
    if name not in eigene and len(eigene) >= PROFILE_MAX:
        raise KonfigFehler(f"Höchstens {PROFILE_MAX} eigene Profile")
    db.meta_setzen(PROFIL_VORSILBE + name, profil_text({"werte": werte, "akzent": akzent, "farbe": farbe}))


def profil_speichern(db, name, akzent="", farbe="") -> None:
    """Die Regeln, die heute gelten, unter einem Namen ablegen (neu oder überschreiben). Feste Profile bleiben, wie sie sind."""
    _eigenes_ablegen(db, name, _stand().cfg, akzent, farbe)


def profil_datei(p: dict) -> dict:
    """Ein Profil als Inhalt einer Profil-Datei (Export): Kennung, Name, Regeln, Farbe, Darstellung."""
    return {"zeiterfassung_profil": PROFIL_DATEI_FORMAT, "name": p["name"], "werte": p["werte"], "akzent": p["akzent"], "farbe": p["farbe"]}


def profil_importieren(db, d) -> None:
    """Übernimmt eine Profil-Datei (profil_datei) als eigenes Profil. Regeln einer neueren Version werden übersprungen.
    KonfigFehler, wenn die Datei kein Profil dieser App ist oder etwas nicht stimmt."""
    if not isinstance(d, dict) or d.get("zeiterfassung_profil") != PROFIL_DATEI_FORMAT or not isinstance(d.get("werte"), dict):
        raise KonfigFehler("Die Datei ist kein Profil dieser App.")
    gelesen = pruefen(d["werte"], True)                      # eine Datei einer älteren Fassung: Minus 0 hieß dort „wie Plus“ (_saldo_minus_alt)
    _eigenes_ablegen(db, d.get("name"), _saldo_minus_alt(gelesen, {**STANDARD, **gelesen}), d.get("akzent") or "", d.get("farbe") or "")


def profil_loeschen(db, name) -> None:
    """Löscht ein eigenes Profil; ein festes oder unbekanntes Profil löst KonfigFehler aus."""
    if not isinstance(name, str) or name in PROFILE_FEST or name not in _eigene_profile(db):
        raise KonfigFehler("Dieses eigene Profil gibt es nicht")
    db.meta_loeschen(PROFIL_VORSILBE + name)
    s = _schalter(db)
    if s.pop(name, None) is not None:                         # ein neues Profil mit demselben Namen beginnt wieder eingeschaltet
        db.meta_setzen(SCHALTER, json.dumps(s, ensure_ascii=False))


def uebersicht(db=None) -> dict:
    """Alles, was die Oberfläche für „Einstellungen“ braucht: heutige Werte, alle Versionen, Voreinstellung (mit db die gewählte), Bundesländer, Module."""
    werte = dict(_stand().cfg)
    werte["zutun_sicherung_tage"] = sicherung_tage(werte)     # die Oberfläche zeigt die wirksame Zahl, nicht die 0 der Vorgabe
    return {"werte": werte, "versionen": [dict(v) for v in _stand().versionen], "standard": grundwerte(db), "bundeslaender": BUNDESLAENDER, "module": MODULE}
