# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Mitgelieferte Vorlage „Mit Homeoffice-Grenze“ (seit 19.11.2026, zweite der drei Vorlagen beim ersten Start, funktionen.md 6.1).
Aufbau wie profil_buero_homeoffice.py: Fehlt diese Datei, fehlt nur dieses Profil."""

NAME = "Mit Homeoffice-Grenze"                               # Anzeigename; steht nur hier
# Steht für sich (nicht „Wie oben“ wie in funktionen.md 6.1): Profile sind einzeln schaltbar, die Vorlage davor kann fehlen.
BESCHREIBUNG = "Arbeitszeit, Urlaub und Gleitzeit. Mit Homeoffice-Grenze, Quote und Spielraum."
# Grenze 80 % aus den eingebauten Regeln (die Einrichtung fragt sie ab); keine Sonderregeln für Fasching, Heiligabend und Silvester, ohne Familientage und ohne angesparten Urlaub (gilt vor allem für Beamte).
# Akzent und Farbe leer: die Vorlage lässt die Darstellung, wie sie ist.
PROFIL = {"name": NAME, "beschreibung": BESCHREIBUNG, "aktiv": True, "voreinstellung": False, "akzent": "", "farbe": "",
          "werte": {"fasching_std": None, "heiligabend_frei": False, "silvester_frei": False, "module_aus": ["familientage", "angespart"]}}
