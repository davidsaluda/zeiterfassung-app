# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Synchronisierung zwischen Geräten (Handy, Desktop) ohne eigenen Server: Jedes Gerät legt seinen ganzen Stand verschlüsselt als eine Datei
„abgleich-<Gerätekennung>.zsich“ in den gemeinsamen Cloud-Ordner und liest die Dateien der anderen Geräte. Umschlag und Ziele: sicherung.py.

Zusammenführen (je Tag und je Einstellung, Speicher: Db.saetze):
- Jeder Eintrag trägt Änderungszeit, Gerät und eine Fassung (je Gerät ein Zähler, der bei jeder Änderung auf diesem Gerät steigt).
- Kennt ein Eintrag alle Änderungen des anderen (seine Fassung ist überall mindestens so hoch), ist er der neuere und gewinnt.
- Haben beide Geräte denselben Eintrag geändert, ohne die Änderung des anderen zu kennen, ist das ein Konflikt: Der eigene Eintrag bleibt,
  der fremde kommt in die Konfliktliste, die Person entscheidet. Nichts wird still überschrieben. Die Uhrzeit dient nur als Vorschlag („neuer“).
- Gleicher Inhalt auf beiden Seiten ist nie ein Konflikt. Gelöschtes bleibt als Markierung erhalten und wird wie eine Änderung behandelt.
- Übertragen werden nur Eingaben. Alle Rechenwerte (Quote, Konten, Gleitzeit) rechnet jedes Gerät nach der Synchronisierung neu."""
import hashlib
import json
import os
import re
import sys
import threading
import time
from datetime import date, datetime, timedelta

from daten import konfig
from daten import sicherung
from daten import update
from daten.db import SYNC_META, ABSCHNITT_FELDER, ABSCHNITTE, EINTRAEGE_SCHLUESSEL, ANSPAREN_AUTO_META, JAHRESWECHSEL_META, KAPPUNG_UEBERNAHME_META, RESTURLAUB_BEHALTEN_META, NACHWEIS_FELDER, NACHWEIS_META, NACHWEIS_VORSILBE, PROFILE_ALT, TAG_FELDER, ZAEHLER_AB_MAX, meta_eintrag_gueltig
from kern.regeln import ABSCHNITT_ARTEN, ARTEN, BUERO_TAGE_MAX, JAHR_MAX, JAHR_MIN, NOTIZ_MAX, STEUERZEICHEN, URLAUB_MAX, WOCHENSTUNDEN_MAX, WT, notiz_bereinigen, tageszeit_gueltig, uhrzeiten_gueltig, zahl_gueltig

PROFIL_TEXT_MAX = konfig.PROFIL_DATEI_MAX                     # ein eigenes Profil als Text: höchstens so lang wie eine Profil-Datei
# 2 seit 18.11.2026: eigene Profile wandern mit (Sammelsatz); 3 seit dem Review am selben Tag: je Profil ein Satz. Ältere Geräte melden „bitte aktualisieren“.
# Format 4 seit 18.11.2026: Annahme für den Monat (buero_pro_woche_monat).
# Bei jedem neuen erlaubten Regelwert hochzählen: Ältere Geräte reichen ihn zwar weiter (konfig.UNBEKANNT), zeigen und rechnen aber mit der Voreinstellung.
# 5: Tag-Arten sonderurlaub_tag und kind_krank, Abschnitt-Feld tagesminuten, Namen der eigenen freien Tage, Einstellung startwerte, Regeln kind_krank_max, feiertage_eigen, feiertage_aus
# (dazu Vermerk und geprüft am Tag, der beim Ansparen gemerkte automatische Übertrag ansparen_auto_<Vorjahr>). Dateien bis Format 4 ohne die neuen Felder gelten weiter: fehlende Felder sind leer.
# 6 seit 23.11.2026: Unterschrift des Monatsnachweises (nachweis_ort, _datum, _zweite, _vorgesetzt). Release v20261122.1619 schreibt Format 5 und würde
# die ganze Datei wegen der unbekannten Schlüssel als ungültig ablehnen; mit 6 meldet es „bitte aktualisieren“.
# 7 seit 23.11.2026 (ein Release, mehrere Neuerungen): „Resturlaub behalten“ je Jahr (resturlaub_behalten_<Jahr>) und Kappung der Gleitzeit (Regeln gleitzeit_kappung, kappung_stichtag, kappung_grenze_min, kappung_ab_jahr; Übernahme kappung_uebernahme_<Jahr>); Zusatzurlaub (Regeln zusatzurlaub_art, zusatzurlaub_tage); Dienstverhältnis „Eigene Frist“ (Wert eigen, Regeln resturlaub_frist, resturlaub_ansparen); Format 6 lehnte die unbekannten Schlüssel ab. Dazu (im selben,
# noch nicht veröffentlichten Format 7) Hinweis-Grenzen 0 = kein Hinweis mit der Kennung zutun_saldo_null_aus: Ältere Geräte meinten mit Minus 0 „wie Plus“,
# konfig._saldo_minus_alt stellt ihre Regeln beim Lesen um; Format 6 und älter lesen keine Datei mit Format 7, sehen also nie eine neue 0.
# Bewusst ohne Formatsprung (24.11.2026): Regel stempel_mitternacht. Ältere Geräte reichen sie weiter und prüfen die Stempeluhr wie bisher (über Mitternacht);
# betrifft nur die Prüfung beim Gehen, keine Rechenwerte.
# 8 seit 25.11.2026: Einträge je Tag (eintraege_<Datum>, Kommen–Gehen-Blöcke der Stempeluhr und des Formulars). Release 20261125.0025 (Format 7) lehnte
# den unbekannten Schlüssel ab; mit 8 meldet es „bitte aktualisieren“. Ältere Dateien ohne die Einträge gelten weiter (die Tage zeigen dann eine Zeile).
FORMAT = 8
MAX_SAETZE = 200_000
FASSUNG_MAX = 10 ** 9                                       # höchster Zähler in einer fremden Datei
FASSUNG_RAND = ZAEHLER_AB_MAX                              # eigener Zähler darüber: nicht übernehmen, sonst zählt dieses Gerät über FASSUNG_MAX und seine Datei gilt überall als ungültig
GERAET = re.compile(r"[0-9a-z]{1,32}")
HIER, DORT = "hier", "dort"
UNGUELTIG = "Die Synchronisierungsdatei eines anderen Geräts ist ungültig und wurde nicht übernommen."
ZU_NEU = "Ein anderes Gerät benutzt eine neuere Version der App. Bitte die App auf diesem Gerät aktualisieren."
GERAET_UNBEKANNT = "Dieses Gerät gibt es in der Synchronisierung nicht (mehr)."
EIGENES_GERAET = "Dieses Gerät selbst lässt sich nicht entfernen. Zum Aufhören die Synchronisierung unter Module abschalten."
VERALTET_TAGE = 30                                          # so lange nichts geschrieben: Vorschlag, das Gerät zu entfernen (Neuinstallation, verloren)
ZEIT_FORM = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")    # Zeitpunkt im Kopf einer Sync-Datei (packen, „erstellt“)
PASSWORT_FALSCH = "Das Passwort passt nicht zur Synchronisierungsdatei eines anderen Geräts. Bitte das Passwort eingeben, das dort festgelegt ist."


class SyncFehler(konfig.Meldung):
    """Fehler mit einem Text für die Oberfläche."""


SYNC_FEHLER = "Die Synchronisierung ist fehlgeschlagen (Details im Protokoll der App)."


def fehlertext(e: ValueError) -> str:
    """Text für den Stand der Synchronisierung (Oberfläche): eine eigene Meldung unverändert, sonst SYNC_FEHLER; Einzelheiten nur ins Protokoll."""
    if isinstance(e, konfig.Meldung):
        return str(e)
    print(f"Synchronisierung: {e!r}", flush=True)
    return SYNC_FEHLER


class ProfilUngueltig(ValueError):
    """Ein eigenes Profil aus der Datei eines anderen Geräts passt nicht (z. B. ein Wert, den erst eine neuere Version kennt).
    Nur dieses Profil wird übersprungen, der Rest der Datei gilt."""


# ---- Fassungen vergleichen

def vergleichen(a: dict, b: dict) -> str:
    """„gleich“, „a“ (a kennt alles aus b und mehr), „b“ oder „getrennt“ (beide haben Änderungen, die der andere nicht kennt)."""
    a_vorn = any(n > b.get(g, 0) for g, n in a.items())
    b_vorn = any(n > a.get(g, 0) for g, n in b.items())
    return "getrennt" if a_vorn and b_vorn else "a" if a_vorn else "b" if b_vorn else "gleich"


def vereinen(a: dict, b: dict) -> dict:
    """Fassung, die alles kennt, was a oder b kennt (je Gerät der höhere Zähler)."""
    return {g: max(a.get(g, 0), b.get(g, 0)) for g in set(a) | set(b)}


def _inhalt(s: dict):
    """Vergleichstext des Werts eines Eintrags (None bei gelöscht); zwei Einträge mit gleichem Inhalt sind nie ein Konflikt."""
    return None if s["wert"] is None else json.dumps(s["wert"], sort_keys=True)


# ---- Prüfen, was von einem anderen Gerät kommt (die Datei ist verschlüsselt und geprüft, ihr Inhalt wird trotzdem nicht blind übernommen)

def _tag(text) -> str:
    """Prüft ein Datum „JJJJ-MM-TT“ (Jahr im erlaubten Bereich, genau diese Schreibweise). ValueError, sonst Rückgabe des Texts."""
    d = date.fromisoformat(text)
    if not isinstance(text, str) or not JAHR_MIN <= d.year <= JAHR_MAX or d.isoformat() != text:
        raise ValueError("Datum")
    return text


def _jahr(text) -> str:
    """Prüft ein Jahr als Text aus Ziffern im erlaubten Bereich. ValueError, sonst Rückgabe des Texts."""
    if not isinstance(text, str) or not text.isascii() or not text.isdigit() or not JAHR_MIN <= int(text) <= JAHR_MAX or str(int(text)) != text:
        raise ValueError("Jahr")
    return text


def _zahl(w, von, bis, leer=False):
    """Prüft eine Zahl zwischen von und bis (mit leer=True ist None erlaubt). ValueError, sonst Rückgabe."""
    if w is None and leer:
        return None
    if not zahl_gueltig(w, von, bis):
        raise ValueError("Zahl")
    return w


def _ganz(w, von, bis) -> int:
    """Prüft eine ganze Zahl (kein bool) zwischen von und bis. ValueError, sonst Rückgabe."""
    if isinstance(w, bool) or not isinstance(w, int) or not von <= w <= bis:
        raise ValueError("ganze Zahl")
    return w


def _text(w, laenge) -> str:
    """Prüft einen Text (höchstens laenge Zeichen, keine Steuerzeichen). ValueError, sonst Rückgabe."""
    if not isinstance(w, str) or len(w) > laenge or STEUERZEICHEN.search(w):
        raise ValueError("Text")
    return w


def _felder(w, namen) -> dict:
    """Prüft, dass w ein Wörterbuch mit genau diesen Feldnamen ist. ValueError, sonst Rückgabe."""
    if not isinstance(w, dict) or set(w) != set(namen):
        raise ValueError("Felder")
    return w


def _wert_tag(schluessel, w):
    """Prüft und bereinigt den Wert eines Tages aus einer fremden Datei. Alte Fassungen ohne Kommen/Gehen/Pause werden ergänzt. ValueError bei Verstößen."""
    _tag(schluessel)
    if isinstance(w, dict) and not {"kommen", "gehen", "pause"} & set(w):
        w = {**w, "kommen": -1, "gehen": -1, "pause": 0}       # Gerät mit einer Fassung vor Kommen/Gehen/Pause
    if isinstance(w, dict) and not {"vermerk", "geprueft"} & set(w):
        w = {**w, "vermerk": "", "geprueft": 0}                # Gerät mit Format bis 4 (vor Vermerk und geprüft)
    _felder(w, TAG_FELDER)
    if w["vermerk"] not in ("", *konfig.VERMERKE):
        raise ValueError("Vermerk")
    if w["art"] not in ARTEN or (w["konto"] and not JAHR_MIN <= _ganz(w["konto"], 0, JAHR_MAX)):
        raise ValueError("Tag")
    if w["attest"] != "":
        _tag(w["attest"])
    if not tageszeit_gueltig(w["ho"], w["dst"], w["art"]) or not uhrzeiten_gueltig(w["kommen"], w["gehen"], w["pause"]):
        raise ValueError("Tag")
    notiz = notiz_bereinigen(w["notiz"]) if isinstance(w["notiz"], str) else w["notiz"]   # alte Anmerkungen aus dem Import mit Zeilenumbruch: bereinigen statt die Datei abzulehnen
    return {"ho": w["ho"], "dst": w["dst"], "art": w["art"], "notiz": _text(notiz, NOTIZ_MAX), "konto": _ganz(w["konto"], 0, JAHR_MAX),
            "attest": w["attest"], "freigabe": _ganz(w["freigabe"], 0, 1), "kommen": w["kommen"], "gehen": w["gehen"], "pause": w["pause"],
            "vermerk": w["vermerk"], "geprueft": _ganz(w["geprueft"], 0, 1)}


def _wert_jahr(schluessel, w):
    """Prüft und bereinigt den Urlaubs-Eintrag eines Jahres (Anspruch, eigene freie Tage, Übertrag). ValueError bei Verstößen.
    Eigene freie Tage: Texte (bis Format 4, Name "") oder {datum, name}; Ergebnis immer Objekte nach Datum (R4b)."""
    _jahr(schluessel)
    _felder(w, ("anspruch", "eigene_frei", "uebertrag"))
    if not isinstance(w["eigene_frei"], list) or len(w["eigene_frei"]) > 366:
        raise ValueError("freie Tage")
    return {"anspruch": float(_zahl(w["anspruch"], 0, URLAUB_MAX)), "eigene_frei": sorted((_frei_tag(x) for x in w["eigene_frei"]), key=lambda x: x["datum"]),
            "uebertrag": None if w["uebertrag"] is None else float(_zahl(w["uebertrag"], -URLAUB_MAX, URLAUB_MAX))}


def _frei_tag(x) -> dict:
    """Ein eigener freier Tag: Datumstext oder {datum, name} (Name bis konfig.FEIERTAG_NAME_MAX Zeichen, ohne Steuerzeichen). ValueError sonst."""
    if isinstance(x, str):
        return {"datum": _tag(x), "name": ""}
    _felder(x, ("datum", "name"))
    return {"datum": _tag(x["datum"]), "name": _text(x["name"], konfig.FEIERTAG_NAME_MAX)}


def _wert_konto(schluessel, w):
    """Prüft und bereinigt ein Konto für angesparten Urlaub (Tage). ValueError bei Verstößen."""
    _jahr(schluessel)
    return {"tage": float(_zahl(_felder(w, ("tage",))["tage"], 0, URLAUB_MAX))}


def _profil_pruefen(v) -> None:
    """Ein eigenes Profil aus der Datei eines anderen Geräts (Text wie konfig.profil_text): geprüft wie beim Lesen. ProfilUngueltig bei Verstößen."""
    try:
        if not isinstance(v, str) or len(v) > PROFIL_TEXT_MAX:
            raise ValueError("Profil")
        konfig.profil_lesen(v)                               # KonfigFehler ist ein ValueError
    except (ValueError, TypeError, RecursionError):
        raise ProfilUngueltig("Profil")


def _wert_meta(schluessel, w):
    """Prüft und bereinigt eine Einstellung (Regeln, Startstände, Familientage, Büro-Tage). ValueError bei Verstößen."""
    if not isinstance(schluessel, str) or not SYNC_META.fullmatch(schluessel):
        raise ValueError("Einstellung")
    v = _felder(w, ("v",))["v"]
    if schluessel == "konfig":
        if not isinstance(v, str) or len(v) > 200_000 or not isinstance(json.loads(v), dict):
            raise ValueError("Regeln")
        return {"v": v}
    if schluessel.startswith(konfig.PROFIL_VORSILBE):
        _profil_pruefen(v)
        return {"v": v}                                      # unverändert: Felder einer neueren Version gehen nicht verloren
    if schluessel == konfig.STARTWERTE:                      # vor _text(v, 40): der JSON-Text ist länger
        konfig.startwerte_lesen(v)                           # KonfigFehler ist ein ValueError
        return {"v": v}
    if not meta_eintrag_gueltig(schluessel, v):              # Kopf des Monatsnachweises und Jahreswechsel-Merker: dieselbe Regel wie beim Wiederherstellen
        raise ValueError("Einstellung")
    if NACHWEIS_META.fullmatch(schluessel) or EINTRAEGE_SCHLUESSEL.fullmatch(schluessel):   # vor _text(v, 40): Kopf und Einträge sind länger
        return {"v": v}
    _text(v, 40)
    if schluessel.endswith("_start_min"):
        int(v)
    elif schluessel.startswith("familientage_") and v not in ("0", "1"):
        raise ValueError("Familientage")
    elif schluessel.startswith("buero_pro_woche") and v != "" and not 0 <= float(v) <= BUERO_TAGE_MAX:
        raise ValueError("Büro-Tage")
    return {"v": v}


def _wert_abschnitte(schluessel, w):
    """Prüft und bereinigt die Liste der Abschnitte (Teilzeit, Elternzeit) und sortiert sie nach Datum. ValueError bei Verstößen."""
    if ("abschnitte", schluessel) != ABSCHNITTE:
        raise ValueError("Abschnitte")
    liste = _felder(w, ("liste",))["liste"]
    if not isinstance(liste, list) or len(liste) > 500:
        raise ValueError("Abschnitte")
    geprueft = []
    for a in liste:
        if isinstance(a, dict) and "tagesminuten" not in a:
            a = {**a, "tagesminuten": ""}                       # Gerät mit Format bis 4 (vor Stunden je Tag): Weg 1 oder 2
        _felder(a, ABSCHNITT_FELDER)
        tage = konfig.arbeitstage_lesen(_text(a["arbeitstage"], 20), doppelte_entfernen=True)   # alte Bestände mit „Mo,Mo“ bleiben syncbar
        if _tag(a["von"]) > _tag(a["bis"]) or a["art"] not in ABSCHNITT_ARTEN or any(t not in WT[:5] for t in tage):
            raise ValueError("Abschnitt")
        a = {**a, "arbeitstage": ",".join(tage)}
        konfig.tagesminuten_pruefen(a["tagesminuten"], a["arbeitstage"])   # ValueError; wie beim Speichern und in der Sicherung
        geprueft.append({**a, "wochenstunden": float(_zahl(a["wochenstunden"], 0, WOCHENSTUNDEN_MAX))})
    return {"liste": sorted(geprueft, key=lambda a: (a["von"], a["bis"]))}


WERT_PRUEFEN = {"tag": _wert_tag, "jahr": _wert_jahr, "konto": _wert_konto, "meta": _wert_meta, "abschnitte": _wert_abschnitte}


def satz_pruefen(roh) -> tuple:
    """Ein Eintrag aus der Datei eines anderen Geräts -> ((art, schluessel), Eintrag). ValueError, wenn er nicht den Regeln der App entspricht."""
    _felder(roh, ("art", "schluessel", "wert", "zeit", "geraet", "fassung"))
    art, schluessel, fassung = roh["art"], roh["schluessel"], roh["fassung"]
    if art not in WERT_PRUEFEN or not isinstance(schluessel, str):
        raise ValueError("Art")
    if not isinstance(fassung, dict) or not fassung or len(fassung) > 64:
        raise ValueError("Fassung")
    for g, n in fassung.items():
        if not GERAET.fullmatch(g):
            raise ValueError("Fassung")
        _ganz(n, 1, FASSUNG_MAX)
    zeit = _text(roh["zeit"], 40)
    if zeit:
        datetime.fromisoformat(zeit)
    if roh["geraet"] != "" and not GERAET.fullmatch(_text(roh["geraet"], 32)):
        raise ValueError("Gerät")
    if roh["wert"] is None:                                 # gelöscht: nur der Schlüssel muss stimmen
        if art == "tag":
            _tag(schluessel)
        elif art in ("jahr", "konto"):
            _jahr(schluessel)
        elif not (art == "meta" and SYNC_META.fullmatch(schluessel)) and (art, schluessel) != ABSCHNITTE:
            raise ValueError("Schlüssel")
        wert = None
    else:
        wert = WERT_PRUEFEN[art](schluessel, roh["wert"])
    return (art, schluessel), {"wert": wert, "zeit": zeit, "geraet": roh["geraet"], "fassung": fassung, "geloescht": wert is None}


def _sammel_profile(roh) -> bool:
    """Der Sammelsatz „profile“ eines Geräts mit der Fassung vom 18.11.2026: wird ausgelassen (dieses Gerät stellt beim nächsten Start selbst um)."""
    return isinstance(roh, dict) and roh.get("art") == "meta" and roh.get("schluessel") == PROFILE_ALT


# ---- Datei des eigenen Stands

def paket(db, abgemeldet: bool = False) -> bytes:
    """Der eigene Stand als JSON in Bytes (alle Einträge samt Zeit, Gerät und Fassung). abgemeldet=True markiert, dass sich dieses Gerät von der Synchronisierung abgemeldet hat."""
    saetze = [{"art": a, "schluessel": k, "wert": s["wert"], "zeit": s["zeit"], "geraet": s["geraet"], "fassung": s["fassung"]} for (a, k), s in sorted(db.saetze().items())]
    return json.dumps({"format": FORMAT, "geraet": db.geraet, "saetze": saetze, **({"abgemeldet": True} if abgemeldet else {})}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def paket_lesen(roh: bytes) -> dict:
    """-> {(art, schluessel): Eintrag}. SyncFehler, wenn die Datei nicht passt; dann wird nichts übernommen.
    Ausnahme: Ein eigenes Profil mit ungültigem Inhalt fehlt nur selbst (ProfilUngueltig), ebenso der alte Sammelsatz „profile“."""
    try:
        d = json.loads(roh.decode("utf-8"))
        if not isinstance(d, dict) or not isinstance(d.get("format"), int) or isinstance(d.get("format"), bool):
            raise ValueError("Format")
        if d["format"] > FORMAT:
            raise SyncFehler(ZU_NEU)
        if d["format"] < 1 or not isinstance(d.get("saetze"), list) or len(d["saetze"]) > MAX_SAETZE:
            raise ValueError("Format")
        saetze, schluessel = {}, set()
        for s in d["saetze"]:
            if _sammel_profile(s):
                continue
            k = (s.get("art"), s.get("schluessel")) if isinstance(s, dict) else None
            if k in schluessel:
                raise ValueError("doppelter Eintrag")
            schluessel.add(k)
            try:
                k, e = satz_pruefen(s)
            except ProfilUngueltig:
                continue
            saetze[k] = e
        return saetze
    except SyncFehler:
        raise
    except (ValueError, TypeError, KeyError, RecursionError):
        raise SyncFehler(UNGUELTIG)


# ---- Zusammenführen

def zusammenfuehren(db, fremd: dict) -> dict:
    """Die Einträge eines anderen Geräts mit den eigenen zusammenführen. -> {"uebernommen", "konflikte" (aus dieser Datei), "gleich",
    "uebersprungen" (Sätze mit einem Zähler dieses Geräts, den es nie vergeben hat: nicht übernommen, U1)}."""
    with db.lock:
        eigene, offen = db.saetze(), db.konflikte()
        nehmen, neu, gleich, uebersprungen = {}, {}, 0, 0
        with db._c() as c:
            untergrenze = db._zaehler_ab(c)
        pruefen = untergrenze > 0 or not db.ist_neu()      # eine neu angelegte Datenbank (Kennung geblieben) holt ihre früheren Einträge zurück
        for k, f in fremd.items():
            if f["fassung"].get(db.geraet, 0) > FASSUNG_RAND or (pruefen and _zaehler_unbekannt(db, eigene.get(k), f, untergrenze)):
                uebersprungen += 1                           # so viele Änderungen macht kein Gerät bzw. diesen Zähler hat es nie vergeben: kein ehrliches Gerät
                continue
            e = eigene.get(k)
            lage = "b" if e is None else vergleichen(e["fassung"], f["fassung"])
            if e is not None and _inhalt(e) == _inhalt(f):   # gleicher Inhalt: nie ein Konflikt, nur die Fassungen zusammenlegen
                gleich += 1
                if lage != "gleich":
                    neuer = f if lage == "b" or (lage == "getrennt" and f["zeit"] > e["zeit"]) else e
                    nehmen[k] = {**e, "zeit": neuer["zeit"], "geraet": neuer["geraet"], "fassung": vereinen(e["fassung"], f["fassung"])}
            elif lage == "b":
                nehmen[k] = f
            elif lage != "a":                                # „getrennt“, oder beide noch ohne Protokoll und verschieden
                neu[k] = f
        # Ältere offene Konflikte (auch die mit einem dritten Gerät) bleiben, bis der eigene Eintrag den fremden kennt oder beide gleich sind.
        jetzt = {**eigene, **nehmen}
        erledigt = [k for k, f in offen.items() if k not in neu and k in jetzt
                    and (_inhalt(jetzt[k]) == _inhalt(f) or vergleichen(jetzt[k]["fassung"], f["fassung"]) == "a")]
        db.saetze_schreiben(nehmen)
        db.konflikte_aendern(neu, erledigt)
        if nehmen:
            konfig.laden(db)
        return {"uebernommen": sum(1 for k, s in nehmen.items() if k not in eigene or _inhalt(s) != _inhalt(eigene[k])), "konflikte": len(neu), "gleich": gleich,
                "uebersprungen": uebersprungen}


def _zaehler_unbekannt(db, eigener, fremder: dict, untergrenze: int) -> bool:
    """Trägt der fremde Eintrag einen Zähler dieses Geräts, den es für diesen Eintrag nie vergeben hat? Ein ehrliches Gerät kennt höchstens den
    eigenen Stand oder den vor dem letzten Wiederherstellen (untergrenze). Höher kommt er nur von einem Gerät mit einem alten Schlüssel
    (etwa einem verlorenen); er sollte sonst jede spätere Änderung hier übertrumpfen. Eine ganz leere Datenbank ohne Untergrenze prüft das nicht
    (Aufrufer), sonst bekäme sie nach dem Neuanlegen ihre früheren Einträge nie zurück."""
    bekannt = eigener["fassung"].get(db.geraet, 0) if eigener else 0
    return fremder["fassung"].get(db.geraet, 0) > max(bekannt, untergrenze)


def entscheiden(db, art: str, schluessel: str, wahl: str) -> None:
    """Einen Konflikt auflösen: HIER = der Eintrag dieses Geräts gilt, DORT = der des anderen. Die Entscheidung ist eine neue Änderung,
    die beide alten Fassungen kennt; sie setzt sich bei der nächsten Synchronisierung auf allen Geräten durch."""
    if wahl not in (HIER, DORT):
        raise SyncFehler("Bitte wählen: dieses Gerät oder anderes Gerät")
    with db.lock:
        k = (art, schluessel)
        fremd = db.konflikte().get(k)
        if fremd is None:
            raise SyncFehler("Diesen Konflikt gibt es nicht mehr")
        eigener = db.saetze().get(k) or {"wert": None, "fassung": {}}
        fassung = db.fassung_weiter(vereinen(eigener["fassung"], fremd["fassung"]))
        gewaehlt = fremd if wahl == DORT else eigener
        db.saetze_schreiben({k: {"wert": gewaehlt["wert"], "zeit": db.uhr().isoformat(timespec="seconds"), "geraet": db.geraet, "fassung": fassung}})
        db.konflikte_aendern({}, [k])
        konfig.laden(db)


def alle_entscheiden(db, wahl: str) -> int:
    """Löst alle offenen Konflikte mit derselben Wahl (HIER oder DORT) auf und gibt ihre Anzahl zurück."""
    offen = list(db.konflikte())
    for art, schluessel in offen:
        entscheiden(db, art, schluessel, wahl)
    return len(offen)


# ---- Konflikte für die Oberfläche beschreiben

META_NAMEN = {"konfig": "Regeln (Arbeitszeit, Grenzen)", "gleitzeit_start_min": "Startstand Gleitzeit", "freizeit_start_min": "Startstand Freizeitausgleich",
              "buero_pro_woche": "Büro-Tage pro Woche (Jahr)", "buero_pro_woche_monat": "Büro-Tage pro Woche (Monat)",
              "startwerte": "Startwerte (Erfassung gültig ab)",
              **{NACHWEIS_VORSILBE + feld: "Monatsnachweis: " + name for feld, name in NACHWEIS_FELDER.items()}}

NACHWEIS_WAHL_TEXT = {(NACHWEIS_VORSILBE + "datum", "heute"): "heute", (NACHWEIS_VORSILBE + "datum", "letzter"): "letzter Arbeitstag",
                      (NACHWEIS_VORSILBE + "zweite", "1"): "an", (NACHWEIS_VORSILBE + "zweite", ""): "aus"}


def _hhmm(minuten: int) -> str:
    """Minuten als „HH:MM“."""
    return f"{minuten // 60:02d}:{minuten % 60:02d}"


def titel(art: str, schluessel: str) -> str:
    """Überschrift eines Eintrags für die Konfliktliste, z. B. Wochentag und Datum bei einem Tag."""
    if art == "tag":
        d = date.fromisoformat(schluessel)
        return f"{WT[d.weekday()]} {d:%d.%m.%Y}"
    if art == "jahr":
        return f"Urlaub {schluessel} (Anspruch, Übertrag, freie Tage)"
    if art == "konto":
        return f"Angesparter Urlaub aus {schluessel}"
    if art == "meta":
        if schluessel.startswith(konfig.PROFIL_VORSILBE):
            return "Profil " + schluessel[len(konfig.PROFIL_VORSILBE):]
        if JAHRESWECHSEL_META.fullmatch(schluessel):
            return "Jahreswechsel " + schluessel.split("_")[1]
        if ANSPAREN_AUTO_META.fullmatch(schluessel):
            return "Übertrag beim Ansparen " + schluessel.rpartition("_")[2]
        if RESTURLAUB_BEHALTEN_META.fullmatch(schluessel):
            return "Resturlaub behalten " + schluessel.rpartition("_")[2]
        if KAPPUNG_UEBERNAHME_META.fullmatch(schluessel):
            return "Gleitzeit: genehmigte Übernahme " + schluessel.rpartition("_")[2]
        if EINTRAEGE_SCHLUESSEL.fullmatch(schluessel):
            return "Einträge " + titel("tag", schluessel.rpartition("_")[2])
        return META_NAMEN.get(schluessel) or "Familientage " + schluessel.rpartition("_")[2]
    return "Abschnitte (Teilzeit, Elternzeit)"


EINTRAEGE_UNLESBAR = "keine lesbaren Einträge"


def _eintraege_kurz(v: str) -> str:
    """Einträge eines Tages (JSON-Liste) für die Konfliktliste, z. B. „2 Einträge“; ein kaputter Wert: EINTRAEGE_UNLESBAR."""
    try:
        liste = json.loads(v)
    except (ValueError, RecursionError):
        return EINTRAEGE_UNLESBAR
    if not isinstance(liste, list):
        return EINTRAEGE_UNLESBAR
    return f"{len(liste)} {'Eintrag' if len(liste) == 1 else 'Einträge'}"


def inhalt_text(art: str, schluessel: str, wert) -> str:
    """Der Inhalt eines Eintrags als kurzer deutscher Text für die Konfliktliste; bei gelöschten Einträgen „kein Eintrag (gelöscht)“."""
    if wert is None:
        return "kein Eintrag (gelöscht)"
    if art == "tag":
        teile = [f"Homeoffice {_hhmm(wert['ho'])}"] if wert["ho"] else []
        teile += [f"Büro {_hhmm(wert['dst'])}"] if wert["dst"] else []
        teile += [ARTEN[wert["art"]]] if wert["art"] else []
        teile += [konfig.VERMERKE[wert["vermerk"]]] if wert.get("vermerk") else []     # get: offene Konflikte aus der Zeit vor Format 5
        teile += [f"Notiz „{wert['notiz']}“"] if wert["notiz"] else []
        return ", ".join(teile) or "leer"
    if art == "jahr":
        ueb = "automatisch" if wert["uebertrag"] is None else f"{wert['uebertrag']:g}"
        return f"Anspruch {wert['anspruch']:g} Tage, Übertrag {ueb}, {len(wert['eigene_frei'])} eigene freie Tage"
    if art == "konto":
        return f"{wert['tage']:g} Tage"
    if art == "meta":
        if schluessel == "konfig":
            return "geänderte Regeln"
        if schluessel.startswith(konfig.PROFIL_VORSILBE):
            return _profil_kurz(wert["v"])
        if schluessel.endswith("_start_min") or KAPPUNG_UEBERNAHME_META.fullmatch(schluessel):
            m = int(wert["v"])
            return ("-" if m < 0 else "") + _hhmm(abs(m))
        if EINTRAEGE_SCHLUESSEL.fullmatch(schluessel):
            return _eintraege_kurz(wert["v"])
        if NACHWEIS_META.fullmatch(schluessel):
            return NACHWEIS_WAHL_TEXT.get((schluessel, wert["v"])) or wert["v"] or "leer"
        if schluessel == konfig.STARTWERTE:
            return _startwerte_kurz(wert["v"])
        if JAHRESWECHSEL_META.fullmatch(schluessel):
            return "Schritt erledigt"
        if ANSPAREN_AUTO_META.fullmatch(schluessel):
            n = float(wert["v"])
            return f"automatisch {n:g} {'Tag' if n == 1 else 'Tage'}".replace(".", ",")
        return {"": "automatisch", "0": "aus", "1": "an"}.get(wert["v"], wert["v"]) if not schluessel.startswith("buero_pro_woche") else (wert["v"] or "automatisch")
    return f"{len(wert['liste'])} Abschnitte" if len(wert["liste"]) != 1 else "1 Abschnitt"


PROFIL_UNLESBAR = "Profil (nicht lesbar)"
STARTWERTE_UNLESBAR = "Startwerte (nicht lesbar)"


def _startwerte_kurz(text: str) -> str:
    """Startwerte für die Konfliktliste (R6, OB 6.10), z. B. „ab 16.06.2025: HO 300:00, Büro 240:00, Urlaub 12, Gleittage 3, Krank 4, Kind krank 0,
    Gleitzeit +12:30“; ein Text, den konfig.startwerte_lesen ablehnt, ergibt STARTWERTE_UNLESBAR."""
    try:
        w = konfig.startwerte_lesen(text)
    except (ValueError, TypeError, RecursionError):
        return STARTWERTE_UNLESBAR
    saldo = ("-" if w.gleitzeit_min < 0 else "+") + _hhmm(abs(w.gleitzeit_min))
    return (f"ab {w.ab.strftime('%d.%m.%Y')}: HO {_hhmm(w.ho_min)}, Büro {_hhmm(w.dst_min)}, Urlaub {w.urlaub}, Gleittage {w.gleittage}, "
            f"Krank {w.krank}, Kind krank {w.kind_krank}, Gleitzeit {saldo}")
PROFIL_HO = {"grenze": "Homeoffice bis {} %", "ohne": "Homeoffice ohne Grenze", "kein": "kein Homeoffice", "nur": "nur Homeoffice"}   # Schlüssel wie konfig.HO_MODI


def _profil_kurz(text: str) -> str:
    """Ein eigenes Profil in Kurzform für die Konfliktliste, z. B. „40 Std./Woche, Mo,Di,Mi,Do,Fr, Bayern, Homeoffice bis 80 %“."""
    try:
        w = konfig.profil_lesen(text)["werte"]
    except (ValueError, TypeError, RecursionError):
        return PROFIL_UNLESBAR
    ho = PROFIL_HO[w["ho_modus"]].format(w["ho_grenze"])
    stunden = f"{w['wochenstunden']:g}".replace(".", ",")
    return f"{stunden} Std./Woche, {w['arbeitstage']}, {konfig.BUNDESLAENDER[w['bundesland']]}, {ho}"


def konfliktliste(db) -> list:
    """Die offenen Konflikte für die Oberfläche: je Eintrag Titel, Text und Zeit hier und dort, und welche Seite neuer ist („neuer“, nur ein Vorschlag)."""
    offen = db.konflikte()
    if not offen:                                         # der Normalfall: nicht alle Sätze lesen (Übersicht und Sync-Seite fragen bei jedem Aufruf)
        return []
    eigene, r = db.saetze(), []
    for (art, schluessel), fremd in sorted(offen.items()):
        e = eigene.get((art, schluessel)) or {"wert": None, "zeit": ""}
        r.append({"art": art, "schluessel": schluessel, "titel": titel(art, schluessel),
                  "hier": {"text": inhalt_text(art, schluessel, e["wert"]), "zeit": e["zeit"]},
                  "dort": {"text": inhalt_text(art, schluessel, fremd["wert"]), "zeit": fremd["zeit"]},
                  "neuer": "" if not e["zeit"] or not fremd["zeit"] or e["zeit"] == fremd["zeit"] else HIER if e["zeit"] > fremd["zeit"] else DORT})
    return r


# ---- Ablauf: Dateien der anderen lesen, zusammenführen, eigenen Stand ablegen

def _schluessel_fuer(g: dict, kopf: dict, passwort, abgeleitet: dict = None):
    """Der Schlüssel zur Datei eines anderen Geräts: der eigene (gleiches Salz), ein früher gemerkter oder aus dem Passwort abgeleitet. None = Passwort nötig.
    abgeleitet: (Salz, Runden) -> Schlüssel aus dem Passwort, schon in diesem Lauf gerechnet (N4, 22.11.2026): Eine fremde Ablage mit vielen Dateien
    gleichen Salzes und falscher Probe erzwingt so nur einmal PBKDF2 (bis RUNDEN_MAX Runden), nicht je Datei. Die Probe prüft weiter jede Datei."""
    salz = kopf["salz"].hex()
    if salz == g["salz"]:
        return bytes.fromhex(g["schluessel"]), False
    if salz in g["fremde"]:
        return bytes.fromhex(g["fremde"][salz]), False
    if passwort:
        abgeleitet = {} if abgeleitet is None else abgeleitet
        stand = (kopf["salz"], kopf["runden"])
        try:
            if stand not in abgeleitet:
                abgeleitet[stand] = sicherung.schluessel_ableiten(passwort, *stand)
        except UnicodeError:
            return None, False
        k = abgeleitet[stand]
        if sicherung.probe_stimmt(k, kopf):
            return k, True
    return None, False


def schreib_schluessel_setzen(daten_ordner: str, ziel, passwort, abgeleitet: dict = None) -> None:
    """Kündigt die Ablage ihr Salz an (NetzZiel.ankuendigung), den Schlüssel dazu für den Schreib-Nachweis suchen: eigener, gemerkter oder aus dem
    eingegebenen Passwort (dann gemerkt). Frisch gelesen, weil der Lauf eben Schlüssel dazugelernt haben kann. Ohne Schlüssel bleibt er None."""
    kopf = getattr(ziel, "ankuendigung", None)
    if not kopf:
        return
    k, neu = _schluessel_fuer(sicherung.geraet_lesen(daten_ordner), kopf, passwort, abgeleitet)
    if neu:
        sicherung.fremden_schluessel_merken(daten_ordner, kopf["salz"].hex(), k.hex())
    ziel.schreib_schluessel = k


VOR_SYNC = "vor-abgleich-"
MERKER = ("netz:", "ablage:", "github:")                   # Vorsilben der Merklisten je Ziel; ohne Vorsilbe: der Cloud-Ordner


def vor_sync_sichern(db, daten_ordner: str, behalten: int = 5) -> None:
    """Kopie der Datenbank im Ordner „sicherung“, bevor eine Synchronisierung Einträge eines anderen Geräts einspielt. Jedes Gerät sichert so sich selbst;
    die Kopie steht unter „Wiederherstellen“ zur Wahl. Die letzten fünf bleiben. Scheitert die Sicherung, findet die Synchronisierung nicht statt."""
    ordner = os.path.join(daten_ordner, "sicherung")
    os.makedirs(ordner, exist_ok=True)
    stamm, nr = os.path.join(ordner, f"{VOR_SYNC}{datetime.now():%Y-%m-%d_%H%M%S}"), 1
    pfad = stamm + ".db"
    while os.path.exists(pfad):                              # „Jetzt synchronisieren“ läuft je Ziel einmal, oft in derselben Sekunde: nie den Stand davor überschreiben
        nr += 1
        pfad = f"{stamm}-{nr}.db"
    db._papierkorb_aufraeumen()                              # wie jede Sicherung: Abgelaufenes aus dem Papierkorb nicht mitnehmen
    db._kopieren(db.pfad, pfad)
    alle = [os.path.join(ordner, f) for f in os.listdir(ordner) if f.startswith(VOR_SYNC) and f.endswith(".db")]
    for alt in sorted(alle, key=lambda p: (os.path.getmtime(p), p))[:-behalten]:   # nach Alter, nicht nach Namen: Stand die Uhr einmal in der Zukunft, bliebe sonst die neue nie
        os.remove(alt)


ABGESCHALTET = "Die Synchronisierung ist abgeschaltet (Einstellungen → Module und Profile)."


def modul_setzen(daten_ordner: str, aus_: bool) -> None:
    """Modul „Synchronisierung“ dieses Geräts ein- oder ausschalten. Die Wahl gilt nur hier und wird nicht synchronisiert:
    Schaltet eines von drei Geräten ab, synchronisieren die beiden anderen weiter (Wunsch vom 17.11.2026)."""
    if bool(sicherung.geraet_lesen(daten_ordner)["abgleich_aus"]) != bool(aus_):
        sicherung.geraet_aendern(daten_ordner, **{"abgleich_aus": bool(aus_), "abgleich_abgemeldet": False, "abgleich_allein": False, "abgleich_partner": False, "abgleich_zaehlung": {}})


def aus(daten_ordner: str) -> bool:
    """Modul „Synchronisierung“ abgeschaltet: Dann findet auf diesem Gerät keine Synchronisierung mehr statt, weder von Hand noch automatisch noch als Speicherort.
    Vorher geht genau eine letzte Synchronisierung hinaus (letzter_offen): Darin meldet sich das Gerät ab, damit die anderen richtig zählen."""
    if not daten_ordner:
        return False
    g = sicherung.geraet_lesen(daten_ordner)
    return bool(g["abgleich_aus"]) and (bool(g["abgleich_abgemeldet"]) or not g["schluessel"])   # ohne Passwort war nie ein Sync eingerichtet: nichts zu melden


def letzter_offen(daten_ordner: str) -> bool:
    """Ist das Modul abgeschaltet, aber die letzte Synchronisierung (zum Abmelden) noch nicht gelaufen?"""
    return bool(daten_ordner) and bool(sicherung.geraet_lesen(daten_ordner)["abgleich_aus"]) and not aus(daten_ordner)


def abmelden(daten_ordner: str) -> None:
    """Die letzte Synchronisierung ist durch: ab jetzt keiner mehr."""
    if sicherung.geraet_lesen(daten_ordner)["abgleich_aus"]:
        sicherung.geraet_aendern(daten_ordner, **{"abgleich_abgemeldet": True})


ABMELDEN_WARTEN = 3.0                                      # Sekunden je Anfrage an Server und GitHub beim Abmelden vor den Werkseinstellungen
ABMELDEN_GESAMT = 15.0                                     # Sekunden für die ganze Abmeldung: danach kein weiteres Ziel (ein Sync stellt viele Anfragen)
ABMELDEN_FEHLER = "Werkseinstellungen: Abmelden:"


def abmelden_versuchen(db, daten_ordner: str, ziele_holen) -> None:
    """Werkseinstellungen: eine letzte Synchronisierung mit abgemeldet=True an jedes eingetragene Ziel (ziele_holen(warten) -> Liste), damit die anderen
    Geräte dieses nicht weiter zählen. Nur ein Versuch: Jeder Fehler wird geschluckt und nur mit seiner Art protokolliert (Pfade und Adressen
    gehören nicht ins Protokoll); das Zurücksetzen danach läuft immer. Ohne eingerichteten Synchronisierung (kein Passwort, schon abgemeldet) kein Versuch.
    Nach ABMELDEN_GESAMT Sekunden kein weiteres Ziel; in der Web-App ohne Server (Pyodide) nur Ordner-Ziele."""
    if aus(daten_ordner) or not sicherung.geraet_lesen(daten_ordner)["schluessel"]:
        return
    frist = time.monotonic() + ABMELDEN_GESAMT
    try:
        ziele = ziele_holen(ABMELDEN_WARTEN)
        sicherung.geraet_aendern(daten_ordner, **{"abgleich_aus": True})          # wie „Modul aus“: der folgende Sync trägt abgemeldet=True
    except Exception as e:
        print(ABMELDEN_FEHLER, type(e).__name__, flush=True)
        return
    if sys.platform == "emscripten":                         # die Anfrage im Browser hat keine Zeitgrenze: ein hängender Server hielte das Zurücksetzen auf
        ziele = [z for z in ziele if not isinstance(z, (sicherung.NetzZiel, sicherung.GitHubZiel))]
    for ziel in ziele:
        if time.monotonic() > frist:
            print(ABMELDEN_FEHLER, "Frist abgelaufen", flush=True)
            return
        try:
            synchronisieren(db, daten_ordner, ziel)
        except Exception as e:                               # ein Ziel, das nicht antwortet, hält die anderen und das Zurücksetzen nicht auf
            print(ABMELDEN_FEHLER, type(e).__name__, flush=True)


def _abgemeldet(inhalt: bytes) -> bool:
    """Steht in der Datei eines Geräts, dass es sich abgemeldet hat? Bei unlesbarem Inhalt False."""
    try:
        return json.loads(inhalt.decode("utf-8")).get("abgemeldet") is True
    except (ValueError, AttributeError):
        return False


def _zaehlung(g: dict) -> dict:
    """Die gemerkte Zählung je Ziel aus der Gerätedatei; ein falscher Typ (beschädigte geraet.json) gilt wie keine Zählung."""
    z = g.get("abgleich_zaehlung")
    return z if isinstance(z, dict) else {}


def _geraete(eintrag, feld: str) -> set:
    """Die Gerätenamen unter „feld“ eines Zählungseintrags; Unbrauchbares (kein Objekt, keine Liste, kein Text) zählt nicht."""
    namen = eintrag.get(feld) if isinstance(eintrag, dict) else None
    return {n for n in namen if isinstance(n, str)} if isinstance(namen, list) else set()


def zaehlen(g: dict) -> tuple:
    """-> (Geräte, die außer diesem noch synchronisieren; Geräte, die sich abgemeldet haben), über alle Ziele, jedes Gerät einmal.
    Eine beschädigte Zählung in der Gerätedatei zählt wie keine, damit die Seite „Synchronisieren“ nicht dauerhaft mit 500 scheitert."""
    z = _zaehlung(g).values()
    aktiv = set().union(*(_geraete(v, "aktiv") for v in z))
    weg = set().union(*(_geraete(v, "weg") for v in z)) - aktiv
    return aktiv, weg


# Ein Sync zur Zeit: Automatik, Zurückkehren in die App und „Jetzt synchronisieren“ teilen sich Stand und Dateien.
# Reihenfolge der Schlösser, überall gleich: erst _SCHLOSS, dann db.lock, dann sicherung._schloss. Wer db.lock hält, wartet nie auf _SCHLOSS
# (sonst Verklemmung mit der Automatik). RLock: Die Routen /api/abgleich* halten es und rufen darin synchronisieren.
_SCHLOSS = threading.RLock()


def synchronisieren(db, daten_ordner: str, ziel, passwort: str = None, jetzt: datetime = None) -> dict:
    """Nacheinander, nie gleichzeitig (sonst überschreibt ein Lauf die Merkliste des anderen, GitHub meldet 409, unter Windows scheitert os.replace)."""
    with _SCHLOSS:
        return _synchronisieren(db, daten_ordner, ziel, passwort, jetzt)


def _hoehere_version(bisher: str, fremd) -> str:
    """Die höhere von zwei App-Versionen (funktionen.md 8.3). „fremd“ kommt aus dem Kopf einer fremden Datei und zählt nur in der Form
    JJJJMMTT.HHMM (update.VERSION_FORM, gleich lang, also als Text vergleichbar); sonst bleibt „bisher“."""
    if isinstance(fremd, str) and update.VERSION_FORM.fullmatch(fremd) and fremd > (bisher or ""):
        return fremd
    return bisher


def _uebersprungen_gemerkt(g: dict) -> dict:
    """Die gemerkten Zähler übersprungener Sätze je Datei (geraet.json sync_uebersprungen, U1). Unbrauchbares (beschädigte Datei) fällt weg:
    Ein Zähler gilt nur mit Abdruck als Text und einer ganzen Zahl von 1 bis MAX_SAETZE (mehr Sätze hat keine Datei)."""
    z = g.get("sync_uebersprungen")
    if not isinstance(z, dict):
        return {}
    return {k: v for k, v in z.items() if isinstance(v, dict) and isinstance(v.get("abdruck"), str) and type(v.get("zahl")) is int and 0 < v["zahl"] <= MAX_SAETZE}


def _synchronisieren(db, daten_ordner: str, ziel, passwort: str = None, jetzt: datetime = None) -> dict:
    """Eine Synchronisierung in zwei Durchgängen (funktionen.md 8.3): erst alle Dateien der anderen Geräte lesen und prüfen, dann zusammenführen.
    Kommt eine Datei aus einer neueren App (ZU_NEU), wird nichts zusammengeführt und die eigene Datei nicht abgelegt; andere Fehler gelten je Datei.
    Schreibt das Ergebnis in den Stand des Geräts (auch bei Fehlern) und gibt es zurück. SicherungFehler/SyncFehler mit Text für die Oberfläche."""
    if aus(daten_ordner):
        raise SyncFehler(ABGESCHALTET)
    zeit = (jetzt or datetime.now()).isoformat(timespec="seconds")
    g = sicherung.geraet_lesen(daten_ordner)
    try:
        if not g["schluessel"]:
            raise sicherung.SicherungFehler(sicherung.KEIN_PASSWORT)
        if ziel is None:
            raise sicherung.SicherungFehler(sicherung.KEIN_ZIEL)
        eigener, salz, runden = bytes.fromhex(g["schluessel"]), bytes.fromhex(g["salz"]), g["runden"]   # zusammen festhalten: g kann sich im Lauf ändern
        ergebnis = {"zeit": zeit, "ok": True, "fehler": "", "geraete": 0, "uebernommen": 0, "gesperrt": 0, "uebersprungen": 0}
        merk = getattr(ziel, "merk", "")                     # zweites Ziel (eigener Server): eigene Merkliste, damit sich Ordner und Server nicht gegenseitig vergessen
        fehler, eigene_datei = "", sicherung.sync_name(g["geraet"])
        gesichert = False
        eigener_stand = getattr(ziel, "eigener_stand", False)
        dieses_ziel = lambda k: k.startswith(merk) if merk else not k.startswith(MERKER)
        gelesen = {k: v for k, v in g["abgleich_gelesen"].items() if not dieses_ziel(k)}   # die Merkliste der anderen Ziele bleibt
        uebersprungen_alt = _uebersprungen_gemerkt(g)
        uebersprungen = {k: v for k, v in uebersprungen_alt.items() if not dieses_ziel(k)}   # ebenso; die dieses Ziels entstehen je Lauf neu
        abgeleitet = {}                                       # (Salz, Runden) -> Schlüssel aus dem Passwort, je Lauf einmal gerechnet (_schluessel_fuer)
        gepruefte, zu_neu = [], False                         # Durchgang 1: (Name, Abdruck, Sätze) jeder neuen Datei, die sich lesen lässt
        aktiv, weg = set(), set()                             # Geräte an diesem Ziel: synchronisieren noch / haben sich abgemeldet
        neueste_app = g["sync_app_neueste"]                   # Dateien im Zweig „unverändert“ werden nicht geöffnet: deshalb nie zurücksetzen, nur erhöhen
        geraete = _gemerkte_geraete(g)                        # Stand und App-Version der anderen Geräte für die Liste der Karte
        try:
            namen = sorted(ziel.sync_namen())
            for name in namen:
                if name == eigene_datei:
                    continue
                try:
                    roh = ziel.lesen(name)
                    abdruck = hashlib.sha256(roh).hexdigest()
                    if g["abgleich_gelesen"].get(merk + name) == abdruck:          # unverändert seit dem letzten Sync: nichts Neues darin
                        gelesen[merk + name] = abdruck
                        ergebnis["geraete"] += 1
                        (weg if merk + name in g["abgleich_weg"] else aktiv).add(name)
                        alt = uebersprungen_alt.get(merk + name)
                        if alt and alt["abdruck"] == abdruck:                          # U1: der Hinweis bleibt, solange die Datei gleich ist
                            uebersprungen[merk + name] = alt
                            ergebnis["uebersprungen"] += alt["zahl"]
                        if name not in geraete and (kopf := _kopf_ansehen(g, roh)):     # gelesen vor dieser Liste: Angaben einmal nachholen
                            geraete[name] = _geraet_angaben(kopf)
                        continue
                    k, neu = _schluessel_fuer(g, sicherung.kopf_lesen(roh), passwort, abgeleitet)
                    if k is None:
                        ergebnis["gesperrt"] += 1
                        aktiv.add(name)
                        continue
                    kopf, inhalt = sicherung.auspacken(roh, schluessel=k)
                    neueste_app = _hoehere_version(neueste_app, kopf.get("app"))
                    geraete[name] = _geraet_angaben(kopf)
                    if neu:                                       # das Passwort passt: Schlüssel gleich merken, auch wenn der Inhalt danach scheitert
                        g = sicherung.fremden_schluessel_merken(daten_ordner, sicherung.kopf_lesen(roh)["salz"].hex(), k.hex())
                    if kopf["art"] != "abgleich":
                        raise SyncFehler(UNGUELTIG)
                    gepruefte.append((name, abdruck, paket_lesen(inhalt)))
                    (weg if _abgemeldet(inhalt) else aktiv).add(name)
                except (sicherung.SicherungFehler, SyncFehler) as e:      # eine kaputte Datei hält die anderen nicht auf
                    fehler = str(e) if isinstance(e, SyncFehler) else UNGUELTIG
                    zu_neu = zu_neu or fehler == ZU_NEU
            if zu_neu:                                        # nichts zusammenführen, ablegen oder als gelesen merken: Nach dem Update liest der nächste Lauf alles neu
                ergebnis.update(ok=False, fehler=ZU_NEU)
                sicherung.geraet_aendern(daten_ordner, **{"abgleich": ergebnis, "sync_app_neueste": neueste_app})
                return ergebnis
            for name, abdruck, fremd in gepruefte:            # Durchgang 2
                if not gesichert:                             # bevor fremde Einträge hereinkommen: den Stand dieses Geräts sichern (je Lauf einmal)
                    vor_sync_sichern(db, daten_ordner)
                    gesichert = True
                r = zusammenfuehren(db, fremd)
                gelesen[merk + name] = abdruck
                ergebnis["geraete"] += 1
                ergebnis["uebernommen"] += r["uebernommen"]
                if r["uebersprungen"]:
                    uebersprungen[merk + name] = {"abdruck": abdruck, "zahl": r["uebersprungen"]}
                    ergebnis["uebersprungen"] += r["uebersprungen"]
            zaehlung = {**{k: v for k, v in _zaehlung(g).items() if isinstance(v, dict)}, merk: {"aktiv": sorted(aktiv), "weg": sorted(weg)}}
            alle_aktiv, alle_weg = zaehlen({"abgleich_zaehlung": zaehlung})
            # Allein übrig: Alle anderen haben sich abgemeldet. Dann hört auch dieses Gerät auf und meldet sich mit diesem Sync selbst ab.
            # Nur wer seit dem Einschalten schon einen Partner hatte: Sonst schaltete sich das erste Gerät, das wieder einschaltet, sofort wieder ab.
            allein = not g["abgleich_aus"] and g["abgleich_partner"] and not alle_aktiv and bool(alle_weg) and not fehler
            eigenes = paket(db, abgemeldet=bool(g["abgleich_aus"]) or allein)
            abdruck = hashlib.sha256(eigenes).hexdigest()
            veraltet = g["abgleich_format"] != sicherung.FORMAT                  # die eigene Datei liegt noch im alten Format im Ordner (Stand vor einem Update)
            if eigener_stand:                                                     # GitHub: was dort liegt, steht in der Merkliste dieses Ziels (ein anderes Ziel ändert daran nichts)
                schreiben = abdruck != g["abgleich_gelesen"].get(merk + eigene_datei) or eigene_datei not in namen
            else:
                schreiben = abdruck != g["abgleich_inhalt"] or eigene_datei not in namen or veraltet or getattr(ziel, "immer_ablegen", False)
            abgewiesen = False
            if schreiben:                                                         # sonst nicht schreiben (jede Datei kostet einen Upload)
                schreib_schluessel_setzen(daten_ordner, ziel, passwort, abgeleitet)
                try:
                    ziel.ablegen(eigene_datei, sicherung.packen(eigenes, "abgleich", eigener, salz, runden, g["geraet"], zeit))
                except sicherung.NachweisFehler as e:                          # die Ablage kennt dieses Gerät nicht: melden, „gesperrt“ bleibt (Passwortfrage)
                    fehler, abgewiesen = str(e), True
            if eigener_stand:
                if not abgewiesen:                                                # abgewiesen liegt dort der alte Stand: der nächste Lauf schreibt neu
                    gelesen[merk + eigene_datei] = abdruck
                ergebnis_merken = {"abgleich_gelesen": gelesen}
            else:
                ergebnis_merken = {"abgleich_gelesen": gelesen, **({} if abgewiesen else {"abgleich_inhalt": abdruck, "abgleich_format": sicherung.FORMAT})}
            weg_liste = [k for k in g["abgleich_weg"] if not dieses_ziel(k)] + [merk + n for n in sorted(weg)]
            ergebnis_merken.update(**{"abgleich_zaehlung": zaehlung, "abgleich_weg": weg_liste, "sync_app_neueste": neueste_app,
                                      "sync_uebersprungen": uebersprungen, "sync_geraete": geraete}, **({"abgleich_partner": True} if alle_aktiv else {}),
                                   **({"abgleich_aus": True, "abgleich_allein": True} if allein else {}))
        except OSError as e:
            raise sicherung.SicherungFehler(sicherung.ziel_fehler(e))
        if passwort and ergebnis["gesperrt"] and not fehler:      # eingegeben, aber es öffnet die Datei eines anderen Geräts nicht: sagen statt still zu warten
            fehler = PASSWORT_FALSCH
        if fehler:
            ergebnis.update(ok=False, fehler=fehler)
    except ValueError as e:
        sicherung.geraet_aendern(daten_ordner, **{"abgleich": {"zeit": zeit, "ok": False, "fehler": fehlertext(e), "geraete": 0, "uebernommen": 0, "gesperrt": 0, "uebersprungen": 0}})
        raise
    sicherung.geraet_aendern(daten_ordner, **{"abgleich": ergebnis}, **ergebnis_merken)
    return ergebnis


AUTOMATIK_ABSTAND = timedelta(minutes=15)                  # so oft sieht die Automatik nach Änderungen der anderen Geräte (Wunsch vom 18.11.2026);
                                                           # eigene Änderungen gehen sofort hinaus, beim Zurückkehren in die App synchronisiert die Oberfläche selbst


def automatik_schritt(db, daten_ordner: str, ziel, jetzt: datetime, zustand: tuple):
    """Ein Blick der Automatik. zustand = (Datenstand bei der letzten Synchronisierung, Zeit des letzten Versuchs). -> (neuer Zustand, Ergebnis oder None).
    Synchronisiert wird, wenn hier etwas geändert wurde, sonst alle 15 Minuten. Fehler stehen im Stand und erscheinen in der Oberfläche."""
    gesehen, zuletzt = zustand
    if aus(daten_ordner):
        return zustand, None
    g = sicherung.geraet_lesen(daten_ordner)
    if ziel is None or not g["abgleich_auto"] or not g["schluessel"]:
        return zustand, None
    if db.gen == gesehen and zuletzt is not None and jetzt - zuletzt < AUTOMATIK_ABSTAND:
        return zustand, None
    try:
        ergebnis = synchronisieren(db, daten_ordner, ziel, jetzt=jetzt)
    except ValueError as e:
        ergebnis = {"ok": False, "fehler": fehlertext(e)}
    return (db.gen, jetzt), ergebnis


def stand(db, daten_ordner: str, ziel) -> dict:
    """Für die Oberfläche: keine Pfade, kein Schlüssel."""
    g = sicherung.geraet_lesen(daten_ordner)
    return {"ziel": {"eingerichtet": ziel is not None, "art": ziel.art if ziel is not None else ""}, "passwort": bool(g["schluessel"]),
            "auto": bool(g["abgleich_auto"]), "letzter": g["abgleich"], "konflikte": konfliktliste(db),
            "modul_aus": bool(g["abgleich_aus"]), "letzter_offen": letzter_offen(daten_ordner), "allein": bool(g["abgleich_allein"]),
            "geraete_aktiv": len(zaehlen(g)[0]) + (0 if g["abgleich_aus"] else 1), "geraete_weg": len(zaehlen(g)[1]), "andere_geraete": andere_geraete(g),
            "veraltet_tage": VERALTET_TAGE}                    # die Oberfläche nennt die Grenze nur von hier


def _gemerkte_geraete(g: dict) -> dict:
    """Die gemerkten Angaben der anderen Geräte (Name der Sync-Datei -> {"erstellt", "app"}); Unbrauchbares aus einer beschädigten geraet.json fällt weg."""
    z = g.get("sync_geraete")
    return {n: v for n, v in z.items() if isinstance(v, dict)} if isinstance(z, dict) else {}


def _geraet_angaben(kopf: dict) -> dict:
    """Stand („erstellt“) und App-Version aus dem Kopf einer fremden Sync-Datei, jeweils nur in gültiger Form, sonst leer."""
    erstellt, app = kopf.get("erstellt"), kopf.get("app")
    return {"erstellt": erstellt if isinstance(erstellt, str) and ZEIT_FORM.fullmatch(erstellt) else "",
            "app": app if isinstance(app, str) and update.VERSION_FORM.fullmatch(app) else ""}


def _kopf_ansehen(g: dict, roh: bytes):
    """Der innere Kopf einer fremden Datei, wenn ein schon bekannter Schlüssel sie öffnet (ohne Passwort, ohne Ableitung); sonst None."""
    try:
        k, _ = _schluessel_fuer(g, sicherung.kopf_lesen(roh), None)
        return sicherung.auspacken(roh, schluessel=k)[0] if k else None
    except sicherung.SicherungFehler:
        return None


def andere_geraete(g: dict) -> list:
    """Die anderen Geräte in der Synchronisierung für die Karte: Name der Sync-Datei, Kennung kurz, letzter Stand, App-Version, abgemeldet,
    veraltet (seit VERALTET_TAGE nichts geschrieben: Vorschlag zum Entfernen). Ohne Pfade und Schlüssel."""
    aktiv, weg = zaehlen(g)
    angaben = _gemerkte_geraete(g)
    grenze = (datetime.now() - timedelta(days=VERALTET_TAGE)).isoformat(timespec="seconds")
    liste = []
    for name in sorted(aktiv | weg):
        treffer = sicherung.SYNC_NAME.fullmatch(name)
        if treffer:
            a = _geraet_angaben(angaben.get(name, {}))
            liste.append({"name": name, "kurz": treffer[1][:6], **a, "abgemeldet": name in weg, "veraltet": bool(a["erstellt"]) and a["erstellt"] < grenze})
    return liste


def entfernen(daten_ordner: str, ziele: list, name, passwort: str = None) -> int:
    """Nimmt ein anderes Gerät aus der Synchronisierung (seit 22.11.2026, z. B. nach einer Neuinstallation): löscht nur seine Sync-Datei in jedem Ziel
    und vergisst es in der Gerätedatei. Einträge bleiben auf allen Geräten. Nur Dateien im Format dieser App; geprüft wird in allen Zielen, bevor
    eins gelöscht wird. Rückgabe: Zahl der gelöschten Dateien. SyncFehler für das eigene oder ein unbekanntes Gerät, SicherungFehler für eine
    fremde Datei oder ein abgewiesenes Löschen (mit Grund), OSError, wenn ein Ziel beim Lesen nicht erreichbar ist. Schreibt das Gerät später wieder, ist es wieder dabei."""
    with _SCHLOSS:
        g = sicherung.geraet_lesen(daten_ordner)
        if not isinstance(name, str) or not sicherung.SYNC_NAME.fullmatch(name):
            raise SyncFehler(GERAET_UNBEKANNT)
        if name == sicherung.sync_name(g["geraet"]):
            raise SyncFehler(EIGENES_GERAET)
        mit_datei = [z for z in ziele if name in z.sync_namen()]
        aktiv, weg = zaehlen(g)
        if not mit_datei and name not in aktiv | weg:
            raise SyncFehler(GERAET_UNBEKANNT)
        for ziel in mit_datei:
            sicherung.kopf_lesen(ziel.lesen(name))               # keine Datei dieser App: nichts löschen
        try:
            for ziel in mit_datei:
                schreib_schluessel_setzen(daten_ordner, ziel, passwort)
                ziel.loeschen(name)
        except OSError as e:                                     # GitHub, Anmeldung, Nachweis: den Grund nennen statt „nicht erreichbar“
            raise sicherung.SicherungFehler(sicherung.ziel_fehler(e))
        _vergessen(daten_ordner, name)
        return len(mit_datei)


def _vergessen(daten_ordner: str, name: str) -> None:
    """Streicht ein entferntes Gerät aus Zählung und Merklisten der Gerätedatei (Schlüssel der Merklisten: Vorsilbe des Ziels und Name)."""
    g = sicherung.geraet_lesen(daten_ordner)
    sicherung.geraet_aendern(daten_ordner, **{
        "abgleich_zaehlung": {k: {f: sorted(_geraete(v, f) - {name}) for f in ("aktiv", "weg")} for k, v in _zaehlung(g).items() if isinstance(v, dict)},
        "abgleich_gelesen": {k: v for k, v in g["abgleich_gelesen"].items() if not k.endswith(name)},
        "abgleich_weg": [k for k in g["abgleich_weg"] if not k.endswith(name)],
        "sync_uebersprungen": {k: v for k, v in _uebersprungen_gemerkt(g).items() if not k.endswith(name)},
        "sync_geraete": {k: v for k, v in _gemerkte_geraete(g).items() if k != name}})
