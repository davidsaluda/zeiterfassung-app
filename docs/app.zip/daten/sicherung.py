# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Verschlüsselte Sicherung für die Handy-Fassung (HO_PLATTFORM=android) und die Web-App ohne Server (browser). Die Web-App auf einem Server benutzt dieses Modul nicht.

Die App selbst öffnet keine Verbindung: Sie legt die verschlüsselte Datei in einen Ordner (HO_SICHERUNG_ZIEL). Diesen Ordner bringt das Gerät
in die Cloud (unter Android überträgt die App-Hülle den Ordner in den gewählten Drive-Ordner).

Dateiformat „.zsich“, Version 2 (alle Zahlen Big-Endian):
    8  Kennung  b"ZEITSICH"
    1  Version des Formats (2)
    1  Schlüsselableitung (1 = PBKDF2-HMAC-SHA-256)
    4  Runden der Schlüsselableitung
   16  Salz
   16  Einmalwert (für jede Datei neu gewürfelt; AES-GCM benutzt die ersten 12 Byte)
    8  Passwort-Probe (damit „falsches Passwort“ und „Datei beschädigt“ unterscheidbar sind)
    n  Inhalt, verschlüsselt mit AES-256-GCM
   16  Prüfmarke von AES-GCM über Kopf und Inhalt
Inhalt vor dem Verschlüsseln: zlib( 4 Byte Länge + JSON-Kopf {"art", "erstellt", "app", "geraet"} + Nutzdaten ). „art“ ist heute „sqlite“
(die ganze Datenbank); die Synchronisierung zwischen Geräten benutzt denselben Umschlag mit einer eigenen Art.

Verschlüsselung seit Version 2: AES-256-GCM aus der Bibliothek OpenSSL, die Python mitbringt (aes.py); nur in der Web-App (Pyodide 314, ohne OpenSSL)
rechnet stattdessen pycryptodome, mit denselben Ergebnissen. Aus dem Passwort
entstehen mit PBKDF2 64 Byte: Die ersten 32 sind der AES-Schlüssel, die zweiten 32 dienen nur der Passwort-Probe. Die Prüfmarke schützt auch den
lesbaren Kopf. Geschrieben wird nur noch Version 2.
Version 1 (bis App 20261116.0410) wird weiter gelesen: derselbe Kopf, der Inhalt mit einem Schlüsselstrom aus HMAC-SHA-256 im Zählermodus
verschlüsselt (erste Schlüsselhälfte), am Ende statt der Prüfmarke 32 Byte HMAC-SHA-256 über alles davor (zweite Schlüsselhälfte).
Das Passwort wird nie gespeichert. Für die automatische Sicherung liegt nur der abgeleitete Schlüssel in geraet.json im Datenordner dieses Geräts;
diese Datei gehört in keine Cloud-Sicherung."""
import errno
import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import secrets
import struct
import sys
import tempfile
import threading
import time
import unicodedata
import zlib
from datetime import datetime, timedelta

from daten import aes
from daten import konfig
from urheber import VERSION

KENNUNG = b"ZEITSICH"
FORMAT = 2                                                 # geschrieben wird nur dieses; gelesen werden 1 und 2
FORMAT_HMAC = 1                                            # bis App 20261116.0410
ABLEITUNG_PBKDF2 = 1
RUNDEN = 600_000
RUNDEN_MIN, RUNDEN_MAX = 100_000, 1_200_000                 # beim Lesen: weniger wäre zu schwach, mehr würde das Gerät lahmlegen
KOPF = struct.Struct(">8sBBI16s16s8s")
MARKE = {FORMAT_HMAC: 32, FORMAT: aes.MARKE}               # Länge der Prüfsumme am Ende, je Format
MAX_KLAR = 64 * 1024 * 1024                                 # größter entpackter Inhalt (Schutz vor einer präparierten Datei)
MAX_DATEI = MAX_KLAR + 1024 * 1024                          # größte Datei: gepackt nie größer als der Inhalt plus Kopf und Rand
ENDUNG = ".zsich"
NAME = re.compile(r"zeiterfassung-(\d{4}-\d{2}-\d{2})_(\d{2})(\d{2})(\d{2})-([0-9a-f]{6})(?:-\d{1,3})?\.zsich")
SYNC_NAME = re.compile(r"abgleich-([0-9a-f]{16})\.zsich")   # der Stand eines Geräts für den Sync (sync.py), je Gerät eine Datei
LOESCH_INHALT = b""                                           # Inhalt im Schreib-Nachweis beim Löschen: keine echte Sync-Datei ist leer (kopf_lesen)
SUMME = re.compile(r"[0-9a-f]{64}")                         # SHA-256 als Hex, wie die Liste der Ablage sie nennt
RHYTHMEN = ("taeglich", "woechentlich", "aenderung")
ZIEL_ARTEN = ("drive", "lokal", "browser")     # browser: Speicher der Seite, die Person speichert die Datei selbst
BEHALTEN_MIN, BEHALTEN_MAX = 1, 30
PASSWORT_MIN, PASSWORT_MAX = 8, 200
NEUER_VERSUCH = timedelta(minutes=15)                       # nach einem Fehler nicht jede Minute wieder versuchen
GESAMT_WARTEN = 3                                           # eine Antwort darf so viele Wartezeiten dauern (urllib begrenzt nur jeden einzelnen Lesezugriff)
LESE_STUECK = 64 * 1024
GERAET_DATEI = "geraet.json"
GITHUB_API = "https://api.github.com"                       # seit 20261117, Auftrag: die einzige fremde Adresse der App, nur für GitHubZiel
GITHUB_REPO = re.compile(r"[A-Za-z0-9][A-Za-z0-9-]{0,38}/(?!\.{1,2}$)[A-Za-z0-9._-]{1,100}")     # Konto/Repo, nie ein Pfad
GITHUB_TOKEN = re.compile(r"[A-Za-z0-9_]{20,255}")
# Jedes GET mit bedingtem Kopf: Der Browser nimmt dann nie seinen Zwischenspeicher (GitHub erlaubt bis 60 s), sonst fehlte nach einem Ablegen die neue
# Kennung (PUT ohne sha, Fehler 422). If-None-Match statt „Cache-Control: no-cache“: Nur ihn lässt GitHub im Browser zu (CORS). Passt nie zu einem ETag.
GITHUB_FRISCH = '"frisch"'
GITHUB_KENNUNG_ALT = (409, 422)                              # PUT mit veralteter bzw. ohne Kennung
ABLAGE_PFAD = "/api/ablage"
ANMELDEDIENST_GERAET = "/pfoertner/geraet"                 # seit 18.11.2026: Geräte-Anmeldung am Anmeldedienst; alter Weg, den jeder Dienst kennt
# An jeder 401 des Anmeldedienstes: „anmeldung“ oder „geraet-ungueltig“; neuer Name zuerst, ein Dienst vor 19.11.2026 schickt nur den alten
ANMELDEDIENST_KOEPFE = ("X-Zeiterfassung-Anmeldedienst", "X-Zeiterfassung-Pfoertner")
ABLAGE_SCHLUESSEL = re.compile(r"[A-Za-z0-9_-]{43}")       # secrets.token_urlsafe(32) des Anmeldedienstes
ANMELDUNG_RUHT = ("anmeldung", "geraet-ungueltig")         # die Automatik fragt den Server erst nach einer neuen Anmeldung wieder
GERAETE_NAME_MAX = 60
SERVER_STATT_KOPPELN = ("Dieses Gerät synchronisiert schon mit deinem eigenen Server. Koppeln würde diese Verbindung samt Anmeldung ersetzen. "
                        "Leere erst die Adresse des eigenen Servers oder kopple trotzdem.")   # beim Koppeln Status 409; die Oberfläche fragt mit „Trotzdem koppeln“ nach (U25)
NUR_DIESES_GERAET = "127."                                  # über http nur an dieses Gerät selbst: da hört niemand mit
FREIGABE_PORT = 8793                                       # Anschluss, auf dem eine lokale App als Speicherort für andere Geräte lauscht (nur die Ablage)
FRUEHERE_KOPPLUNG = re.compile(rf"http://\d{{1,3}}(\.\d{{1,3}}){{3}}:{FREIGABE_PORT}")   # so schreibt das Koppeln die Adresse (IPv4 aus dem Code)
_schloss = threading.RLock()                               # Lesen, Ändern und Schreiben der Gerätedatei gehören zusammen


class SicherungFehler(konfig.Meldung):
    """Fehler mit einem Text, den die Oberfläche unverändert zeigen darf (keine Pfade, keine Technik)."""


KEINE_SICHERUNG = "Die Datei ist keine verschlüsselte Sicherung dieser App (.zsich)."
NUR_IP = "Die Gegenstelle nimmt diese Adresse nicht an. Bei einem Gerät als Speicherort die IP eintragen, so wie das Gerät sie anzeigt (http://<IP>:8793), keinen Gerätenamen."
ZU_NEU = "Diese Sicherung stammt aus einer neueren Version der App. Bitte die App aktualisieren und es dann noch einmal versuchen."
BESCHAEDIGT = "Die Sicherung ist beschädigt (unvollständig übertragen oder verändert). Bitte eine andere Sicherung wählen."
FALSCHES_PASSWORT = "Das Passwort passt nicht zu dieser Sicherung."
PASSWORT_NOETIG = "Für diese Sicherung wird das Passwort gebraucht, mit dem sie angelegt wurde."
KEIN_PASSWORT = "Erst ein Passwort für die Sicherung festlegen."
KEIN_ZIEL = "Auf diesem Gerät ist kein Sicherungsziel eingerichtet."
ZIEL_WEG = "Das Sicherungsziel ist nicht erreichbar. Es wurde nichts gesichert. Die Daten in der App sind unverändert."
GITHUB_WEG = "GitHub ist von diesem Gerät aus nicht erreichbar (Netz, Namensauflösung oder Zeitüberschreitung). Es wurde nichts gesichert. Die Daten in der App sind unverändert."
GITHUB_TOKEN_NEIN = "GitHub lehnt das Token ab oder es darf in dieses Repo nicht schreiben. Das Token braucht für dieses Repo die Berechtigung „Contents: Read and write“ und darf nicht abgelaufen sein."
ZIEL_VOLL = "Im Sicherungsziel ist kein Speicherplatz mehr frei. Es wurde nichts gesichert. Die Daten in der App sind unverändert."
OHNE_AES = "Auf diesem Gerät fehlt die Verschlüsselung AES. Es wurde nichts gesichert und nichts gelesen. Die Daten in der App sind unverändert."
ANMELDUNG_NOETIG = "Der Server verlangt eine Anmeldung: Benutzername und Passwort eintragen"
ANMELDUNG_FALSCH = "Benutzername oder Passwort stimmen nicht. Neues Konto? Dann das Passwort zuerst im Browser am Server festlegen."
ANMELDUNG_GESPERRT = "Zu viele Versuche. Die Anmeldung ist für eine Weile gesperrt. Bitte später noch einmal versuchen."
GERAET_UNGUELTIG = "Der Server kennt dieses Gerät nicht mehr (abgemeldet oder Passwort geändert). Bitte neu anmelden."
KONTO_NICHT_BEREIT = "Dieses Konto kann gerade kein Gerät anmelden (gesperrt oder noch ohne Passwort). Bitte erst im Browser am Server anmelden."
ZERTIFIKAT = "Zertifikat des Servers nicht vertraut. Bitte das Zertifikat der eigenen Zertifikatsstelle im Gerät eintragen. Ohne Anmeldung geht auch die Adresse mit http, IP und Port."
NUR_HTTPS = "Mit Anmeldung nur über https. Bitte die Adresse des Servers mit https angeben und neu anmelden."
ANMELDE_TEXTE = {"anmeldung": ANMELDUNG_NOETIG, "geraet-ungueltig": GERAET_UNGUELTIG, "gesperrt": ANMELDUNG_GESPERRT, "zertifikat": ZERTIFIKAT}
ABLAGE_NACHWEIS = ("Die Ablage nimmt die Datei dieses Geräts nur an, wenn es das Passwort kennt, das dort festgelegt ist. "
                   "Bitte hier einmal das Passwort eingeben (dasselbe wie dort).")       # seit 21.11.2026 (Befund klein 5): Status 403 der Ablage
NACHWEIS_KENNUNG = "ablage_nachweis"                        # „kennung“ im 403 der Ablage: daran erkennt das Gerät die Abweisung, nicht am Wortlaut
NACHWEIS_ZWECK = b"zeiterfassung-ablage-schreiben"           # eigener Zweck des Schlüssels: nie gleich der Passwort-Probe oder der Prüfsumme von Format 1
PROBE_FEHLER = "Die Sicherung ließ sich nach dem Schreiben nicht zurücklesen und wurde verworfen. Bitte später noch einmal versuchen."


# ---- Umschlag: verschlüsseln und entschlüsseln

def schluessel_ableiten(passwort: str, salz: bytes, runden: int = RUNDEN) -> bytes:
    """64 Byte: die ersten 32 verschlüsseln, die zweiten 32 prüfen. Gleiche Zeichen in anderer Unicode-Schreibweise ergeben denselben Schlüssel.
    SicherungFehler(OHNE_AES), wenn das Gerät kein PBKDF2 hat (aes.ableiten)."""
    try:
        return aes.ableiten(unicodedata.normalize("NFC", passwort).encode("utf-8"), salz, runden, 64)
    except aes.Fehlt:
        raise SicherungFehler(OHNE_AES) from None


def _probe(schluessel: bytes, salz: bytes) -> bytes:
    """Die 8 Byte Passwort-Probe aus dem zweiten Schlüsselteil und dem Salz (steht im Dateikopf)."""
    return hmac.digest(schluessel[32:], b"probe" + salz, "sha256")[:8]


def probe_stimmt(schluessel: bytes, kopf: dict) -> bool:
    """Passt der Schlüssel zu der Datei mit diesem Kopf (kopf_lesen)?"""
    return hmac.compare_digest(_probe(schluessel, kopf["salz"]), kopf["probe"])


def schreib_nachweis(schluessel: bytes, salz: bytes, name: str, roh: bytes, vorher: str) -> str:
    """Nachweis, dass der Schreiber den Schlüssel zum Salz kennt (Ablage, seit 21.11.2026): HMAC-SHA-256 über Name, SHA-256 des Inhalts und
    SHA-256 der Datei, die er ersetzt (vorher: Hex wie in der Liste der Ablage, "" ohne Datei; seit 22.11.2026), mit einem eigenen Schreibschlüssel
    aus der zweiten Schlüsselhälfte. Gilt nur für genau diesen Inhalt unter genau diesem Namen und nur, solange der Vorgänger dort liegt:
    Ein mitgeschnittener Nachweis spielt so keinen alten Stand über einen neueren. Rückgabe: Hex. ValueError, wenn vorher kein Hex ist."""
    schreib = hmac.digest(schluessel[32:], NACHWEIS_ZWECK + salz, "sha256")
    return hmac.digest(schreib, name.encode() + b"\n" + hashlib.sha256(roh).digest() + b"\n" + bytes.fromhex(vorher), "sha256").hex()


def nachweis_ankuendigung(g: dict):
    """Was die Ablage über ihren Schlüssel verrät, damit Geräte den Nachweis bilden: Salz, Runden und Probe (wie in jedem Dateikopf, öffentlich).
    None, solange auf dem Host kein Passwort festgelegt ist."""
    if not g["schluessel"]:
        return None
    salz = bytes.fromhex(g["salz"])
    return {"salz": g["salz"], "runden": g["runden"], "probe": _probe(bytes.fromhex(g["schluessel"]), salz).hex()}


def ankuendigung_lesen(w):
    """Die Ankündigung der Ablage als Kopf (Form wie kopf_lesen) oder None, wenn sie fehlt oder nicht passt. Runden nur in den Grenzen von
    kopf_lesen: Eine fremde Ablage soll das Gerät nicht minutenlang rechnen lassen."""
    try:
        salz, probe, runden = bytes.fromhex(w["salz"]), bytes.fromhex(w["probe"]), w["runden"]
        if len(salz) != 16 or len(probe) != 8 or type(runden) is not int or not RUNDEN_MIN <= runden <= RUNDEN_MAX:
            return None
    except (TypeError, KeyError, ValueError):
        return None
    return {"salz": salz, "probe": probe, "runden": runden}


def _strom(schluessel: bytes, einmal: bytes, daten: bytes) -> bytes:
    """Nur noch zum Lesen von Format 1: Daten mit dem Schlüsselstrom verknüpfen (HMAC-SHA-256 im Zählermodus)."""
    k = schluessel[:32]
    strom = b"".join(hmac.digest(k, einmal + struct.pack(">Q", i), "sha256") for i in range((len(daten) + 31) // 32))
    return (int.from_bytes(daten, "big") ^ int.from_bytes(strom[:len(daten)], "big")).to_bytes(len(daten), "big")


def packen(nutzdaten: bytes, art: str, schluessel: bytes, salz: bytes, runden: int = RUNDEN, geraet: str = "", erstellt: str = "") -> bytes:
    """Baut die verschlüsselte Datei (Format 2): packt Kopf-JSON und Nutzdaten mit zlib und verschlüsselt sie mit AES-256-GCM.
    art: Art des Inhalts („sqlite“ für eine Sicherung oder der Format-Wert der Synchronisierung; der Wert bleibt). schluessel/salz: aus schluessel_ableiten. Gibt die Bytes der Datei zurück.
    SicherungFehler(OHNE_AES), wenn AES fehlt; es wird nie das alte Format geschrieben."""
    kopf_json = json.dumps({"art": art, "erstellt": erstellt or datetime.now().isoformat(timespec="seconds"), "app": VERSION, "geraet": geraet}).encode("utf-8")
    klar = zlib.compress(struct.pack(">I", len(kopf_json)) + kopf_json + nutzdaten, 6)
    if not aes.verfuegbar():
        raise SicherungFehler(OHNE_AES)                      # nie auf das alte Format ausweichen
    einmal = secrets.token_bytes(16)
    kopf = KOPF.pack(KENNUNG, FORMAT, ABLEITUNG_PBKDF2, runden, salz, einmal, _probe(schluessel, salz))
    return kopf + aes.verschluesseln(schluessel[:aes.SCHLUESSEL], einmal[:aes.EINMAL], klar, kopf)


def _entschluesseln(roh: bytes, k: dict, schluessel: bytes) -> bytes:
    """Der gepackte Inhalt der Datei. SicherungFehler(BESCHAEDIGT), wenn die Prüfsumme nicht passt; vorher wird nichts herausgegeben."""
    if k["format"] == FORMAT_HMAC:
        if not hmac.compare_digest(hmac.digest(schluessel[32:], roh[:-MARKE[FORMAT_HMAC]], "sha256"), roh[-MARKE[FORMAT_HMAC]:]):
            raise SicherungFehler(BESCHAEDIGT)
        return _strom(schluessel, k["einmal"], roh[KOPF.size:-MARKE[FORMAT_HMAC]])
    if not aes.verfuegbar():
        raise SicherungFehler(OHNE_AES)
    try:
        return aes.entschluesseln(schluessel[:aes.SCHLUESSEL], k["einmal"][:aes.EINMAL], roh[KOPF.size:], roh[:KOPF.size])
    except aes.Ungueltig:
        raise SicherungFehler(BESCHAEDIGT)


def kopf_lesen(roh: bytes) -> dict:
    """Die unverschlüsselten Angaben am Anfang der Datei (Version, Runden, Salz). SicherungFehler, wenn die Datei nicht passt."""
    if len(roh) < KOPF.size + min(MARKE.values()) or roh[:8] != KENNUNG:
        raise SicherungFehler(KEINE_SICHERUNG)
    _, fassung, ableitung, runden, salz, einmal, probe = KOPF.unpack_from(roh)
    if fassung > FORMAT:
        raise SicherungFehler(ZU_NEU)
    if fassung not in MARKE or ableitung != ABLEITUNG_PBKDF2 or not RUNDEN_MIN <= runden <= RUNDEN_MAX or len(roh) < KOPF.size + MARKE[fassung]:
        raise SicherungFehler(BESCHAEDIGT)
    return {"format": fassung, "runden": runden, "salz": salz, "einmal": einmal, "probe": probe}


def auspacken(roh: bytes, passwort: str = None, schluessel: bytes = None):
    """-> (Kopf {"art", "erstellt", "app", "geraet"}, Nutzdaten). Entweder das Passwort oder den schon abgeleiteten Schlüssel angeben."""
    k = kopf_lesen(roh)
    if schluessel is None:
        if not passwort:
            raise SicherungFehler(PASSWORT_NOETIG)
        try:
            schluessel = schluessel_ableiten(passwort, k["salz"], k["runden"])
        except UnicodeError:
            raise SicherungFehler(FALSCHES_PASSWORT)
    if not probe_stimmt(schluessel, k):
        raise SicherungFehler(FALSCHES_PASSWORT)
    gepackt = _entschluesseln(roh, k, schluessel)
    try:
        entpacker = zlib.decompressobj()
        klar = entpacker.decompress(gepackt, MAX_KLAR)
        if entpacker.unconsumed_tail or not entpacker.eof:
            raise SicherungFehler(BESCHAEDIGT)
        (laenge,) = struct.unpack_from(">I", klar)
        kopf = json.loads(klar[4:4 + laenge].decode("utf-8"))
        if not isinstance(kopf, dict) or not isinstance(kopf.get("art"), str):
            raise SicherungFehler(BESCHAEDIGT)
    except (zlib.error, struct.error, ValueError, RecursionError) as e:      # RecursionError: Kopf zu tief verschachtelt
        if isinstance(e, SicherungFehler):
            raise
        raise SicherungFehler(BESCHAEDIGT)
    return kopf, klar[4 + laenge:]


# ---- Ziele: wohin die verschlüsselte Datei gelegt wird

def sync_name(geraet: str) -> str:
    """Dateiname des Sync-Stands für die Gerätekennung, z. B. „abgleich-<Kennung>.zsich“."""
    return f"abgleich-{geraet}{ENDUNG}"


class NurIpFehler(OSError):
    """Das freigebende Gerät hat einen Gerätenamen statt seiner IP abgelehnt (421). Text für die Person: NUR_IP."""


class NachweisFehler(OSError):
    """Die Ablage hat die Datei ohne gültigen Nachweis abgewiesen (403). Text für die Person: ABLAGE_NACHWEIS."""


class GitHubFehler(OSError):
    """Ein Fehler bei GitHub mit fertigem Text für die Person (ohne Token, ohne Adressen). status: HTTP-Status der Antwort, 0 ohne Antwort."""
    status = 0


def bearer_erlaubt(adresse: str) -> bool:
    """Darf Passwort oder Geräte-Schlüssel an diese Adresse? Nur über https; über http nur an dieses Gerät selbst (127.x).
    Auch eine private IP über http nicht: In einem fremden WLAN mit gleichem Adressbereich läse ein anderer Rechner mit (Entscheidung 18.11.2026)."""
    if adresse.startswith("https://"):
        return True
    host = adresse.split("://", 1)[-1].split("/", 1)[0].rsplit(":", 1)[0]
    return adresse.startswith("http://") and host.startswith(NUR_DIESES_GERAET) and host.replace(".", "").isdigit()


class AnmeldeFehler(OSError):
    """Der eigene Server (Anmeldedienst) lässt dieses Gerät nicht herein oder sein Zertifikat ist nicht vertraut. grund: ein Schlüssel aus ANMELDE_TEXTE;
    der Text (str) darf die Oberfläche zeigen. Anders als ein Netzfehler unterwegs wird er gemeldet."""

    def __init__(self, grund: str, text: str = ""):
        """grund: Kennwort aus ANMELDE_TEXTE; text: eigener Text, sonst der zum Grund."""
        super().__init__(text or ANMELDE_TEXTE[grund])
        self.grund = grund


def ziel_fehler(e: OSError) -> str:
    """Text für die Person zu einem Fehler beim Ziel: eigener Text bei GitHub/NurIp/Anmeldung, „kein Platz“ bei vollem Speicher, sonst „nicht erreichbar“."""
    if isinstance(e, (GitHubFehler, NurIpFehler, AnmeldeFehler, NachweisFehler)):
        return str(e)
    return ZIEL_VOLL if e.errno in (errno.ENOSPC, getattr(errno, "EDQUOT", errno.ENOSPC)) else ZIEL_WEG


def _zeit_aus_name(name: str) -> str:
    """Die Zeit aus dem Namen einer Sicherung als ISO-Text („JJJJ-MM-TTTHH:MM:SS“)."""
    g = NAME.fullmatch(name)
    return f"{g[1]}T{g[2]}:{g[3]}:{g[4]}"


class OrdnerZiel:
    """Ein Ordner: auf dem Gerät oder der Übergabe-Ordner, den die Android-Hülle nach Google Drive überträgt."""

    def __init__(self, ordner: str, art: str = "lokal"):
        """Merkt Ordner und Art; eine unbekannte Art wird zu „lokal“."""
        self.ordner, self.art = ordner, art if art in ZIEL_ARTEN else "lokal"

    def _pfad(self, name: str) -> str:
        """Voller Pfad zu einer Datei im Ordner. Nur eigene Dateinamen sind erlaubt, sonst SicherungFehler."""
        if not NAME.fullmatch(name) and not SYNC_NAME.fullmatch(name):      # nur eigene Dateinamen, nie ein Pfad
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        return os.path.join(self.ordner, name)

    def ablegen(self, name: str, daten: bytes) -> None:
        """Schreibt die Datei erst unter „.teil“ und benennt sie dann um. Bei einem Fehler (z. B. Speicher voll) wird der Rest gelöscht und der OSError weitergegeben."""
        ziel = self._pfad(name)
        os.makedirs(self.ordner, exist_ok=True)
        try:
            with open(ziel + ".teil", "wb") as f:           # erst fertig schreiben, dann umbenennen: die Cloud sieht nie eine halbe Datei
                f.write(daten)
                f.flush()
                os.fsync(f.fileno())
            os.replace(ziel + ".teil", ziel)
        except OSError:
            try:
                os.remove(ziel + ".teil")                   # Speicher voll: keinen Rest liegen lassen
            except OSError:
                pass
            raise

    def _dateien(self, muster) -> list:
        """Namen im Ordner, die zum Muster passen; ein fehlender Ordner ergibt eine leere Liste."""
        try:
            return [f for f in os.listdir(self.ordner) if muster.fullmatch(f)]
        except FileNotFoundError:
            return []

    def namen(self) -> list:
        """Namen der Sicherungs-Dateien im Ordner."""
        return self._dateien(NAME)

    def sync_namen(self) -> list:
        """Namen der Synchronisierungsdateien im Ordner."""
        return self._dateien(SYNC_NAME)

    def groesse(self, name: str) -> int:
        """Größe der Datei in Byte."""
        return os.path.getsize(self._pfad(name))

    def lesen(self, name: str) -> bytes:
        """Inhalt der Datei. SicherungFehler, wenn es sie nicht gibt oder sie größer als MAX_DATEI ist."""
        try:
            with open(self._pfad(name), "rb") as f:
                daten = f.read(MAX_DATEI + 1)                # wer in den geteilten Ordner schreiben darf, soll den Speicher nicht füllen können
        except FileNotFoundError:
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        if len(daten) > MAX_DATEI:
            raise SicherungFehler(BESCHAEDIGT)
        return daten

    def loeschen(self, name: str) -> None:
        """Löscht die Datei."""
        os.remove(self._pfad(name))


class NetzZiel:
    """Die Ablage auf dem eigenen Server (Web-App im Heimnetz, /api/ablage): dieselben verschlüsselten Synchronisierungsdateien wie im Cloud-Ordner.
    Die einzige Stelle, an der die App selbst eine Verbindung öffnet, und nur zu der Adresse, die die Person eingetragen hat (Ablage und Geräte-Anmeldung).
    Fehler sind OSError; AnmeldeFehler, wenn der Anmeldedienst davor das Gerät nicht hereinlässt oder das Zertifikat nicht vertraut ist."""
    art, merk, immer_ablegen = "server", "netz:", True       # merk: eigene Merkliste im Gerät; immer_ablegen: die Datei dort kann älter sein als die im Ordner

    def __init__(self, adresse: str, warten: float = 10.0, schluessel: str = ""):
        """Adresse des Servers (ohne Schrägstrich am Ende), Wartezeit in Sekunden und Geräte-Schlüssel des Anmeldedienstes (leer: ohne Anmeldung).
        Die Ablage liegt unter „/api/ablage“."""
        self.server = adresse.rstrip("/")
        self.adresse, self.warten, self.schluessel = self.server + ABLAGE_PFAD, warten, schluessel
        self.ankuendigung, self.schreib_schluessel = None, None   # aus der Liste der Ablage (ankuendigung_lesen); Schlüssel dazu setzt die Synchronisierung
        self.summen = {}                                          # Name -> SHA-256 der Datei dort (aus der Liste): Vorgänger im Schreib-Nachweis

    def _anfrage(self, adresse: str, daten: bytes = None, methode: str = "", schluessel: str = "") -> bytes:
        """Eine Anfrage an den eigenen Server: PUT, wenn daten gegeben sind, sonst GET (oder methode). Gibt die Antwort als Bytes zurück.
        Mit schluessel geht „Authorization: Bearer“ mit, nie an eine Weiterleitung. 421 wird zu NurIpFehler; 401 des Anmeldedienstes, 429 und ein nicht
        vertrautes Zertifikat werden zu AnmeldeFehler; andere Fehler bleiben OSError (unterwegs nicht erreichbar)."""
        import ssl
        import urllib.error
        import urllib.request                                 # nur hier gebraucht; die Browser-Fassung (Pyodide) lädt das Modul so nie
        anfrage = urllib.request.Request(adresse, data=daten, method=methode or ("PUT" if daten is not None else "GET"), headers={"Content-Type": "application/json"})
        if schluessel and not bearer_erlaubt(adresse):
            raise AnmeldeFehler("anmeldung", NUR_HTTPS)
        if schluessel:                                        # urllib reicht sonst bei einer Weiterleitung alle Kopfzeilen weiter, auch an einen fremden Rechner
            anfrage.add_unredirected_header("Authorization", "Bearer " + schluessel)
        try:
            with urllib.request.urlopen(anfrage, timeout=self.warten) as antwort:
                return _lesen_mit_frist(antwort, self.warten)
        except urllib.error.HTTPError as e:
            with e:
                grund = next((w for k in ANMELDEDIENST_KOEPFE if (w := e.headers.get(k))), "") if e.headers else ""
                kennung = _fehler_kennung(e) if e.code == 403 else ""
            if e.code == 421:                                 # ein freigebendes Gerät nimmt nur seine IP an (Schutz gegen DNS-Rebinding)
                raise NurIpFehler(NUR_IP) from None
            if e.code == 401 and grund:
                raise AnmeldeFehler(grund if grund in ANMELDUNG_RUHT else "anmeldung") from None
            if e.code == 429:
                raise AnmeldeFehler("gesperrt") from None
            if kennung == NACHWEIS_KENNUNG:
                raise NachweisFehler(ABLAGE_NACHWEIS) from None
            raise
        except urllib.error.URLError as e:
            if isinstance(e.reason, ssl.SSLCertVerificationError):
                raise AnmeldeFehler("zertifikat") from None
            raise
        except ssl.SSLCertVerificationError:                 # kann auch erst beim Lesen kommen, ohne Hülle
            raise AnmeldeFehler("zertifikat") from None

    def _holen(self, pfad: str = "", daten: bytes = None) -> bytes:
        """Eine Anfrage an die Ablage, mit dem Geräte-Schlüssel, wenn es einen gibt. Fehler wie bei _anfrage."""
        return self._anfrage(self.adresse + pfad, daten, schluessel=self.schluessel)

    def anmelden(self, benutzer: str, passwort: str, name: str) -> str:
        """Meldet dieses Gerät am Anmeldedienst an (POST /pfoertner/geraet) und gibt den Geräte-Schlüssel zurück. Das Passwort geht nur in dieser
        Anfrage hinaus und wird nirgends gespeichert. AnmeldeFehler bei falschen Angaben (401), Sperre (429), gesperrtem Konto (403); ein Konto ohne
        Passwort meldet der Anmeldedienst seit 19.11.2026 wie falsch (401), ältere noch mit 409; OSError, wenn der Server nicht wie der Anmeldedienst antwortet."""
        if not bearer_erlaubt(self.server):
            raise AnmeldeFehler("anmeldung", NUR_HTTPS)
        koerper = json.dumps({"benutzer": benutzer, "passwort": passwort, "name": name[:GERAETE_NAME_MAX]}).encode()
        try:
            antwort = self._anfrage(self.server + ANMELDEDIENST_GERAET, koerper, "POST")
        except AnmeldeFehler as e:
            raise AnmeldeFehler(e.grund, ANMELDUNG_FALSCH if e.grund == "anmeldung" else "") from None
        except OSError as e:
            if getattr(e, "code", None) in (403, 409):                         # Konto gesperrt oder (älterer Anmeldedienst) noch ohne Passwort: im Browser klären
                raise AnmeldeFehler("anmeldung", KONTO_NICHT_BEREIT) from None
            raise
        try:
            schluessel = json.loads(antwort)["schluessel"]
            if not isinstance(schluessel, str) or not ABLAGE_SCHLUESSEL.fullmatch(schluessel):
                raise ValueError
        except (ValueError, KeyError, TypeError):
            raise OSError("Die Adresse antwortet nicht wie der Anmeldedienst") from None
        return schluessel

    def sync_namen(self) -> list:
        """Namen der Synchronisierungsdateien auf dem Server. OSError, wenn die Adresse nicht wie die Zeiterfassung antwortet."""
        try:
            liste = json.loads(self._holen())
            dateien = [d for d in liste["dateien"] if SYNC_NAME.fullmatch(d["name"])]
            summen = {d["name"]: d["summe"] for d in dateien if isinstance(d.get("summe"), str) and SUMME.fullmatch(d["summe"])}
        except (ValueError, KeyError, TypeError, AttributeError):
            raise OSError("Die Adresse antwortet nicht wie die Zeiterfassung")
        self.ankuendigung, self.summen = ankuendigung_lesen(liste.get("nachweis")), summen
        return [d["name"] for d in dateien]

    def nachweis_holen(self, name: str, daten: bytes):
        """Der Nachweis zur Datei (schreib_nachweis), wenn die Synchronisierung den Schlüssel der Ablage kennt; sonst None (dann ohne Nachweis)."""
        if not (self.ankuendigung and self.schreib_schluessel):
            return None
        return schreib_nachweis(self.schreib_schluessel, self.ankuendigung["salz"], name, daten, self.summen.get(name, ""))

    def lesen(self, name: str) -> bytes:
        """Lädt eine Synchronisierungsdatei vom Server. Nur gültige Sync-Namen sind erlaubt."""
        if not SYNC_NAME.fullmatch(name):
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        return self._holen("/" + name)

    def ablegen(self, name: str, daten: bytes) -> None:
        """Legt eine Synchronisierungsdatei auf dem Server ab (Inhalt als Base64 in JSON). Nur gültige Sync-Namen sind erlaubt."""
        if not SYNC_NAME.fullmatch(name):
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        self._holen("/" + name, json.dumps({"daten": base64.b64encode(daten).decode(), "nachweis": self.nachweis_holen(name, daten) or ""}).encode())
        self.summen[name] = hashlib.sha256(daten).hexdigest()   # jetzt der Vorgänger, falls ohne neue Liste noch einmal abgelegt wird

    def loeschen(self, name: str) -> None:
        """Löscht die Synchronisierungsdatei eines anderen Geräts auf dem Server. Der Nachweis gilt für die Datei aus der Liste und einen leeren Inhalt
        (LOESCH_INHALT), damit taugt er nicht zum Ablegen. Fehler wie bei _anfrage (NachweisFehler, wenn der Schlüssel der Ablage fehlt)."""
        if not SYNC_NAME.fullmatch(name):
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        self._anfrage(f"{self.adresse}/{name}", json.dumps({"nachweis": self.nachweis_holen(name, LOESCH_INHALT) or ""}).encode(), "DELETE", self.schluessel)
        self.summen.pop(name, None)


def _fehler_kennung(e) -> str:
    """Die Kennung „kennung“ aus der Antwort zu einem HTTP-Fehler (höchstens LESE_STUECK Byte), sonst leer."""
    try:
        return str(json.loads(e.read(LESE_STUECK)).get("kennung", ""))
    except (ValueError, AttributeError, OSError):
        return ""


def _lesen_mit_frist(antwort, warten: float) -> bytes:
    """Liest eine Antwort (höchstens MAX_KLAR Byte) in Stücken. OSError, wenn das länger als GESAMT_WARTEN Wartezeiten dauert:
    Eine Gegenstelle, die nur ab und zu ein Byte schickt, soll die Synchronisierung und die Automatik nicht beliebig lange festhalten."""
    frist, teile, laenge = time.monotonic() + GESAMT_WARTEN * warten, [], 0
    while laenge < MAX_KLAR:
        teil = antwort.read1(min(LESE_STUECK, MAX_KLAR - laenge))
        if not teil:
            break
        teile.append(teil)
        laenge += len(teil)
        if time.monotonic() > frist:
            raise OSError(errno.ETIMEDOUT, "Die Gegenstelle antwortet zu langsam")
    return b"".join(teile)


def _netz_anfrage(methode: str, adresse: str, kopf: dict, koerper, warten: float) -> tuple:
    """Anfrage über urllib. Gibt (Status, Inhalt) zurück; HTTP-Fehler werden zu (Code, leer). Die Kopfzeile „Authorization“ geht nur an die erste Adresse, nie an eine Weiterleitung."""
    import urllib.error
    import urllib.request
    anfrage = urllib.request.Request(adresse, data=koerper, method=methode, headers={k: v for k, v in kopf.items() if k != "Authorization"})
    if "Authorization" in kopf:                              # urllib reicht sonst bei einer Weiterleitung alle Kopfzeilen weiter, auch an einen fremden Rechner
        anfrage.add_unredirected_header("Authorization", kopf["Authorization"])
    try:
        with urllib.request.urlopen(anfrage, timeout=warten) as antwort:
            return antwort.status, _lesen_mit_frist(antwort, warten)
    except urllib.error.HTTPError as e:
        with e:
            return e.code, b""


MS_JE_SEKUNDE = 1000


def _browser_anfrage(methode: str, adresse: str, kopf: dict, koerper, warten: float) -> tuple:
    """Web-App im Browser (Pyodide): Python hat dort kein Netz, die Anfrage geht über den Browser. Im Arbeitsfaden darf sie warten,
    aber höchstens warten Sekunden (Zeitlimit der Anfrage). Fehler und Abbruch werden zu OSError."""
    try:
        from js import XMLHttpRequest
        x = XMLHttpRequest.new()
        x.open(methode, adresse, False)
        x.timeout = int(warten * MS_JE_SEKUNDE)            # sonst wartet der Rechenkern ohne Netz unbegrenzt und mit ihm jede Anfrage der Oberfläche; Abbruch wirft hier
        for name, wert in kopf.items():
            x.setRequestHeader(name, wert)
        x.send(koerper.decode() if koerper else None)
        return int(x.status), str(x.responseText)
    except Exception:                                       # ohne Verbindung wirft der Browser einen eigenen Fehler
        raise OSError("keine Verbindung") from None


class GitHubZiel:
    """Ein eigenes Repo bei GitHub (öffentlich oder privat) als Speicherort: dieselben verschlüsselten Synchronisierungsdateien wie im Cloud-Ordner.
    Die App spricht dafür nur mit der Schnittstelle von GitHub und nur mit dem Repo und dem Token, die die Person eingetragen hat. Fehler sind OSError."""
    art, merk, eigener_stand = "github", "github:", True     # eigener_stand: merkt sich selbst, was dort liegt (jedes Ablegen ist ein Commit)
    api = GITHUB_API

    def __init__(self, repo: str, token: str, warten: float = 15.0):
        """Repo („Konto/Repo“), Token und Wartezeit in Sekunden. Merkt sich die Kennungen (sha) der Dateien im Repo."""
        self.repo, self.token, self.warten, self._kennung = repo, token, warten, {}

    def _holen(self, pfad: str = "", daten: dict = None, methode: str = ""):
        """Eine Anfrage an die GitHub-Schnittstelle (methode, sonst PUT mit daten, sonst GET). Gibt die Antwort als JSON zurück.
    FileNotFoundError bei 404 (Lesen); GitHubFehler bei fehlender Verbindung, abgelehntem Token oder anderen Fehlern, jeweils mit Text ohne Token."""
        kopf = {"Accept": "application/vnd.github+json", "Authorization": "Bearer " + self.token, "X-GitHub-Api-Version": "2022-11-28"}
        senden = _browser_anfrage if sys.platform == "emscripten" else _netz_anfrage
        methode = methode or ("PUT" if daten is not None else "GET")
        if methode == "GET":
            kopf["If-None-Match"] = GITHUB_FRISCH
        try:
            status, text = senden(methode, f"{self.api}/repos/{self.repo}{pfad}", kopf, json.dumps(daten).encode() if daten is not None else None, self.warten)
        except OSError as e:                                # Der technische Grund hilft bei der Fehlersuche; URLError und SSL-Fehler nennen weder Adresse noch Token
            raise GitHubFehler(f"{GITHUB_WEG} Technisch: {type(e).__name__}: {e}"[:400]) from None
        if status == 404 and methode == "GET":
            raise FileNotFoundError(errno.ENOENT, "bei GitHub nicht gefunden")
        if status in (401, 403, 404):                       # Beim Schreiben zeigt GitHub ein Token ohne Schreibrecht auch als 404
            raise GitHubFehler(GITHUB_TOKEN_NEIN)
        if status >= 400:
            fehler = GitHubFehler(f"GitHub antwortet mit dem Fehler {status}. Bitte später noch einmal versuchen.")
            fehler.status = status
            raise fehler
        try:
            return json.loads(text)
        except ValueError:
            raise OSError("GitHub antwortet nicht wie erwartet")

    def pruefen(self) -> dict:
        """Beim Verbinden: Gibt es das Repo, ist es privat, darf das Token schreiben?"""
        r = self._holen()
        if not isinstance(r, dict):
            raise OSError("GitHub antwortet nicht wie erwartet")
        return {"privat": r.get("private") is not False, "schreiben": (r.get("permissions") or {}).get("push") is not False}

    def sync_namen(self) -> list:
        """Namen der Synchronisierungsdateien im Repo; merkt sich dabei ihre Kennungen. Ein leeres Repo ergibt eine leere Liste."""
        try:
            liste = self._holen("/contents/")
        except FileNotFoundError:                           # ein Repo ohne Dateien meldet GitHub so
            liste = []
        try:
            self._kennung = {d["name"]: d["sha"] for d in liste if d.get("type") == "file" and SYNC_NAME.fullmatch(d["name"])}
        except (AttributeError, KeyError, TypeError):
            raise OSError("GitHub antwortet nicht wie erwartet")
        return list(self._kennung)

    def _name(self, name: str) -> str:
        """Prüft, dass der Name ein Sync-Name ist (sonst SicherungFehler), und gibt ihn zurück."""
        if not SYNC_NAME.fullmatch(name):
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        return name

    def lesen(self, name: str) -> bytes:
        """Lädt eine Synchronisierungsdatei über ihre Kennung (auch über 1 MB). SicherungFehler, wenn es sie nicht gibt."""
        if self._name(name) not in self._kennung:
            self.sync_namen()
        if name not in self._kennung:
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        try:                                                # über die Kennung statt über den Namen: so gehen auch Dateien über 1 MB
            return base64.b64decode(self._holen("/git/blobs/" + self._kennung[name])["content"])
        except (binascii.Error, KeyError, TypeError):
            raise OSError("GitHub antwortet nicht wie erwartet")

    def ablegen(self, name: str, daten: bytes) -> None:
        """Legt eine Synchronisierungsdatei als Commit „Synchronisierung“ ab. Eine vorhandene Datei wird mit ihrer Kennung ersetzt; die neue Kennung wird gemerkt.
        Lehnt GitHub die Kennung ab (GITHUB_KENNUNG_ALT: fehlt oder veraltet), holt das Ziel die Liste frisch und versucht es genau einmal neu."""
        inhalt = base64.b64encode(daten).decode()
        self._name(name)
        for versuch in range(2):
            neu = {"message": "Synchronisierung", "content": inhalt}
            if name in self._kennung:
                neu["sha"] = self._kennung[name]            # GitHub ersetzt eine Datei nur, wenn die Kennung der alten Fassung stimmt
            try:
                antwort = self._holen("/contents/" + name, neu)
                break
            except GitHubFehler as e:
                if versuch or e.status not in GITHUB_KENNUNG_ALT:
                    raise
                self.sync_namen()                           # über die Liste, nicht /contents/<name>: die nennt die Kennung über 1 MB nicht
        try:
            self._kennung[name] = antwort["content"]["sha"]
        except (KeyError, TypeError):
            raise OSError("GitHub antwortet nicht wie erwartet")

    def loeschen(self, name: str) -> None:
        """Löscht eine Synchronisierungsdatei als Commit „Gerät entfernt“ (GitHub verlangt die Kennung der Fassung, die dort liegt). Gibt es sie nicht, ist nichts zu tun."""
        if self._name(name) not in self._kennung:
            self.sync_namen()
        if name in self._kennung:
            self._holen("/contents/" + name, {"message": "Gerät entfernt", "sha": self._kennung.pop(name)}, "DELETE")


class TestZiel:
    """Ziel im Arbeitsspeicher für die Tests. „stoerung“: "weg" (nicht erreichbar), "voll" (kein Platz), "halb" (Datei kommt abgeschnitten an)."""

    def __init__(self, art: str = "lokal"):
        """Leeres Ziel im Speicher mit der gegebenen Art und ohne Störung."""
        self.art, self.dateien, self.stoerung = art, {}, None

    def _pruefen(self):
        """Wirft einen OSError, wenn die Störung „weg“ eingestellt ist."""
        if self.stoerung == "weg":
            raise OSError(errno.ENOENT, "Ziel nicht erreichbar")

    def ablegen(self, name: str, daten: bytes) -> None:
        """Legt die Datei im Speicher ab; bei „voll“ OSError, bei „halb“ nur die erste Hälfte."""
        self._pruefen()
        if self.stoerung == "voll":
            raise OSError(errno.ENOSPC, "kein Platz")
        self.dateien[name] = daten[:len(daten) // 2] if self.stoerung == "halb" else daten

    def namen(self) -> list:
        """Namen der Sicherungs-Dateien."""
        self._pruefen()
        return [n for n in self.dateien if NAME.fullmatch(n)]

    def sync_namen(self) -> list:
        """Namen der Synchronisierungsdateien."""
        self._pruefen()
        return [n for n in self.dateien if SYNC_NAME.fullmatch(n)]

    def groesse(self, name: str) -> int:
        """Größe der Datei in Byte."""
        return len(self.dateien[name])

    def lesen(self, name: str) -> bytes:
        """Inhalt der Datei; SicherungFehler, wenn es sie nicht gibt."""
        self._pruefen()
        if name not in self.dateien:
            raise SicherungFehler("Diese Sicherung gibt es nicht.")
        return self.dateien[name]

    def loeschen(self, name: str) -> None:
        """Entfernt die Datei, falls vorhanden."""
        self._pruefen()
        self.dateien.pop(name, None)


def ziel_aus_umgebung(daten_ordner: str = ""):
    """Das Ziel, das die App-Hülle beim Start nennt: HO_SICHERUNG_ZIEL (Ordner) und HO_SICHERUNG_ART (drive, lokal oder browser; Unbekanntes gilt als lokal).
    Fehlt die Angabe, gilt der Ordner, den die Person in der Desktop-Fassung gewählt hat (geraet.json). None = nicht eingerichtet."""
    ordner = os.environ.get("HO_SICHERUNG_ZIEL", "").strip()
    if ordner:
        return OrdnerZiel(ordner, os.environ.get("HO_SICHERUNG_ART", "lokal").strip().lower())
    ordner = geraet_lesen(daten_ordner)["ziel_ordner"] if daten_ordner else ""
    return OrdnerZiel(ordner) if ordner else None


def liste(ziel, geraet: str = "") -> list:
    """Sicherungen im Ziel, neueste zuerst. Die Zeit steht im Namen (eine Synchronisierung über die Cloud ändert das Dateidatum)."""
    if ziel is None:
        return []
    r = [{"name": n, "zeit": _zeit_aus_name(n), "bytes": ziel.groesse(n), "eigene": bool(geraet) and NAME.fullmatch(n)[5] == geraet[:6]} for n in ziel.namen()]
    return sorted(r, key=lambda s: (s["zeit"], s["name"]), reverse=True)


# ---- Einstellungen dieses Geräts (nicht Teil der Datenbank: Sie gelten für das Gerät, nicht für den Datenbestand)

def _vorgabe() -> dict:
    """Die Standardwerte der Gerätedatei, mit neuer zufälliger Gerätekennung (16 Hex-Zeichen)."""
    return {"geraet": secrets.token_hex(8), "auto": False, "rhythmus": "taeglich", "behalten": 7, "salz": "", "schluessel": "", "runden": RUNDEN,
            "letzte": None, "geprueft": "", "inhalt": "", "fremde": {}, "abgleich": None, "abgleich_aus": False, "abgleich_abgemeldet": False, "abgleich_allein": False, "abgleich_partner": False, "abgleich_zaehlung": {}, "abgleich_weg": [], "abgleich_auto": False, "ziel_ordner": "", "ablage_adresse": "", "ablage_schluessel": "", "ablage_geraet": "", "ablage_fehler": "", "github_repo": "", "github_token": "", "github_privat": True, "freigabe": False, "oberflaeche": False, "oberflaeche_zugang": "", "browser": "",
            "abgleich_inhalt": "", "abgleich_gelesen": {}, "abgleich_format": FORMAT_HMAC,
            "update_pruefen": True, "update_zuletzt": "", "update_versuch": "", "update_neueste": "",     # Update-Prüfung (update.py): ab Werk an
            "sync_app_neueste": "",                     # höchste App-Version eines anderen Geräts im Sync (Zu tun update-anderes-geraet)
            "sync_uebersprungen": {},               # je Datei {"abdruck", "zahl"}: übersprungene Sätze, solange die Datei gleich bleibt (U1)
            "sync_geraete": {}}                     # je Sync-Datei eines anderen Geräts {"erstellt", "app"} aus ihrem Kopf (Liste der Geräte, 22.11.2026)


def geraet_lesen(daten_ordner: str) -> dict:
    """Liest geraet.json im Datenordner und füllt fehlende Felder mit Vorgaben auf. Fehlt die Datei oder ist sie unbrauchbar, wird sie neu angelegt.
    Andere Lesefehler werden weitergegeben, damit Kennung und Schlüssel nicht überschrieben werden."""
    pfad = os.path.join(daten_ordner, GERAET_DATEI)
    with _schloss:
        try:
            with open(pfad, encoding="utf-8") as f:
                g = json.load(f)
            if not isinstance(g, dict) or not re.fullmatch(r"[0-9a-f]{16}", str(g.get("geraet", ""))):
                raise ValueError
        except (FileNotFoundError, ValueError):             # erster Start oder unbrauchbare Datei; andere Lesefehler (gesperrt, kein Zugriff) werden gemeldet,
            g = _vorgabe()                                  # denn neue Vorgaben würden Kennung und Schlüssel des Geräts überschreiben
            _schreiben(pfad, g)
        return {**_vorgabe(), **g}


def _schreiben(pfad: str, g: dict) -> None:
    """Schreibt die Gerätedatei (erst „.teil“, dann umbenennen), nur für den Besitzer lesbar, weil der Schlüssel darin steht."""
    fd = os.open(pfad + ".teil", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)      # enthält den Schlüssel: nur für die App lesbar
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(g, f)
    os.replace(pfad + ".teil", pfad)


def geraet_aendern(daten_ordner: str, **werte) -> dict:
    """Ändert Felder der Gerätedatei (Lesen und Schreiben unter einem Schloss) und gibt den neuen Stand zurück.
    Eine neue Server-Adresse ohne neuen Schlüssel verwirft die Anmeldung: Der Geräte-Schlüssel geht nie an einen anderen Rechner (z. B. nach einer Kopplung)."""
    with _schloss:
        g = geraet_lesen(daten_ordner)
        if "ablage_adresse" in werte and werte["ablage_adresse"] != g["ablage_adresse"] and "ablage_schluessel" not in werte:
            werte = {**werte, "ablage_schluessel": "", "ablage_geraet": "", "ablage_fehler": ""}
        g.update(werte)
        _schreiben(os.path.join(daten_ordner, GERAET_DATEI), g)
    return g


def fremden_schluessel_merken(daten_ordner: str, salz: str, schluessel: str) -> dict:
    """Merkt den Schlüssel zur Datei eines anderen Geräts (salz und schluessel als Hex). Liest die gemerkten Schlüssel erst unter dem Schloss:
    Eine Synchronisierung, der vor einem Passwortwechsel begann, brächte sonst die dabei vergessenen alten Schlüssel zurück. Rückgabe: neuer Stand."""
    with _schloss:
        return geraet_aendern(daten_ordner, fremde={**geraet_lesen(daten_ordner)["fremde"], salz: schluessel})


def sync_neu_lesen(daten_ordner: str) -> None:
    """Nach dem Wiederherstellen oder Zurücksetzen: Merklisten der Synchronisierung leeren. Die nächste Synchronisierung liest alle Dateien der anderen Geräte neu
    und legt die eigene neu ab; sonst liefe dieses Gerät still auseinander, bis ein anderes etwas ändert."""
    geraet_aendern(daten_ordner, **{"abgleich_inhalt": "", "abgleich_gelesen": {}, "sync_uebersprungen": {}})


def geraet_zuruecksetzen(daten_ordner: str) -> None:
    """Werkseinstellungen: alle Angaben der Gerätedatei auf die Vorgabe (Passwort-Schlüssel, gemerkte Schlüssel, Token, Server, Merklisten).
    Nur die Gerätekennung bleibt, damit der Zähler dieses Geräts in der Synchronisierung weiter über allem liegt, was die anderen kennen."""
    geraet_aendern(daten_ordner, **{k: v for k, v in _vorgabe().items() if k != "geraet"})


def koppeln_pruefen(daten_ordner: str) -> None:
    """Vor dem Koppeln: Synchronisiert dieses Gerät schon mit einem eigenen Server, würde die Kopplung diese Verbindung (samt Geräte-Schlüssel)
    ersetzen. Dann SicherungFehler mit Text für die Oberfläche. Ersetzt werden darf nur eine leere Adresse oder eine frühere Kopplung
    (http, IP, Anschluss FREIGABE_PORT, ohne Anmeldung)."""
    g = geraet_lesen(daten_ordner)
    if g["ablage_schluessel"] or (g["ablage_adresse"] and not FRUEHERE_KOPPLUNG.fullmatch(g["ablage_adresse"])):
        raise SicherungFehler(SERVER_STATT_KOPPELN)


def einstellungen_setzen(daten_ordner: str, auto=None, rhythmus=None, behalten=None) -> dict:
    """Prüft und speichert automatische Sicherung (an/aus), Rhythmus und Anzahl aufzubewahrender Sicherungen. Nur angegebene Werte werden geändert; SicherungFehler bei ungültigen Werten."""
    neu = {}
    if auto is not None:
        if not isinstance(auto, bool):
            raise SicherungFehler("Automatische Sicherung: an oder aus")
        neu["auto"] = auto
    if rhythmus is not None:
        if rhythmus not in RHYTHMEN:
            raise SicherungFehler("Rhythmus: täglich, wöchentlich oder bei jeder Änderung")
        neu["rhythmus"] = rhythmus
    if behalten is not None:
        if isinstance(behalten, bool) or not isinstance(behalten, int) or not BEHALTEN_MIN <= behalten <= BEHALTEN_MAX:
            raise SicherungFehler(f"Aufbewahren: {BEHALTEN_MIN} bis {BEHALTEN_MAX} Sicherungen")
        neu["behalten"] = behalten
    return geraet_aendern(daten_ordner, **neu)


def passwort_setzen(daten_ordner: str, passwort) -> None:
    """Leitet den Schlüssel ab und merkt ihn sich für die automatische Sicherung. Das Passwort selbst wird nicht gespeichert.
    Ältere Sicherungen bleiben mit ihrem alten Passwort lesbar. Gemerkte Schlüssel anderer Geräte werden vergessen."""
    if not isinstance(passwort, str) or not PASSWORT_MIN <= len(passwort) <= PASSWORT_MAX:
        raise SicherungFehler(f"Das Passwort braucht mindestens {PASSWORT_MIN} Zeichen (höchstens {PASSWORT_MAX}).")
    try:
        passwort.encode("utf-8")
    except UnicodeError:                                    # kaputte Zeichen: als Eingabefehler melden, damit das Passwort nie in einer Fehlermeldung im Protokoll landet
        raise SicherungFehler("Das Passwort enthält ungültige Zeichen.")
    salz = secrets.token_bytes(16)
    g = geraet_lesen(daten_ordner)
    gelesen = {k: v for k, v in g["abgleich_gelesen"].items() if not k.endswith(sync_name(g["geraet"]))}     # die eigene Datei bei GitHub gilt als veraltet
    # fremde leeren: Nach einem verlorenen Gerät öffnet dessen alter Schlüssel sonst weiter jede Datei; die anderen Geräte brauchen einmal das neue Passwort
    geraet_aendern(daten_ordner, salz=salz.hex(), schluessel=schluessel_ableiten(passwort, salz, RUNDEN).hex(), runden=RUNDEN, inhalt="", **{"abgleich_inhalt": "", "abgleich_gelesen": gelesen}, fremde={})


def stand(daten_ordner: str, ziel) -> dict:
    """Für die Oberfläche: keine Pfade, kein Schlüssel."""
    g = geraet_lesen(daten_ordner)
    try:
        sicherungen, erreichbar = liste(ziel, g["geraet"]), True
    except OSError:
        sicherungen, erreichbar = [], False
    return {"ziel": {"eingerichtet": ziel is not None, "art": ziel.art if ziel is not None else "", "erreichbar": erreichbar},
            "passwort": bool(g["schluessel"]), "auto": bool(g["auto"]), "rhythmus": g["rhythmus"], "behalten": g["behalten"],
            "letzte": g["letzte"], "geprueft": g["geprueft"], "sicherungen": sicherungen}


# ---- Sichern und Wiederherstellen

def sichern(db, daten_ordner: str, ziel, jetzt: datetime = None, nur_neues: bool = False) -> dict:
    """Die Datenbank verschlüsselt ins Ziel legen, zurücklesen (nur eine lesbare Sicherung zählt) und alte eigene Sicherungen aufräumen.
    nur_neues: Hat sich seit der letzten Sicherung nichts geändert, wird keine neue Datei geschrieben. Gibt den Stand zurück; SicherungFehler bei Fehlern
    (der Fehler steht dann auch im Stand, die Daten in der App bleiben unberührt)."""
    jetzt = jetzt or datetime.now()
    g = geraet_lesen(daten_ordner)
    if not g["schluessel"]:
        raise SicherungFehler(KEIN_PASSWORT)
    if ziel is None:
        raise SicherungFehler(KEIN_ZIEL)
    inhalt = db.sicherung_bytes()
    abdruck = hashlib.sha256(inhalt).hexdigest()
    zeit = jetzt.isoformat(timespec="seconds")
    if nur_neues and abdruck == g["inhalt"] and g["letzte"] and g["letzte"].get("ok"):
        geraet_aendern(daten_ordner, geprueft=zeit)
        return {**g["letzte"], "neu": False}
    schluessel, salz = bytes.fromhex(g["schluessel"]), bytes.fromhex(g["salz"])
    name = None
    try:
        vorhanden = set(ziel.namen())
        stamm, nr = f"zeiterfassung-{jetzt:%Y-%m-%d_%H%M%S}-{g['geraet'][:6]}", 1
        name = stamm + ENDUNG
        while name in vorhanden:                            # nie eine vorhandene Sicherung überschreiben
            nr += 1
            name = f"{stamm}-{nr}{ENDUNG}"
        ziel.ablegen(name, packen(inhalt, "sqlite", schluessel, salz, g["runden"], g["geraet"], zeit))
        try:
            kopf, zurueck = auspacken(ziel.lesen(name), schluessel=schluessel)
            if kopf["art"] != "sqlite" or hashlib.sha256(zurueck).hexdigest() != abdruck:
                raise SicherungFehler(BESCHAEDIGT)
        except SicherungFehler:
            ziel.loeschen(name)
            raise SicherungFehler(PROBE_FEHLER)
        eigene = sorted((n for n in ziel.namen() if NAME.fullmatch(n)[5] == g["geraet"][:6]), key=lambda n: (_zeit_aus_name(n), n))
        for alt in eigene[:-g["behalten"]]:                 # nur Sicherungen dieses Geräts aufräumen, nie die eines anderen
            ziel.loeschen(alt)
    except (OSError, SicherungFehler) as e:
        text = str(e) if isinstance(e, SicherungFehler) else ziel_fehler(e)
        geraet_aendern(daten_ordner, letzte={"zeit": zeit, "ok": False, "fehler": text, "datei": ""}, geprueft=zeit)
        raise SicherungFehler(text)
    letzte = {"zeit": zeit, "ok": True, "fehler": "", "datei": name}
    geraet_aendern(daten_ordner, letzte=letzte, geprueft=zeit, inhalt=abdruck)
    return {**letzte, "neu": True}


def wiederherstellen(db, daten_ordner: str, roh: bytes, passwort: str = None) -> dict:
    """Den Datenbestand durch den Inhalt einer verschlüsselten Sicherung ersetzen. Ohne Passwort geht das nur für Sicherungen, die mit dem
    Schlüssel dieses Geräts angelegt sind. Der Stand davor wird gesichert (db.wiederherstellen); bei einem Fehler bleibt alles, wie es war."""
    g = geraet_lesen(daten_ordner)
    k = kopf_lesen(roh)
    if passwort:
        kopf, inhalt = auspacken(roh, passwort=passwort)
    elif g["schluessel"] and g["salz"] == k["salz"].hex():
        kopf, inhalt = auspacken(roh, schluessel=bytes.fromhex(g["schluessel"]))
    else:
        raise SicherungFehler(PASSWORT_NOETIG)
    if kopf["art"] != "sqlite":
        raise SicherungFehler("Diese Datei ist keine Sicherung des Datenbestands.")
    with tempfile.TemporaryDirectory() as t:
        quelle = os.path.join(t, "sicherung.db")
        with open(quelle, "wb") as f:
            f.write(inhalt)
        r = db.wiederherstellen(quelle, os.path.join(daten_ordner, "sicherung"))
    geraet_aendern(daten_ordner, inhalt="")
    sync_neu_lesen(daten_ordner)
    return {**r, "erstellt": str(kopf.get("erstellt", ""))[:19]}


# ---- Automatik

def faellig(g: dict, jetzt: datetime, geaendert: bool) -> bool:
    """Ist jetzt eine automatische Sicherung dran? geaendert: Seit dem letzten Blick wurde etwas gespeichert."""
    if not g["auto"] or not g["schluessel"]:
        return False
    letzte = g["letzte"]
    if letzte and not letzte.get("ok"):                     # nach einem Fehler: in Abständen wieder versuchen
        return jetzt - datetime.fromisoformat(letzte["zeit"]) >= NEUER_VERSUCH
    if not g["geprueft"]:
        return True
    if g["rhythmus"] == "aenderung":
        return geaendert
    return jetzt.date() >= datetime.fromisoformat(g["geprueft"]).date() + timedelta(days=7 if g["rhythmus"] == "woechentlich" else 1)


def automatik_schritt(db, daten_ordner: str, ziel, jetzt: datetime, gesehen: int):
    """Ein Blick der Automatik. -> (neuer Merkstand, Ergebnis oder None). Fehler stehen im Stand und erscheinen in der Oberfläche."""
    stand_db = db.gen
    if ziel is None or not faellig(geraet_lesen(daten_ordner), jetzt, stand_db != gesehen):
        return stand_db, None
    try:
        return stand_db, sichern(db, daten_ordner, ziel, jetzt, nur_neues=True)
    except SicherungFehler as e:
        return stand_db, {"ok": False, "fehler": str(e)}
