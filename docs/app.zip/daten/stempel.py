# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Stempeluhr: „Kommen“ startet eine laufende Zeit (HO oder Büro), „Gehen“ addiert sie zum Tag. Vergessenes lässt sich nachtragen:
Beginn und Ende können von Hand angegeben werden (Uhrzeit hh:mm), der Beginn der laufenden Uhr lässt sich korrigieren (beginn_korrigieren).
Gebucht wird immer auf den Tag des Beginns. Über Mitternacht nur mit der Regel „stempel_mitternacht“ (ab Werk aus, Entscheidung des Entwicklers vom
24.11.2026): Dann sind 22:00 bis 1:00 drei Stunden am ersten Tag, ein Ende von Hand vor dem Beginn liegt am Tag danach, und „Gehen“ braucht das Ende
von Hand erst, wenn die Zeit seit einem früheren Tag länger als 10 Stunden läuft („Gehen“ vergessen). Ohne die Regel endet die Uhr spätestens um 23:59
am Tag des Beginns; läuft sie seit einem früheren Tag, braucht „Gehen“ immer das Ende von Hand. Die Pause wird automatisch abgezogen: über 6 Stunden anteilig, höchstens 30 Minuten
(6:25 -> 25 Minuten); eine von Hand angegebene Pause ersetzt das. Mehr als 10 Stunden Arbeitszeit pro Tag nur mit Freigabe.
Kommt „jetzt“ mit Zeitzonen-Versatz, rechnet die Uhr echte Minuten, auch über die Zeitumstellung (Frühjahr 1:30 bis 3:30 = 1 Stunde)."""
import json
from datetime import date, datetime, timedelta

from daten import konfig
from kern import regeln
from kern.zeit import parse_hhmm, fmt_dauer, fmt_hhmm

# Einträge je Tag (Wunsch vom 23.11.2026): [art, kommen, gehen, pause, minuten] je „Gehen“, als JSON in meta. Seit 25.11.2026 in der Synchronisierung (db.SYNC_META,
# Sync-Format 8), sonst zeigte ein anderes Gerät den Tag zusammengefasst. Der Tag selbst bleibt die eine Wahrheit (siehe eintraege).
EINTRAEGE_META = "eintraege_{}"
EINTRAEGE_MAX = 48                                         # mehr Kommen und Gehen an einem Tag gilt als kaputter Wert
EINTRAEGE_TEXT_MAX = 4096                                  # 48 Einträge brauchen rund 1600 Zeichen; Längeres nehmen Synchronisierung und Wiederherstellen nicht an
# Stunden ohne Uhrzeit als eigener Eintrag [Ort, OHNE, OHNE, 0, Minuten] (seit 25.11.2026): sonst verschmolz „Gehen“ nach von Hand gebuchten Stunden alles zu einer Zeile
OHNE = regeln.OHNE_UHRZEIT
BLOCK_DAUER = "Block {n}: Stunden ohne Uhrzeit von 00:01 bis 23:59 (hh:mm), ohne Kommen und Gehen"
ORTE = ("ho", "dst")
ZUKUNFT_TOLERANZ = timedelta(minutes=3)                 # Uhren von Handy und Server weichen ab; so weit voraus gilt eine Uhrzeit als „jetzt“
ZEIT_TEXT_MAX = 5                                       # „hh:mm“; Längeres wird ohne Echo der Eingabe abgelehnt
ENDE_AM_STARTTAG = "Die Stempeluhr endet spätestens um 23:59 am Tag des Beginns. Über Mitternacht unter Einstellungen › Arbeitszeit erlauben."
NUR_HEUTE = "Den Beginn kannst du nur korrigieren, wenn die Uhr heute gestartet wurde. Bitte erst „Gehen“ nachtragen."
BEGINN_FEHLT = "Bitte den Beginn als Uhrzeit eintragen (hh:mm)"
BEGINN_FORMAT = "Beginn: Uhrzeit hh:mm, zum Beispiel 07:30"
UEBERSCHNEIDUNG = "Der Beginn überschneidet sich mit schon gebuchter Zeit ({von} bis {bis} Uhr)"
GEHEN_UEBERSCHNEIDUNG = ("Die laufende Zeit überschneidet sich mit schon gebuchter Zeit ({von} bis {bis} Uhr). Bitte Beginn oder Ende korrigieren "
                         "oder den Eintrag auf der Seite Tag ändern. Die Uhr läuft weiter.")
LAUFENDE_UHR = "Der Eintrag {von}–{bis} überschneidet sich mit der laufenden Stempeluhr (seit {beginn} Uhr). Bitte die Zeiten ändern oder erst „Gehen“ buchen."
BLOECKE_LISTE = f"Blöcke: Liste mit 1 bis {EINTRAEGE_MAX} Einträgen erwartet"
BLOCK_ORT = "Block {n}: Ort Homeoffice oder Büro"
BLOCK_FEHLER = "Block {n}: {text}"
BLOCK_UEBERSCHNEIDUNG = "Die Blöcke {a}–{b} und {c}–{d} überschneiden sich."
GEHEN_NACH_MITTERNACHT = "Gehen spätestens um 23:59 am Tag des Kommens. Über Mitternacht unter Einstellungen › Arbeitszeit erlauben."
BLOCK_NACH_MITTERNACHT = "Block {n}: " + GEHEN_NACH_MITTERNACHT
PAUSE_ZU_LANG = "Die Pause ist länger als die Zeit"
UEBER_ZEHN = "Das wären {ist} Stunden an diesem Tag, erlaubt sind höchstens 10. Ende oder Pause korrigieren oder „Über 10 Stunden freigegeben“ ankreuzen."


class StempelFehler(konfig.Meldung):
    """Fehler bei der Stempeluhr; die Meldung ist für die Person lesbar."""
    pass


def _ortszeit(wand: datetime) -> datetime:
    """Wanduhrzeit ohne Versatz -> derselbe Zeitpunkt mit dem Versatz der Ortszeit (Sommer- oder Winterzeit laut Betriebssystem).
    Ohne zoneinfo, weil das unter Windows und Android Zusatzdaten (tzdata) bräuchte."""
    return wand.astimezone()


def _angleichen(t: datetime, bezug: datetime) -> datetime:
    """t in der Form des Bezugs, damit beide vergleichbar sind: Hat der Bezug keinen Versatz, zählt die Wanduhrzeit (wie bisher);
    hat er einen, bekommt ein t ohne Versatz (Start aus älteren Fassungen, Uhrzeit von Hand) den der Ortszeit."""
    if bezug.tzinfo is None:
        return t.replace(tzinfo=None)
    return t if t.tzinfo else _ortszeit(t)


def _uhrzeit(text, bezug: datetime) -> datetime:
    """„7:45“ -> 7:45 Ortszeit am Datum des Bezugs (mit Versatz, wenn der Bezug einen hat); leer -> None."""
    m = parse_hhmm(text)
    if m is None:
        return None
    wand = bezug.replace(hour=m // 60, minute=m % 60, second=0, microsecond=0, tzinfo=None)
    return _angleichen(wand, bezug)


def status(db, jetzt: datetime) -> dict:
    """Zustand der Stempeluhr zum Zeitpunkt „jetzt“: laeuft, bei laufender Zeit Art, Beginn, vergangene Sekunden, die Feierabend-Angaben
    und die Live-Minuten (_live), dazu die schon gebuchte HO- und Büro-Zeit des heutigen Tages als hh:mm."""
    s = db.stempel_lesen()
    tag = _tag_von(db, jetzt.date())
    heute = {"ho": fmt_hhmm(tag.ho) if tag and tag.ho else "", "dst": fmt_hhmm(tag.dst) if tag and tag.dst else ""}
    if not s:
        return {"laeuft": False, "heute": heute}
    b = _angleichen(s["start"], jetzt)
    sek = max(0, int((jetzt - b).total_seconds()))
    return {"laeuft": True, "art": s["art"], "start": b.isoformat(timespec="seconds"), "start_text": b.strftime("%H:%M"),
            "start_datum": b.date().isoformat(), "sekunden": sek, "heute": heute, **_live(db, b, s["art"])}


def _tag_von(db, d: date):
    """Der gespeicherte Tag d oder None."""
    return next((x for x in db.tage(d.year) if x.datum == d), None)


def _zuwachs(db, b: datetime, art: str) -> tuple:
    """([Zuwachs des Tagesist, wenn „Gehen“ in Minute i nach dem Beginn bucht] bis zum letzten möglichen Gehen, gebuchtes Ist des Tages).
    Gerechnet mit der Tagesrechnung (regeln.tag_rechnen) über alle Einträge des Tages, also genau wie stop."""
    tag = b.date()
    alt = _tag_von(db, tag)
    bisher, frei = _bisher(db, alt), bool(alt and alt.freigabe)
    gebucht = alt.ho + alt.dst if alt else 0
    k = b.hour * 60 + b.minute
    ende = max(k, regeln.GEHEN_MAX_MIN - 1 if ueber_mitternacht(tag) else regeln.TAG_MIN - 1)
    return [sum(e[4] for e in regeln.tag_rechnen(bisher + [[art, k, g, 0, 0]], tag, frei)[0]) - gebucht for g in range(k, ende + 1)], gebucht


def _live(db, b: datetime, art: str) -> dict:
    """Live-Angaben der laufenden Uhr mit Beginn b (Pausenregel Punkt 7): live = Stücke [Minute ab Beginn, Zuwachs, Steigung 0 oder 1], aus denen
    die Oberfläche den Zuwachs des Tagesist für jede Minute abliest (was „Gehen“ jetzt buchen würde); soll_erreicht_um (Tagessoll des Tages des
    Beginns mit Auffüllung „Krank im Dienst“, leer an Tagen ohne Soll) und grenze_10h_um (netto an der Tagesgrenze, vor regeln.KAPPZEIT_AB
    10 Stunden) als ISO-Zeitpunkt; schon erreicht = Beginn, leer, wenn nicht mehr erreichbar (Ende der Regelarbeitszeit, 23:59 ohne Regel
    stempel_mitternacht, Tagesgrenze aus). Keine Fehler."""
    from kern import woche                                  # erst hier: woche lädt db, db lädt stempel (Zirkel beim Import)
    tag = b.date()
    zuwachs, gebucht = _zuwachs(db, b, art)
    t = _tag_von(db, tag)
    eigene, abschnitte = db.eigene_frei_tage(tag.year), db.abschnitte()
    grenze = regeln.tagesgrenze(tag)
    soll = woche.soll_tag(tag, t, eigene, abschnitte) > 0
    return {"live": _stuecke(zuwachs), "soll_erreicht_um": _erreicht_um(b, zuwachs, -woche.saldo_tag(tag, t, eigene, abschnitte)) if soll else "",
            "grenze_10h_um": _erreicht_um(b, zuwachs, grenze - gebucht) if grenze else ""}


def tagesziel(db, jetzt, tag: date) -> tuple:
    """Für das Tagesziel der Kachel „Heute“ am Tag tag: (Beginn der heute gestarteten Uhr oder None, Zuwachs des Ist, wenn „Gehen“ jetzt bucht,
    Uhrzeit hh:mm, zu der das Tagessoll erreicht ist, oder ""), gerechnet wie _live. Ohne Uhr oder bei einer Uhr seit einem früheren Tag
    (None, 0, ""). jetzt None: Uhrzeit des Rechners (Wanduhr wie die Stempeluhr). Keine Fehler."""
    s = db.stempel_lesen()
    b = s["start"].replace(tzinfo=None) if s else None
    if b is None or b.date() != tag:
        return None, 0, ""
    jetzt = jetzt or datetime.combine(tag, datetime.now().time())
    live = _live(db, b, s["art"])
    i = max(0, int((jetzt.replace(second=0, microsecond=0) - b.replace(second=0, microsecond=0)).total_seconds() // 60))
    von, wert, steigung = next(x for x in reversed(live["live"]) if x[0] <= i)
    return b, wert + steigung * (i - von), live["soll_erreicht_um"][11:16]


def gehen_jetzt(db, jetzt: datetime, tag: date):
    """(HO, Büro) des Tages tag in Minuten, wenn „Gehen“ jetzt die heute gestartete Uhr bucht: Tagesrechnung über alle Einträge wie stop
    (die Pflichtpause kann auch frühere Einträge kürzen); ohne Uhr oder bei einer Uhr seit einem früheren Tag None. Sekunden fallen weg (K4). Keine Fehler."""
    s = db.stempel_lesen()
    b = s["start"].replace(tzinfo=None) if s else None
    if b is None or b.date() != tag:
        return None
    alt, k = _tag_von(db, tag), b.hour * 60 + b.minute
    g = max(k, int((jetzt - datetime.combine(tag, datetime.min.time())).total_seconds() // 60))
    liste, _ = regeln.tag_rechnen(_bisher(db, alt) + [[s["art"], k, g, 0, 0]], tag, bool(alt and alt.freigabe))
    return _je_ort(liste)


def _stuecke(zuwachs: list) -> list:
    """Zuwachs je Minute als Stücke [Minute, Zuwachs, Steigung]: ein neues Stück, wo sich die Steigung ändert (Pause, Kappzeit)."""
    stuecke = []
    for i, z in enumerate(zuwachs):
        s = zuwachs[i + 1] - z if i + 1 < len(zuwachs) else 0
        if not stuecke or stuecke[-1][2] != s:              # gleiche Steigung heißt: z liegt schon auf dem Stück (Steigung des Vorgängers = z - Vorgänger)
            stuecke.append([i, z, s])
    return stuecke


def _erreicht_um(b: datetime, zuwachs: list, fehlt: int) -> str:
    """Erster Zeitpunkt (ISO, volle Minute) ab b, an dem der Zuwachs fehlt erreicht; b, wenn nichts fehlt; leer, wenn nie."""
    if fehlt <= 0:
        return b.isoformat(timespec="seconds")
    i = next((i for i, z in enumerate(zuwachs) if z >= fehlt), None)
    return "" if i is None else (b.replace(second=0, microsecond=0) + timedelta(minutes=i)).isoformat(timespec="seconds")


def start(db, art: str, jetzt: datetime, beginn: str = "") -> dict:
    """Startet die Uhr (art: „ho“ oder „dst“), wenn keine läuft. Ein Beginn von Hand (hh:mm) darf höchstens 3 Minuten in der Zukunft liegen,
    Beginn bis jetzt keine gebuchte Zeit schneiden (sonst zählte „Gehen“ sie doppelt). Gibt den neuen Zustand zurück; sonst StempelFehler."""
    if art not in ("ho", "dst"):
        raise StempelFehler("Art muss „ho“ oder „dst“ sein")
    if db.stempel_lesen():
        raise StempelFehler("Es läuft schon eine Zeit – erst „Gehen“")
    beginn = (beginn or "").strip()
    try:
        b = _uhrzeit(beginn, jetzt) if beginn else jetzt.replace(microsecond=0)
    except konfig.Meldung as e:
        raise StempelFehler(str(e))
    b = _nicht_in_der_zukunft(b, jetzt)
    _ohne_ueberschneidung(db, b.date(), b, jetzt)
    db.stempel_setzen(art, b)
    return status(db, jetzt)


def _nicht_in_der_zukunft(b: datetime, jetzt: datetime) -> datetime:
    """Beginn b, höchstens jetzt: bis ZUKUNFT_TOLERANZ voraus gilt jetzt, weiter voraus StempelFehler."""
    if b <= jetzt:
        return b
    if b - jetzt > ZUKUNFT_TOLERANZ:
        raise StempelFehler("Der Beginn liegt in der Zukunft")
    return jetzt.replace(microsecond=0)


def ueber_mitternacht(tag: date) -> bool:
    """Darf die Stempeluhr über Mitternacht laufen? Regel stempel_mitternacht am Tag „tag“. Die laufende Uhr fragt den heutigen Tag, damit eine eben
    „ab heute“ eingeschaltete Regel schon für die Uhr von gestern gilt; das Bearbeiten-Formular fragt den bearbeiteten Tag (gehen_erlaubt),
    die Feierabend-Angaben (_live) den Tag des Beginns."""
    return bool(konfig.fuer(tag).get(konfig.MITTERNACHT_REGEL))


def gehen_erlaubt(gehen: int, tag: date) -> bool:
    """Darf ein Eintrag am Tag „tag“ mit Gehen „gehen“ (Minuten ab 0 Uhr des Tages) enden? Nach 23:59 nur mit der Regel stempel_mitternacht an diesem Tag,
    gleich für die Blockliste und das einzelne Kommen–Gehen des Formulars."""
    return gehen < regeln.TAG_MIN or ueber_mitternacht(tag)


def beginn_korrigieren(db, jetzt: datetime, beginn) -> dict:
    """Setzt nur den Beginn der laufenden Uhr auf die Uhrzeit „beginn“ (hh:mm) am Tag ihres Beginns, früher oder später; der Ort bleibt.
    Nur, wenn die Uhr heute gestartet wurde, außer die Regel stempel_mitternacht ist an. Nie in der Zukunft (bis ZUKUNFT_TOLERANZ gilt jetzt),
    nie überschneidend mit schon gebuchter Zeit des Tages. Rückgabe: neuer Zustand wie status. Fehler: StempelFehler (die Uhr bleibt, wie sie war)."""
    s = db.stempel_lesen()
    if not s:
        raise StempelFehler("Es läuft keine Zeit")
    alt = _angleichen(s["start"], jetzt)
    if alt.date() != jetzt.date() and not ueber_mitternacht(jetzt.date()):
        raise StempelFehler(NUR_HEUTE)
    if beginn is None or (isinstance(beginn, str) and not beginn.strip()):
        raise StempelFehler(BEGINN_FEHLT)
    if not isinstance(beginn, str) or len(beginn.strip()) > ZEIT_TEXT_MAX:
        raise StempelFehler(BEGINN_FORMAT)
    try:
        b = _nicht_in_der_zukunft(_uhrzeit(beginn, alt), jetzt)
    except konfig.Meldung as e:
        raise StempelFehler(str(e))
    _ohne_ueberschneidung(db, alt.date(), b, jetzt)
    db.stempel_setzen(s["art"], b)
    return status(db, jetzt)


def _gebucht(db, tag: date) -> list:
    """Schon gebuchte Spannen des Tages als [(kommen, gehen)] in Minuten ab Mitternacht: die gemerkten Einträge mit Uhrzeit, dazu Kommen und Gehen
    des Tages, wenn er keine gemerkten Einträge hat oder Stunden ohne Uhrzeit darin (HO und Büro in einer Spanne: wo sie liegen, ist offen);
    ein Tag ohne Uhrzeit hat keine Spanne."""
    t = _tag_von(db, tag)
    liste = eintraege(db, t)
    mit = [(e[1], e[2]) for e in liste if e[1] != OHNE]
    spanne = t is not None and t.kommen >= 0 and (not liste or len(mit) < len(liste))
    return mit + [(t.kommen, t.gehen)] if spanne else mit


def _gebucht_um(db, tag: date) -> list:
    """Gebuchte Spannen des Tages und der Nachbartage (über Mitternacht reichende Einträge), in Minuten ab Mitternacht des Tages."""
    return [(k + v * regeln.TAG_MIN, g + v * regeln.TAG_MIN) for v in (-1, 0, 1) for k, g in _gebucht(db, tag + timedelta(days=v))]


def _schnitt(spannen: list, von: int, bis: int):
    """Erste Spanne (kommen, gehen), die von–bis schneidet (Berühren an der Kante zählt nicht), sonst None."""
    return next(((k, g) for k, g in spannen if k < bis and von < g), None)


def _uhr_text(m: int) -> str:
    """Minuten ab Mitternacht eines Tages (auch eines Nachbartags) als Uhrzeit hh:mm."""
    return fmt_hhmm(m % regeln.TAG_MIN)


def _frei_von_gebuchtem(db, tag: date, von: int, bis: int, meldung: str) -> None:
    """StempelFehler mit meldung (Platzhalter von, bis), wenn von–bis (Minuten ab Mitternacht des Tages) gebuchte Zeit schneidet."""
    treffer = _schnitt(_gebucht_um(db, tag), von, bis)
    if treffer:
        raise StempelFehler(meldung.format(von=_uhr_text(treffer[0]), bis=_uhr_text(treffer[1])))


def _ohne_ueberschneidung(db, tag: date, beginn: datetime, jetzt: datetime) -> None:
    """StempelFehler, wenn die laufende Zeit von beginn bis jetzt eine gebuchte Spanne des Tages schneidet (Berühren ist erlaubt)."""
    _frei_von_gebuchtem(db, tag, *_am_tag(tag, beginn, _angleichen(jetzt, beginn)), UEBERSCHNEIDUNG)


def neben_der_uhr(db, tag: date, spannen: list, jetzt: datetime) -> None:
    """Für das Speichern eines Tages: StempelFehler (LAUFENDE_UHR), wenn eine Spanne [(kommen, gehen)] des Tages tag die laufende Uhr von ihrem
    Beginn bis jetzt schneidet (sonst zählte „Gehen“ die Zeit doppelt); Berühren ist erlaubt. Ohne laufende Uhr nichts."""
    s = db.stempel_lesen()
    if not s:
        return
    beginn = _angleichen(s["start"], jetzt)
    von, bis = _am_tag(tag, beginn, _angleichen(jetzt, beginn))
    treffer = _schnitt(spannen, von, bis)
    if treffer:
        raise StempelFehler(LAUFENDE_UHR.format(von=_uhr_text(treffer[0]), bis=_uhr_text(treffer[1]), beginn=beginn.strftime("%H:%M")))


def _am_tag(tag: date, beginn: datetime, ende: datetime) -> tuple:
    """(kommen, gehen) als Minuten ab Mitternacht des Tages (Gehen nach Mitternacht über 1440), in der Zeitzone des Beginns.
    Sekunden fallen weg (K4: die Minute des Ein- und Ausbuchens zählt, nie gerundet)."""
    null = datetime.combine(tag, datetime.min.time(), beginn.tzinfo)
    return int((beginn - null).total_seconds() // 60), int((ende - null).total_seconds() // 60)


def tageszeiten(liste: list, kapp: dict, spanne: tuple = ()) -> tuple:
    """(Kommen, Gehen, Pause) des Tages aus den gerechneten Einträgen: frühestes Kommen, spätestes Gehen; Pause = was dazwischen weder Arbeit
    noch Kappzeit ist (Lücken, Pausen von Hand, Pflichtpause). spanne (Kommen, Gehen) eines Tages mit Uhrzeit, dessen Stunden ohne Uhrzeit in der
    Liste stehen (Homeoffice und Büro in einer Spanne), zählt mit. Sonst mit Stunden ohne Uhrzeit oder einer unmöglichen Angabe (Lücke als Pause
    zu lang): ohne Uhrzeit."""
    mit = [e for e in liste if e[1] != OHNE]
    ohne = len(mit) < len(liste)
    if not liste or (ohne and not spanne):
        return OHNE, OHNE, 0
    rand = list(spanne) if ohne else []
    k, g = min([e[1] for e in mit] + rand[:1]), max([e[2] for e in mit] + rand[1:])
    pause = g - k - sum(e[4] for e in liste) - sum(kapp.values())
    return (k, g, pause) if regeln.uhrzeiten_gueltig(k, g, pause) else (OHNE, OHNE, 0)


def spanne_beides(alt) -> tuple:
    """(Kommen, Gehen) eines Tages mit Homeoffice und Büro in einer Spanne (tageszeiten, Argument spanne), sonst (); ein Tag mit Uhrzeit an nur
    einem Ort bleibt ohne (K4 streng: passt er nicht als Eintrag, ist er Stunden ohne Uhrzeit)."""
    return (alt.kommen, alt.gehen) if alt and alt.kommen >= 0 and alt.ho and alt.dst else ()


def _bisher(db, alt) -> list:
    """Einträge des Tages alt, an die „Gehen“ anhängt (bestand); ein Tag mit Uhrzeit an beiden Orten ohne gemerkte Liste zählt je Ort als
    Stunden ohne Uhrzeit."""
    return bestand(db, alt) or ([[o, OHNE, OHNE, 0, m] for o, m in zip(ORTE, (alt.ho, alt.dst)) if m] if alt else [])


def _je_ort(liste: list) -> tuple:
    """(HO-Minuten, Büro-Minuten) der Einträge."""
    return tuple(sum(e[4] for e in liste if e[0] == o) for o in ORTE)


def tag_pruefen(tag: date, minuten: int, freigabe) -> None:
    """Grenzen eines Tages nach der Tagesrechnung: höchstens 24 Stunden, über der Grenze ohne Freigabe nur, was die Kappzeit nicht kürzt
    (regeln.zehn_stunden_fehler). Fehler: StempelFehler."""
    if minuten > regeln.TAG_MIN:
        raise StempelFehler(f"{regeln.TAG_VOLL}; das wären {fmt_hhmm(minuten)}. Ende oder Pause korrigieren.")
    if regeln.zehn_stunden_fehler(tag, minuten, freigabe):
        raise StempelFehler(UEBER_ZEHN.format(ist=fmt_hhmm(minuten)))


def stop(db, jetzt: datetime, ende: str = "", pause_min=None, art: str = "", freigabe: bool = False) -> dict:
    """Beendet die Uhr und bucht die Zeit auf den Tag des Beginns (Ende, Pause von Hand in Minuten, Art und Freigabe sind optional); „Pause“ an
    der Stempeluhr ist dasselbe Gehen. Der ganze Tag wird neu gerechnet (regeln.tag_rechnen: Kappzeit, Pflichtpause vom letzten Eintrag rückwärts).
    Gibt den Zustand mit dem Zuwachs des Tagesist (gebucht_min) und der Pause des Tages (pause_min) zurück; StempelFehler bei Zukunft, negativer
    Zeit, mehr als 24 Stunden am Tag oder über der Grenze ohne Freigabe (tag_pruefen)."""
    s = db.stempel_lesen()
    if not s:
        raise StempelFehler("Es läuft keine Zeit")
    ende = (ende or "").strip()
    beginn = _angleichen(s["start"], jetzt)
    frueher = beginn.date() != jetzt.date()
    mitternacht = ueber_mitternacht(jetzt.date())
    if not ende and frueher and (not mitternacht or jetzt - beginn > timedelta(minutes=regeln.MAX_TAG_MIN)):     # „Gehen“ vergessen: nie die Nacht mitbuchen
        raise StempelFehler(f"Die Zeit läuft seit dem {beginn.strftime('%d.%m.%Y, %H:%M')} Uhr. Bitte das Ende als Uhrzeit eintragen oder die Zeit verwerfen.")
    try:
        e = _uhrzeit(ende, beginn) if ende else jetzt.replace(second=0, microsecond=0)   # Minute des Gehens (K4); ein Ende von Hand gilt für den Tag des Beginns …
        if ende and e < beginn and frueher:
            if not mitternacht:
                raise StempelFehler(ENDE_AM_STARTTAG)
            e = _uhrzeit(ende, beginn + timedelta(days=1))      # … oder, nach Mitternacht, für den Tag danach (Versatz dieses Tages)
    except konfig.Meldung as ex:
        raise StempelFehler(str(ex))
    if e - jetzt > ZUKUNFT_TOLERANZ:                # bis 3 Minuten voraus gilt das Ende so, wie es im Feld steht (Uhren weichen ab, „gleich 12:00“)
        raise StempelFehler("Das Ende liegt in der Zukunft")
    if e < beginn:
        raise StempelFehler("Das Ende liegt vor dem Beginn")
    hand = pause_min or 0
    if not 0 <= hand <= regeln.PAUSE_HAND_MAX_MIN:
        raise StempelFehler(f"Pause: 0 bis {regeln.PAUSE_HAND_MAX_MIN} Minuten")
    tag = beginn.date()
    k, g = _am_tag(tag, beginn, e)
    if hand > g - k:
        raise StempelFehler(PAUSE_ZU_LANG)
    art = art or s["art"]
    if art not in ORTE:
        raise StempelFehler("Art muss „ho“ oder „dst“ sein")
    _frei_von_gebuchtem(db, tag, k, g, GEHEN_UEBERSCHNEIDUNG)     # sonst zählte die Zeit doppelt (Endprüfung 26.11.2026)
    alt = _tag_von(db, tag)
    frei = bool(freigabe or (alt and alt.freigabe))
    liste, kapp = regeln.tag_rechnen(_bisher(db, alt) + [[art, k, g, hand, 0]], tag, frei)
    ho, dst = _je_ort(liste)
    tag_pruefen(tag, ho + dst, frei)
    # Zeitumstellung im Block: die Wanduhr passt nicht zur Dauer, der Tag bleibt ohne Uhrzeit (reicht für die eine Nacht im Jahr)
    kommen, gehen, pause = tageszeiten(liste, kapp, spanne_beides(alt)) if beginn.utcoffset() == e.utcoffset() else (OHNE, OHNE, 0)
    db.tag_setzen(tag, ho, dst, alt.art if alt else "", alt.notiz if alt else "", alt.konto if alt else 0, alt.attest if alt else "", 1 if frei else 0,
                  kommen, gehen, pause, meta=(EINTRAEGE_META.format(tag.isoformat()), json.dumps(liste)))
    db.stempel_loeschen()
    r = status(db, jetzt)
    zuwachs = ho + dst - (alt.ho + alt.dst if alt else 0)
    r.update({"pause_min": pause, "gebucht_min": zuwachs, "gebucht": fmt_hhmm(zuwachs), "gebucht_datum": tag.isoformat()})
    return r


def verwerfen(db, jetzt: datetime) -> dict:
    """Wirft die laufende Zeit weg, ohne zu buchen, und gibt den Zustand zurück."""
    db.stempel_loeschen()
    return status(db, jetzt)


def _eintrag_gueltig(e) -> bool:
    """Ein gespeicherter Eintrag [art, kommen, gehen, pause, minuten]: Ort HO oder Büro, ganze Minuten in den Grenzen des Tages;
    ohne Uhrzeit genau [Ort, OHNE, OHNE, 0, Minuten] mit 1 bis regeln.TAG_MIN Minuten."""
    if not (isinstance(e, list) and len(e) == 5 and e[0] in ORTE and all(type(x) is int for x in e[1:])):
        return False
    if e[1] == OHNE:
        return e[2] == OHNE and e[3] == 0 and 0 < e[4] <= regeln.TAG_MIN
    return 0 <= e[1] <= e[2] <= regeln.GEHEN_MAX_MIN and 0 <= e[3] <= regeln.PAUSE_HAND_MAX_MIN and 0 <= e[4] <= e[2] - e[1] + 1


def _passt(liste: list, t) -> bool:
    """Ergeben die Einträge genau den gespeicherten Tag t (frühestes Kommen, spätestes Gehen, Minuten je Ort)? Ohne Uhrzeit (Lücke als Pause
    zu lang, etwa über Mitternacht, oder Stunden ohne Uhrzeit dabei) zählen nur die Minuten je Ort."""
    return (bool(liste) and all(map(_eintrag_gueltig, liste))
            and (t.kommen < 0 or _in_der_spanne(liste, t))
            and all(sum(e[4] for e in liste if e[0] == o) == m for o, m in zip(ORTE, (t.ho, t.dst))))


def _in_der_spanne(liste: list, t) -> bool:
    """Passen die Einträge zu Kommen–Gehen des Tages t? Ohne Stunden ohne Uhrzeit genau (frühestes Kommen, spätestes Gehen); mit ihnen (Homeoffice
    und Büro in einer Spanne, danach gestempelt) liegt mindestens ein Eintrag mit Uhrzeit darin, und alle mit Uhrzeit liegen in Kommen–Gehen."""
    mit = [e for e in liste if e[1] != OHNE]
    if len(mit) == len(liste):
        return (min(e[1] for e in mit), max(e[2] for e in mit)) == (t.kommen, t.gehen)
    return bool(mit) and t.kommen <= min(e[1] for e in mit) and max(e[2] for e in mit) <= t.gehen


def eintraege(db, t) -> list:
    """Die gemerkten Einträge des Tages t (regeln.Tag oder None), soweit sie zu ihm passen: der längste passende Anfang der Liste.
    So fällt nach Rückgängig des letzten „Gehen“ nur dieser Eintrag weg; nach einer Änderung von Hand, einem Sync oder bei einem kaputten
    Wert passt nichts mehr, und der Tag hat keine Einträge (die Seite zeigt dann die eine Zeile wie bisher). Nie ein Fehler."""
    if t is None:
        return []
    try:
        liste = json.loads(db.meta_lesen(EINTRAEGE_META.format(t.datum.isoformat()), "[]"))
    except (ValueError, RecursionError):
        return []
    if not isinstance(liste, list) or len(liste) > EINTRAEGE_MAX:
        return []
    return next((liste[:n] for n in range(len(liste), 0, -1) if _passt(liste[:n], t)), [])


def _aus_dem_tag(t) -> list:
    """Ein Tag mit Kommen–Gehen an genau einem Ort (von Hand gespeichert, ohne gemerkte Liste) als ein Eintrag [art, kommen, gehen, pause, minuten].
    Ohne Uhrzeit, mit Homeoffice und Büro in einer Spanne oder mit Werten, die kein gültiger Eintrag sind (Pause samt Lücke alter Fassungen): keiner.
    Pause −1 eines Tages vor regeln.KAPPZEIT_AB (gerundete Minute alter Fassungen) gilt als 0 (K4c)."""
    if t is None or t.kommen < 0 or (t.ho and t.dst) or not t.ho + t.dst:
        return []
    alt_gerundet = t.pause == -1 and t.datum < regeln.KAPPZEIT_AB       # K4c: alte Fassungen rundeten auf Minuten, Pause −1 war geduldet; ab KAPPZEIT_AB streng (K4)
    e = [ORTE[0] if t.ho else ORTE[1], t.kommen, t.gehen, 0 if alt_gerundet else t.pause, t.ho + t.dst]
    return [e] if _eintrag_gueltig(e) else []


def einzeln(db, t) -> list:
    """Die Einträge des Tages t: die gemerkten (eintraege), sonst der Tag selbst als ein Eintrag (_aus_dem_tag). So hängt „Gehen“ an ein von Hand
    gespeichertes Kommen–Gehen einen zweiten Eintrag an, statt beide zu verschmelzen (Meldung vom 25.11.2026)."""
    return eintraege(db, t) or _aus_dem_tag(t)


def _ohne_uhrzeit(t) -> list:
    """Stunden eines Tages ohne Uhrzeit als Einträge ohne Uhrzeit, je Ort einer; ein Tag mit Uhrzeit oder ohne Stunden: keiner."""
    if t is None or t.kommen >= 0:
        return []
    return [[o, OHNE, OHNE, 0, m] for o, m in zip(ORTE, (t.ho, t.dst)) if m]


def bestand(db, t) -> list:
    """Alle Einträge des Tages t, an die „Gehen“ anhängt und die die Seite Tag einzeln zeigt: einzeln, sonst die Stunden ohne Uhrzeit (_ohne_uhrzeit)."""
    return einzeln(db, t) or _ohne_uhrzeit(t)


def liste_text_gueltig(v) -> bool:
    """Wert der Einträge eines Tages aus Synchronisierung oder Sicherung: Text bis EINTRAEGE_TEXT_MAX Zeichen. Den Inhalt prüft eintraege beim Lesen
    (ein kaputter Wert gibt dort keine Einträge), damit ein Gerät mit einem alten, ungültigen Wert die Synchronisierung der anderen nicht blockiert."""
    return isinstance(v, str) and len(v) <= EINTRAEGE_TEXT_MAX


def _block_ohne_uhrzeit(n: int, b: dict) -> list:
    """Block n (ab 1) mit Stunden ohne Uhrzeit {art, dauer hh:mm} -> [art, OHNE, OHNE, 0, Minuten]; StempelFehler mit Blocknummer
    (auch mit Kommen, Gehen oder Pause daneben)."""
    try:
        m = parse_hhmm(b["dauer"]) if isinstance(b["dauer"], str) and not {"kommen", "gehen", "pause"} & b.keys() else None
    except konfig.Meldung:
        m = None
    if not m:
        raise StempelFehler(BLOCK_DAUER.format(n=n))
    return [b["art"], OHNE, OHNE, 0, m]


def _block_lesen(n: int, b, tag: date) -> list:
    """Block n (ab 1) des Formulars {art, kommen, gehen, pause} -> Roh-Eintrag [art, kommen, gehen, Pause von Hand (leer = 0), 0]; StempelFehler mit Blocknummer.
    Gehen nach Mitternacht (über 23:59) nur mit der Regel stempel_mitternacht, wie bei der Stempeluhr. {art, dauer}: Stunden ohne Uhrzeit (_block_ohne_uhrzeit)."""
    if not isinstance(b, dict) or b.get("art") not in ORTE:
        raise StempelFehler(BLOCK_ORT.format(n=n))
    if "dauer" in b:
        return _block_ohne_uhrzeit(n, b)
    try:
        k, g, p = parse_hhmm(b.get("kommen")), parse_hhmm(b.get("gehen"), 47), parse_hhmm(b.get("pause"))
        if k is None or g is None:
            raise konfig.Meldung("Kommen und Gehen bitte zusammen eintragen")
        regeln.arbeitszeit(k, g, p or 0, tag)
    except konfig.Meldung as e:
        raise StempelFehler(BLOCK_FEHLER.format(n=n, text=e))
    if not gehen_erlaubt(g, tag):
        raise StempelFehler(BLOCK_NACH_MITTERNACHT.format(n=n))
    return [b["art"], k, g, p or 0, 0]


def bloecke(roh, tag: date, freigabe=False, spanne: tuple = ()) -> tuple:
    """Blöcke eines Tages aus dem Bearbeiten-Formular und der Seite Tag (PUT /api/tag mit „eintraege“: [{art „ho“/„dst“, kommen, gehen bis 23:59
    (mit Regel stempel_mitternacht bis 47:59), pause = Pause von Hand, leer = 0}] oder für Stunden ohne Uhrzeit {art, dauer}).
    Prüft wie die Stempeluhr: Format, Gehen nach Kommen, keine Überschneidung, höchstens EINTRAEGE_MAX Blöcke (Grenzen des Tages prüft tag_pruefen).
    Gerechnet wird der ganze Tag mit regeln.tag_rechnen und der Genehmigung freigabe (Stunden ohne Uhrzeit sind reine Arbeitszeit). spanne
    (spanne_beides des gespeicherten Tages) hält Kommen–Gehen eines Tages mit Homeoffice und Büro in einer Spanne, solange Blöcke mit Uhrzeit dabei sind.
    Rückgabe (kommen, gehen, pause, ho, dst, liste): Kommen, Gehen und Pause des Tages wie tageszeiten, liste = gemerkte Einträge
    [art, kommen, gehen, Pause von Hand, Minuten], die ohne Uhrzeit zuerst, dann nach Beginn sortiert. Fehler: StempelFehler mit lesbarer Meldung."""
    if not isinstance(roh, list) or not 1 <= len(roh) <= EINTRAEGE_MAX:
        raise StempelFehler(BLOECKE_LISTE)
    liste = sorted((_block_lesen(n, b, tag) for n, b in enumerate(roh, 1)), key=lambda e: e[1])
    mit = [e for e in liste if e[1] != OHNE]
    for a, b in zip(mit, mit[1:]):
        if b[1] < a[2]:
            raise StempelFehler(BLOCK_UEBERSCHNEIDUNG.format(a=fmt_hhmm(a[1]), b=fmt_hhmm(a[2]), c=fmt_hhmm(b[1]), d=fmt_hhmm(b[2])))
    liste, kapp = regeln.tag_rechnen(liste, tag, freigabe)
    return (*tageszeiten(liste, kapp, spanne if mit else ()), *_je_ort(liste), liste)


def kappzeit(db, t) -> dict:
    """Kappzeit des gespeicherten Tages t (regeln.Tag oder None) je Grund {"vor", "nach", "ueber"} in Minuten, neu gerechnet aus den Einträgen
    (gemerkte Liste mit der Pause von Hand je Eintrag, sonst Kommen–Gehen des Tages mit seiner Pause) nach den Regeln des Tages; ohne Uhrzeit oder wenn die gespeicherten Minuten nicht zur Rechnung passen 0.
    shortcut: der Grund folgt den heutigen Regeln für dieses Datum; ändert jemand die Regel später rückwirkend, bleiben die gebuchten Minuten."""
    if t is None:
        return dict.fromkeys(regeln.KAPP_GRUENDE, 0)
    liste = eintraege(db, t) or ([[ORTE[1], t.kommen, t.gehen, t.pause, 0]] if t.kommen >= 0 else [])
    gerechnet, kapp = regeln.tag_rechnen(liste, t.datum, t.freigabe)
    # Ein Tag, dessen Minuten nicht aus dieser Rechnung stammen (von Hand, Import, Synchronisierung), hat nichts verloren: keine Kappzeit erfinden
    if sum(e[4] for e in gerechnet) != t.ho + t.dst:
        return dict.fromkeys(regeln.KAPP_GRUENDE, 0)
    return kapp


def _uhr(m: int) -> str:
    """Kommen oder Gehen eines Eintrags als hh:mm; ohne Uhrzeit (OHNE) leer."""
    return "" if m == OHNE else fmt_hhmm(m)


KAPP_TEXTE = {"vor": "vor {beginn}", "nach": "nach {ende}", "ueber": "über {grenze} Std."}    # Grund der Kappzeit, Uhrzeiten der Regeln des Tages


def kappzeit_grund(kapp: dict, d: date) -> str:
    """Gründe der Kappzeit kapp ({"vor", "nach", "ueber"}) am Tag d als Text, z. B. „vor 06:00 · über 10:00 Std.“; leer ohne Kappzeit."""
    regelzeit, grenze = regeln.kappzeit_regeln(d)
    beginn, ende = regelzeit or (0, 0)
    werte = {"beginn": fmt_hhmm(beginn), "ende": fmt_hhmm(ende), "grenze": fmt_hhmm(grenze or 0)}
    return " · ".join(KAPP_TEXTE[g].format(**werte) for g in regeln.KAPP_GRUENDE if kapp[g])


def _mit_kappzeit(db, z: dict, t, zeitformat: str) -> dict:
    """Tageszeile z mit „kappzeit“ (Summe im Zeitformat), „kappzeit_min“ und „kappzeit_grund“, wenn der Tag t Kappzeit hat; sonst unverändert."""
    kapp = kappzeit(db, t)
    summe = sum(kapp.values())
    if not summe:
        return z
    return {**z, "kappzeit": fmt_dauer(summe, zeitformat), "kappzeit_min": summe, "kappzeit_grund": kappzeit_grund(kapp, t.datum)}


def mit_eintraegen(db, antwort: dict, zeitformat: str, seite_tag: bool = False) -> dict:
    """Antwort von bericht.woche oder bericht.monat, je Tag mit mindestens zwei Einträgen (einzeln; Monat, Nachweis und Exporte) bzw. mit seite_tag
    (GET /woche für die Seite Tag, Woche zeigt nur die Tageszeile) ab einem Eintrag samt Stunden ohne Uhrzeit (bestand) ergänzt um „eintraege“ ([{art, kommen, gehen, dauer, pause, hand}],
    Uhrzeiten hh:mm, ohne Uhrzeit leer, Dauer im Zeitformat, Pause = Pause von Hand plus Pflichtpause dieses Eintrags, hand = nur die Pause von Hand, beide leer bei 0), „eintraege_pause“
    (Summe dieser Pausen, ohne die Lücken; leer bei 0) und „eintraege_summe“ (Arbeitszeit aller Blöcke im Zeitformat, die Tagessumme der letzten
    Blockzeile im Nachweis und in der CSV). Jeder Tag mit Kappzeit bekommt dazu kappzeit, kappzeit_min und kappzeit_grund (_mit_kappzeit).
    Andere Tage bleiben, wie sie sind. Die Antwort selbst wird nicht verändert (sie kann aus dem Zwischenspeicher kommen)."""
    tage = {t.datum: t for j in {int(z["datum"][:4]) for z in antwort["tage"]} for t in db.tage(j)}
    neu = []
    for z in antwort["tage"]:
        t = tage.get(date.fromisoformat(z["datum"]))
        liste = bestand(db, t) if seite_tag else einzeln(db, t)
        if len(liste) >= (1 if seite_tag else 2):
            pausen = regeln.pausen_je_eintrag(liste, t.datum, t.freigabe)
            z = {**z, "eintraege_pause": fmt_hhmm(sum(pausen)) if sum(pausen) else "", "eintraege_summe": fmt_dauer(sum(e[4] for e in liste), zeitformat),
                 "eintraege": [{"art": a, "kommen": _uhr(k), "gehen": _uhr(g), "dauer": fmt_dauer(m, zeitformat), "pause": fmt_hhmm(p) if p else "",
                                "hand": fmt_hhmm(h) if h else ""} for (a, k, g, h, m), p in zip(liste, pausen)]}
        neu.append(_mit_kappzeit(db, z, t, zeitformat) if t else z)
    return {**antwort, "tage": neu}
