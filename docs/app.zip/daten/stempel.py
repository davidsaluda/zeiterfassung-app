# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Stempeluhr: „Kommen“ startet eine laufende Zeit (HO oder Büro), „Gehen“ addiert sie zum Tag. Vergessenes lässt sich nachtragen:
Beginn und Ende können von Hand angegeben werden (Uhrzeit hh:mm), der Beginn der laufenden Uhr lässt sich korrigieren (beginn_korrigieren).
Gebucht wird immer auf den Tag des Beginns. Über Mitternacht nur mit der Regel „stempel_mitternacht“ (ab Werk aus, Entscheidung des Entwicklers vom
24.11.2026): Dann sind 22:00 bis 1:00 drei Stunden am ersten Tag, ein Ende von Hand vor dem Beginn liegt am Tag danach, und „Gehen“ braucht das Ende
von Hand erst, wenn die Zeit seit einem früheren Tag länger als 10 Stunden läuft („Gehen“ vergessen). Ohne die Regel endet die Uhr spätestens um 23:59
am Tag des Beginns; läuft sie seit einem früheren Tag, braucht „Gehen“ immer das Ende von Hand. Die Pause wird automatisch abgezogen: über 6 Stunden anteilig, höchstens 30 Minuten
(6:25 -> 25 Minuten); eine von Hand angegebene Pause ersetzt das. Mehr als 10 Stunden Arbeitszeit pro Tag nur mit Freigabe.
Kommt „jetzt“ mit Zeitzonen-Versatz, rechnet die Uhr echte Minuten, auch über die Zeitumstellung (Frühjahr 1:30 bis 3:30 = 1 Stunde)."""
import json
from datetime import date, datetime, timedelta

from daten import konfig
from kern import regeln
from kern.zeit import parse_hhmm, fmt_dauer, fmt_hhmm

# Einträge je Tag (Wunsch vom 23.11.2026): [art, kommen, gehen, pause, minuten] je „Gehen“, als JSON in meta. Nur auf diesem Gerät (nicht in SYNC_META):
# Ältere Fassungen und andere Geräte übergehen den Schlüssel, und der Tag selbst bleibt die eine Wahrheit (siehe eintraege).
EINTRAEGE_META = "eintraege_{}"
EINTRAEGE_MAX = 48                                         # mehr Kommen und Gehen an einem Tag gilt als kaputter Wert
ORTE = ("ho", "dst")
ZUKUNFT_TOLERANZ = timedelta(minutes=3)                 # Uhren von Handy und Server weichen ab; so weit voraus gilt eine Uhrzeit als „jetzt“
ZEIT_TEXT_MAX = 5                                       # „hh:mm“; Längeres wird ohne Echo der Eingabe abgelehnt
ENDE_AM_STARTTAG = "Die Stempeluhr endet spätestens um 23:59 am Tag des Beginns. Über Mitternacht unter Einstellungen › Arbeitszeit erlauben."
NUR_HEUTE = "Den Beginn kannst du nur korrigieren, wenn die Uhr heute gestartet wurde. Bitte erst „Gehen“ nachtragen."
BEGINN_FEHLT = "Bitte den Beginn als Uhrzeit eintragen (hh:mm)"
BEGINN_FORMAT = "Beginn: Uhrzeit hh:mm, zum Beispiel 07:30"
UEBERSCHNEIDUNG = "Der Beginn überschneidet sich mit schon gebuchter Zeit ({von} bis {bis} Uhr)"
BLOECKE_LISTE = f"Blöcke: Liste mit 1 bis {EINTRAEGE_MAX} Einträgen erwartet"
BLOCK_ORT = "Block {n}: Ort Homeoffice oder Büro"
BLOCK_FEHLER = "Block {n}: {text}"
BLOCK_UEBERSCHNEIDUNG = "Die Blöcke {a}–{b} und {c}–{d} überschneiden sich."
GEHEN_NACH_MITTERNACHT = "Gehen spätestens um 23:59 am Tag des Kommens. Über Mitternacht unter Einstellungen › Arbeitszeit erlauben."
BLOCK_NACH_MITTERNACHT = "Block {n}: " + GEHEN_NACH_MITTERNACHT
BLOCK_PAUSE_ZU_LANG = "Block {n}: Die Pause nach Regel ist länger als der Block. Pause selbst eintragen."


class StempelFehler(konfig.Meldung):
    """Fehler bei der Stempeluhr; die Meldung ist für die Person lesbar."""
    pass


def _ortszeit(wand: datetime) -> datetime:
    """Wanduhrzeit ohne Versatz -> derselbe Zeitpunkt mit dem Versatz der Ortszeit (Sommer- oder Winterzeit laut Betriebssystem).
    Ohne zoneinfo, weil das unter Windows und Android Zusatzdaten (tzdata) bräuchte."""
    return wand.astimezone()


def _angleichen(t: datetime, bezug: datetime) -> datetime:
    """t in der Form des Bezugs, damit beide vergleichbar sind: Hat der Bezug keinen Versatz, zählt die Wanduhrzeit (wie bisher);
    hat er einen, bekommt ein t ohne Versatz (Start aus älteren Fassungen, Uhrzeit von Hand) den der Ortszeit."""
    if bezug.tzinfo is None:
        return t.replace(tzinfo=None)
    return t if t.tzinfo else _ortszeit(t)


def _uhrzeit(text, bezug: datetime) -> datetime:
    """„7:45“ -> 7:45 Ortszeit am Datum des Bezugs (mit Versatz, wenn der Bezug einen hat); leer -> None."""
    m = parse_hhmm(text)
    if m is None:
        return None
    wand = bezug.replace(hour=m // 60, minute=m % 60, second=0, microsecond=0, tzinfo=None)
    return _angleichen(wand, bezug)


def status(db, jetzt: datetime) -> dict:
    """Zustand der Stempeluhr zum Zeitpunkt „jetzt“: laeuft, bei laufender Zeit Art, Beginn und vergangene Sekunden,
    dazu die schon gebuchte HO- und Büro-Zeit des heutigen Tages als hh:mm."""
    s = db.stempel_lesen()
    tag = next((t for t in db.tage(jetzt.year) if t.datum == jetzt.date()), None)
    heute = {"ho": fmt_hhmm(tag.ho) if tag and tag.ho else "", "dst": fmt_hhmm(tag.dst) if tag and tag.dst else ""}
    if not s:
        return {"laeuft": False, "heute": heute}
    b = _angleichen(s["start"], jetzt)
    sek = max(0, int((jetzt - b).total_seconds()))
    return {"laeuft": True, "art": s["art"], "start": b.isoformat(timespec="seconds"), "start_text": b.strftime("%H:%M"),
            "start_datum": b.date().isoformat(), "sekunden": sek, "heute": heute}


def start(db, art: str, jetzt: datetime, beginn: str = "") -> dict:
    """Startet die Uhr (art: „ho“ oder „dst“), wenn keine läuft. Ein Beginn von Hand (hh:mm) darf höchstens 3 Minuten in der Zukunft liegen.
    Gibt den neuen Zustand zurück; sonst StempelFehler."""
    if art not in ("ho", "dst"):
        raise StempelFehler("Art muss „ho“ oder „dst“ sein")
    if db.stempel_lesen():
        raise StempelFehler("Es läuft schon eine Zeit – erst „Gehen“")
    beginn = (beginn or "").strip()
    try:
        b = _uhrzeit(beginn, jetzt) if beginn else jetzt.replace(microsecond=0)
    except konfig.Meldung as e:
        raise StempelFehler(str(e))
    db.stempel_setzen(art, _nicht_in_der_zukunft(b, jetzt))
    return status(db, jetzt)


def _nicht_in_der_zukunft(b: datetime, jetzt: datetime) -> datetime:
    """Beginn b, höchstens jetzt: bis ZUKUNFT_TOLERANZ voraus gilt jetzt, weiter voraus StempelFehler."""
    if b <= jetzt:
        return b
    if b - jetzt > ZUKUNFT_TOLERANZ:
        raise StempelFehler("Der Beginn liegt in der Zukunft")
    return jetzt.replace(microsecond=0)


def ueber_mitternacht(tag: date) -> bool:
    """Darf die Stempeluhr über Mitternacht laufen? Regel stempel_mitternacht am Tag „tag“. Die laufende Uhr fragt den heutigen Tag, damit eine eben
    „ab heute“ eingeschaltete Regel schon für die Uhr von gestern gilt; das Bearbeiten-Formular fragt den bearbeiteten Tag (gehen_erlaubt)."""
    return bool(konfig.fuer(tag).get(konfig.MITTERNACHT_REGEL))


def gehen_erlaubt(gehen: int, tag: date) -> bool:
    """Darf ein Eintrag am Tag „tag“ mit Gehen „gehen“ (Minuten ab 0 Uhr des Tages) enden? Nach 23:59 nur mit der Regel stempel_mitternacht an diesem Tag,
    gleich für die Blockliste und das einzelne Kommen–Gehen des Formulars."""
    return gehen < regeln.TAG_MIN or ueber_mitternacht(tag)


def beginn_korrigieren(db, jetzt: datetime, beginn) -> dict:
    """Setzt nur den Beginn der laufenden Uhr auf die Uhrzeit „beginn“ (hh:mm) am Tag ihres Beginns, früher oder später; der Ort bleibt.
    Nur, wenn die Uhr heute gestartet wurde, außer die Regel stempel_mitternacht ist an. Nie in der Zukunft (bis ZUKUNFT_TOLERANZ gilt jetzt),
    nie überschneidend mit schon gebuchter Zeit des Tages. Rückgabe: neuer Zustand wie status. Fehler: StempelFehler (die Uhr bleibt, wie sie war)."""
    s = db.stempel_lesen()
    if not s:
        raise StempelFehler("Es läuft keine Zeit")
    alt = _angleichen(s["start"], jetzt)
    if alt.date() != jetzt.date() and not ueber_mitternacht(jetzt.date()):
        raise StempelFehler(NUR_HEUTE)
    if beginn is None or (isinstance(beginn, str) and not beginn.strip()):
        raise StempelFehler(BEGINN_FEHLT)
    if not isinstance(beginn, str) or len(beginn.strip()) > ZEIT_TEXT_MAX:
        raise StempelFehler(BEGINN_FORMAT)
    try:
        b = _nicht_in_der_zukunft(_uhrzeit(beginn, alt), jetzt)
    except konfig.Meldung as e:
        raise StempelFehler(str(e))
    _ohne_ueberschneidung(db, alt.date(), b, jetzt)
    db.stempel_setzen(s["art"], b)
    return status(db, jetzt)


def _gebucht(db, tag: date) -> list:
    """Schon gebuchte Spannen des Tages als [(kommen, gehen)] in Minuten ab Mitternacht: die gemerkten Einträge, sonst Kommen und Gehen des Tages;
    ein Tag ohne Uhrzeit hat keine Spanne."""
    t = next((x for x in db.tage(tag.year) if x.datum == tag), None)
    liste = eintraege(db, t)
    if liste:
        return [(e[1], e[2]) for e in liste]
    return [(t.kommen, t.gehen)] if t and t.kommen >= 0 else []


def _ohne_ueberschneidung(db, tag: date, beginn: datetime, jetzt: datetime) -> None:
    """StempelFehler, wenn die laufende Zeit von beginn bis jetzt eine gebuchte Spanne des Tages schneidet (Berühren ist erlaubt)."""
    von, bis = _am_tag(tag, beginn, _angleichen(jetzt, beginn))
    for kommen, gehen in _gebucht(db, tag):
        if kommen < bis and von < gehen:
            raise StempelFehler(UEBERSCHNEIDUNG.format(von=fmt_hhmm(kommen), bis=fmt_hhmm(gehen)))


def _am_tag(tag: date, beginn: datetime, ende: datetime) -> tuple:
    """(kommen, gehen) als Minuten ab Mitternacht des Tages (Gehen nach Mitternacht über 1440), in der Zeitzone des Beginns."""
    null = datetime.combine(tag, datetime.min.time(), beginn.tzinfo)
    return int(round((beginn - null).total_seconds() / 60)), int(round((ende - null).total_seconds() / 60))


def _uhrzeiten(alt, tag, beginn: datetime, ende: datetime, arbeit: int) -> tuple:
    """Kommen = frühester Beginn, Gehen = spätestes Ende des Tages; die Pause ist die Zeit dazwischen, die nicht gearbeitet wurde
    (die Pause dieses Blocks und Lücken zwischen mehreren Blöcken). Hat der Tag schon Zeit ohne Uhrzeit oder lag eine Zeitumstellung
    im Block (Wanduhr passt nicht zur Dauer), bleibt er ohne Uhrzeit."""
    if beginn.utcoffset() != ende.utcoffset():     # shortcut: Kommen und Gehen früherer Blöcke fallen weg, weil gespeicherte Zeiten zur Dauer passen müssen; reicht für die eine Nacht im Jahr
        return regeln.OHNE_UHRZEIT, regeln.OHNE_UHRZEIT, 0
    k, g = _am_tag(tag, beginn, ende)
    if alt and alt.kommen >= 0:
        k, g = min(k, alt.kommen), max(g, alt.gehen)
    elif alt and alt.ho + alt.dst > 0:
        return regeln.OHNE_UHRZEIT, regeln.OHNE_UHRZEIT, 0
    pause = g - k - arbeit
    if pause < -1 or not regeln.uhrzeiten_gueltig(k, g, max(0, pause)):       # Rundung auf Minuten darf 1 Minute ausmachen
        return regeln.OHNE_UHRZEIT, regeln.OHNE_UHRZEIT, 0
    return k, g, max(0, pause)


def stop(db, jetzt: datetime, ende: str = "", pause_min=None, art: str = "", freigabe: bool = False) -> dict:
    """Beendet die Uhr und bucht die Zeit auf den Tag des Beginns (Ende, Pause in Minuten, Art und Freigabe sind optional).
    Ohne Pausenangabe gilt die Pausenregel. Gibt den Zustand mit den gebuchten Minuten zurück; StempelFehler bei Zukunft, negativer Zeit,
    mehr als 24 Stunden am Tag oder mehr als 10 Stunden ohne Freigabe."""
    s = db.stempel_lesen()
    if not s:
        raise StempelFehler("Es läuft keine Zeit")
    ende = (ende or "").strip()
    beginn = _angleichen(s["start"], jetzt)
    frueher = beginn.date() != jetzt.date()
    mitternacht = ueber_mitternacht(jetzt.date())
    if not ende and frueher and (not mitternacht or jetzt - beginn > timedelta(minutes=regeln.MAX_TAG_MIN)):     # „Gehen“ vergessen: nie die Nacht mitbuchen
        raise StempelFehler(f"Die Zeit läuft seit dem {beginn.strftime('%d.%m.%Y, %H:%M')} Uhr. Bitte das Ende als Uhrzeit eintragen oder die Zeit verwerfen.")
    try:
        e = _uhrzeit(ende, beginn) if ende else jetzt           # ein Ende von Hand gilt für den Tag des Beginns …
        if ende and e < beginn and frueher:
            if not mitternacht:
                raise StempelFehler(ENDE_AM_STARTTAG)
            e = _uhrzeit(ende, beginn + timedelta(days=1))      # … oder, nach Mitternacht, für den Tag danach (Versatz dieses Tages)
    except konfig.Meldung as ex:
        raise StempelFehler(str(ex))
    if e - jetzt > ZUKUNFT_TOLERANZ:                # bis 3 Minuten voraus gilt das Ende so, wie es im Feld steht (Uhren weichen ab, „gleich 12:00“)
        raise StempelFehler("Das Ende liegt in der Zukunft")
    if e < beginn:
        raise StempelFehler("Das Ende liegt vor dem Beginn")
    dauer = int(round((e - beginn).total_seconds() / 60))
    if pause_min is None:
        pause_min = regeln.pause_auto(dauer, beginn.date())
    if not 0 <= pause_min <= regeln.PAUSE_HAND_MAX_MIN:
        raise StempelFehler(f"Pause: 0 bis {regeln.PAUSE_HAND_MAX_MIN} Minuten")
    minuten = dauer - pause_min
    if minuten < 0:
        raise StempelFehler("Die Pause ist länger als die Zeit")
    art = art or s["art"]
    if art not in ("ho", "dst"):
        raise StempelFehler("Art muss „ho“ oder „dst“ sein")
    tag = beginn.date()
    alt = next((t for t in db.tage(tag.year) if t.datum == tag), None)
    ho, dst = (alt.ho if alt else 0), (alt.dst if alt else 0)
    if art == "ho":
        ho += minuten
    else:
        dst += minuten
    if ho + dst > regeln.TAG_MIN:
        raise StempelFehler(f"{regeln.TAG_VOLL}; das wären {fmt_hhmm(ho + dst)}. Ende oder Pause korrigieren.")
    frei = bool(freigabe or (alt and alt.freigabe))
    if ho + dst > regeln.MAX_TAG_MIN and not frei:
        raise StempelFehler(f"Das wären {fmt_hhmm(ho + dst)} Stunden an diesem Tag, erlaubt sind höchstens 10. Ende oder Pause korrigieren oder „Über 10 Stunden freigegeben“ ankreuzen.")
    kommen, gehen, pause = _uhrzeiten(alt, tag, beginn, e, ho + dst)
    liste = eintraege(db, alt) + [[art, *_am_tag(tag, beginn, e), pause_min, minuten]]     # mit dem Tag in einer Transaktion: beide oder keins
    db.tag_setzen(tag, ho, dst, alt.art if alt else "", alt.notiz if alt else "", alt.konto if alt else 0, alt.attest if alt else "", 1 if frei else 0,
                  kommen, gehen, pause, alt.vermerk if alt else "", alt.geprueft if alt else 0, meta=(EINTRAEGE_META.format(tag.isoformat()), json.dumps(liste)))
    db.stempel_loeschen()
    r = status(db, jetzt)
    r["pause_min"] = pause_min
    r["gebucht_min"] = minuten
    r["gebucht"] = fmt_hhmm(minuten)
    r["gebucht_datum"] = tag.isoformat()
    return r


def verwerfen(db, jetzt: datetime) -> dict:
    """Wirft die laufende Zeit weg, ohne zu buchen, und gibt den Zustand zurück."""
    db.stempel_loeschen()
    return status(db, jetzt)


def _eintrag_gueltig(e) -> bool:
    """Ein gespeicherter Eintrag [art, kommen, gehen, pause, minuten]: Ort HO oder Büro, ganze Minuten in den Grenzen des Tages."""
    return (isinstance(e, list) and len(e) == 5 and e[0] in ORTE and all(type(x) is int for x in e[1:])
            and 0 <= e[1] <= e[2] <= regeln.GEHEN_MAX_MIN and 0 <= e[3] <= regeln.PAUSE_HAND_MAX_MIN and 0 <= e[4] <= e[2] - e[1] + 1)


def _passt(liste: list, t) -> bool:
    """Ergeben die Einträge genau den gespeicherten Tag t (frühestes Kommen, spätestes Gehen, Minuten je Ort)? Ohne Uhrzeit (Lücke als Pause
    zu lang, etwa über Mitternacht) zählen nur die Minuten je Ort."""
    return (bool(liste) and all(map(_eintrag_gueltig, liste))
            and (t.kommen < 0 or (min(e[1] for e in liste), max(e[2] for e in liste)) == (t.kommen, t.gehen))
            and all(sum(e[4] for e in liste if e[0] == o) == m for o, m in zip(ORTE, (t.ho, t.dst))))


def eintraege(db, t) -> list:
    """Die gemerkten Einträge des Tages t (regeln.Tag oder None), soweit sie zu ihm passen: der längste passende Anfang der Liste.
    So fällt nach Rückgängig des letzten „Gehen“ nur dieser Eintrag weg; nach einer Änderung von Hand, einem Sync oder bei einem kaputten
    Wert passt nichts mehr, und der Tag hat keine Einträge (die Seite zeigt dann die eine Zeile wie bisher). Nie ein Fehler."""
    if t is None:
        return []
    try:
        liste = json.loads(db.meta_lesen(EINTRAEGE_META.format(t.datum.isoformat()), "[]"))
    except (ValueError, RecursionError):
        return []
    if not isinstance(liste, list) or len(liste) > EINTRAEGE_MAX:
        return []
    return next((liste[:n] for n in range(len(liste), 0, -1) if _passt(liste[:n], t)), [])


def _block_lesen(n: int, b, tag: date) -> list:
    """Block n (ab 1) des Formulars {art, kommen, gehen, pause} -> [art, kommen, gehen, Pause oder None (nach Regel), Arbeitsminuten]; StempelFehler mit Blocknummer.
    Gehen nach Mitternacht (über 23:59) nur mit der Regel stempel_mitternacht, wie bei der Stempeluhr."""
    if not isinstance(b, dict) or b.get("art") not in ORTE:
        raise StempelFehler(BLOCK_ORT.format(n=n))
    try:
        k, g, p = parse_hhmm(b.get("kommen")), parse_hhmm(b.get("gehen"), 47), parse_hhmm(b.get("pause"))
        if k is None or g is None:
            raise konfig.Meldung("Kommen und Gehen bitte zusammen eintragen")
        pause, arbeit = regeln.arbeitszeit(k, g, p or 0, tag)
    except konfig.Meldung as e:
        raise StempelFehler(BLOCK_FEHLER.format(n=n, text=e))
    if not gehen_erlaubt(g, tag):
        raise StempelFehler(BLOCK_NACH_MITTERNACHT.format(n=n))
    return [b["art"], k, g, None if p is None else pause, arbeit]


def _regelpause_verteilen(liste: list, tag: date) -> None:
    """Pause nach Regel über alle Blöcke des Tages (Dauer = Summe der Blöcke): Lücken und eigene Pausen zählen mit, der Rest geht vom letzten Block
    ohne eigene Pause ab, die anderen ohne eigene Pause bekommen 0. Ändert liste an Ort und Stelle; StempelFehler, wenn der Rest länger als der Block ist."""
    offen = [e for e in liste if e[3] is None]
    for e in offen:
        e[3] = 0
    if not offen:
        return
    luecken = sum(b[1] - a[2] for a, b in zip(liste, liste[1:]))
    rest = max(0, regeln.pause_auto(sum(e[2] - e[1] for e in liste), tag) - luecken - sum(e[3] for e in liste))
    letzter = offen[-1]
    if rest > letzter[4]:
        raise StempelFehler(BLOCK_PAUSE_ZU_LANG.format(n=liste.index(letzter) + 1))
    letzter[3], letzter[4] = rest, letzter[4] - rest


def bloecke(roh, tag: date) -> tuple:
    """Blöcke eines Tages aus dem Bearbeiten-Formular (PUT /api/tag mit „eintraege“: [{art „ho“/„dst“, kommen, gehen bis 23:59 (mit Regel stempel_mitternacht
    bis 47:59), pause leer = Regel}]).
    Prüft wie die Stempeluhr: Format, Gehen nach Kommen, keine Überschneidung, höchstens EINTRAEGE_MAX Blöcke (Summe, 24 und 10 Stunden prüft tag_speichern).
    Rückgabe (kommen, gehen, pause, ho, dst, liste): Kommen und Gehen des Tages = frühester Beginn und spätestes Ende, Pause = Lücken und Pausen
    (wie _uhrzeiten; ohne Uhrzeit, wenn die Lücke als Pause zu lang ist), liste = gemerkte Einträge [art, kommen, gehen, pause, minuten] nach Beginn sortiert.
    Fehler: StempelFehler mit lesbarer Meldung."""
    if not isinstance(roh, list) or not 1 <= len(roh) <= EINTRAEGE_MAX:
        raise StempelFehler(BLOECKE_LISTE)
    liste = sorted((_block_lesen(n, b, tag) for n, b in enumerate(roh, 1)), key=lambda e: e[1])
    for a, b in zip(liste, liste[1:]):
        if b[1] < a[2]:
            raise StempelFehler(BLOCK_UEBERSCHNEIDUNG.format(a=fmt_hhmm(a[1]), b=fmt_hhmm(a[2]), c=fmt_hhmm(b[1]), d=fmt_hhmm(b[2])))
    _regelpause_verteilen(liste, tag)
    ho, dst = (sum(e[4] for e in liste if e[0] == o) for o in ORTE)
    k, g = liste[0][1], max(e[2] for e in liste)
    pause = g - k - ho - dst
    if not regeln.uhrzeiten_gueltig(k, g, pause):
        k, g, pause = regeln.OHNE_UHRZEIT, regeln.OHNE_UHRZEIT, 0
    return k, g, pause, ho, dst, liste


def mit_eintraegen(db, antwort: dict, zeitformat: str) -> dict:
    """Antwort von bericht.woche oder bericht.monat, je Tag mit mehr als einem Eintrag ergänzt um „eintraege“ ([{art, kommen, gehen, dauer, pause}],
    Uhrzeiten hh:mm, Dauer im Zeitformat, Pause leer ohne eigene), „eintraege_pause“ (Summe der eigenen Pausen, ohne die Lücken; leer bei 0) und
    „eintraege_summe“ (Arbeitszeit aller Blöcke im Zeitformat, die Tagessumme der letzten Blockzeile im Nachweis und in der CSV).
    Andere Tage bleiben, wie sie sind. Die Antwort selbst wird nicht verändert (sie kann aus dem Zwischenspeicher kommen)."""
    tage = {t.datum: t for j in {int(z["datum"][:4]) for z in antwort["tage"]} for t in db.tage(j)}
    neu = []
    for z in antwort["tage"]:
        liste = eintraege(db, tage.get(date.fromisoformat(z["datum"])))
        if len(liste) > 1:
            pause = sum(e[3] for e in liste)
            z = {**z, "eintraege_pause": fmt_hhmm(pause) if pause else "", "eintraege_summe": fmt_dauer(sum(e[4] for e in liste), zeitformat),
                 "eintraege": [{"art": a, "kommen": fmt_hhmm(k), "gehen": fmt_hhmm(g), "dauer": fmt_dauer(m, zeitformat), "pause": fmt_hhmm(p) if p else ""}
                               for a, k, g, p, m in liste]}
        neu.append(z)
    return {**antwort, "tage": neu}
