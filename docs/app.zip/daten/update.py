# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Update-Prüfung (funktionen.md 8.1, Ausnahme in CLAUDE.md „Update-Prüfung“ seit 18.11.2026): Windows- und Android-App fragen alle 30 Tage (seit 20.11.2026, vorher 7)
die Nummer der neuesten Release-Version ab. Nur GET an genau RELEASE_API, ohne Token, ohne Weiterleitung, nur tag_name gelesen, kein Download,
keine Installation. Ab Werk an, abschaltbar (geraet.json, je Gerät). Die Route entscheidet über die Plattform; in Pyodide nie aufgerufen."""
import json
import re
from datetime import date, timedelta

from daten import konfig
from daten import sicherung
from urheber import VERSION

RELEASE_API = "https://api.github.com/repos/davidsaluda/zeiterfassung-app/releases/latest"
RELEASE_SEITE = "https://github.com/davidsaluda/zeiterfassung-app/releases/latest"     # nur als Link für die Person, die App ruft sie nie auf
ABSTAND = timedelta(days=30)                                 # Auftrag 19.11.2026: alle 30 statt 7 Tage
VERSION_FORM = re.compile(r"\d{8}\.\d{4}", re.ASCII)          # wie urheber.VERSION (JJJJMMTT.HHMM): gleich lang, also als Text vergleichbar; ASCII: andere Ziffern lägen als Text über jeder Version
TAG = re.compile(r"v?(" + VERSION_FORM.pattern + ")", re.ASCII)   # Form der Release-Tags (git: v20261118.1825)
MAX_ANTWORT = 256 * 1024                                     # längere Antworten gelten als unlesbar
ZEITLIMIT = 10                                               # Sekunden
KOPF = {"Accept": "application/vnd.github+json", "User-Agent": "Zeiterfassung"}     # neutral: ohne Version, ohne Gerätekennung


def _anfrage(adresse: str) -> tuple:
    """Ein GET an „adresse“ ohne Weiterleitung, Kopf nur KOPF, höchstens MAX_ANTWORT + 1 Bytes gelesen. Rückgabe: (HTTP-Status, Bytes).
    Eine HTTP-Antwort mit Fehler (auch 3xx, weil nicht weitergeleitet wird) ergibt (Status, b""). Fehler: OSError, wenn keine Verbindung zustande kam."""
    import urllib.error
    import urllib.request                                    # nur hier gebraucht; die Browser-Fassung (Pyodide) lädt das Modul so nie

    class _KeinWeiter(urllib.request.HTTPRedirectHandler):
        """Folgt keiner Weiterleitung: urllib meldet die 3xx-Antwort dann als HTTPError."""
        def redirect_request(self, *a, **k):
            """Keine neue Anfrage an eine andere Adresse."""
            return None
    try:
        with urllib.request.build_opener(_KeinWeiter).open(urllib.request.Request(adresse, headers=KOPF, method="GET"), timeout=ZEITLIMIT) as antwort:
            return getattr(antwort, "status", 200), antwort.read(MAX_ANTWORT + 1)
    except urllib.error.HTTPError as e:                      # vor OSError: eine Antwort von GitHub zählt als Abfrage
        return e.code, b""


def tag_lesen(roh: bytes):
    """Die Versionsnummer aus der Antwort von GitHub: nur das Feld tag_name, Form TAG. Rückgabe: „JJJJMMTT.HHMM“ oder None (zu lang, kein JSON, anderes Format)."""
    if len(roh) > MAX_ANTWORT:
        return None
    try:
        d = json.loads(roh.decode("utf-8"))
    except (ValueError, RecursionError):                     # UnicodeDecodeError ist ein ValueError
        return None
    tag = d.get("tag_name") if isinstance(d, dict) else None
    m = TAG.fullmatch(tag) if isinstance(tag, str) else None
    return m[1] if m else None


def _datum(text):
    """Ein gespeichertes Datum (JJJJ-MM-TT) oder None, wenn es fehlt oder unlesbar ist."""
    try:
        return date.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def faellig(g: dict, heute: date) -> bool:
    """True, wenn die Abfrage heute dran ist: eingeschaltet, heute noch kein Versuch ohne Verbindung, und die letzte Antwort fehlt,
    ist mindestens ABSTAND alt oder liegt in der Zukunft (Uhr verstellt)."""
    if not g.get("update_pruefen", True) or g.get("update_versuch") == heute.isoformat():
        return False
    zuletzt = _datum(g.get("update_zuletzt"))
    return zuletzt is None or zuletzt > heute or heute - zuletzt >= ABSTAND


def pruefen(daten: str, heute: date, anfrage=_anfrage):
    """Fragt GitHub, wenn fällig, und merkt das Ergebnis in geraet.json. update_versuch = heute steht schon vor der Anfrage: Endet sie mit
    irgendeinem Fehler (OSError ohne Verbindung, aber auch http.client.IncompleteRead), fragt die App erst morgen wieder; der Fehler geht an den Aufrufer.
    Jede HTTP-Antwort setzt update_zuletzt; nur ein gültiger tag_name ändert update_neueste. Rückgabe: hinweis() danach."""
    g = sicherung.geraet_lesen(daten)
    if not faellig(g, heute):
        return hinweis(g)
    g = sicherung.geraet_aendern(daten, update_versuch=heute.isoformat())
    try:
        status, roh = anfrage(RELEASE_API)
    except OSError:
        return hinweis(g)
    neu = {"update_zuletzt": heute.isoformat()}
    tag = tag_lesen(roh) if status == 200 else None
    if tag:
        neu["update_neueste"] = tag
    return hinweis(sicherung.geraet_aendern(daten, **neu))


def hinweis(g: dict):
    """Die neuere Version („JJJJMMTT.HHMM“), wenn die Prüfung an ist und GitHub eine neuere als diese App gemeldet hat, sonst None."""
    neueste = g.get("update_neueste") or ""
    return neueste if g.get("update_pruefen", True) and VERSION_FORM.fullmatch(neueste) and neueste > VERSION else None


def schalten(daten: str, an) -> dict:
    """Schalter „Alle 30 Tage nach einer neuen Version fragen“: nur True oder False (konfig.Meldung sonst). Aus leert die gemerkte neueste Version."""
    if not isinstance(an, bool):
        raise konfig.Meldung("Update-Prüfung: an oder aus")
    return sicherung.geraet_aendern(daten, update_pruefen=an, **({} if an else {"update_neueste": ""}))


def stand(daten: str, verfuegbar: bool) -> dict:
    """Antwort für GET /api/update. verfuegbar: Die Plattform darf fragen (Windows- oder Android-App, nicht über den Fern-Anschluss)."""
    g = sicherung.geraet_lesen(daten)
    return {"verfuegbar": verfuegbar, "an": g["update_pruefen"], "zuletzt": g["update_zuletzt"], "neueste": g["update_neueste"], "eigene": VERSION,
            "neuer": hinweis(g) is not None}
