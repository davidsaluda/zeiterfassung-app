# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Mitgelieferte Vorlage „Nur Zeiterfassung“ (seit 19.11.2026, erste der drei Vorlagen beim ersten Start, funktionen.md 6.1).
Aufbau wie profil_buero_homeoffice.py: Fehlt diese Datei, fehlt nur dieses Profil."""

NAME = "Nur Zeiterfassung"                                   # Anzeigename; steht nur hier
BESCHREIBUNG = "Arbeitszeit, Urlaub und Gleitzeit. Ohne Homeoffice-Grenze."
# HO und Büro erfassbar, ohne Grenze und ohne Quote-Warnungen; keine Sonderregeln für Fasching, Heiligabend und Silvester.
# Akzent und Farbe leer: die Vorlage lässt die Darstellung, wie sie ist.
PROFIL = {"name": NAME, "beschreibung": BESCHREIBUNG, "aktiv": True, "voreinstellung": False, "akzent": "", "farbe": "",
          "werte": {"ho_modus": "ohne", "fasching_std": None, "heiligabend_frei": False, "silvester_frei": False, "module_aus": ["horest", "familientage"]}}
