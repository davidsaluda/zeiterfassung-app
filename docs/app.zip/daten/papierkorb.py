# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Papierkorb für Tage (A7, 25.11.2026): Ein geleerter Tag oder ein gelöschter Eintrag bleibt 30 Tage (TAGE) in der Tabelle „papierkorb“ und lässt sich
wiederherstellen, zusätzlich zum Rückgängig der letzten Minute.

Abgelegt wird der ganze Tag vor dem Speichern (alle TAG_FELDER und die Einträge der Stempeluhr) samt dem Stand danach. Wiederherstellen geht nur,
solange der Tag noch genau diesen Stand danach hat; ist er inzwischen neu belegt, meldet die App das (409), statt etwas zu überschreiben.
Der Papierkorb bleibt auf dem Gerät: Die Synchronisierung überträgt das Löschen des Tages schon selbst, und ein fremder Papierkorb könnte auf einem anderen
Gerät einen Stand zurückholen, den dort niemand gelöscht hat. Eine eingespielte Sicherung bringt deshalb auch keinen Papierkorb mit (Db._eingespielt_umstellen).
Vor dem Wiederherstellen laufen die Zählregeln des Speicherns (Jahreslimits, ganze Tage, Konten des angesparten Urlaubs); die Prüfung meldet
routen_zeiten an (pruefung_anmelden), weil daten nie routen importiert."""
import json
from datetime import date, datetime, timedelta

from daten import stempel
from daten.db import TAG_FELDER, InzwischenGeaendert

TAGE = 30                                                   # so lange bleibt ein Eintrag liegen
MAX = 500                                                   # mehr Einträge verdrängen die ältesten (Schutz vor endlosem Wachsen)
NUMMER_MAX = 2 ** 63 - 1                                    # größte Zahl, die SQLite als Nummer kennt
UNGUELTIG = "Papierkorb: ungültige Nummer"
NICHT_DA = "Der Eintrag ist nicht mehr im Papierkorb (nach 30 Tagen gelöscht oder schon wiederhergestellt)."
OHNE_PRUEFUNG = "Wiederherstellen geht gerade nicht."
BELEGT = "Der Tag ist inzwischen neu belegt. Erst den Tag leeren oder so ändern, wie er nach dem Löschen war, dann wiederherstellen."


class PapierkorbFehler(Exception):
    """Wiederherstellen geht nicht. status: 400 (Nummer ungültig), 404 (nicht mehr da), 409 (Tag neu belegt); der Text geht an die Person."""
    def __init__(self, text: str, status: int):
        """Merkt sich Meldetext und HTTP-Status."""
        super().__init__(text)
        self.status = status


def _ungeprueft(db, iso: str, vorher: dict) -> None:
    """Vorgabe, solange keine Prüfung angemeldet ist: lehnt ab, damit nie ein Tag an den Zählregeln vorbei zurückkommt."""
    raise PapierkorbFehler(OHNE_PRUEFUNG, 400)


_pruefung = _ungeprueft


def pruefung_anmelden(pruefen) -> None:
    """Meldet die Zählregel-Prüfung an: pruefen(db, iso, vorher) wirft PapierkorbFehler (400), wenn der abgelegte Stand heute nicht gespeichert
    werden dürfte (etwa Gleittage über der Grenze)."""
    global _pruefung
    _pruefung = pruefen


def _zeile(t) -> dict:
    """Ein regeln.Tag als Wörterbuch der TAG_FELDER (wie db.aufnahme), None ohne Tag."""
    return {f: getattr(t, f) for f in TAG_FELDER} if t else None


def _stand(text: str):
    """Ein abgelegter Stand (JSON) als Wörterbuch der TAG_FELDER, None ohne Tag. Stände alter Versionen tragen noch vermerk und geprueft: fallen weg."""
    d = json.loads(text)
    return {f: d[f] for f in TAG_FELDER} if d else None


def ablegen(db, iso: str, vorher, nachher, eintraege: list, eintraege_nachher: int, art_weg: bool = False) -> bool:
    """Legt den Stand „vorher“ eines eben gespeicherten Tages ab, wenn das Speichern etwas entfernt hat: der Tag ist leer oder hat weniger Einträge,
    mit art_weg (Zeitraum löschen) auch, wenn er nur seine Art verloren hat und wegen Notiz oder Vermerk stehen bleibt.
    Eingaben: Datum, Tag vorher und nachher (TAG_FELDER oder None, aus db.aufnahme), Einträge der Stempeluhr vorher (Liste) und Zahl nachher.
    Zeit: db.uhr() (Weltzeit). Räumt zuerst fällige Einträge weg (aufraeumen), bei jedem Speichern, damit nichts lange über TAGE liegt.
    Rückgabe: True, wenn abgelegt."""
    aufraeumen(db)
    art_verloren = art_weg and nachher is not None and vorher is not None and vorher["art"] != nachher["art"]
    if vorher is None or (nachher is not None and eintraege_nachher >= len(eintraege) and not art_verloren):
        return False
    zeit = db.uhr().isoformat(timespec="seconds")
    with db._c() as c:
        c.execute("INSERT INTO papierkorb (datum, zeit, vorher, nachher, eintraege) VALUES (?,?,?,?,?)",
                  (iso, zeit, json.dumps(vorher), json.dumps(nachher), json.dumps(eintraege)))
        c.execute("DELETE FROM papierkorb WHERE id NOT IN (SELECT id FROM papierkorb ORDER BY id DESC LIMIT ?)", (MAX,))
    return True


def _faellig(db, zeilen, jetzt: datetime) -> set:
    """Nummern der Zeilen (id, datum, zeit, vorher), die weg können: älter als TAGE oder ihr Tag steht schon wieder genau so da (etwa nach Rückgängig)."""
    grenze = (jetzt - timedelta(days=TAGE)).isoformat(timespec="seconds")
    tage = {t.datum.isoformat(): t for j in {date.fromisoformat(r["datum"]).year for r in zeilen} for t in db.tage(j)}   # je Jahr einmal laden
    return {r["id"] for r in zeilen if r["zeit"] < grenze or _zeile(tage.get(r["datum"])) == _stand(r["vorher"])}


def aufraeumen(db, jetzt: datetime = None) -> None:
    """Löscht die fälligen Einträge (_faellig). Nur beim Schreiben (ablegen, wiederherstellen, Rückgängig), vor jeder Sicherung (Db.sicherung, Db.sicherung_bytes, sync.vor_sync_sichern) und beim Start (server.handler_erstellen),
    nie beim Lesen: GET bleibt ohne Änderung."""
    with db.lock:
        with db._c() as c:
            zeilen = c.execute("SELECT id, datum, zeit, vorher FROM papierkorb").fetchall()
        weg = _faellig(db, zeilen, jetzt or db.uhr())
        with db._c() as c:
            c.executemany("DELETE FROM papierkorb WHERE id=?", [(nr,) for nr in weg])


def liste(db, jetzt: datetime = None) -> list:
    """GET /api/papierkorb: die Einträge, neueste zuerst: {id, datum, zeit (gelöscht, Weltzeit), ho, dst, art, notiz, eintraege (Zahl)}.
    Fällige (_faellig) fehlen, bleiben aber in der Tabelle: Lesen ändert nichts, gelöscht wird erst beim Schreiben (aufraeumen)."""
    with db.lock, db._c() as c:
        zeilen = c.execute("SELECT id, datum, zeit, vorher, eintraege FROM papierkorb ORDER BY id DESC").fetchall()
    weg = _faellig(db, zeilen, jetzt or db.uhr())
    r = []
    for z in (z for z in zeilen if z["id"] not in weg):
        v = json.loads(z["vorher"])
        r.append({"id": z["id"], "datum": z["datum"], "zeit": z["zeit"], "ho": v["ho"], "dst": v["dst"], "art": v["art"], "notiz": v["notiz"],
                  "eintraege": len(json.loads(z["eintraege"]))})
    return r


def _nummer(nr) -> int:
    """Die Nummer aus der Anfrage: ganze Zahl ab 1 (kein bool, kein Text). PapierkorbFehler 400 sonst."""
    if type(nr) is not int or not 1 <= nr <= NUMMER_MAX:
        raise PapierkorbFehler(UNGUELTIG, 400)
    return nr


def wiederherstellen(db, nr, jetzt: datetime = None) -> dict:
    """POST /api/papierkorb/wiederherstellen {id}: setzt den Tag auf den abgelegten Stand samt Einträgen (eine neue Änderung, die Synchronisierung
    überträgt sie) und nimmt ihn aus dem Papierkorb. Vorher prüft die angemeldete Prüfung die Zählregeln mit dem abgelegten Stand.
    Rückgabe {"ok": True, "datum"}. Fehler: PapierkorbFehler 400 (Nummer ungültig, Zählregel verletzt), 404 oder 409 (dann bleibt alles)."""
    nr = _nummer(nr)
    with db.lock:                                          # Lesen, Prüfen und Schreiben am Stück
        aufraeumen(db, jetzt)
        with db._c() as c:
            z = c.execute("SELECT datum, vorher, nachher, eintraege FROM papierkorb WHERE id=?", (nr,)).fetchone()
        if z is None:
            raise PapierkorbFehler(NICHT_DA, 404)
        vorher = _stand(z["vorher"])
        _pruefung(db, z["datum"], vorher)
        try:
            db.zuruecksetzen({z["datum"]: (vorher, _stand(z["nachher"]))})
        except InzwischenGeaendert:
            raise PapierkorbFehler(BELEGT, 409)
        eintraege = json.loads(z["eintraege"])
        if eintraege:
            db.meta_setzen(stempel.EINTRAEGE_META.format(z["datum"]), json.dumps(eintraege))
        with db._c() as c:
            c.execute("DELETE FROM papierkorb WHERE id=?", (nr,))
    return {"ok": True, "datum": z["datum"]}
