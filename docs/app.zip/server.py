# Zeiterfassung. © 2026 David Saluda. Alle Rechte vorbehalten. Erstellt mit Unterstützung von KI (Claude, Anthropic).
"""Zeiterfassung-App: kleiner Webdienst (nur Standardbibliothek, keine Zusatzpakete, keine Verbindungen nach außen), SQLite in /data.
Läuft im Container auf Port 8000, am besten nur lokal gebunden und hinter einem Reverse-Proxy betrieben (keine Anmeldung in der App, nur im privaten Netz einsetzen).
Schutz: Schreibzugriffe (POST, PUT, DELETE) nur mit Content-Type application/json und nur von der eigenen Seite (Sec-Fetch-Site/Origin),
Anfragen höchstens 8 MB, Sicherheits-Kopfzeilen auf jeder Antwort, Fehlertexte ohne interne Details (die stehen im Protokoll des Dienstes).
Tempo: Antworten auf GET /api/... werden gemerkt, bis sich Daten, Regeln oder das Datum ändern.
Aufbau (seit Runde 1.4): Hier bleiben Schutz, Verteilung, Statik, Start und Automatik. Die Routen liegen je Bereich in
app/routen/routen_*.py (Mixin-Klassen des Handlers), gemeinsame Teile in app/routen/: eingabe.py, anschluesse.py, kopplung.py und ziele.py.
Schnittstelle (JSON, Fehler als {"fehler": "..."} mit Status 400/403/404/413/415/503):
  GET  /health
  GET  /api/monat/<jahr>/<monat>      Tage mit Summen, Quote, Feiertagen
  POST /api/tage                      {tage:[{datum, ho, dst, art, notiz}, …]}  (Sammel-Import in einer Transaktion)
  PUT  /api/tag                       {datum, ho, dst, art, notiz, konto?}  (ho/dst als "hh:mm")
  GET  /api/jahr/<jahr>[.pdf]         Jahresübersicht (12 Monate, Summen, Urlaub); .pdf = Jahresrückblick
  GET  /api/horest/<jahr>/<monat>     „noch möglich“ für Monat und Jahr
  GET  /api/urlaub/<jahr>   PUT /api/urlaub {jahr, anspruch, uebertrag? (Zahl, oder null = automatisch), konten:[{herkunft,tage}], eigene_frei:["JJJJ-MM-TT"]}
  GET  /api/krank/<jahr>
  GET  /api/abschnitte        alle Abschnitte;  POST /api/abschnitt {id?, von, bis, wochenstunden, art, arbeitstage};  DELETE /api/abschnitt/<id>
  GET  /api/steuer/<jahr>[.csv|.xlsx|.pdf|.json|.xml|.docx|.odt|.ods|.md|.txt]
  GET  /api/monat/<jahr>/<monat>[.pdf|.json|.xml|.csv|.docx|.odt|.ods|.md|.txt]
  GET  /api/export.json|.xml|.csv   (alle erfassten Tage)
  GET  /api/planung   POST /api/planung/vorschau|/api/planung {art, von, bis}   DELETE /api/planung/<von>_<bis>_<art>   GET /api/planung/<von>_<bis>,….ics  (Urlaubsplanung)
  GET  /api/kalender[/<jahr>[/<monat>]].ics[?arten=urlaub,krank][&ansehen=1]   (Urlaub, Gleittage, Krank usw. als Ganztagstermine; Arten wie in export.ICS_ARTEN)
  GET  /api/buero   PUT /api/buero {rate (0–5 oder leer = automatisch), zeitraum: monat|jahr}   (Annahme „Büro-Tage pro Woche“ der Prognose je Karte)
  GET  /api/sicherung/liste   POST /api/sicherung/wiederherstellen {bestaetigt: true, datei | daten (Base64)}   (ersetzt alle Daten, sichert vorher)
  POST /api/werkseinstellungen {bestaetigt: true}   (alles auf Anfang: leere Datenbank, Regeln Voreinstellung; sichert vorher)
  Nur in der Handy- und der Browser-Fassung (HO_PLATTFORM=android|browser), sonst 404; verschlüsselte Sicherung in den Cloud-Ordner des Geräts (sicherung.py):
  GET  /api/handysicherung   PUT /api/handysicherung {auto, rhythmus, behalten}   POST /api/handysicherung/passwort {passwort}
  POST /api/handysicherung/jetzt   POST /api/handysicherung/wiederherstellen {bestaetigt: true, datei | daten (Base64), passwort}
  GET  /api/handysicherung/datei/<Name>   (eine verschlüsselte Sicherung als Datei, Name aus der Liste)
  Nur in den lokalen Fassungen (HO_PLATTFORM=desktop|android|browser), sonst 404; Synchronisierung mit anderen Geräten über den Cloud-Ordner (sync.py):
  Nur im Browser (kein Cloud-Ordner): GET /api/abgleich/datei (eigene Synchronisierungsdatei)   POST /api/abgleich/einlesen {name, daten (Base64), passwort}
  GET  /api/abgleich   PUT /api/abgleich {auto, ordner (nur Desktop)}   POST /api/abgleich/passwort {passwort}   POST /api/abgleich/jetzt {passwort}
  GET  /api/profile   POST /api/profile {name, akzent}   POST /api/profile/loeschen {name}   POST /api/profile/schalten {name, aktiv}
     POST /api/profile/wahl {name} (Frage beim ersten Start)   POST /api/profile/import <Profil-Datei>   GET /api/profile/<nr>.json (Export)   (Vorbelegungen für die Regeln)
  POST /api/abgleich/koppeln (Code anzeigen)   POST /api/abgleich/koppeln/annehmen {code}   (nur Desktop und Handy-Apps)
  POST /api/abgleich/entscheiden {art, schluessel, wahl: hier|dort} oder {alle: hier|dort}
  PUT  /api/abgleich {oberflaeche: true|false}   (nur Desktop: Oberfläche auf Anschluss 8794 für das eigene Handy freigeben; Stand: oberflaeche {adresse, qr})
  POST /api/desktop/beenden   (nur HO_PLATTFORM=desktop: beendet die App)
  GET  /api/sicherung   (Datenbank)   GET /api/sicherung/info   (Stand der Nachtsicherung, Plattform, Stand vor dem letzten Wiederherstellen)
  GET  /api/sicherung/davor/<Name>   (den Stand vor einem Wiederherstellen herunterladen)
"""
import gzip
import hashlib
import hmac
import functools
import ipaddress
import json
import mimetypes
import os
import re
import socket
import sqlite3
import sys
import threading
import time
import traceback
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler

from daten import sync
from routen import anschluesse
from daten import demo
from ausgabe import design
from daten import konfig
from daten import rueckgaengig
from daten import sicherung
from daten import update
from routen.anschluesse import Dienst, freigabe_an, freigabe_schalten, oberflaeche_schalten
from daten.db import Db, sicherung_stand
from routen.eingabe import Fehler, MIT_ADRESSE, MIT_UPDATE_PRUEFUNG, NICHT_ZUSTAENDIG, _jahr, plattform
from routen.routen_ablage import AblageRouten
from routen.routen_bericht import BerichtRouten
from routen.routen_einstellungen import EinstellungenRouten
from routen.routen_export import ExportRouten
from routen.routen_oberflaeche import OberflaecheRouten, _DEMO_SCHLOSS
from routen.routen_sicherung import SicherungRouten
from routen.routen_sync import SyncRouten
from routen.routen_urlaub import UrlaubRouten
from routen.routen_zeiten import ZeitenRouten
from urheber import VERSION
import buendel
from routen.ziele import ablage_des_servers, eigene_ablage, github_ziel, netz_ziel
# Namen und Module, die Tests über server. erreichen oder patchen (liegen seit dem Schnitt anderswo); die Ports leitet _ServerModul weiter
from kern import bericht  # noqa: F401
from ausgabe import export as exportformat  # noqa: F401
from kern import regeln  # noqa: F401
from routen.anschluesse import _freigabe, _oberflaeche  # noqa: F401
from routen.kopplung import _kopplung, _KOPPEL_SCHLOSS, KOPPEL_VERSUCHE, _koppel_inhalt, _koppel_merken, koppeln_annehmen  # noqa: F401
from routen.routen_einstellungen import PROFIL_PFADE, DEMO_PROFILE  # noqa: F401
from routen.routen_zeiten import tag_speichern, tage_import, krank_phase, attest_fuer_phase  # noqa: F401
from routen.ziele import adresse_vervollstaendigen, _ablage_liste, _ablage_summe  # noqa: F401


class _ServerModul(type(sys)):
    """Leitet server.FREIGABE_PORT und server.OBERFLAECHE_PORT an anschluesse weiter: Tests binden die Ports über server. um, gelesen
    werden sie in anschluesse. Ein einfacher Re-Export bliebe wirkungslos, und die Tests öffneten die echten Anschlüsse 8793 und 8794.
    Nur mit einfacher Zuweisung umbinden, nie mit mock.patch: Die Eigenschaft hat keinen deleter, patch scheitert beim Zurücksetzen
    und ließe den Port in anschluesse verstellt.

    shortcut: nur für die Umbindungen in tests/test_ablage.py; sobald die auf anschluesse.<Port> zeigen, Klasse und Zuweisung entfernen.
    """
    FREIGABE_PORT = property(lambda self: anschluesse.FREIGABE_PORT, lambda self, wert: setattr(anschluesse, "FREIGABE_PORT", wert))
    OBERFLAECHE_PORT = property(lambda self: anschluesse.OBERFLAECHE_PORT, lambda self, wert: setattr(anschluesse, "OBERFLAECHE_PORT", wert))


sys.modules[__name__].__class__ = _ServerModul

# Die Dateien der Oberfläche liegen neben dem Programm; die Android-Hülle packt sie aus und nennt den Ort (HO_WEB).
WEB = os.path.abspath(os.environ.get("HO_WEB", "").strip() or os.path.join(os.path.dirname(os.path.abspath(__file__)), "web"))
WEBAPP = os.path.abspath(os.environ.get("HO_WEBAPP", "").strip() or os.path.join(os.path.dirname(WEB), "webapp"))   # die Web-App ohne Server (Bau von web_bauen.py), ausgeliefert unter /mobil/
# Liste der Dateien der Oberfläche neben dem Ordner web, vom Bau der Windows-App abgelegt (desktop_bauen.web_liste_schreiben). Entpackt jemand über
# einen alten Ordner, blieben dort alte Dateien liegen: Mit Liste liefert der Dienst nur, was der Bau mitbrachte. Ohne Liste (NAS, Quelltext) alles in web.
WEB_LISTE = "web-dateien.txt"
MAX_BODY = 8 * 1024 * 1024                                   # größte Anfrage (der Sammel-Import mit 20000 Tagen braucht rund 3 MB)
NACHLESEN_HOECHSTENS = MAX_BODY                              # nach einer Ablehnung vor dem Lesen: so viel vom ungelesenen Körper noch abholen und verwerfen (nie gespeichert)
NACHLESEN_FRIST = 1.0                                        # Sekunden, gesamt; danach schließt die Verbindung auch, wenn noch Daten kommen
INTERNER_FEHLER = "Interner Fehler (Details im Protokoll des Dienstes)"
UNGUELTIGE_EINGABE = konfig.UNGUELTIGE_EINGABE
SPEICHERFEHLER_LESEN = "Die Datenbank lässt sich gerade nicht lesen. Bitte später noch einmal versuchen. Hilft das nicht, eine Sicherung wiederherstellen."
SPEICHERFEHLER_SCHREIBEN = "Nicht gespeichert: Die Datenbank lässt sich gerade nicht schreiben (Speicher voll oder gesperrt). Die Eingabe bitte später wiederholen."
ZUGANG_COOKIE = "ho_zugang"
FERN_COOKIE_DAUER = 30 * 24 * 3600                         # Zugang am Handy: danach neu per QR-Code
# Ändern geraet.json oder ersetzen die Datenbank: unter sync._SCHLOSS, sonst schreibt ein laufender Sync am Ende seinen alten Stand
# (gemerkte Schlüssel, Merklisten) zurück. Reihenfolge wie überall: erst _SCHLOSS, dann db.lock.
UNTER_SYNC_SCHLOSS = ("/api/sicherung/wiederherstellen", "/api/handysicherung/passwort", "/api/handysicherung/wiederherstellen")
# Nur unter _SCHLOSS: Netz-Zugriffe des Syncs. Die Werkseinstellungen melden sich vorher übers Netz ab und nehmen db.lock erst danach selbst.
NUR_SYNC_SCHLOSS = ("/api/werkseinstellungen",)
# Ohne db.lock: „App prüfen“ rechnet nur in Wegwerf-Datenbanken mit eigenem Regelstand und lehnt einen zweiten Lauf selbst ab (429).
EIGENES_SCHLOSS = ("/api/selbsttest",)
NICHT_MERKEN = ("/health", "/api/stempel", "/api/zutun", "/api/heute", "/api/version", "/api/demo", "/api/sicherung/info", "/api/handysicherung", "/api/abgleich", "/api/ablage", "/api/desktop/browser", "/api/update",
                "/api/startwerte", "/api/jahreswechsel", "/api/einrichtung", "/api/pruefen", "/api/gleitzeit/verlauf", "/api/feiertage")   # hängen von der Uhrzeit oder von Dateien ab
NICHT_MERKEN_ANFANG = ("/api/feiertage/", "/api/gleitzeit/verlauf/", "/api/monatsnachweis/", "/api/jahreswechsel/")   # dieselben Gründe, Pfade mit Jahr oder Unterpfad
# Skripte nur aus eigenen Dateien: keine eingebetteten Skripte und keine Inline-Handler (die Oberfläche bedient sich über data-klick, siehe anlauf.js).
# Auch Stile nur aus der eigenen Datei: Die Oberfläche schreibt keine style-Attribute, Maße und Farben setzt das Skript (data-stil, siehe darstellung.js).
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; "
       "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
FREMDE_ANFRAGE = "Diese Anfrage versteht die App nicht"
UNBEKANNTE_ADRESSE = "Unbekannte Adresse"
NAME_EINTRAGEN = "Unbekannte Adresse. Bitte den Namen dieser Seite in HO_HOSTS eintragen und die App neu starten."
HOSTS_LEER = ("Host-Prüfung: HO_HOSTS ist leer, die App antwortet nur unter IP-Adressen und localhost. "
              "Wer sie unter einem Namen öffnet (z. B. über einen Proxy), trägt diesen in HO_HOSTS ein.")
SCHUTZ_KOPF = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Cross-Origin-Resource-Policy": "same-origin",
               "Cross-Origin-Opener-Policy": "same-origin",             # fremde Fenster bekommen keinen Griff auf das Fenster der App
               "Permissions-Policy": "camera=(self), geolocation=(), microphone=(), payment=(), usb=(), serial=(), hid=(), bluetooth=(), midi=(), display-capture=()"}   # Kamera nur für den QR-Code beim Koppeln (Android-App), alles andere braucht die App nicht


def _endliche_zahl(text: str) -> float:
    """JSON-Zahl lesen; Unendlich (z. B. 1e999) wird abgelehnt (ValueError)."""
    z = float(text)
    if z in (float("inf"), float("-inf")):
        raise ValueError("Zahl zu groß")
    return z


def _keine_konstante(name: str):
    """JSON-Konstanten wie NaN und Infinity werden abgelehnt (ValueError)."""
    raise ValueError(f"{name} ist keine Zahl")


@functools.lru_cache(maxsize=4)
def _liste_lesen(pfad: str, *_stand) -> frozenset:
    """Die Namen in der Liste pfad (je Zeile einer, „/“ getrennt); _stand (mtime, Größe) nur als Schlüssel des Merkers."""
    with open(pfad, encoding="utf-8") as f:
        return frozenset(zeile.strip() for zeile in f if zeile.strip())


def web_liste() -> frozenset | None:
    """-> die Dateien, die der Bau in den Ordner web gelegt hat (WEB_LISTE), oder None ohne Liste.
    Lässt sich eine vorhandene Liste nicht lesen, ist sie leer: lieber nichts ausliefern als Fremdes."""
    pfad = os.path.join(os.path.dirname(WEB), WEB_LISTE)
    try:
        st = os.stat(pfad)
    except FileNotFoundError:
        return None
    except OSError:
        return frozenset()
    try:
        return _liste_lesen(pfad, st.st_mtime_ns, st.st_size)
    except (OSError, ValueError):
        return frozenset()


def _datei_lesen(pfad: str) -> bytes:
    """Inhalt einer Datei als Bytes."""
    with open(pfad, "rb") as f:
        return f.read()


_BUENDEL_MERKER: dict = {}       # Bündelname -> (Stand, Bündel, ETag); Stand: VERSION, WEB und mtime/Größe von index.html und jeder Quelle


def _stand(datei: str) -> tuple:
    """(Name, mtime, Größe) einer Datei unter WEB, ohne sie zu lesen. Fehler: ValueError außerhalb der Oberfläche, OSError, wenn sie fehlt."""
    st = os.stat(os.path.join(WEB, buendel.sicherer_name(datei)))
    return datei, st.st_mtime_ns, st.st_size


def buendel_der_oberflaeche(name: str) -> tuple:
    """-> (Bündel name aus den Dateien, die index.html unter WEB nennt, ETag). Gebaut wird nur, wenn sich eine der Dateien geändert hat:
    Sonst kostete jeder Abruf (auch ein 304) das Lesen von rund 55 Dateien. Fehler: Fehler 404, wenn eine fehlt oder außerhalb liegt."""
    try:
        kopf = (VERSION, WEB, _stand("index.html"))
        liste = _BUENDEL_MERKER.get("index.html")
        if liste is None or liste[0] != kopf:
            liste = (kopf, buendel.bestandteile(_datei_lesen(os.path.join(WEB, "index.html")).decode("utf-8")))
            _BUENDEL_MERKER["index.html"] = liste
        dateien = liste[1][name]
        stand = (kopf, tuple(map(_stand, dateien)))
        gemerkt = _BUENDEL_MERKER.get(name)
        if gemerkt is None or gemerkt[0] != stand:
            daten = buendel.buendel(name, dateien, lambda datei: _datei_lesen(os.path.join(WEB, datei)))
            gemerkt = (stand, daten, f'"{VERSION}-{hashlib.sha256(daten).hexdigest()[:16]}"')
            _BUENDEL_MERKER[name] = gemerkt
        return gemerkt[1], gemerkt[2]
    except (OSError, ValueError):
        raise Fehler("Nicht gefunden", 404) from None


def mit_kennung(html: str) -> str:
    """Hängt an jede Datei der Liste in index.html (Skripte und Stile, auch in Unterordnern) die Versions-Kennung ?v=<VERSION>.
    Jede braucht sie: Nur mit Kennung darf der Browser die Datei behalten, und nur so lädt eine neue Version alle Dateien neu."""
    html = buendel.SKRIPT.sub(lambda treffer: f'<script src="{treffer[1]}?v={VERSION}"></script>', html)
    return buendel.STIL.sub(lambda treffer: f'<link rel="stylesheet" href="{treffer[1]}?v={VERSION}">', html)


class Handler(OberflaecheRouten, ExportRouten, BerichtRouten, ZeitenRouten, UrlaubRouten, SicherungRouten, SyncRouten, AblageRouten, EinstellungenRouten, BaseHTTPRequestHandler):
    """Verarbeitet die HTTP-Anfragen der App: Oberfläche, JSON-Schnittstelle und Ablage. Die Klassenwerte steuern die Fassung
        (z. B. „nur_ablage“, „fern“, erlaubte Hosts, Zugangsgeheimnis)."""
    db: Db = None
    demo_db: Db = None
    demo_pfad: str = "/tmp/zeiterfassung-demo.db"
    daten_ordner: str = ""
    nur_ablage: bool = False                               # True nur auf dem freigegebenen Anschluss (freigabe_schalten): Dort gibt es allein die Ablage
    fern: bool = False                                     # True nur auf dem Anschluss der freigegebenen Oberfläche (oberflaeche_schalten): das eigene Handy bedient die Desktop-Fassung
    erlaubte_hosts: frozenset = frozenset()                # leer = nur IP-Adressen und localhost (siehe _host_pruefen)
    antworten: dict = {}                                   # gemerkte JSON-Antworten je Dienst (Schlüssel enthält Datenstand, Regelstand und Datum)
    gepackt: dict = {}                                     # gepackte Fassungen gemerkter Antworten und der Dateien der Oberfläche (gleiche Schlüssel)
    protocol_version = "HTTP/1.1"
    server_version = "Zeiterfassung"                       # keine Python-Version in der Server-Kopfzeile
    sys_version = ""
    timeout = 120                                          # hängende Verbindungen blockieren keinen Thread auf Dauer

    def log_message(self, fmt, *args):
        """Schreibt kein Zugriffsprotokoll."""
        pass

    def send_error(self, code, message=None, explain=None):
        """Fehler, die http.server selbst meldet (fremde Methode, kaputte Anfragezeile, zu lange Adresse): kurz, als JSON und mit den Schutz-Kopfzeilen
        statt der englischen HTML-Seite der Standardbibliothek."""
        daten = json.dumps({"fehler": FREMDE_ANFRAGE}).encode()
        self.close_connection = True
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(daten)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            for k, v in SCHUTZ_KOPF.items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(daten)
        except OSError:                                        # Gegenstelle ist schon weg
            pass

    def _senden(self, status, daten, typ="application/json; charset=utf-8", kopf=None, merk=None):
        """merk: Schlüssel, unter dem die gepackte Fassung gemerkt wird (enthält den Stand der Daten bzw. der Datei, veraltet also nie)."""
        if not isinstance(daten, (bytes, bytearray)):
            daten = json.dumps(daten, ensure_ascii=False).encode("utf-8")
        kopf = dict(kopf or {})
        komprimierbar = typ.startswith(("text/", "application/json", "application/javascript", "image/svg", "application/manifest", "application/wasm")) or "javascript" in typ
        if komprimierbar and len(daten) > 800 and "gzip" in (self.headers.get("Accept-Encoding") or ""):
            gepackt = self.gepackt.get(merk) if merk is not None else None
            if gepackt is None:
                gepackt = gzip.compress(daten, 6, mtime=0)
                if merk is not None:
                    if len(self.gepackt) > 400:
                        self.gepackt.clear()
                    self.gepackt[merk] = gepackt
            daten = gepackt
            kopf["Content-Encoding"] = "gzip"
        self.send_response(status)
        self.send_header("Content-Type", typ)
        self.send_header("Vary", "Accept-Encoding")
        self.send_header("X-Version", VERSION)               # ein noch offener Tab erkennt daran, dass sein Skript veraltet ist
        self.send_header("Content-Length", str(len(daten)))
        self.send_header("Cache-Control", kopf.pop("Cache-Control", "no-store"))
        for k, v in SCHUTZ_KOPF.items():
            # Das App-Symbol darf eine andere Seite im eigenen Netz anzeigen (z. B. eine Startseite); alles andere bleibt same-origin.
            if k == "Cross-Origin-Resource-Policy" and typ.startswith("image/") and status == 200:
                v = "cross-origin"
            self.send_header(k, v)
        ohne_csp = kopf.pop("ohne-csp", False)          # nur ein Merker für diese Stelle, keine Kopfzeile
        if typ.startswith("text/html") and not ohne_csp:
            self.send_header("Content-Security-Policy", CSP)
        for k, v in kopf.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(daten)

    def _demo_db(self):
        """Die Demo-Datenbank (gemeinsam für alle Anschlüsse); wird bei Bedarf angelegt oder neu befüllt."""
        h = next(k for k in type(self).__mro__ if "demo_pfad" in k.__dict__)      # die freigegebenen Anschlüsse teilen sich die Demo-Datenbank mit dem Hauptanschluss
        with _DEMO_SCHLOSS:
            if h.demo_db is None:
                h.demo_db = Db(h.demo_pfad)
            if not h.demo_db.tage_alle() or not demo.passt(h.demo_db):      # leer, oder die Regeln (Profil) haben sich seit dem Befüllen geändert
                demo.zuruecksetzen(h.demo_db)
            return h.demo_db

    def _koerper_lesen(self):
        """Den Anfragekörper ganz abholen, nach Pfad-, Host- und Zugangsprüfung und vor allem anderen. Zwei Gründe: Ein Rest in der Verbindung würde als nächste
        Anfrage gelesen, und ein langsamer oder abgebrochener Upload darf nicht innerhalb der Schreibsperre auf Daten warten.
        Erst nach den Prüfungen, damit ein Gerät ohne Zugang keine 8 MB in den Speicher schieben und keinen Thread warten lassen kann.
        Was sich nicht sauber abholen lässt (zu groß, in Stücken, unvollständig), beendet die Verbindung."""
        self.close_connection = True                         # gilt, bis der Körper vollständig gelesen ist
        if self.headers.get("Transfer-Encoding"):
            raise Fehler("Transfer-Encoding wird nicht unterstützt")
        laengen = self.headers.get_all("Content-Length") or ["0"]
        laenge = laengen[0].strip(" \t")
        if len(laengen) > 1 or not re.fullmatch(r"[0-9]{1,9}", laenge):   # zwei Angaben oder „+5“/„0_5“ (nähme int() an): ein Proxy davor sähe die Grenze der Anfrage anders
            raise Fehler("Ungültige Content-Length")
        n = int(laenge)
        if n > MAX_BODY:
            raise Fehler("Anfrage zu groß (höchstens 8 MB)", 413)
        koerper = self.rfile.read(n) if n else b""
        if len(koerper) < n:
            raise ConnectionError("Anfrage unvollständig")
        self._koerper = koerper
        self.close_connection = self._verbindung_schliessen

    def _ungelesenes_verwerfen(self):
        """Nach einer Ablehnung vor dem Lesen des Körpers (sanftes Schließen): Liegt der Körper noch ungelesen im Empfangspuffer, schickt das System beim
        Schließen ein RST (unter Windows sicher zu sehen), und die Gegenseite verliert die schon gesendete Antwort. Deshalb erst die Senderichtung schließen, dann höchstens
        NACHLESEN_HOECHSTENS Bytes in NACHLESEN_FRIST abholen und verwerfen, stückweise: Ein Gerät ohne Zugang hält so weder Speicher noch länger als die Frist einen Thread."""
        ende = time.monotonic() + NACHLESEN_FRIST
        gelesen = 0
        try:
            self.connection.shutdown(socket.SHUT_WR)
            while gelesen < NACHLESEN_HOECHSTENS and (rest := ende - time.monotonic()) > 0:
                self.connection.settimeout(rest)
                stueck = self.connection.recv(min(16384, NACHLESEN_HOECHSTENS - gelesen))
                if not stueck:
                    break
                gelesen += len(stueck)
        except OSError:                                      # Gegenseite schon weg oder Frist um: nichts mehr zu retten
            pass

    def _body(self):
        """Der Anfragekörper als JSON-Objekt. Fehler 400 bei ungültigem JSON, Nicht-Objekt oder unendlichen Zahlen."""
        try:                                                 # NaN, Infinity und 1e999 liest Python als Zahl; beim Umrechnen würde daraus ein interner Fehler
            d = json.loads(self._koerper or b"{}", parse_float=_endliche_zahl, parse_constant=_keine_konstante)
        except (ValueError, RecursionError):                 # RecursionError: zu tief verschachtelt
            raise Fehler("Ungültiges JSON")
        if not isinstance(d, dict):
            raise Fehler("JSON-Objekt erwartet")
        return d

    def _host_pruefen(self):
        """Gegen DNS-Rebinding: Eine fremde Seite, deren Name per DNS auf diesen Rechner zeigt, käme sonst als „eigene Seite“ an die Daten.
        Mit Liste (HO_HOSTS) gilt nur die Liste, ohne Liste nur IP-Adressen und localhost; Namen (z. B. des Proxys) gehören in die Liste.
        Ausnahme: Die Browser-Fassung hat keinen Anschluss im Netz. Fehler 421 sonst."""
        host = (self.headers.get("Host") or "").strip().lower()
        meldung = NAME_EINTRAGEN if plattform() == "server" else UNBEKANNTE_ADRESSE    # nur auf dem Server kann die Person HO_HOSTS selbst setzen
        if self.erlaubte_hosts and host not in self.erlaubte_hosts:
            raise Fehler(meldung, 421)
        if (self.nur_ablage or self.fern) and not _ist_ip(host):
            raise Fehler(UNBEKANNTE_ADRESSE, 421)
        if not self.erlaubte_hosts and plattform() != "browser" and not _ist_ip(host) and not _ist_localhost(host):
            raise Fehler(meldung, 421)
        if self.fern and host != self._eigene_adresse():     # das Zugangs-Cookie hängt am Host-Kopf: nur die Adresse, die diese Anfrage wirklich erreicht hat
            raise Fehler(UNBEKANNTE_ADRESSE, 421)

    def _eigene_adresse(self) -> str:
        """Adresse und Anschluss, über die diese Verbindung angekommen ist (IPv6 in eckigen Klammern)."""
        ip, port = self.connection.getsockname()[:2]
        return (f"[{ip}]" if ":" in ip else ip).lower() + f":{port}"

    def _zugang_wert(self) -> str:
        """Wert des Zugangs-Cookies. Am Handy (Anschluss der freigegebenen Oberfläche) an Adresse und Anschluss gebunden: Browser trennen Cookies
        nicht nach Anschluss, das Handy schickt es an jeden Dienst unter dieser IP, auch an ein Gerät, das später die IP bekommt."""
        if not self.fern:
            return self.zugang
        host = (self.headers.get("Host") or "").strip().lower()
        return hmac.new(self.zugang.encode(), host.encode(), hashlib.sha256).hexdigest()

    def _zugang_pruefen(self, methode: str, pfad: str) -> bool:
        """Nur lokale Fassungen (Desktop, Handy): Der Dienst lauscht zwar nur im eigenen Gerät, dort erreicht ihn aber jedes Programm. Deshalb gilt
        je Start ein Zugangsgeheimnis: Die Hülle gibt es dem eigenen Fenster als Cookie mit; ohne das Cookie gibt es nichts, auch nicht die Oberfläche.
        Einstieg ohne Cookie: GET /?z=<Geheimnis> setzt es und leitet auf / um (so öffnet der Desktop-Starter sein Fenster). -> True, wenn umgeleitet wurde."""
        if not self.zugang:
            return False
        erwartet = self._zugang_wert()
        kekse = [c.strip().partition("=") for c in (self.headers.get("Cookie") or "").split(";")]
        if any(name == ZUGANG_COOKIE and hmac.compare_digest(wert.encode(), erwartet.encode()) for name, _, wert in kekse):
            return False
        if methode == "GET" and pfad == "/" and hmac.compare_digest(self.path.partition("?")[2].encode(), ("z=" + self.zugang).encode()):
            self.send_response(303)
            self.send_header("Location", "/")
            self.send_header("Set-Cookie", f"{ZUGANG_COOKIE}={erwartet}; Path=/; HttpOnly; " + (f"Max-Age={FERN_COOKIE_DAUER}; SameSite=Lax" if self.fern else "SameSite=Strict"))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", "0")
            for k, v in SCHUTZ_KOPF.items():
                self.send_header(k, v)
            self.end_headers()
            return True
        raise Fehler("Kein Zugang", 403)

    def _herkunft_pruefen(self):
        """Schreibzugriffe nur von der eigenen Seite. Eine fremde Webseite kann ohne Rückfrage des Browsers nur „einfache“ Anfragen schicken
        (kein application/json); der Browser meldet außerdem, ob die Anfrage von einer fremden Seite kommt (Sec-Fetch-Site, sonst Origin)."""
        if (self.headers.get("Content-Type") or "").split(";")[0].strip().lower() != "application/json":
            raise Fehler("Content-Type application/json erwartet", 415)
        sfs = (self.headers.get("Sec-Fetch-Site") or "").lower()
        if sfs:
            if sfs not in ("same-origin", "none"):
                raise Fehler("Anfrage von einer fremden Seite abgelehnt", 403)
            return
        herkunft = self.headers.get("Origin")
        if herkunft:
            host = herkunft.split("://", 1)[-1].lower()
            eigene = {(self.headers.get(k) or "").split(",")[0].strip().lower() for k in ("Host", "X-Forwarded-Host")} - {""}
            if host not in eigene:
                raise Fehler("Anfrage von einer fremden Seite abgelehnt", 403)

    def _bearbeiten(self, methode):
        """Gemeinsamer Ablauf für GET, PUT, POST und DELETE: Pfad, Host und Zugang prüfen, dann Körper lesen, Herkunft prüfen, Route ausführen, Antwort senden.
            Fehler werden als JSON gemeldet: Eingabefehler mit ihrem Status, Speicherfehler als 503, Unerwartetes als 500 (Details nur im Protokoll)."""
        pfad = self.path.split("?")[0]
        self._verbindung_schliessen = self.close_connection     # was die Anfrage selbst verlangt (Connection: close)
        self.close_connection = True                             # bis der Körper gelesen ist: Eine Ablehnung davor lässt ihn ungelesen, er darf nie als nächste Anfrage gelten
        self._koerper = None                                     # None = Körper dieser Anfrage noch nicht gelesen
        # Freigabe aus: Eine offene Keep-alive-Verbindung behält keinen Zugriff, auch nicht, solange shutdown() noch auf die Schleife des Dienstes wartet
        if (self.nur_ablage and self.server is not anschluesse._freigabe["dienst"]) or (self.fern and self.server is not anschluesse._oberflaeche["dienst"]):
            return
        try:
            if self.nur_ablage and pfad != "/api/ablage" and not pfad.startswith("/api/ablage/"):
                raise Fehler("Nicht gefunden", 404)
            self._host_pruefen()
            if self._zugang_pruefen(methode, pfad):
                return
            self._koerper_lesen()
            if methode == "GET" and not pfad.startswith("/api/") and pfad != "/health":
                return self._statisch(pfad)
            if methode != "GET":
                self._herkunft_pruefen()
            g = re.match(r"/api/(?:monat|monatsnachweis|woche|jahr|horest|urlaub|krank|steuer|kalender|feiertage|gleitzeit/verlauf|kappung)/(\d{4})", pfad)
            if g:
                _jahr(g[1])
            merk = None
            if methode == "GET" and pfad not in NICHT_MERKEN and not pfad.startswith(NICHT_MERKEN_ANFANG):
                h = self.__class__
                demo_an = any(c.strip() == "ho_demo=1" for c in (self.headers.get("Cookie") or "").split(";"))
                merk = (pfad, demo_an, self.db.gen, h.demo_db.gen if h.demo_db else -1, konfig.regelstand_nr(), date.today())
                if merk in h.antworten:
                    return self._senden(200, h.antworten[merk], merk=merk)
            r = self._route(methode, pfad) if methode == "GET" else self._schreiben(methode, pfad)
            if r is not None:
                daten = json.dumps(r, ensure_ascii=False).encode("utf-8")
                if merk and merk[2] == self.db.gen:
                    if len(self.antworten) > 400:
                        self.antworten.clear()
                    self.antworten[merk] = daten
                    return self._senden(200, daten, merk=merk)
                self._senden(200, daten)
        except Fehler as e:
            antwort = {"fehler": str(e), **({"kennung": e.kennung} if e.kennung else {})}
            if self._koerper is not None:
                return self._senden(e.status, antwort)
            self._senden(e.status, antwort, kopf={"Connection": "close"})     # die Gegenseite schickt auf dieser Verbindung nichts mehr nach
            self._ungelesenes_verwerfen()
        except (ConnectionError, TimeoutError):               # die Gegenseite hat die Verbindung beendet: nichts zu melden
            self.close_connection = True
        except (sqlite3.Error, OSError) as e:  # Datenbank beschädigt oder gesperrt, Speicher voll: klare Meldung, Details nur ins Protokoll
            print(f"Speicherfehler bei {methode} {pfad}: {e!r}", flush=True)
            self.close_connection = True
            self._senden(503, {"fehler": SPEICHERFEHLER_LESEN if methode == "GET" else SPEICHERFEHLER_SCHREIBEN})
        except Exception as e:  # unerwartet: Details nur ins Protokoll, nicht an den Browser
            print(f"Fehler bei {methode} {pfad}: {e!r}\n{traceback.format_exc()}", flush=True)
            self.close_connection = True
            if methode != "GET" and isinstance(e, (ValueError, TypeError, KeyError)):
                self._senden(400, {"fehler": UNGUELTIGE_EINGABE})
            else:
                self._senden(500, {"fehler": INTERNER_FEHLER})

    def _schreiben(self, methode: str, pfad: str):
        """Schreibzugriffe nacheinander: Prüfen und Speichern gehören zusammen (z. B. Höchstzahl der Gleittage). Schlösser in der festen Reihenfolge
        erst sync._SCHLOSS, dann db.lock (wie die Automatik). Die Synchronisierung und die Werkseinstellungen (NUR_SYNC_SCHLOSS) nehmen hier nur _SCHLOSS:
        Ihre Netz-Zugriffe halten keine Lese- und Schreibzugriffe auf; die Werkseinstellungen nehmen db.lock danach selbst. EIGENES_SCHLOSS braucht kein db.lock (eigenes Schloss in der Route).
        Rückgabe wie _route."""
        if pfad == "/api/abgleich" or pfad.startswith("/api/abgleich/") or pfad in NUR_SYNC_SCHLOSS:
            with sync._SCHLOSS:
                return self._route(methode, pfad)
        if pfad in UNTER_SYNC_SCHLOSS:
            with sync._SCHLOSS, self.db.lock:
                return self._route(methode, pfad)
        if pfad in EIGENES_SCHLOSS:
            return self._route(methode, pfad)
        with self.db.lock:
            return self._route(methode, pfad)

    def _route(self, m, p):
        """Die Schnittstelle: ordnet Methode „m“ und Pfad „p“ der passenden Aktion zu und gibt die JSON-Antwort zurück (None, wenn schon gesendet).
            Wählt die Demo-Datenbank, wenn das Demo-Cookie gesetzt ist. Unbekannte Pfade ergeben Fehler 404."""
        cookies = dict(c.strip().split("=", 1) for c in (self.headers.get("Cookie") or "").split(";") if "=" in c)
        design.setze("#" + cookies.get("ho_akzent_hex", "").lstrip("#"))                 # Akzentfarbe der Oberfläche für die Exportdateien
        demo_an = any(c.strip() == "ho_demo=1" for c in (self.headers.get("Cookie") or "").split(";"))
        db = self._demo_db() if demo_an else self.db
        for gruppe in (self._routen_oberflaeche, self._routen_export, self._routen_bericht, self._routen_zeiten, self._routen_urlaub,
                       self._routen_sicherung, self._routen_sync, self._routen_ablage, self._routen_einstellungen):
            r = gruppe(m, p, db, demo_an)
            if r is not NICHT_ZUSTAENDIG:
                return r
        raise Fehler("Nicht gefunden", 404)

    def _ziel(self):
        """Das Ziel für Sicherung und Synchronisierung: auf dem Server dessen eigene Ablage, sonst das Ziel des Handys oder aus der Umgebung."""
        if plattform() == "server" and not self.handy_ziel:   # der Server ist selbst die Ablage: Ordner „sync“ in seinen Daten
            return ablage_des_servers(self.daten_ordner)
        return self.handy_ziel or sicherung.ziel_aus_umgebung(self.daten_ordner)

    def _statisch(self, pfad):
        """Liefert eine Datei der Oberfläche (mit ETag und gepackt, wenn möglich). Pfade mit Nullzeichen oder Rückwärtsstrich und unbekannte Dateien ergeben 404."""
        if pfad in ("", "/"):
            pfad = "/index.html"
        if "\x00" in pfad or "\\" in pfad:
            raise Fehler("Nicht gefunden", 404)
        if pfad == "/mobil" and plattform() == "server":       # ohne den Schrägstrich am Ende stimmen die Adressen in der Seite nicht: umleiten
            self.send_response(301)
            self.send_header("Location", "/mobil/")
            self.send_header("Content-Length", "0")
            for k, v in SCHUTZ_KOPF.items():
                self.send_header(k, v)
            self.end_headers()
            return
        # /mobil/: die Web-App ohne Server (fürs iPhone), wenn ihr Bau neben der App liegt. Sie bringt ihre eigene Sicherheitsrichtlinie mit (Rechenkern als WebAssembly).
        mobil = pfad.startswith("/mobil/") and plattform() == "server"
        wurzel = WEBAPP if mobil else WEB
        if mobil:
            pfad = pfad[len("/mobil"):]
            if pfad == "/":
                pfad = "/index.html"
        daten = None
        if not mobil and pfad.lstrip("/") in buendel.NAMEN:            # entsteht im Speicher; der ETag folgt dem Inhalt, nicht einer Datei
            daten, etag = buendel_der_oberflaeche(pfad.lstrip("/"))
        else:
            voll = os.path.normpath(os.path.join(wurzel, pfad.lstrip("/")))
            if not voll.startswith(wurzel + os.sep) or not os.path.isfile(voll):    # bleibt immer im Ordner web (kein ../, keine absoluten Pfade)
                raise Fehler("Nicht gefunden", 404)
            liste = None if mobil else web_liste()
            if liste is not None and os.path.relpath(voll, wurzel).replace(os.sep, "/") not in liste:   # Rest eines alten Ordners oder abgelegt
                raise Fehler("Nicht gefunden", 404)
            st = os.stat(voll)
            etag = f'"{VERSION}-{st.st_mtime_ns:x}-{st.st_size:x}"'
        typ = mimetypes.guess_type(pfad)[0] or "application/octet-stream"
        if pfad.endswith(".webmanifest"):
            typ = "application/manifest+json"
        # Skript und Gestaltung ruft die Seite mit der Versions-Kennung auf: so darf der Browser sie behalten, ohne nachzufragen.
        # Eine neue Version hat eine neue Adresse. Die Seite selbst und alles ohne (oder mit fremder) Kennung wird immer geprüft.
        fest = not mobil and pfad != "/index.html" and self.path.partition("?")[2] == f"v={VERSION}"
        behalten = "public, max-age=31536000, immutable" if fest else "no-cache"
        if self.headers.get("If-None-Match") == etag:                  # unverändert: nur 304, die Datei bleibt im Gerät
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", behalten)
            self.send_header("Content-Length", "0")
            for k, v in SCHUTZ_KOPF.items():
                if k == "Cross-Origin-Resource-Policy" and typ.startswith("image/"):
                    v = "cross-origin"
                self.send_header(k, v)
            self.end_headers()
            return
        if daten is None:
            daten = _datei_lesen(voll)
        if pfad == "/index.html" and not mobil:
            daten = mit_kennung(buendel.mit_buendel(daten.decode("utf-8"))).encode("utf-8")
        kopf = {"ETag": etag, "Cache-Control": behalten, **({"ohne-csp": True} if mobil else {})}
        self._senden(200, daten, typ + ("; charset=utf-8" if typ.startswith("text/") or typ.endswith("javascript") else ""), kopf, merk=("datei", mobil, pfad, etag))

    def do_GET(self):
        """GET-Anfrage."""
        self._bearbeiten("GET")

    def do_PUT(self):
        """PUT-Anfrage."""
        self._bearbeiten("PUT")

    def do_POST(self):
        """POST-Anfrage."""
        self._bearbeiten("POST")

    def do_DELETE(self):
        """DELETE-Anfrage."""
        self._bearbeiten("DELETE")


def _hosts(liste: str, port: int) -> frozenset:
    """„127.0.0.1:{port},localhost:{port}“ -> Menge der erlaubten Host-Angaben; {port} steht für den wirklich belegten Port."""
    return frozenset(h.strip().lower().replace("{port}", str(port)) for h in (liste or "").split(",") if h.strip())


def handler_erstellen(daten: str, zugang: str = ""):
    """Datenbank öffnen und die Bearbeitung der Anfragen daran binden, noch ohne Anschluss ans Netz -> (Handler-Klasse, Datenbank).
    Die Browser-Fassung (mobil/web) benutzt sie direkt, alle anderen über erstellen()."""
    os.makedirs(daten, exist_ok=True)                        # erster Start: der Datenordner entsteht von selbst
    alt, neu = os.path.join(daten, "homeoffice.db"), os.path.join(daten, "zeiterfassung.db")
    if os.path.exists(alt) and not os.path.exists(neu):      # Umbenennung 15.11.2026 (Projekt homeoffice -> zeiterfassung)
        os.rename(alt, neu)
    db = Db(neu, sicherung.geraet_lesen(daten)["geraet"])
    konfig.profile_aus_ordner(os.path.join(daten, konfig.PROFIL_ORDNER))   # weitere feste Profile (z. B. private); vor laden(): das Voreinstellungs-Profil gibt die Grundregeln
    konfig.laden(db)
    h = type("H", (Handler,), {"db": db, "demo_db": None, "demo_pfad": os.path.join(daten, "demo.db"), "daten_ordner": daten, "antworten": {}, "handy_ziel": None, "beenden": None, "zugang": zugang})
    return h, db


def erstellen(daten: str, port: int, host="127.0.0.1", hosts: str = "", zugang: str = ""):
    """hosts: erlaubte Host-Angaben (HO_HOSTS; Desktop und Handy nennen ihre eigene Adresse), leer = nur IP-Adressen und localhost.
    zugang: Zugangsgeheimnis der lokalen Fassungen (siehe Handler._zugang_pruefen), leer = keines (Server hinter dem eigenen Proxy)."""
    h, db = handler_erstellen(daten, zugang)
    httpd = Dienst((host, port), h)
    h.erlaubte_hosts = _hosts(hosts, httpd.server_address[1])
    if plattform() in MIT_ADRESSE and sicherung.geraet_lesen(daten).get("freigabe"):   # war beim letzten Mal an: wieder freigeben
        try:
            freigabe_schalten(h, True)
        except OSError:
            print("Freigabe: Anschluss belegt", flush=True)
    if plattform() == "desktop" and sicherung.geraet_lesen(daten).get("oberflaeche"):
        try:
            oberflaeche_schalten(h, daten, True)
        except OSError:
            print("Freigabe der Oberfläche: Anschluss belegt", flush=True)
    return httpd, db


SICHERUNG_UHRZEIT = (3, 10)                                 # Stunde, Minute der Nachtsicherung


def _sicherung_schleife(db: Db, daten: str, warten=time.sleep):
    """Jede Nacht eine Sicherung. Beim Start wird die von heute nachgeholt, wenn sie fehlt: Ein Neustart um die Sicherungszeit herum
    (Update, Stromausfall) ließ sie sonst ausfallen, weil die Schleife danach bis zur nächsten Nacht wartet."""
    try:
        tagessicherung(db, daten)
    except Exception as e:
        print("Sicherung fehlgeschlagen:", type(e).__name__, flush=True)
    while True:
        jetzt = datetime.now()
        ziel = jetzt.replace(hour=SICHERUNG_UHRZEIT[0], minute=SICHERUNG_UHRZEIT[1], second=0, microsecond=0)
        if ziel <= jetzt:
            ziel += timedelta(days=1)
        warten((ziel - jetzt).total_seconds())
        try:
            db.sicherung(os.path.join(daten, "sicherung"))
        except Exception as e:
            print("Sicherung fehlgeschlagen:", type(e).__name__, flush=True)


def tagessicherung(db: Db, daten: str) -> None:
    """Beim Start: Gibt es für heute noch keine Sicherung, die Datenbank jetzt in den Ordner „sicherung“ legen (die letzten sieben bleiben).
    Lokale Fassungen laufen nachts meist nicht; auf dem Server holt das eine Nachtsicherung nach, die wegen eines Neustarts ausfiel."""
    ordner = os.path.join(daten, "sicherung")
    stand = sicherung_stand(ordner)
    if db.tage_alle() and (stand is None or stand["datei"] != f"zeiterfassung-{date.today().isoformat()}.db"):
        db.sicherung(ordner)


HOST_ANGABE = re.compile(r"\[([^\]]+)\](?::[0-9]{1,5})?|([^:\[\]]+)(?::[0-9]{1,5})?")   # [IPv6]:Anschluss oder Name/IPv4:Anschluss


def _ist_ip(host: str) -> bool:
    """Ist die Host-Angabe (mit oder ohne Anschluss) eine IP-Adresse? Ein Name kann per DNS auf eine fremde Seite zeigen (DNS-Rebinding), eine IP nicht."""
    teile = HOST_ANGABE.fullmatch(host)
    if not teile:
        return False
    try:
        ipaddress.ip_address(teile.group(1) or teile.group(2))
        return True
    except ValueError:
        return False


def _ist_localhost(host: str) -> bool:
    """Ist die Host-Angabe (mit oder ohne Anschluss) „localhost“? Der Name zeigt immer auf das eigene Gerät."""
    teile = HOST_ANGABE.fullmatch(host)
    return bool(teile) and teile.group(2) == "localhost"


def _update_pruefen(daten: str, heute: date) -> None:
    """Fragt in der Windows- und der Android-App nach einer neuen Version, wenn es fällig ist (update.pruefen: alle 30 Tage, abschaltbar).
    Auf dem Server und in der Web-App nie. Ein Fehler hält die Automatik nicht an; ins Protokoll kommt nur seine Art."""
    if plattform() not in MIT_UPDATE_PRUEFUNG:
        return
    try:
        update.pruefen(daten, heute)
    except Exception as e:
        print("Update-Prüfung:", type(e).__name__, flush=True)


def _lokale_automatik(db: Db, daten: str, halt: threading.Event, abstand: float = 60.0, ziel_holen=None):
    """Sicherung (Handy), Update-Prüfung (nur Windows- und Android-App) und Synchronisierung im Hintergrund, alle „abstand“ Sekunden, bis halt gesetzt ist.
    Jeder Durchgang gleicht zuerst den Anschluss 8793 an das Netz an (anschluesse.freigabe_angleichen; im Container wirkungslos, dort gibt es
    keinen gemerkten Handler). Solange ein Rückgängig offen ist, wartet die Synchronisierung (nicht die Sicherung am Handy).
    ziel_holen: liefert das Ziel für Sicherung und Synchronisierung (Vorgabe: Ordner aus der Umgebung bzw. aus geraet.json)."""
    gesichert, abgeglichen, netz, frei, github = -1, (-1, None), (-1, None), (-1, None), (-1, None)
    erg = []

    def schritt(*a):                                         # merkt sich die Ergebnisse eines Durchgangs: Nach dem letzten Sync (Modul aus) ist Schluss
        """Führt einen Schritt der Automatik aus und merkt sich das Ergebnis der Synchronisierung."""
        r = sync.automatik_schritt(*a)
        if r[1] is not None:
            erg.append(r[1])
        return r
    ziel_holen = ziel_holen or (lambda: sicherung.ziel_aus_umgebung(daten))
    while not halt.wait(abstand):
        try:
            anschluesse.freigabe_angleichen(daten)              # ohne Schloss: Netzwechsel bei laufender App (Ruhezustand, Café), Start vor dem WLAN
            ziel, jetzt = ziel_holen(), datetime.now()
            erg.clear()
            if plattform() == "android":
                gesichert, _ = sicherung.automatik_schritt(db, daten, ziel, jetzt, gesichert)
            _update_pruefen(daten, jetzt.date())
            if rueckgaengig.offen(db):                           # kein Stand geht hinaus, den die Person Sekunden später zurücknimmt
                continue
            abgeglichen, _ = schritt(db, daten, ziel, jetzt, abgeglichen)
            if db.gen != netz[0] or netz[1] is None or jetzt - netz[1] >= sync.AUTOMATIK_ABSTAND:     # eigener Server (Desktop), wenn eingetragen und erreichbar
                erreichbar = netz_ziel(daten)
                netz = schritt(db, daten, erreichbar, jetzt, netz)[0] if erreichbar is not None else (db.gen, jetzt)   # nicht da: erst nach dem Abstand wieder fragen
            if db.gen != github[0] or github[1] is None or jetzt - github[1] >= sync.AUTOMATIK_ABSTAND:     # GitHub, wenn verbunden, eingeschaltet und erreichbar
                erreichbar = github_ziel(daten, pruefen=True) if sicherung.geraet_lesen(daten)["abgleich_auto"] else None
                github = schritt(db, daten, erreichbar, jetzt, github)[0] if erreichbar is not None else (db.gen, jetzt)
            if freigabe_an(daten):                               # dieses Gerät ist selbst Speicherort: die Dateien der anderen lesen, die eigene hinlegen
                frei, _ = schritt(db, daten, eigene_ablage(daten), jetzt, frei)
            if erg and all(e.get("ok") for e in erg) and sync.letzter_offen(daten):
                sync.abmelden(daten)                         # die anderen Geräte haben das Abschalten jetzt vorliegen
        except Exception as e:                               # die Automatik darf die App nie anhalten
            print("Automatik:", type(e).__name__, flush=True)


if __name__ == "__main__":
    daten = os.environ.get("HO_DATEN", "/data")
    port = int(os.environ.get("PORT", "8000"))
    httpd, db = erstellen(daten, port, os.environ.get("HOST", "0.0.0.0"), os.environ.get("HO_HOSTS", ""))
    if not httpd.RequestHandlerClass.erlaubte_hosts:
        print(HOSTS_LEER, flush=True)
    threading.Thread(target=_sicherung_schleife, args=(db, daten), daemon=True).start()
    # lokale Fassungen: Sync über den Cloud-Ordner, am Handy zusätzlich die verschlüsselte Sicherung. Server: Sync mit seiner eigenen Ablage.
    threading.Thread(target=_lokale_automatik, args=(db, daten, threading.Event()), kwargs={"ziel_holen": (lambda: ablage_des_servers(daten)) if plattform() == "server" else None}, daemon=True).start()
    print(f"Zeiterfassung-App läuft auf Port {port}, Daten in {daten}", flush=True)
    httpd.serve_forever()
